# NaviWriter Development Archive

This folder contains older progress versions of NaviWriter from V1 through V26.

There is no V27. The version number was skipped because I did not like that number. This is not a bug. This is lore.

These builds are preserved for historical/reference purposes only. The recommended version is the latest release build.