// js/tiptap-adapter.js
// Optional Tiptap adapter for NaviWriter.
// Uses CDN imports. If imports fail, NaviWriter falls back to contenteditable.

let Editor = null;
let StarterKit = null;
let ImageExtension = null;
let TableKit = null;
let TextStyle = null;
let Color = null;
let Highlight = null;
let Underline = null;
let FontFamily = null;
let Extension = null;
let FontSize = null;
let NaviImage = null;
let tiptapEditor = null;
let suppressTiptapUpdate = false;

function clearTiptapMountElement(element) {
  if (!element) return;

  /*
    Important:
    The browser can restore old contenteditable DOM on reload.
    Tiptap then mounts its own ProseMirror tree inside the same element.
    Clearing the mount element prevents ghost/duplicate visual content.
  */
  element.innerHTML = '';

  /*
    Tiptap manages editing through its own ProseMirror element.
    Leaving contenteditable on the outer article can invite browser
    restoration weirdness.
  */
  element.removeAttribute('contenteditable');
}

function removeTiptapGhostNodes(element) {
  if (!element) return;

  const proseMirror = element.querySelector('.ProseMirror');

  if (!proseMirror) return;

  Array.from(element.childNodes).forEach(node => {
    if (node === proseMirror) return;

    if (
      node.nodeType === Node.ELEMENT_NODE &&
      node.contains(proseMirror)
    ) {
      return;
    }

    node.remove();
  });
}

function setEngineStatus(text, className) {
  const el = document.getElementById('engineStatus');

  if (!el) return;

  el.textContent = text;
  el.classList.remove('engine-tiptap', 'engine-fallback', 'engine-error');

  if (className) {
    el.classList.add(className);
  }
}

window.NaviTiptapReady = (async () => {
  try {
    const [
  CoreModule,
  StarterKitModule,
  ImageModule,
  TableModule,
  TextStyleModule,
  ColorModule,
  HighlightModule,
      UnderlineModule,
FontFamilyModule
] = await Promise.all([
  import('https://esm.sh/@tiptap/core@3.27.3'),
  import('https://esm.sh/@tiptap/starter-kit@3.27.3'),
  import('https://esm.sh/@tiptap/extension-image@3.27.3'),
  import('https://esm.sh/@tiptap/extension-table@3.27.3'),
  import('https://esm.sh/@tiptap/extension-text-style@3.27.3'),
  import('https://esm.sh/@tiptap/extension-color@3.27.3'),
  import('https://esm.sh/@tiptap/extension-highlight@3.27.3'),
  import('https://esm.sh/@tiptap/extension-underline@3.27.3'),
import('https://esm.sh/@tiptap/extension-font-family@3.27.3')
]);

Editor = CoreModule.Editor;
StarterKit = StarterKitModule.default;
ImageExtension = ImageModule.default;

TableKit =
  TableModule.TableKit ||
  TableModule.default ||
  null;

TextStyle =
  TextStyleModule.TextStyle ||
  TextStyleModule.default ||
  null;

Color =
  ColorModule.Color ||
  ColorModule.default ||
  null;

Highlight =
  HighlightModule.Highlight ||
  HighlightModule.default ||
  null;
    
Extension =
  CoreModule.Extension || null;

Underline =
  UnderlineModule.Underline ||
  UnderlineModule.default ||
  null;

FontFamily =
  FontFamilyModule.FontFamily ||
  FontFamilyModule.default ||
  null;

    if (Extension && TextStyle) {
  FontSize =
    Extension.create({
      name: 'fontSize',

      addOptions() {
        return {
          types: ['textStyle']
        };
      },

      addGlobalAttributes() {
        return [
          {
            types: this.options.types,
            attributes: {
              fontSize: {
                default: null,
                parseHTML: element => {
                  return element.style.fontSize || null;
                },
                renderHTML: attributes => {
                  if (!attributes.fontSize) {
                    return {};
                  }

                  return {
                    style: `font-size: ${attributes.fontSize}`
                  };
                }
              }
            }
          }
        ];
      },

      addCommands() {
        return {
          setFontSize:
            fontSize =>
            ({ chain }) => {
              return chain()
                .setMark('textStyle', {
                  fontSize
                })
                .run();
            },

          unsetFontSize:
            () =>
            ({ chain }) => {
              return chain()
                .setMark('textStyle', {
                  fontSize: null
                })
                .removeEmptyTextStyle()
                .run();
            }
        };
      }
    });
}


console.log('Tiptap loaded extensions:', {
  hasTextStyle: Boolean(TextStyle),
  hasColor: Boolean(Color),
  hasHighlight: Boolean(Highlight),
  hasTableKit: Boolean(TableKit),
  hasImage: Boolean(ImageExtension)
});

    Editor = CoreModule.Editor;
    StarterKit = StarterKitModule.default;
    ImageExtension = ImageModule.default;
    TextStyle = TextStyleModule.default;
Color = ColorModule.default;
Highlight = HighlightModule.default;

    /*
      TableKit is available in newer Tiptap builds.
      If esm.sh gives us only default/other exports, this fallback keeps the app from exploding.
    */
    TableKit =
      TableModule.TableKit ||
      TableModule.default ||
      null;

    NaviImage = ImageExtension.extend({
      addAttributes() {
        const parentAttributes =
          this.parent ? this.parent() : {};

        return {
          ...parentAttributes,

          width: {
            default: null,

            parseHTML: element => {
              return (
                element.getAttribute('data-width') ||
                element.getAttribute('width') ||
                element.style.width ||
                null
              );
            },

            renderHTML: attributes => {
              const baseAttributes = {
                class: 'navi-editor-image'
              };

              if (!attributes.width) {
                return {
                  ...baseAttributes,
                  style: 'max-width: 100%; height: auto;'
                };
              }

              return {
                ...baseAttributes,
                'data-width': attributes.width,
                style: `width: ${attributes.width}; max-width: 100%; height: auto;`
              };
            }
          }
        };
      }
    });

    window.NaviTiptap = {
      initTiptapEditor,
      getEditor,
      getHtml,
      getText,
      setHtml,
      focus,
      run,
      insertImage,
      updateImageWidthBySrc
    };

    console.log('NaviTiptap loaded successfully.');

    return true;
  } catch (error) {
    console.warn(
      'NaviTiptap failed to load. Falling back to contenteditable.',
      error
    );

    window.NaviTiptap = null;

    setEngineStatus('Engine: fallback editor', 'engine-fallback');

    return false;
  }
})();

function initTiptapEditor({
  element,
  content = '<p></p>',
  onChange
} = {}) {
  if (!element) {
    console.warn('NaviTiptap: missing editor element.');
    setEngineStatus('Engine: fallback editor', 'engine-fallback');
    return null;
  }

  if (!Editor || !StarterKit) {
    console.warn('NaviTiptap: editor modules are not loaded.');
    setEngineStatus('Engine: fallback editor', 'engine-fallback');
    return null;
  }

  if (tiptapEditor) {
  tiptapEditor.destroy();
  tiptapEditor = null;
}

clearTiptapMountElement(element);

const extensions = [
  StarterKit
];

if (TextStyle) {
  extensions.push(TextStyle);
}

if (FontFamily && TextStyle) {
  extensions.push(FontFamily);
}

if (FontSize) {
  extensions.push(FontSize);
}

if (Underline) {
  extensions.push(Underline);
}

if (Color) {
  extensions.push(Color);
}

if (Highlight) {
  extensions.push(
    Highlight.configure({
      multicolor: true
    })
  );
}

  if (NaviImage) {
    extensions.push(
      NaviImage.configure({
        inline: false,
        allowBase64: true,
        HTMLAttributes: {
          class: 'navi-editor-image'
        }
      })
    );
  }

  if (TableKit) {
    extensions.push(
      TableKit.configure({
        table: {
          resizable: true
        }
      })
    );
  }

tiptapEditor = new Editor({
  element,
  extensions,
  content: content || '<p></p>',

  onUpdate({ editor }) {
    if (suppressTiptapUpdate) {
      return;
    }

    if (window.NaviWriterIsLoadingDocument) {
      return;
    }

    if (typeof onChange === 'function') {
      onChange(
        editor.getHTML(),
        editor.getText()
      );
    }
  }
});

setTimeout(() => {
  removeTiptapGhostNodes(element);
}, 0);

setEngineStatus('Engine: Tiptap', 'engine-tiptap');

return tiptapEditor;
  
}

function getEditor() {
  return tiptapEditor;
}

function getHtml() {
  return tiptapEditor
    ? tiptapEditor.getHTML()
    : '';
}

function getText() {
  return tiptapEditor
    ? tiptapEditor.getText()
    : '';
}

function setHtml(html = '<p></p>') {
  if (!tiptapEditor) return;

  const nextHtml =
    html && String(html).trim()
      ? html
      : '<p></p>';

  suppressTiptapUpdate = true;

  try {
    try {
      tiptapEditor.commands.setContent(
        nextHtml,
        {
          emitUpdate: false
        }
      );
    } catch (error) {
      tiptapEditor.commands.setContent(
        nextHtml,
        false
      );
    }

    const mountElement = tiptapEditor.options.element;

    setTimeout(() => {
      removeTiptapGhostNodes(mountElement);
    }, 0);
  } finally {
    setTimeout(() => {
      suppressTiptapUpdate = false;
    }, 120);
  }
}

function focus() {
  if (!tiptapEditor) return;

  tiptapEditor.commands.focus();
}

function insertImage(src, alt = '') {
  if (!tiptapEditor || !src) return false;

  return tiptapEditor
    .chain()
    .focus()
    .setImage({
      src,
      alt,
      width: '75%'
    })
    .run();
}

function updateImageWidthBySrc(src, width = null) {
  if (!tiptapEditor || !src) return false;

  const { state } = tiptapEditor;

  let foundPos = null;

  state.doc.descendants((node, pos) => {
    if (
      node.type.name === 'image' &&
      node.attrs.src === src
    ) {
      foundPos = pos;
      return false;
    }

    return true;
  });

  if (foundPos === null) {
    return false;
  }

  return tiptapEditor
    .chain()
    .focus()
    .setNodeSelection(foundPos)
    .updateAttributes('image', {
      width
    })
    .run();
}

function run(command, value = null) {
  if (!tiptapEditor) return false;

  const chain =
    tiptapEditor
      .chain()
      .focus();

  if (command === 'bold') {
    return chain.toggleBold().run();
  }

  if (command === 'italic') {
    return chain.toggleItalic().run();
  }
  
  if (command === 'underline') {
  return chain.toggleUnderline().run();
}

  if (command === 'strikeThrough') {
    return chain.toggleStrike().run();
  }

  if (command === 'bulletList') {
    return chain.toggleBulletList().run();
  }

  if (command === 'orderedList') {
    return chain.toggleOrderedList().run();
  }

  if (command === 'blockquote') {
    return chain.toggleBlockquote().run();
  }

  if (command === 'horizontalRule') {
    return chain.setHorizontalRule().run();
  }

  if (command === 'undo') {
    return tiptapEditor.commands.undo();
  }

  if (command === 'redo') {
    return tiptapEditor.commands.redo();
  }

  if (command === 'paragraph') {
    return chain.setParagraph().run();
  }

  if (command === 'heading') {
    return chain
      .toggleHeading({
        level: Number(value) || 1
      })
      .run();
  }
  
  if (command === 'fontFamily') {
  if (!value) return false;

 

  /*
    Tables.
    These commands come from Tiptap's table extension/TableKit.
  */
  if (command === 'insertTable') {
  const options =
    value && typeof value === 'object'
      ? value
      : {};

  return chain
    .insertTable({
      rows: Number(options.rows) || 3,
      cols: Number(options.cols) || 3,
      withHeaderRow: options.withHeaderRow !== false
    })
    .run();
}

if (command === 'addRowBefore') {
  return chain.addRowBefore().run();
}

if (command === 'addRowAfter') {
  return chain.addRowAfter().run();
}

if (command === 'deleteRow') {
  return chain.deleteRow().run();
}

if (command === 'addColumnBefore') {
  return chain.addColumnBefore().run();
}

if (command === 'addColumnAfter') {
  return chain.addColumnAfter().run();
}

if (command === 'deleteColumn') {
  return chain.deleteColumn().run();
}

if (command === 'deleteTable') {
  return chain.deleteTable().run();
}

if (command === 'mergeCells') {
  return chain.mergeCells().run();
}

if (command === 'splitCell') {
  return chain.splitCell().run();
}

if (command === 'textColor') {
  if (!value) return false;

  if (!tiptapEditor.schema.marks.textStyle) {
    console.warn('Text color unavailable: textStyle mark is not registered.');
    return false;
  }

  if (!tiptapEditor.commands.setColor) {
    console.warn('Text color unavailable: setColor command is missing.');
    return false;
  }

  return chain
    .setColor(value)
    .run();
}

if (command === 'highlightColor') {
  if (!value) return false;

  if (!tiptapEditor.commands.setHighlight) {
    console.warn('Highlight unavailable: setHighlight command is missing.');
    return false;
  }

  return chain
    .setHighlight({
      color: value
    })
    .run();
}

if (command === 'removeFormat') {
  return chain
    .unsetAllMarks()
    .clearNodes()
    .run();
}

  return false;
}