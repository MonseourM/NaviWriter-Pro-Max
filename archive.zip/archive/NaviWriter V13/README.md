# HCODX Project

Exported from HCODX — Full HTML Editor IDE with Live Preview.
https://hcodx.com/vs-editor

Open naviwriter/index.html in any browser.

.nwproj / .naviwriter-backup are the native file formats for this Writer.