// js/themes.js
// NaviWriter theme system

const NAVI_THEME_KEY = 'naviwriter-theme';
const NAVI_LIGHT_KEY = 'naviwriter-light-mode';

const NAVI_THEMES = [
  'purple', 'midnight', 'forest', 'rose',
  'ocean', 'amber', 'plain-light', 'plain-dark'
];


const NAVI_APPEARANCE_MODE_KEY = 'naviwriter-appearance-mode';
function getAppearanceMode(){
  const saved=localStorage.getItem(NAVI_APPEARANCE_MODE_KEY);
  if(saved==='light'||saved==='dark')return saved;
  return document.body.classList.contains('light')?'light':'dark';
}
function syncAppearanceModeControls(){
  const mode=getAppearanceMode();
  document.body.classList.toggle('light',mode==='light');
  document.querySelectorAll('[data-appearance-mode]').forEach(button=>{
    const active=button.dataset.appearanceMode===mode;
    button.classList.toggle('active',active);
    button.setAttribute('aria-pressed',active?'true':'false');
  });
  document.dispatchEvent(new CustomEvent('naviwriter:appearance-mode-change',{detail:mode}));
}
const NAVI_CUSTOM_THEME_KEY = 'naviwriter-custom-theme-v1';
const NAVI_CUSTOM_THEME_FIELDS = ['bg','panel','panel2','text','muted','line','accent','accent2'];
function readCustomTheme(){try{return JSON.parse(localStorage.getItem(NAVI_CUSTOM_THEME_KEY)||'null')||{}}catch{return{}}}
function applyCustomTheme(values=readCustomTheme()){
  const root=document.body;
  NAVI_CUSTOM_THEME_FIELDS.forEach(key=>{if(values[key])root.style.setProperty(`--${key}`,values[key]);else root.style.removeProperty(`--${key}`);});
  const accent=values.accent; if(accent)root.style.setProperty('--soft',`${accent}26`); else root.style.removeProperty('--soft');
  document.body.classList.toggle('custom-theme-active',Object.keys(values).length>0);
  document.querySelectorAll('[data-custom-theme-field]').forEach(input=>{if(values[input.dataset.customThemeField])input.value=values[input.dataset.customThemeField];});
}
function saveCustomTheme(values){localStorage.setItem(NAVI_CUSTOM_THEME_KEY,JSON.stringify(values));applyCustomTheme(values)}
function clearCustomTheme(){localStorage.removeItem(NAVI_CUSTOM_THEME_KEY);applyCustomTheme({});}

function clearThemeClasses() {
  NAVI_THEMES.forEach(theme => {
    document.body.classList.remove(`theme-${theme}`);
  });
}

function applyTheme(themeName='purple'){
  const safeTheme=NAVI_THEMES.includes(themeName)?themeName:'purple';
  let mode=getAppearanceMode();
  if(safeTheme==='plain-light')mode='light';
  else if(safeTheme==='plain-dark')mode='dark';
  localStorage.setItem(NAVI_APPEARANCE_MODE_KEY,mode);
  localStorage.setItem(NAVI_LIGHT_KEY,mode==='light'?'true':'false');
  clearThemeClasses();
  document.body.classList.add(`theme-${safeTheme}`);
  document.body.classList.toggle('light',mode==='light');
  document.body.classList.toggle('neutral-theme',safeTheme==='plain-light'||safeTheme==='plain-dark');
  const selector=document.getElementById('themeSelect');if(selector)selector.value=safeTheme;
  localStorage.setItem(NAVI_THEME_KEY,safeTheme);
  document.querySelectorAll('[data-theme-choice]').forEach(button=>{const selected=button.dataset.themeChoice===safeTheme;button.classList.toggle('active',selected);button.dataset.selected=selected?'true':'false';});
  applyCustomTheme();syncAppearanceModeControls();
  return safeTheme;
}

function loadSavedTheme() {
  const savedTheme = localStorage.getItem(NAVI_THEME_KEY) || 'purple';
  return applyTheme(savedTheme);
}

function setLightMode(enabled){const mode=enabled?'light':'dark';localStorage.setItem(NAVI_APPEARANCE_MODE_KEY,mode);localStorage.setItem(NAVI_LIGHT_KEY,enabled?'true':'false');document.body.classList.toggle('light',enabled);applyCustomTheme();updateLightModeButton();syncAppearanceModeControls();return enabled;}

function loadSavedLightMode(){return setLightMode(getAppearanceMode()==='light');}

function toggleLightMode() {
  const enabled = !document.body.classList.contains('light');
  return setLightMode(enabled);
}

function updateLightModeButton() {
  const btn = document.getElementById('lightModeBtn');

  if (!btn) return;

  const isLight = document.body.classList.contains('light');

  btn.textContent = isLight ? 'Dark' : 'Light';
  btn.classList.toggle('active', isLight);
}

function setupThemeControls() {
  const selector = document.getElementById('themeSelect');
  const labels = { purple:'Purple', midnight:'Midnight', forest:'Forest', rose:'Rose', ocean:'Ocean', amber:'Amber', 'plain-light':'Plain Light', 'plain-dark':'Plain Dark' };
  if (selector) selector.innerHTML = NAVI_THEMES.map(theme => `<option value="${theme}">${labels[theme]}</option>`).join('');
  const lightBtn = document.getElementById('lightModeBtn');

  if (selector) {
    selector.onchange = event => {
      applyTheme(event.target.value);
    };
  }

  if (lightBtn) {
    lightBtn.onclick = () => {
      toggleLightMode();
    };
  }

  updateLightModeButton();
  applyCustomTheme();
}

function initThemes() {
  loadSavedTheme();
  loadSavedLightMode();
  setupThemeControls();
}

window.NaviThemes = {
  themes: NAVI_THEMES,
  initThemes,
  applyTheme,
  loadSavedTheme,
  setLightMode,
  loadSavedLightMode,
  toggleLightMode,
  updateLightModeButton,
  readCustomTheme, applyCustomTheme, saveCustomTheme, clearCustomTheme, getAppearanceMode, syncAppearanceModeControls
};