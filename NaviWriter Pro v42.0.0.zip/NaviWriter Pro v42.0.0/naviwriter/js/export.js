// naviwriter/js/export.js
// js/export.js
// NaviWriter import/export helpers

const NAVIDOC_VERSION = 2;
const NAVIDOC_MAGIC = 'NAVIWRITER:NAVIDOC:2';

/**
 * Make a safe filename.
 */
function safeFileName(name = 'Untitled Document') {
  return String(name || 'Untitled Document')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 90) || 'Untitled Document';
}

/**
 * Download a blob as a file.
 */
function downloadBlob(blob, filename) {
  const a = document.createElement('a');

  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();

  URL.revokeObjectURL(a.href);
}

/**
 * Create a stable NaviDoc export payload.
 */
async function createNaviDocPayload(document) {
  const now=Date.now();
  const content=window.NaviAssets?.serializeHtml ? NaviAssets.serializeHtml(document.content||'<p></p>') : (document.content||'<p></p>');
  const assetIds=new Set(window.NaviAssets?.idsFromHtml?.(content)||[]);if(document.sourceAttachmentId)assetIds.add(document.sourceAttachmentId);if(document.cover?.assetId)assetIds.add(document.cover.assetId);
  for(const id of boardAssetIds(document.board))assetIds.add(id);
  const assets=window.NaviStorage?.getAssets ? await NaviStorage.getAssets([...assetIds]) : [];
  const portableAssets=[];
  for(const asset of assets){const item=await NaviAssets.assetToPortable(asset);if(item)portableAssets.push(item);}
  return {app:'NaviWriter',format:'navidoc',type:'naviwriter-document',magic:NAVIDOC_MAGIC,schemaVersion:NAVIDOC_VERSION,exportedAt:now,document:{...document,content,id:document.id||'',title:document.title||'Untitled Document',plainText:document.plainText||'',createdAt:document.createdAt||now,updatedAt:document.updatedAt||now,tags:Array.isArray(document.tags)?document.tags:[]},boards:boardsForDocuments([document]),boardManifest:{version:1,scope:'document',count:document.board?1:0},assets:portableAssets};
}
/**
 * Export as .navidoc JSON file.
 */
async function exportNaviDoc(document) {
  if (!document) return;

  const payload = await createNaviDocPayload(document);

  const blob = await NaviNativeContainer.encode(payload, 'navidoc');

  const filename = `${safeFileName(document.title)}.navidoc`;

  downloadBlob(blob, filename);
}

/**
 * Export current document as standalone HTML.
 */
function exportHtml(document) {
  if (!document) return;

  const title = document.title || 'Untitled Document';
  const content = document.content || '<p></p>';

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>${escapeHtml(title)}</title>
<style>
  body {
    max-width: 800px;
    margin: 48px auto;
    padding: 0 24px;
    font-family: Arial, Helvetica, sans-serif;
    line-height: 1.7;
    color: #111827;
    background: #ffffff;
  }

  h1, h2, h3 {
    line-height: 1.25;
  }

  blockquote {
    border-left: 4px solid #8b5cf6;
    padding-left: 1em;
    color: #4b5563;
  }

  table {
    width: 100%;
    border-collapse: collapse;
  }

  th, td {
    border: 1px solid #d1d5db;
    padding: 8px;
  }

  img {
    max-width: 100%;
  }
</style>
</head>
<body>
${content}
</body>
</html>`;

  const blob = new Blob([html], {
    type: 'text/html'
  });

  downloadBlob(blob, `${safeFileName(title)}.html`);
}

/**
 * Export plain text.
 */
function exportTxt(document) {
  if (!document) return;

  const title = document.title || 'Untitled Document';
  const text = document.plainText || htmlToPlainText(document.content || '');

  const blob = new Blob([text], {
    type: 'text/plain'
  });

  downloadBlob(blob, `${safeFileName(title)}.txt`);
}

function safeExportFileName(name) {
  return String(name || 'Untitled')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'Untitled';
}

function downloadTextFile(filename, content, type = 'text/plain') {
  const blob = new Blob([content], {
    type
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');

  link.href = url;
  link.download = filename;
  link.click();

  URL.revokeObjectURL(url);
}

/**
 * Parse imported file text.
 * Supports:
 * - .navidoc wrapped format
 * - raw old document JSON
 * - plain text fallback
 */
function parseImportedDocument(text, fileName = 'Imported Document') {
  const fallbackTitle = fileName.replace(/\.[^.]+$/, '') || 'Imported Document';

  let parsed = null;

  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = null;
  }

  // New wrapped .navidoc format
  if (parsed && (parsed.type === 'naviwriter-document' || parsed.type === 'navidoc') && parsed.document) {
    if(parsed.type==='naviwriter-document' && (parsed.magic!==NAVIDOC_MAGIC || parsed.schemaVersion!==NAVIDOC_VERSION)) throw new Error('Unsupported or invalid NaviDoc signature.');
    const normalized=normalizeImportedDocument(parsed.document,fallbackTitle); normalized.__navidocAssets=Array.isArray(parsed.assets)?parsed.assets:[]; normalized.__navidocVersion=parsed.version||1; return normalized;
  }

  // Older direct document object format
  if (parsed && (parsed.content || parsed.title || parsed.plainText)) {
    return normalizeImportedDocument(parsed, fallbackTitle);
  }

  // HTML-ish import
  if (looksLikeHtml(text)) {
    return normalizeImportedDocument(
      {
        title: fallbackTitle,
        content: text,
        plainText: htmlToPlainText(text)
      },
      fallbackTitle
    );
  }

  // Plain text fallback
  return normalizeImportedDocument(
    {
      title: fallbackTitle,
      content: plainTextToHtml(text),
      plainText: text
    },
    fallbackTitle
  );
}

/**
 * Normalize an imported document into NaviWriter's document shape.
 */
function normalizeImportedDocument(input, fallbackTitle = 'Imported Document') {
  const now = Date.now();

  const title = input.title || fallbackTitle || 'Imported Document';
  const content = input.content || plainTextToHtml(input.plainText || '');

  const plainText = input.plainText || htmlToPlainText(content);

  return {
    title,
    content,
    plainText,
    createdAt: input.createdAt || now,
    updatedAt: now,
    wordCount: countWordsFromText(plainText),
    charCount: plainText.length,
    tags: Array.isArray(input.tags) ? input.tags : [],
    folder: input.folder || ''
  };
}

/**
 * Convert plain text to simple HTML paragraphs.
 */
function plainTextToHtml(text = '') {
  const clean = String(text || '');

  if (!clean.trim()) {
    return '<p></p>';
  }

  return clean
    .split(/\n{2,}/)
    .map(paragraph => `<p>${escapeHtml(paragraph).replace(/\n/g, '<br>')}</p>`)
    .join('');
}

/**
 * Convert HTML to plain text using the browser.
 */
function htmlToPlainText(html = '') {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.innerText || div.textContent || '';
}

/**
 * Check if text looks like HTML.
 */
function looksLikeHtml(text = '') {
  return /<\/?[a-z][\s\S]*>/i.test(String(text || ''));
}

/**
 * Count words from plain text.
 */
function countWordsFromText(text = '') {
  const clean = String(text)
    .trim()
    .replace(/\s+/g, ' ');

  if (!clean) return 0;

  return clean.split(' ').filter(Boolean).length;
}

/**
 * Escape text for safe HTML output.
 */
function escapeHtml(value) {
  return String(value || '').replace(/[&<>'"]/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[char]));
}
function exportMarkdown(document) {
  if (!document) return;

  const title = document.title || 'Untitled Document';
  const markdown = htmlToMarkdown(document.content || '');

  const blob = new Blob([markdown], {
    type: 'text/markdown'
  });

  downloadBlob(blob, `${safeFileName(title)}.md`);
}

function htmlToMarkdown(html = '') {
  const container = document.createElement('div');
  container.innerHTML = html;

  function walk(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      return node.nodeValue;
    }

    if (node.nodeType !== Node.ELEMENT_NODE) {
      return '';
    }

    const tag = node.tagName.toLowerCase();
    const content = Array.from(node.childNodes).map(walk).join('');

    if (tag === 'h1') return `# ${content.trim()}\n\n`;
    if (tag === 'h2') return `## ${content.trim()}\n\n`;
    if (tag === 'h3') return `### ${content.trim()}\n\n`;
    if (tag === 'p') return `${content.trim()}\n\n`;
    if (tag === 'br') return '\n';
    if (tag === 'strong' || tag === 'b') return `**${content}**`;
    if (tag === 'em' || tag === 'i') return `*${content}*`;
    if (tag === 'u') return content;
    if (tag === 's' || tag === 'strike') return `~~${content}~~`;
    if (tag === 'blockquote') return `> ${content.trim()}\n\n`;
    if (tag === 'li') return `- ${content.trim()}\n`;
    if (tag === 'ul' || tag === 'ol') return `${content}\n`;
    if (tag === 'hr') return `---\n\n`;

    if (tag === 'table') {
      return `\n\n${content.trim()}\n\n`;
    }

    if (tag === 'tr') {
      return `${Array.from(node.children).map(cell => cell.innerText.trim()).join(' | ')}\n`;
    }

    if (tag === 'td' || tag === 'th') {
      return node.innerText.trim();
    }

    if (tag === 'img') {
      return `![Image](${node.getAttribute('src') || ''})`;
    }

    if (tag === 'figcaption') {
      return `\n*${content.trim()}*\n\n`;
    }

    return content;
  }

  return Array.from(container.childNodes)
    .map(walk)
    .join('')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function printDocument() {
  window.print();
}

function stripHtmlToText(html = '') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html || '';

  return wrapper.innerText || '';
}

function orderDocumentsForExport(docs = []) {
  return docs.slice().sort((a, b) => {
    const aOrder = Number.isFinite(Number(a.sortOrder)) ? Number(a.sortOrder) : Number(a.order || a.createdAt || 0);
    const bOrder = Number.isFinite(Number(b.sortOrder)) ? Number(b.sortOrder) : Number(b.order || b.createdAt || 0);
    return aOrder - bOrder || String(a.title || '').localeCompare(String(b.title || ''));
  });
}

function combineManuscriptHtml(rootDoc, docs) {
  const parts = orderDocumentsForExport(docs).map(doc => {
    return `
      <section data-doc-id="${doc.id}" data-doc-type="${doc.docType || ''}">
        ${doc.content || '<p></p>'}
      </section>
    `;
  });

  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>${rootDoc.title || 'Manuscript'}</title>
        <style>
          body {
            max-width: 760px;
            margin: 40px auto;
            font-family: Georgia, "Times New Roman", serif;
            line-height: 1.7;
            padding: 0 24px;
          }

          section {
            margin-bottom: 3rem;
            page-break-after: always;
          }

          h1, h2, h3 {
            font-family: Arial, Helvetica, sans-serif;
          }
        </style>
      </head>
      <body>
        ${parts.join('\n')}
      </body>
    </html>
  `;
}

function exportManuscriptHtml(rootDoc, docs) {
  const html = combineManuscriptHtml(rootDoc, docs);

  downloadTextFile(
    `${safeExportFileName(rootDoc.title || 'Manuscript')}.html`,
    html,
    'text/html'
  );
}

function exportManuscriptTxt(rootDoc, docs) {
  const text = orderDocumentsForExport(docs)
    .map(doc => stripHtmlToText(doc.content || ''))
    .filter(Boolean)
    .join('\n\n\n');

  downloadTextFile(
    `${safeExportFileName(rootDoc.title || 'Manuscript')}.txt`,
    text,
    'text/plain'
  );
}

function exportManuscriptMarkdown(rootDoc, docs) {
  const markdown = orderDocumentsForExport(docs)
    .map(doc => {
      const title = doc.title || 'Untitled';
      const text = stripHtmlToText(doc.content || '');

      return `# ${title}\n\n${text}`;
    })
    .join('\n\n---\n\n');

  downloadTextFile(
    `${safeExportFileName(rootDoc.title || 'Manuscript')}.md`,
    markdown,
    'text/markdown'
  );
}

function escapeXml(value = '') {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function htmlToDocxParagraphs(html = '') {
  const container = document.createElement('div');
  container.innerHTML = html || '';

  const blocks = [];

  function textFromNode(node) {
    return node.innerText || node.textContent || '';
  }

  Array.from(container.childNodes).forEach(node => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.nodeValue.trim();

      if (text) {
        blocks.push({
          style: 'Normal',
          text
        });
      }

      return;
    }

    if (node.nodeType !== Node.ELEMENT_NODE) {
      return;
    }

    const tag = node.tagName.toLowerCase();
    const text = textFromNode(node).trim();

    if (!text && tag !== 'hr') return;

    if (tag === 'h1') {
      blocks.push({
        style: 'Heading1',
        text
      });
      return;
    }

    if (tag === 'h2') {
      blocks.push({
        style: 'Heading2',
        text
      });
      return;
    }

    if (tag === 'h3') {
      blocks.push({
        style: 'Heading3',
        text
      });
      return;
    }

    if (tag === 'blockquote') {
      blocks.push({
        style: 'Quote',
        text
      });
      return;
    }

    if (tag === 'li') {
      blocks.push({
        style: 'Normal',
        text: `• ${text}`
      });
      return;
    }

    if (tag === 'table') {
      blocks.push({
        style: 'Normal',
        text
      });
      return;
    }

    if (tag === 'img') {
      blocks.push({
        style: 'Normal',
        text: '[Image omitted in DOCX export]'
      });
      return;
    }

    if (tag === 'figure') {
      const figureText = text || '[Image omitted in DOCX export]';

      blocks.push({
        style: 'Normal',
        text: figureText
      });
      return;
    }

    blocks.push({
      style: 'Normal',
      text
    });
  });

  if (!blocks.length) {
    blocks.push({
      style: 'Normal',
      text: ''
    });
  }

  return blocks;
}

function buildDocxDocumentXml(documentTitle, html, options = {}) {
  const includeTitlePage = Boolean(options.includeTitlePage);

  const blocks = includeTitlePage
    ? [
        {
          style: 'Title',
          text: documentTitle || 'Untitled Document'
        },
        ...htmlToDocxParagraphs(html)
      ]
    : htmlToDocxParagraphs(html);

  const paragraphs = blocks.map(block => {
    const styleXml =
      block.style && block.style !== 'Normal'
        ? `<w:pPr><w:pStyle w:val="${block.style}"/></w:pPr>`
        : '';

    return `
      <w:p>
        ${styleXml}
        <w:r>
          <w:t xml:space="preserve">${escapeXml(block.text)}</w:t>
        </w:r>
      </w:p>
    `;
  }).join('');

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document
  xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
  xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
  xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
  xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
  xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
  xmlns:w10="urn:schemas-microsoft-com:office:word"
  xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
  xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
  xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
  xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
  xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
  mc:Ignorable="w14 wp14">
  <w:body>
    ${paragraphs}
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>
    </w:sectPr>
  </w:body>
</w:document>`;
}

function buildDocxStylesXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:qFormat/>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:rPr><w:b/><w:sz w:val="36"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:basedOn w:val="Normal"/>
    <w:next w:val="Normal"/>
    <w:qFormat/>
    <w:rPr><w:b/><w:sz w:val="32"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:basedOn w:val="Normal"/>
    <w:next w:val="Normal"/>
    <w:qFormat/>
    <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading3">
    <w:name w:val="heading 3"/>
    <w:basedOn w:val="Normal"/>
    <w:next w:val="Normal"/>
    <w:qFormat/>
    <w:rPr><w:b/><w:sz w:val="24"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Quote">
    <w:name w:val="Quote"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:pPr><w:ind w:left="720"/></w:pPr>
    <w:rPr><w:i/></w:rPr>
  </w:style>
</w:styles>`;
}

async function exportDocx(document) {
  if (!document) return;

  if (!window.JSZip) {
    alert('DOCX export tools are not loaded.');
    return;
  }

  const zip = new JSZip();

  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>`);

  zip.folder('_rels').file('.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1"
    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
    Target="word/document.xml"/>
</Relationships>`);

  zip.folder('word').file(
  'document.xml',
  buildDocxDocumentXml(
    document.title || 'Untitled Document',
    document.content || '<p></p>',
    {
      includeTitlePage: false
    }
  )
);

  zip.folder('word').file(
    'styles.xml',
    buildDocxStylesXml()
  );

  zip.folder('word').folder('_rels').file('document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>`);

  const blob = await zip.generateAsync({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  });

  downloadBlob(
    blob,
    `${safeFileName(document.title || 'Untitled Document')}.docx`
  );
}

const NAVI_NATIVE_SCHEMA_VERSION = 2;
const NAVI_MAGIC = Object.freeze({
  document: 'NAVIWRITER:NAVIDOC:2',
  project: 'NAVIWRITER:NWPROJ:2',
  backup: 'NAVIWRITER:WORKSPACE-BACKUP:2'
});

async function portableAssets(assets = []) {
  const out=[];
  for(const asset of assets){const item=window.NaviAssets?.assetToPortable?await NaviAssets.assetToPortable(asset):null;if(item)out.push(item);}
  return out;
}
function boardAssetIds(board){const ids=new Set();for(const item of board?.items||[]){const direct=item.assetId||item.imageAssetId||item.attachmentId||item.attachmentAssetId||'';if(direct)ids.add(String(direct));const src=String(item.src||'');const parsed=window.NaviAssets?.idFrom?.(src);if(parsed)ids.add(parsed);}return ids;}
function boardsForDocuments(documents=[]){return documents.filter(document=>document?.board&&Array.isArray(document.board.items)).map(document=>({id:`board:${document.id}`,scope:'document',ownerDocumentId:document.id,title:`${document.title||'Untitled Document'} Board`,board:{...document.board,ownership:{scope:'document',documentId:document.id},schemaVersion:Number(document.board.schemaVersion||2)}}));}
function collectDocumentAndBoardAssetIds(documents=[]){const ids=new Set();for(const documentRecord of documents){for(const id of window.NaviAssets?.idsFromHtml?.(documentRecord.content||'')||[])ids.add(id);if(documentRecord.sourceAttachmentId)ids.add(documentRecord.sourceAttachmentId);for(const id of boardAssetIds(documentRecord.board))ids.add(id);}return ids;}
async function restorePortableAssets(assets=[]){return window.NaviAssets?.importPortable?NaviAssets.importPortable(assets):[];}
function isNaviWriterStorageKey(key){return /^(naviwriter|navi[-_])/i.test(String(key||''));}
function captureNaviWriterLocalStorage(){const data={};for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key&&isNaviWriterStorageKey(key))data[key]=localStorage.getItem(key);}return data;}
function restoreNaviWriterLocalStorage(data={}){const remove=[];for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(isNaviWriterStorageKey(key))remove.push(key);}remove.forEach(key=>localStorage.removeItem(key));Object.entries(data||{}).forEach(([key,value])=>{if(isNaviWriterStorageKey(key))localStorage.setItem(key,String(value));});}
function nativeHeader(format,type,magic){return{app:'NaviWriter',vendor:'NaviWriter',format,type,magic,schemaVersion:NAVI_NATIVE_SCHEMA_VERSION,exportedAt:Date.now()};}
function validateNative(payload, expectedType, expectedMagic){if(!payload||typeof payload!=='object')throw new Error('The native NaviWriter file is empty or invalid.');if(payload.app!=='NaviWriter')throw new Error('This file was not created for NaviWriter.');if(payload.type!==expectedType)throw new Error(`Native file type mismatch. Expected ${expectedType}, received ${payload.type||'unknown'}.`);if(payload.schemaVersion!==NAVI_NATIVE_SCHEMA_VERSION||payload.magic!==expectedMagic)throw new Error('This NaviWriter native file uses an unsupported or invalid schema signature.');return true;}
async function integrityDigest(value){const bytes=new TextEncoder().encode(JSON.stringify(value));const hash=await crypto.subtle.digest('SHA-256',bytes);return[...new Uint8Array(hash)].map(v=>v.toString(16).padStart(2,'0')).join('');}

async function createProjectFilePayload(){
  if(!window.NaviStorage)throw new Error('NaviStorage is unavailable.');
  const documents=await NaviStorage.getAllDocuments();
  const settings=NaviStorage.getAllSettings?await NaviStorage.getAllSettings():[];
  const assets=await portableAssets(NaviStorage.getAllAssets?await NaviStorage.getAllAssets():[]);
  const boards=boardsForDocuments(documents);
  const core={project:{title:(settings.find(x=>x.key==='naviwriter-project-meta')?.value?.title)||'',savedAt:Date.now()},documents,boards,boardManifest:{version:1,documentBoards:boards.length,projectBoards:0,workspaceBoards:0},assets,settings};
  return{...nativeHeader('nwproj','naviwriter-project',NAVI_MAGIC.project),...core,integrity:{manifestHash:await integrityDigest(core),recordCounts:{documents:documents.length,assets:assets.length,settings:settings.length}}};
}

async function createProjectSelectionPayload(resolution){
  if(!resolution?.includedNodes?.length)throw new Error('No documents were selected for project export.');
  const selectedIds=new Set(resolution.includedNodes.map(node=>node.id));
  const documents=resolution.includedNodes.map(node=>({...node.doc,parentId:selectedIds.has(node.doc.parentId)?node.doc.parentId:null}));
  const assetIds=collectDocumentAndBoardAssetIds(documents);
  const boards=boardsForDocuments(documents);
  const storedAssets=NaviStorage.getAllAssets?await NaviStorage.getAllAssets():[];
  const assets=await portableAssets(storedAssets.filter(asset=>assetIds.has(asset.id)));
  const allSettings=NaviStorage.getAllSettings?await NaviStorage.getAllSettings():[];
  const settings=allSettings.filter(item=>['naviwriter-project-meta','naviwriter-collections','naviwriter-relationships','naviwriter-custom-metadata-fields'].includes(item.key));
  const first=documents[0],label=resolution.scope==='branch'?`${first.title||'Branch'} Branch`:resolution.scope==='root'?`${first.title||'Tree'} Tree`:'Project Selection';
  const core={project:{title:label,savedAt:Date.now(),exportedScope:resolution.scope,sourceRootId:resolution.rootDocumentId||null},documents,boards,boardManifest:{version:1,documentBoards:boards.length,projectBoards:0,workspaceBoards:0},assets,settings};
  return{...nativeHeader('nwproj','naviwriter-project',NAVI_MAGIC.project),...core,integrity:{manifestHash:await integrityDigest(core),recordCounts:{documents:documents.length,assets:assets.length,settings:settings.length}}};
}
async function exportProjectSelection(resolution){
  const payload=await createProjectSelectionPayload(resolution),blob=await NaviNativeContainer.encode(payload,'nwproj');
  downloadBlob(blob,`${safeFileName(payload.project.title||'NaviWriter Project')}.nwproj`);
  return payload;
}

async function createProjectBackupPayload(){
  if(!window.NaviStorage)throw new Error('NaviStorage is unavailable.');
  const stores={documents:await NaviStorage.getAllDocuments(),assets:await portableAssets(NaviStorage.getAllAssets?await NaviStorage.getAllAssets():[]),settings:NaviStorage.getAllSettings?await NaviStorage.getAllSettings():[],snapshots:NaviStorage.getAllSnapshots?await NaviStorage.getAllSnapshots():[],writingSessions:NaviStorage.getWritingSessions?await NaviStorage.getWritingSessions():[]};
  const persistentState={localStorage:captureNaviWriterLocalStorage()};
  const documentBoards=boardsForDocuments(stores.documents);
  const manifest={databaseName:'NaviWriterDB',databaseVersion:4,recordCounts:{...Object.fromEntries(Object.entries(stores).map(([k,v])=>[k,v.length])),boards:documentBoards.length},boardManifest:{version:1,documentBoards:documentBoards.length,projectBoards:0,workspaceBoards:0},localStorageKeys:Object.keys(persistentState.localStorage),excludedRuntime:['blob URLs','open file handles','DOM state','workers','promises','browser caches']};
  const core={workspace:{stores,persistentState,boards:documentBoards},manifest};
  return{...nativeHeader('naviwriter-backup','naviwriter-workspace-backup',NAVI_MAGIC.backup),...core,integrity:{manifestHash:await integrityDigest(core)}};
}
async function exportProjectBackup(){const payload=await createProjectBackupPayload(),date=new Date(payload.exportedAt).toISOString().slice(0,10),blob=await NaviNativeContainer.encode(payload,'naviwriter-backup');downloadBlob(blob,`NaviWriter Workspace ${date}.naviwriter-backup`);}

function migrateLegacyNative(payload){
  if(payload?.type==='naviwriter-project-file')return{legacy:true,kind:'project',payload:{...nativeHeader('nwproj','naviwriter-project',NAVI_MAGIC.project),project:{migratedFrom:1},documents:payload.documents||[],assets:payload.assets||[],settings:payload.settings||[],integrity:{legacy:true}}};
  if(payload?.type==='naviwriter-project-backup')return{legacy:true,kind:'backup',payload:{...nativeHeader('naviwriter-backup','naviwriter-workspace-backup',NAVI_MAGIC.backup),workspace:{stores:{documents:payload.documents||[],assets:payload.assets||[],settings:payload.settings||[],snapshots:payload.snapshots||[],writingSessions:payload.writingSessions||[]},persistentState:{localStorage:{}}},manifest:{migratedFrom:1},integrity:{legacy:true}}};
  return null;
}
async function decodeNativeFile(fileOrBuffer, expectedFormat='') {
  if(!window.NaviNativeContainer) throw new Error('NaviWriter native container tools are unavailable.');
  const decoded=await NaviNativeContainer.decode(fileOrBuffer,expectedFormat);
  const raw=decoded.payload,migrated=migrateLegacyNative(raw),payload=migrated?.payload||raw;
  if(payload.type==='naviwriter-project'){validateNative(payload,'naviwriter-project',NAVI_MAGIC.project);return{kind:'project',payload,legacy:decoded.legacy||Boolean(migrated)};}
  if(payload.type==='naviwriter-workspace-backup'){validateNative(payload,'naviwriter-workspace-backup',NAVI_MAGIC.backup);return{kind:'backup',payload,legacy:decoded.legacy||Boolean(migrated)};}
  if(payload.type==='naviwriter-document'||payload.type==='navidoc')return{kind:'document',payload,legacy:decoded.legacy||payload.type==='navidoc'};
  throw new Error('Unsupported NaviWriter native payload.');
}
function parseNativeFileText(text){const raw=JSON.parse(text),migrated=migrateLegacyNative(raw);const payload=migrated?.payload||raw;if(payload.type==='naviwriter-project'){validateNative(payload,'naviwriter-project',NAVI_MAGIC.project);return{kind:'project',payload,legacy:Boolean(migrated)};}if(payload.type==='naviwriter-workspace-backup'){validateNative(payload,'naviwriter-workspace-backup',NAVI_MAGIC.backup);return{kind:'backup',payload,legacy:Boolean(migrated)};}if(payload.type==='naviwriter-document'||payload.type==='navidoc')return{kind:'document',payload,legacy:payload.type==='navidoc'};throw new Error('Unsupported NaviWriter native file type.');}
async function importProjectPayload(payload){validateNative(payload,'naviwriter-project',NAVI_MAGIC.project);if(!payload.integrity?.legacy){const core=payload.boards?{project:payload.project,documents:payload.documents,boards:payload.boards,boardManifest:payload.boardManifest,assets:payload.assets,settings:payload.settings}:{project:payload.project,documents:payload.documents,assets:payload.assets,settings:payload.settings};const actual=await integrityDigest(core);if(actual!==payload.integrity?.manifestHash)throw new Error('This NaviWriter project failed integrity validation.');}const assets=[];for(const item of payload.assets||[]){if(item?.dataUrl){const blob=await(await fetch(item.dataUrl)).blob();const{dataUrl,...rest}=item;assets.push({...rest,blob});}}const boardByOwner=new Map((payload.boards||[]).filter(item=>item.scope==='document'&&item.ownerDocumentId).map(item=>[item.ownerDocumentId,item.board]));const documents=(payload.documents||[]).map(document=>boardByOwner.has(document.id)?{...document,board:boardByOwner.get(document.id)}:document);await NaviStorage.replaceProjectRecords({documents,assets,settings:payload.settings||[]});return{documents,kind:'project'};}
async function restoreWorkspacePayload(payload){validateNative(payload,'naviwriter-workspace-backup',NAVI_MAGIC.backup);if(!payload.integrity?.legacy){const actual=await integrityDigest({workspace:payload.workspace,manifest:payload.manifest});if(actual!==payload.integrity?.manifestHash)throw new Error('This NaviWriter workspace backup failed integrity validation.');}const stores=payload.workspace?.stores||{},assets=[];for(const item of stores.assets||[]){if(item?.dataUrl){const blob=await(await fetch(item.dataUrl)).blob();const{dataUrl,...rest}=item;assets.push({...rest,blob});}}await NaviStorage.replaceWorkspaceRecords({...stores,assets});restoreNaviWriterLocalStorage(payload.workspace?.persistentState?.localStorage||{});return{documents:stores.documents||[],kind:'backup'};}
async function importProjectBackupText(text,options={}){const parsed=parseNativeFileText(text);if(parsed.kind==='project')return importProjectPayload(parsed.payload);if(parsed.kind==='backup'){if(!options.replaceExisting)throw new Error('A complete workspace backup can only be restored with Replace Workspace.');return restoreWorkspacePayload(parsed.payload);}throw new Error('Use Import File for NaviDoc files.');}


/**
 * Expose export API globally.
 */
window.NaviExport = {
  exportNaviDoc,
  exportHtml,
  exportTxt,
  parseImportedDocument,
  normalizeImportedDocument,
  plainTextToHtml,
  htmlToPlainText,
  safeFileName,
  exportMarkdown,
  htmlToMarkdown,
  printDocument,
  exportManuscriptHtml,
exportManuscriptTxt,
exportManuscriptMarkdown,
  exportProjectBackup,
importProjectBackupText,
exportDocx,
  createProjectBackupPayload,
createProjectFilePayload, createProjectSelectionPayload, exportProjectSelection,
  parseNativeFileText, decodeNativeFile, importProjectPayload, restoreWorkspacePayload
};