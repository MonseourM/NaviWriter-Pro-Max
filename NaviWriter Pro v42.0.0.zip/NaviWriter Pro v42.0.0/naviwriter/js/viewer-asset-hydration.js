/* NaviWriter flowing-document viewer asset hydration v1 */
(() => {
  'use strict';
  const SELECTOR='.reference-office-paper,.retained-office-paper,.split-reference-paper,.board-attachment-document-paper,.navi-source-original,.navi-source-parsed';
  const mounted=new WeakSet();
  function hydrate(root){
    if(!(root instanceof Element)||!root.matches?.(SELECTOR))return;
    window.NaviAssets?.installEditorRecovery?.(root);
    window.NaviAssets?.hydrateStable?.(root);
    mounted.add(root);
  }
  function scan(root=document){
    if(root instanceof Element&&root.matches?.(SELECTOR))hydrate(root);
    root.querySelectorAll?.(SELECTOR).forEach(hydrate);
  }
  const observer=new MutationObserver(records=>records.forEach(record=>record.addedNodes.forEach(node=>{
    if(node instanceof Element)scan(node);
  })));
  function install(){scan();observer.observe(document.body,{childList:true,subtree:true});}
  document.readyState==='loading'?document.addEventListener('DOMContentLoaded',install,{once:true}):install();
  window.NaviViewerAssetHydration={version:'1.0.0',scan,hydrate};
})();
