/* NaviWriter encrypted native container v1 */
(() => {
  'use strict';
  const HEADER_SIZE=48, VERSION=1, PBKDF2_ROUNDS=210000;
  const encoder=new TextEncoder(), decoder=new TextDecoder();
  const formatCodes={navidoc:1,nwproj:2,'naviwriter-backup':3};
  const codeFormats={1:'navidoc',2:'nwproj',3:'naviwriter-backup'};
  const magic=encoder.encode('NAVIENC1');
  const secret=()=>['NVW','::','Aster','-','Orchid','::','2026','::','Native'].join('');
  const concat=(...parts)=>{const size=parts.reduce((n,p)=>n+p.length,0),out=new Uint8Array(size);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;};
  async function compress(bytes){if(!globalThis.CompressionStream)return{bytes,compressed:false};const stream=new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'));return{bytes:new Uint8Array(await new Response(stream).arrayBuffer()),compressed:true};}
  async function decompress(bytes,compressed){if(!compressed)return bytes;if(!globalThis.DecompressionStream)throw new Error('This browser cannot decompress NaviWriter native files.');const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));return new Uint8Array(await new Response(stream).arrayBuffer());}
  async function keyFrom(salt){const material=await crypto.subtle.importKey('raw',encoder.encode(secret()),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:PBKDF2_ROUNDS,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);}
  function buildHeader(format,compressed,salt,iv){const header=new Uint8Array(HEADER_SIZE);header.set(magic,0);header[8]=VERSION;header[9]=formatCodes[format]||0;header[10]=compressed?1:0;new DataView(header.buffer).setUint32(12,PBKDF2_ROUNDS,false);header.set(salt,16);header.set(iv,32);crypto.getRandomValues(header.subarray(44,48));return header;}
  function hasMagic(bytes){return bytes.length>=HEADER_SIZE&&magic.every((v,i)=>bytes[i]===v);}
  async function encode(payload,format){if(!formatCodes[format])throw new Error('Unknown NaviWriter native format.');const packed=await compress(encoder.encode(JSON.stringify(payload)));const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),header=buildHeader(format,packed.compressed,salt,iv),key=await keyFrom(salt);const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:header,tagLength:128},key,packed.bytes));return new Blob([header,cipher],{type:'application/x-naviwriter-native'});}
  async function decode(input,expectedFormat=''){const bytes=input instanceof Uint8Array?input:new Uint8Array(input instanceof ArrayBuffer?input:await input.arrayBuffer());if(!hasMagic(bytes)){const text=decoder.decode(bytes);if(text.trim().startsWith('{'))return{payload:JSON.parse(text),format:'legacy-json',legacy:true};throw new Error('This is not a recognized NaviWriter native container.');}const version=bytes[8],format=codeFormats[bytes[9]],compressed=bytes[10]===1;if(version!==VERSION||!format)throw new Error('Unsupported NaviWriter native container version.');if(expectedFormat&&format!==expectedFormat)throw new Error(`Native container mismatch. Expected ${expectedFormat}, received ${format}.`);const header=bytes.slice(0,HEADER_SIZE),salt=bytes.slice(16,32),iv=bytes.slice(32,44),key=await keyFrom(salt);let plain;try{plain=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:header,tagLength:128},key,bytes.slice(HEADER_SIZE)));}catch{throw new Error('NaviWriter could not authenticate or decrypt this native file.');}plain=await decompress(plain,compressed);return{payload:JSON.parse(decoder.decode(plain)),format,legacy:false};}
  window.NaviNativeContainer={version:VERSION,encode,decode,hasMagic};
})();
