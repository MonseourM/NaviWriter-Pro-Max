/* NaviWriter Universal Import Studio v2
   Enhances every non-PDF import review without replacing format parsers. */
(() => {
  'use strict';
  const VERSION = '2.1.0';
  const enhanced = new WeakSet();
  const selected = new WeakMap();
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const sourceContext = { html:'', format:'', engine:'', capturedAt:0, file:null };
  function safeSourceHtml(html='') {
    const root=document.createElement('div');root.innerHTML=String(html||'');
    root.querySelectorAll('script,style,iframe,object,embed,link,meta,form').forEach(node=>node.remove());
    root.querySelectorAll('*').forEach(node=>[...node.attributes].forEach(attribute=>{if(/^on/i.test(attribute.name)||attribute.name.toLowerCase()==='srcdoc')node.removeAttribute(attribute.name);}));
    return root.innerHTML||'<p>No source preview is available.</p>';
  }
  function captureSource(html,format,engine){sourceContext.html=safeSourceHtml(html);sourceContext.format=String(format||'').toUpperCase();sourceContext.engine=engine||'';sourceContext.capturedAt=Date.now();}
  function installParserBridges(){
    if(window.mammoth?.convertToHtml&&!window.mammoth.convertToHtml.__naviStudioWrapped){
      const original=window.mammoth.convertToHtml.bind(window.mammoth);
      const wrapped=async(input,options={})=>{
        const imageConverter=window.mammoth.images?.imgElement?window.mammoth.images.imgElement(async image=>({src:`data:${image.contentType||'image/png'};base64,${await image.read('base64')}`})):null;
        let result=await original(input,{...options,...(imageConverter?{convertImage:imageConverter}:{})});
        const file=sourceContext.file;
        if(file&&window.NaviImportedMedia?.resolve){const normalized=await NaviImportedMedia.resolve(file,{html:result?.value||'',warnings:(result?.messages||[]).map(item=>item?.message||String(item)),diagnostics:{parser:'mammoth',imagesDetected:0,imagesOmitted:0}});result={...result,value:normalized.html,messages:(normalized.warnings||[]).map(message=>({type:'warning',message}))};}
        captureSource(result?.value||'','DOCX','Mammoth');return result;
      };
      wrapped.__naviStudioWrapped=true;window.mammoth.convertToHtml=wrapped;
    }
    if(window.NaviOfficeParserAdapter?.parseFile&&!window.NaviOfficeParserAdapter.parseFile.__naviStudioWrapped){
      const original=window.NaviOfficeParserAdapter.parseFile.bind(window.NaviOfficeParserAdapter);
      const wrapped=async(file,options={})=>{let result=await original(file,options);if(window.NaviImportedMedia?.resolve)result=await NaviImportedMedia.resolve(file,result);captureSource(result?.html||result?.sourceHtml||'',options.fileType||file?.name?.split('.').pop()||'',result?.engine||'OfficeParser');return result;};
      wrapped.__naviStudioWrapped=true;window.NaviOfficeParserAdapter.parseFile=wrapped;
    }
  }

  function actionLabel(select, value) {
    return [...select.options].find(option => option.value === value)?.textContent || value;
  }
  function rows(modal) {
    return [...modal.querySelectorAll('.navi-import-review-item[data-decision-row]')];
  }
  function selection(modal) {
    if (!selected.has(modal)) selected.set(modal, new Set());
    return selected.get(modal);
  }
  function visibleRows(modal) {
    return rows(modal).filter(row => !row.hidden);
  }
  function commonActions(modal) {
    const ids = selection(modal);
    const targets = rows(modal).filter(row => ids.has(row.dataset.decisionRow));
    if (!targets.length) return [];
    const lists = targets.map(row => [...row.querySelector('[data-review-action]')?.options || []].map(option => option.value));
    return lists[0].filter(value => lists.every(list => list.includes(value)));
  }
  function sync(modal) {
    const ids = selection(modal);
    rows(modal).forEach(row => {
      const checked = ids.has(row.dataset.decisionRow);
      row.classList.toggle('is-selected', checked);
      const input = row.querySelector('[data-studio-select]');
      if (input) input.checked = checked;
    });
    const count = modal.querySelector('[data-studio-count]');
    if (count) count.textContent = `${ids.size} selected`;
    const bulk = modal.querySelector('[data-studio-bulk]');
    const apply = modal.querySelector('[data-studio-apply]');
    if (bulk) {
      const previous = bulk.value;
      const first = rows(modal).find(row => ids.has(row.dataset.decisionRow))?.querySelector('[data-review-action]');
      bulk.innerHTML = '<option value="">Bulk action…</option>' + commonActions(modal).map(value => `<option value="${esc(value)}">${esc(actionLabel(first, value))}</option>`).join('');
      if ([...bulk.options].some(option => option.value === previous)) bulk.value = previous;
    }
    if (apply) apply.disabled = !ids.size || !bulk?.value;
    const pageToggle = modal.querySelector('[data-studio-select-visible]');
    const visible = visibleRows(modal);
    if (pageToggle) {
      pageToggle.checked = Boolean(visible.length && visible.every(row => ids.has(row.dataset.decisionRow)));
      pageToggle.indeterminate = !pageToggle.checked && visible.some(row => ids.has(row.dataset.decisionRow));
    }
  }
  function selectRows(modal, targets, replace = true) {
    const ids = selection(modal);
    if (replace) ids.clear();
    targets.forEach(row => ids.add(row.dataset.decisionRow));
    sync(modal);
  }
  function enhance(modal) {
    if (enhanced.has(modal) || !modal.querySelector('#naviDocImportSave')) return;
    const card = modal.querySelector('.navi-doc-import-card');
    const body = modal.querySelector('#naviDocImportBody');
    const review = body?.querySelector('.navi-import-review');
    const preview = body?.querySelector('.navi-doc-import-preview');
    if (!card || !body || !preview) return;
    enhanced.add(modal);
    modal.classList.add('navi-universal-import-studio');
    card.classList.add('navi-universal-import-card');

    const toolbar = document.createElement('section');
    toolbar.className = 'navi-universal-studio-toolbar';
    toolbar.innerHTML = `<div class="navi-universal-select-scopes"><label><input type="checkbox" data-studio-select-visible> Select visible</label><button type="button" data-studio-scope="all">All decisions</button><button type="button" data-studio-scope="review">Needs review</button><button type="button" data-studio-scope="structure">Structure</button><button type="button" data-studio-scope="clear">Clear</button></div><div class="navi-universal-bulk"><strong data-studio-count>0 selected</strong><select data-studio-bulk><option value="">Bulk action…</option></select><button type="button" data-studio-apply disabled>Apply</button></div>`;

    const workspace = document.createElement('section');
    workspace.className = 'navi-universal-studio-workspace';
    const sourcePane = document.createElement('section');
    sourcePane.className = 'navi-universal-source-pane';
    const hasOriginal=Boolean(sourceContext.html&&Date.now()-sourceContext.capturedAt<120000);
    sourcePane.innerHTML = `<header><div class="navi-source-tabs" role="tablist" aria-label="Source views"><button type="button" role="tab" data-source-tab="original" class="active" ${hasOriginal?'':'disabled'}>Original</button><button type="button" role="tab" data-source-tab="parsed" ${hasOriginal?'':'class="active"'}>Parsed</button></div><small>${hasOriginal?`${esc(sourceContext.format)} via ${esc(sourceContext.engine)}`:'Original preview unavailable'}</small></header><div class="navi-universal-source-body"><div class="navi-source-original" data-source-panel="original" ${hasOriginal?'':'hidden'}>${hasOriginal?sourceContext.html:'<div class="navi-source-unavailable">A source-faithful preview is unavailable for this format. Use Parsed to review extracted content.</div>'}</div><div class="navi-source-parsed" data-source-panel="parsed" ${hasOriginal?'hidden':''}></div></div>`;
    preview.parentNode.insertBefore(workspace, preview);
    sourcePane.querySelector('[data-source-panel="parsed"]').appendChild(preview);
    sourcePane.querySelectorAll('[data-source-tab]').forEach(button=>button.onclick=()=>{if(button.disabled)return;sourcePane.querySelectorAll('[data-source-tab]').forEach(tab=>{tab.classList.toggle('active',tab===button);tab.setAttribute('aria-selected',String(tab===button));});sourcePane.querySelectorAll('[data-source-panel]').forEach(panel=>panel.hidden=panel.dataset.sourcePanel!==button.dataset.sourceTab);});
    workspace.appendChild(sourcePane);

    const interpretation = document.createElement('section');
    interpretation.className = 'navi-universal-interpretation-pane';
    interpretation.innerHTML = '<header><strong>NaviWriter interpretation</strong><small>Review transformations before import</small></header><div class="navi-universal-interpretation-body"></div>';
    if (review) interpretation.querySelector('.navi-universal-interpretation-body').appendChild(review);
    else interpretation.querySelector('.navi-universal-interpretation-body').innerHTML = '<div class="navi-doc-import-note">No format-specific transformations were proposed. The parsed source will import as shown.</div>';
    workspace.appendChild(interpretation);
    workspace.parentNode.insertBefore(toolbar, workspace);

    rows(modal).forEach(row => {
      const label = document.createElement('label');
      label.className = 'navi-universal-row-select';
      label.innerHTML = `<input type="checkbox" data-studio-select="${esc(row.dataset.decisionRow)}"><span class="sr-only">Select transformation</span>`;
      row.prepend(label);
      label.querySelector('input').addEventListener('change', event => {
        const ids = selection(modal);
        event.currentTarget.checked ? ids.add(row.dataset.decisionRow) : ids.delete(row.dataset.decisionRow);
        sync(modal);
      });
    });

    toolbar.querySelector('[data-studio-select-visible]').onchange = event => {
      const ids = selection(modal);
      visibleRows(modal).forEach(row => event.currentTarget.checked ? ids.add(row.dataset.decisionRow) : ids.delete(row.dataset.decisionRow));
      sync(modal);
    };
    toolbar.querySelectorAll('[data-studio-scope]').forEach(button => button.onclick = () => {
      const scope = button.dataset.studioScope;
      if (scope === 'clear') return selectRows(modal, []);
      if (scope === 'all') return selectRows(modal, rows(modal));
      if (scope === 'review') return selectRows(modal, rows(modal).filter(row => row.dataset.confidence === 'needs-review'));
      if (scope === 'structure') return selectRows(modal, rows(modal).filter(row => row.dataset.category === 'structure'));
    });
    toolbar.querySelector('[data-studio-bulk]').onchange = () => sync(modal);
    toolbar.querySelector('[data-studio-apply]').onclick = () => {
      const ids = selection(modal), value = toolbar.querySelector('[data-studio-bulk]').value;
      if (!ids.size || !value) return;
      if (value === 'omit' && !window.confirm(`Omit ${ids.size} selected transformation target${ids.size === 1 ? '' : 's'}?`)) return;
      rows(modal).filter(row => ids.has(row.dataset.decisionRow)).forEach(row => {
        const select = row.querySelector('[data-review-action]');
        if (select && [...select.options].some(option => option.value === value)) {
          select.value = value;
          select.dispatchEvent(new Event('change', { bubbles:true }));
        }
      });
      const notice = modal.querySelector('[data-studio-notice]') || document.createElement('div');
      notice.dataset.studioNotice = 'true'; notice.className = 'navi-universal-studio-notice'; notice.textContent = `Applied ${ids.size} bulk decision${ids.size === 1 ? '' : 's'}.`;
      if (!notice.isConnected) toolbar.after(notice);
      sync(modal);
    };
    modal.querySelectorAll('[data-review-filter]').forEach(button => button.addEventListener('click', () => requestAnimationFrame(() => sync(modal))));
    sync(modal);
  }

  function scan(root = document) {
    root.querySelectorAll?.('.navi-doc-import').forEach(enhance);
  }
  const observer = new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => {
    if (!(node instanceof Element)) return;
    const owningModal = node.matches('.navi-doc-import') ? node : node.closest('.navi-doc-import');
    if (owningModal) enhance(owningModal);
    scan(node);
  })));
  const install = () => { const input=document.getElementById('importFile');if(input)document.addEventListener('change',event=>{if(event.target===input)sourceContext.file=input.files?.[0]||null;},true);installParserBridges(); observer.observe(document.body, { childList:true, subtree:true }); scan(); window.NaviImportStudio = { version:VERSION, enhance, scan, captureSource }; };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once:true }); else install();
})();
