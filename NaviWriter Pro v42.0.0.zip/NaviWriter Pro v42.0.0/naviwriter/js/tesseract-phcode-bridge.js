/* NaviWriter Phoenix Code OCR compatibility bridge.
   Load after tesseract.min.js and before pdf-ocr-import.js. */
(() => {
  'use strict';

  const EMBEDDED_CORE = './js/vendor/tesseract/tesseract-core-lstm.wasm.min.js';
  const ENGLISH_MODEL = './js/vendor/tesseract/tessdata/eng.traineddata.gz';
  const STARTUP_LIMIT_MS = 35000;

  const absolute = path => new URL(path, document.baseURI).href;

  async function verifyAsset(url, label, signature) {
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error(`${label} returned HTTP ${response.status}.`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (!bytes.length) throw new Error(`${label} was empty.`);
    if (signature && !signature.every((value, index) => bytes[index] === value)) {
      throw new Error(`${label} did not contain the expected binary data.`);
    }
    return { url, bytes: bytes.length, type: response.headers.get('content-type') || 'unknown' };
  }

  function withTimeout(promise, milliseconds, message) {
    let timer = 0;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), milliseconds);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  async function preflight() {
    const results = {};
    const coreUrl = absolute(EMBEDDED_CORE);
    const modelUrl = absolute(ENGLISH_MODEL);

    const [core, model] = await Promise.all([
      verifyAsset(coreUrl, 'Embedded Tesseract core'),
      verifyAsset(modelUrl, 'English OCR model', [0x1f, 0x8b])
    ]);

    results.core = core;
    results.model = model;
    window.NaviOcrAssetDiagnostics = results;
    return results;
  }

  function install() {
    if (!window.Tesseract?.createWorker || window.Tesseract.__naviPhcodeBridge) return;

    const originalCreateWorker = window.Tesseract.createWorker.bind(window.Tesseract);
    window.Tesseract.createWorker = async function patchedCreateWorker(langs, oem, options = {}, config = {}) {
      const diagnostics = await withTimeout(
        preflight(),
        STARTUP_LIMIT_MS,
        'Phoenix Code could not read the local OCR core or English model.'
      );

      console.info('NaviWriter OCR preflight passed', diagnostics);
      const nextOptions = {
        ...options,
        corePath: absolute(EMBEDDED_CORE),
        langPath: absolute('./js/vendor/tesseract/tessdata'),
        gzip: true,
        workerBlobURL: true,
        errorHandler(error) {
          console.error('NaviWriter OCR worker error', error);
          options.errorHandler?.(error);
        }
      };

      return withTimeout(
        originalCreateWorker(langs, oem, nextOptions, config),
        STARTUP_LIMIT_MS,
        'Tesseract worker started but could not initialize the embedded OCR core. Phoenix Code may be blocking nested worker imports.'
      );
    };

    window.Tesseract.__naviPhcodeBridge = true;
    window.NaviOcrPhoenixBridge = {
      version: '1.0.0',
      preflight,
      embeddedCore: absolute(EMBEDDED_CORE),
      englishModel: absolute(ENGLISH_MODEL)
    };
  }

  install();
})();
