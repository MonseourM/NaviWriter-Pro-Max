// js/app.js
// NaviWriter app controller
// Wires together storage, editor, themes, autosave, and document UI.
// globals are up here hobo

let currentDocumentId = null;
let showResolvedInlineComments = false;
let commentsDrawerDragging = false;
let projectCommentsDragging = false;

const LAYOUT_MODE_KEY =
  'naviwriter-layout-mode';

let currentLayoutPreference =
  'auto';

let currentResolvedLayoutMode =
  'desktop';

let projectCommentsDragStart = {
  x: 0,
  y: 0
};

let projectCommentsStart = {
  x: 0,
  y: 0
};
let commentsDrawerDragStart = {
  x: 0,
  y: 0
};

let commentsDrawerStart = {
  x: 0,
  y: 0
};

const COMMENTS_DRAWER_POSITION_KEY =
  'naviwriter-comments-drawer-position';
let showOtherCustomMetadataFields = false;
let localGraphSelectedNodeId = null;
let localGraphMode = 'local';
let isBoardMinimapDragging = false;
let boardMinimapScale = 1;
let isBoardMinimapPanelDragging = false;


let boardMinimapPanelDragStart = {
  x: 0,
  y: 0
};

let boardMinimapPanelStart = {
  x: 0,
  y: 0
};

const BOARD_MINIMAP_POSITION_KEY =
  'naviwriter-board-minimap-position';
let localGraphNodeDragStart = {
  x: 0,
  y: 0
};

let localGraphSuppressNextNodeClick = false;
let localGraphData = {
  nodes: [],
  edges: []
};

let localGraphPositions = {};
let localGraphZoom = 1;
let localGraphPan = {
  x: 0,
  y: 0
};

let localGraphDragNodeId = null;
let localGraphDragOffset = {
  x: 0,
  y: 0
};

let localGraphIsPanning = false;
let localGraphPanStart = {
  x: 0,
  y: 0
};
let collectionsCache = [];
let pendingCollectionPickerSelectedIds = new Set();
let localGraphMinimapScale = 1;
let isLocalGraphMinimapDragging = false;
let editingSourceId = null;
let splitPaneDocId = null;
let splitOwnerDocumentId = null;
let splitPaneEditable = false;
let splitPaneAutosaveTimer = null;
const SPLIT_PANE_AUTOSAVE_DELAY = 700;
let documentsCache = [];
let activeFolderFilter = null;
let showFolderParentContext = false;
let activeCollectionId = null;
let autosaveTimer = null;
let currentProjectFileHandle = null;
let currentProjectFileName = '';
let projectFileAutosaveTimer = null;
let projectFileSaveInFlight = false;
let pendingCoverDocId = null;
let editingBoardLinkId = null;
let openDocumentRequestId = 0;
let pendingMessageResolve = null;
let pendingMatterPresetResolve = null;
let pendingChoiceResolve = null;
let pendingBoardLinkResolve = null;
let pendingBoardConnectionResolve = null;
let editingBoardConnectorId = null;
let retainedSourceViewerAssetId = null;
let retainedSourceViewerZoom = 1;
let retainedSourcePdf = null;
let retainedSourcePdfPage = 1;
let retainedSourcePdfRotation = 0;
let retainedSourceLastImportFile = null;
let retainedSourceViewerDocumentId = null;
let referenceWorkspaceMode = 'viewer';
let pendingAttachmentMetadataItem = null;
let pendingTextInputResolve = null;
let pendingConfirmResolve = null;
let pendingMatterPresetKind = '';
let editingBoardPersonId = null;
const PROJECT_FILE_AUTOSAVE_KEY =
  'naviwriter-project-file-autosave-minutes';
let isSaving = false;
let sessionStartWords = 0;
let currentGoal = 0;
let temporaryGoalSession = null;
let activeStatsScope = 'current';
let collapsedDocIds = new Set();
let pendingPdfParentId = null;
let isLoadingDocument = false;
let currentBoardData = {
  items: [],
  connectors: [],
  canvas: {
    width: 5000,
    height: 3500
  }
};
let activeBoardItemId = null;
let selectedBoardItemIds = new Set();
let boardConnectMode = false;
let boardConnectStartId = null;
let boardZoom = 1;
let boardUndoStack = [];
let boardRedoStack = [];
const BOARD_UNDO_LIMIT = 50;
const AUTOSAVE_DELAY = 900;
const els = {};
const COLLECTIONS_KEY = 'naviwriter-collections';
const RELATIONSHIP_ENTITY_TYPES = [
  'document',
  'folder',
  'collection',
  'source',

  // future
  'tag',
  'customField',
  'boardItem',
  'relationshipType'
];

const DEFAULT_RELATIONSHIP_TYPES = [
  'related',
  'references',
  'supports',
  'foreshadows',
  'continues',
  'contradicts',
  'contains lore for'
];

const RELATIONSHIP_TYPES_KEY = 'naviwriter-relationship-types';

const RELATIONSHIPS_KEY = 'naviwriter-relationships';

const CUSTOM_METADATA_FIELDS_KEY =
  'naviwriter-custom-metadata-fields';

const OUTLINER_CUSTOM_METADATA_COLUMNS_KEY =
  'naviwriter-outliner-custom-metadata-columns';

const CUSTOM_METADATA_FIELD_TYPES = [
  'text',
  'longText',
  'dropdown',
  'checkbox',
  'number',
  'date'
];

let relationshipsCache = [];

// globals end here boi. please for the love of god dont put globals below this unless absloutley necessary

async function renderRelationshipPanel(docId) {
  if (!docId) {
    if (els.relationshipOutgoing) {
      els.relationshipOutgoing.innerHTML =
        '<div class="empty-note relationship-empty">Open a document to review relationships.</div>';
    }
    if (els.relationshipBacklinks) {
      els.relationshipBacklinks.innerHTML =
        '<div class="empty-note relationship-empty">Open a document to review references.</div>';
    }
    return;
  }

  try {
    relationshipsCache = await getRelationships();
    await Promise.all([
      renderOutgoingRelationships(docId),
      renderBacklinks(docId)
    ]);

    if (
      els.relationshipDashboardModal &&
      !els.relationshipDashboardModal.classList.contains('hidden')
    ) {
      await renderRelationshipDashboard();
    }

    if (
      els.localGraphModal &&
      !els.localGraphModal.classList.contains('hidden')
    ) {
      await refreshLocalGraphData({ keepLayout: true });
    }
  } catch (error) {
    console.error('Relationship panel render failed:', error);
    window.NaviDiagnostics?.report?.({
      severity: 'error',
      subsystem: 'Relationships',
      message: error?.message || String(error),
      error,
      recovered: true
    });

    const message =
      '<div class="empty-note relationship-empty">Relationships could not be refreshed. See Diagnostics for details.</div>';
    if (els.relationshipOutgoing) els.relationshipOutgoing.innerHTML = message;
    if (els.relationshipBacklinks) els.relationshipBacklinks.innerHTML = message;
  }
}
window.NaviDiagnosticsContext={currentDocumentId:()=>currentDocumentId};
function $(id) {
  return document.getElementById(id);
}

function syncBoardModeBarState() {
  if (!els.boardModeBar) {
    return;
  }

  const boardIsActive =
    els.boardSurface &&
    !els.boardSurface.classList.contains('hidden');

  els.boardModeBar.classList.toggle(
    'is-board-mode',
    boardIsActive
  );
  document.getElementById('addBoardAudioBtn')?.toggleAttribute('hidden',!boardIsActive);
}



async function handleNewManuscript() {
  const title = await openTextInputModal({
    title: 'New Manuscript',
    message: 'Name this manuscript project.',
    label: 'Manuscript title',
    defaultValue: 'Untitled Manuscript',
    placeholder: 'Untitled Manuscript',
    submitText: 'Create Manuscript'
  });

  if (!title || !title.trim()) return;

  const cleanTitle = title.trim();

  const manuscript =
    NaviStorage.createBlankDocument(cleanTitle);

  manuscript.docType = 'manuscript';
  manuscript.content =
    `<h1>${escapeHtml(cleanTitle)}</h1>` +
    '<p>Manuscript overview...</p>';
  manuscript.plainText =
    `${cleanTitle} Manuscript overview...`;
  manuscript.wordCount =
    NaviEditor.countWords(manuscript.plainText);
  manuscript.charCount =
    manuscript.plainText.length;

  const savedManuscript =
    await NaviStorage.saveDocument(manuscript);

  const chapter =
    NaviStorage.createBlankDocument('Chapter 1');

  chapter.parentId = savedManuscript.id;
  chapter.docType = 'chapter';
  chapter.content = '<h1>Chapter 1</h1><p></p>';
  chapter.plainText = 'Chapter 1';
  chapter.wordCount = NaviEditor.countWords(chapter.plainText);
  chapter.charCount = chapter.plainText.length;

  await NaviStorage.saveDocument(chapter);

  await loadDocuments();
  await openDocument(savedManuscript.id);
}

function cacheElements() {
  els.newDocBtn = $('newDocBtn');
  els.duplicateDocBtn = $('duplicateDocBtn');
  els.renameDocBtn = $('renameDocBtn');
  els.deleteDocBtn = $('deleteDocBtn');
  els.importBtn = $('importBtn');
  els.exportCurrentNaviDocBtn = $('exportCurrentNaviDocBtn');
  els.exportSelect = $('exportSelect');
els.focusBtn = $('focusBtn');
els.exitFocusBtn = $('exitFocusBtn');

  els.docSearch = $('docSearch');
  els.documentList = $('documentList');
  els.docCount = $('docCount');

  els.docTitle = $('docTitle');
  els.editor = $('editor');

  els.importFile = $('importFile');
  els.findInput = $('findInput');
  els.replaceInput = $('replaceInput');
  els.findNextBtn = $('findNextBtn');
  els.replaceBtn = $('replaceBtn');
  els.replaceAllBtn = $('replaceAllBtn');

  els.outlineList = $('outlineList');

  els.goalInput = $('goalInput');
  els.temporaryGoalScopeSelect = $('temporaryGoalScopeSelect');
  els.temporaryGoalScopeSummary = $('temporaryGoalScopeSummary');
  els.clearTemporaryGoalBtn = $('clearTemporaryGoalBtn');
  els.statsScopeSelect = $('statsScopeSelect');
  els.statsScopeSummary = $('statsScopeSummary');
  els.saveGoalBtn = $('saveGoalBtn');
  els.goalProgress = $('goalProgress');
  els.goalBarFill = $('goalBarFill');

  els.statWords = $('statWords');
  els.statChars = $('statChars');
  els.statParagraphs = $('statParagraphs');
  els.statHeadings = $('statHeadings');
  els.statReadingTime = $('statReadingTime');
  els.statSessionWords = $('statSessionWords');

  els.folderInput = $('folderInput');
  els.tagsInput = $('tagsInput');
  els.saveMetaBtn = $('saveMetaBtn');
  
  els.applyStatusToSubdocsBtn = $('applyStatusToSubdocsBtn');
  
  els.docStatusSelect = $('docStatusSelect');
els.docPovInput = $('docPovInput');
els.docLocationInput = $('docLocationInput');
els.docTimelineInput = $('docTimelineInput');
els.docCharactersInput = $('docCharactersInput');
els.docSummaryInput = $('docSummaryInput');

  els.recentDocsList = $('recentDocsList');

  els.topWordsList = $('topWordsList');
  els.topPhrasesList = $('topPhrasesList');
  els.headingCountsList = $('headingCountsList');

  els.longGoalWordsInput = $('longGoalWordsInput');
  els.longGoalDateInput = $('longGoalDateInput');
  els.longGoalScopeSelect = $('longGoalScopeSelect');
  els.longGoalScopeSummary = $('longGoalScopeSummary');
  els.saveLongGoalBtn = $('saveLongGoalBtn');
  els.clearLongGoalBtn = $('clearLongGoalBtn');
  els.longGoalOutput = $('longGoalOutput');
  els.longGoalRing = $('longGoalRing');
  els.longGoalRingValue = $('longGoalRingValue');
  els.dailyGoalRing = $('dailyGoalRing');
  els.dailyGoalRingValue = $('dailyGoalRingValue');

  els.dailyGoalOutput = $('dailyGoalOutput');
els.dailyGoalBarFill = $('dailyGoalBarFill');

  els.insertEndnoteBtn = $('insertEndnoteBtn');
  els.splitDocBtn = $('splitDocBtn');
  els.toggleInspectorSectionsBtn = $('toggleInspectorSectionsBtn');
  
  els.exportProjectBackupBtn = $('exportProjectBackupBtn');
els.importProjectBackupBtn = $('importProjectBackupBtn');
els.projectBackupInput = $('projectBackupInput');
  
  els.openProjectFileBtn = $('openProjectFileBtn');
els.saveProjectAsBtn = $('saveProjectAsBtn');
els.saveProjectFileBtn = $('saveProjectFileBtn');
els.projectAutosaveSelect = $('projectAutosaveSelect');
  
  els.takeSnapshotBtn = $('takeSnapshotBtn');
els.snapshotHistoryBtn = $('snapshotHistoryBtn');
els.snapshotModal = $('snapshotModal');
els.closeSnapshotModalBtn = $('closeSnapshotModalBtn');
els.snapshotList = $('snapshotList');

  els.importPdfBtn = $('importPdfBtn');
  els.pdfInput = $('pdfInput');

els.newSubDocBtn = $('newSubDocBtn');
  
  els.openSidebarDrawerBtn =
  $('openSidebarDrawerBtn');

els.openInspectorDrawerBtn =
  $('openInspectorDrawerBtn');

els.closeSidebarDrawerBtn =
  $('closeSidebarDrawerBtn');

els.closeInspectorDrawerBtn =
  $('closeInspectorDrawerBtn');

els.responsiveOverlay =
  $('responsiveOverlay');

  els.newManuscriptBtn = $('newManuscriptBtn');

  els.analysisScopeSelect = $('analysisScopeSelect');

els.findPanel = $('findPanel');
els.closeFindPanelBtn = $('closeFindPanelBtn');
els.floatingFindInput = $('floatingFindInput');
els.floatingReplaceInput = $('floatingReplaceInput');
els.floatingFindBtn = $('floatingFindBtn');
els.floatingReplaceSelectedBtn = $('floatingReplaceSelectedBtn');
els.floatingReplaceAllBtn = $('floatingReplaceAllBtn');
els.findResultsSummary = $('findResultsSummary');
  els.findResultsList = $('findResultsList');
  els.floatingFindScopeSelect = $('floatingFindScopeSelect');
  els.floatingFindMatchCase = $('floatingFindMatchCase');
  els.floatingFindWholeWord = $('floatingFindWholeWord');

  els.subdocTypeModal = $('subdocTypeModal');
  els.closeSubdocModalBtn = $('closeSubdocModalBtn');

els.pdfSubdocModal = $('pdfSubdocModal');
els.closePdfSubdocModalBtn = $('closePdfSubdocModalBtn');
els.pdfUploadNewBtn = $('pdfUploadNewBtn');
els.pdfBlankNoteBtn = $('pdfBlankNoteBtn');
els.existingPdfList = $('existingPdfList');

els.boardModeBar = $('boardModeBar');
els.writeModeBtn = $('writeModeBtn');
els.boardModeBtn = $('boardModeBtn');
els.boardSurface = $('boardSurface');
els.addBoardNoteBtn = $('addBoardNoteBtn');
els.addBoardImageBtn = $('addBoardImageBtn');
els.addBoardLinkBtn = $('addBoardLinkBtn');
  els.boardImageInput = $('boardImageInput');

els.addBoardPersonBtn = $('addBoardPersonBtn');
  els.exportBoardBtn = $('exportBoardBtn');

els.connectBoardItemsBtn = $('connectBoardItemsBtn');
els.zoomOutBoardBtn = $('zoomOutBoardBtn');
els.zoomInBoardBtn = $('zoomInBoardBtn');
  els.boardZoomLabel = $('boardZoomLabel');

els.colorBoardItemBtn = $('colorBoardItemBtn');

  els.undoBoardBtn = $('undoBoardBtn');

els.redoBoardBtn = $('redoBoardBtn');
  
  els.projectFileStatus = $('projectFileStatus');
  
  els.compileIncludeFrontMatter = $('compileIncludeFrontMatter');
els.compileIncludeBackMatter = $('compileIncludeBackMatter');
  els.compileExportBtn = $('compileExportBtn');
els.compileModal = $('compileModal');
els.closeCompileModalBtn = $('closeCompileModalBtn');
els.cancelCompileBtn = $('cancelCompileBtn');
els.runCompileBtn = $('runCompileBtn');
els.compileFormatSelect = $('compileFormatSelect');
els.compilePreviewList = $('compilePreviewList');
els.compileIncludeTitles = $('compileIncludeTitles');
els.compilePageBreaks = $('compilePageBreaks');
els.compileIncludeNotes = $('compileIncludeNotes');
els.compileIncludeResearch = $('compileIncludeResearch');
els.compileIncludePdf = $('compileIncludePdf');
  els.coverImageInput = $('coverImageInput');
  
  els.compileIncludeCover = $('compileIncludeCover');
  
  els.projectTitleInput = $('projectTitleInput');
els.projectSubtitleInput = $('projectSubtitleInput');
els.projectAuthorInput = $('projectAuthorInput');
els.saveProjectMetaBtn = $('saveProjectMetaBtn');

els.compileIncludeCover = $('compileIncludeCover');
els.compileIncludeBodyMatter = $('compileIncludeBodyMatter');
  
  els.matterPresetModal = $('matterPresetModal');
els.matterPresetTitle = $('matterPresetTitle');
els.matterPresetSubtitle = $('matterPresetSubtitle');
els.matterPresetGrid = $('matterPresetGrid');
els.closeMatterPresetModalBtn = $('closeMatterPresetModalBtn');
  
  els.textInputModal = $('textInputModal');
els.textInputModalTitle = $('textInputModalTitle');
els.textInputModalMessage = $('textInputModalMessage');
els.textInputModalLabel = $('textInputModalLabel');
els.textInputModalField = $('textInputModalField');
els.closeTextInputModalBtn = $('closeTextInputModalBtn');
els.cancelTextInputModalBtn = $('cancelTextInputModalBtn');
els.submitTextInputModalBtn = $('submitTextInputModalBtn');

els.confirmModal = $('confirmModal');
els.confirmModalTitle = $('confirmModalTitle');
els.confirmModalMessage = $('confirmModalMessage');
els.closeConfirmModalBtn = $('closeConfirmModalBtn');
els.cancelConfirmModalBtn = $('cancelConfirmModalBtn');
els.submitConfirmModalBtn = $('submitConfirmModalBtn');
  
  els.printPageSizeSelect = $('printPageSizeSelect');
els.printStyleSelect = $('printStyleSelect');
els.printFontSelect = $('printFontSelect');
els.printMarginsSelect = $('printMarginsSelect');
els.printAutoTitlePage = $('printAutoTitlePage');
  
  els.messageModal = $('messageModal');
els.messageModalTitle = $('messageModalTitle');
els.messageModalText = $('messageModalText');
els.closeMessageModalBtn = $('closeMessageModalBtn');
els.okMessageModalBtn = $('okMessageModalBtn');
  
  els.boardPersonModal = $('boardPersonModal');
els.closeBoardPersonModalBtn = $('closeBoardPersonModalBtn');
els.cancelBoardPersonModalBtn = $('cancelBoardPersonModalBtn');
els.submitBoardPersonModalBtn = $('submitBoardPersonModalBtn');
els.boardPersonNameInput = $('boardPersonNameInput');
els.boardPersonRoleInput = $('boardPersonRoleInput');
els.boardPersonNotesInput = $('boardPersonNotesInput');
  
  els.choiceModal = $('choiceModal');
els.choiceModalTitle = $('choiceModalTitle');
els.choiceModalSubtitle = $('choiceModalSubtitle');
els.choiceModalGrid = $('choiceModalGrid');
els.closeChoiceModalBtn = $('closeChoiceModalBtn');

els.boardLinkModal = $('boardLinkModal');
els.closeBoardLinkModalBtn = $('closeBoardLinkModalBtn');
els.cancelBoardLinkModalBtn = $('cancelBoardLinkModalBtn');
els.submitBoardLinkModalBtn = $('submitBoardLinkModalBtn');
els.boardLinkTitleInput = $('boardLinkTitleInput');
els.boardLinkUrlInput = $('boardLinkUrlInput');

els.boardConnectionModal = $('boardConnectionModal');
els.closeBoardConnectionModalBtn = $('closeBoardConnectionModalBtn');
els.cancelBoardConnectionModalBtn = $('cancelBoardConnectionModalBtn');
els.submitBoardConnectionModalBtn = $('submitBoardConnectionModalBtn');
els.boardConnectionLabelInput = $('boardConnectionLabelInput');
els.boardConnectionTypeSelect = $('boardConnectionTypeSelect');
els.boardConnectionColorInput = $('boardConnectionColorInput');
els.boardConnectionWidthInput = $('boardConnectionWidthInput');
els.boardConnectionWidthOutput = $('boardConnectionWidthOutput');
els.boardConnectionDirectionSelect = $('boardConnectionDirectionSelect');
els.boardConnectionFromSelect = $('boardConnectionFromSelect');
els.boardConnectionToSelect = $('boardConnectionToSelect');
els.reverseBoardConnectionBtn = $('reverseBoardConnectionBtn');
els.deleteBoardConnectionBtn = $('deleteBoardConnectionBtn');
els.addBoardDocumentViewBtn = $('addBoardDocumentViewBtn');
els.retainedSourceInput = $('retainedSourceInput');
els.retainedSourceViewerModal = $('retainedSourceViewerModal');
els.retainedSourceViewerTitle = $('retainedSourceViewerTitle');
els.retainedSourceViewerMeta = $('retainedSourceViewerMeta');
els.retainedSourceStage = $('retainedSourceStage');
els.attachmentMetadataModal=$('attachmentMetadataModal');els.attachmentDisplayTitleInput=$('attachmentDisplayTitleInput');els.attachmentDescriptionInput=$('attachmentDescriptionInput');
  
  els.bookThemeSelect = $('bookThemeSelect');

els.compileProfileSelect = $('compileProfileSelect');
els.applyCompileProfileBtn = $('applyCompileProfileBtn');
els.saveCompileProfileBtn = $('saveCompileProfileBtn');
els.deleteCompileProfileBtn = $('deleteCompileProfileBtn');
  
  els.duplicateBoardItemBtn = $('duplicateBoardItemBtn');
els.bringBoardItemFrontBtn = $('bringBoardItemFrontBtn');
els.sendBoardItemBackBtn = $('sendBoardItemBackBtn');
els.familyConnectorBtn = $('familyConnectorBtn');
els.resetBoardZoomBtn = $('resetBoardZoomBtn');
  
  els.decreaseBoardFontBtn = $('decreaseBoardFontBtn');
els.increaseBoardFontBtn = $('increaseBoardFontBtn');
els.resetBoardFontBtn = $('resetBoardFontBtn');
  
  els.openOutlinerBtn = $('openOutlinerBtn');
els.outlinerModal = $('outlinerModal');
els.closeOutlinerModalBtn = $('closeOutlinerModalBtn');
els.outlinerScopeSelect = $('outlinerScopeSelect');
els.outlinerSearchInput = $('outlinerSearchInput');
els.refreshOutlinerBtn = $('refreshOutlinerBtn');
els.outlinerTableBody = $('outlinerTableBody');
  
  els.outlinerStatusFilterSelect = $('outlinerStatusFilterSelect');
els.outlinerTypeFilterSelect = $('outlinerTypeFilterSelect');
els.outlinerFolderFilterSelect = $('outlinerFolderFilterSelect');
els.outlinerSortSelect = $('outlinerSortSelect');
  
  els.workspace = document.querySelector('.workspace');

els.openSplitEditorBtn = $('openSplitEditorBtn');
els.splitPane = $('splitPane');
els.closeSplitEditorBtn = $('closeSplitEditorBtn');
els.splitDocSelect = $('splitDocSelect');
els.splitDocSearch = $('splitDocSearch');
els.splitDocMeta = $('splitDocMeta');
els.splitDocContent = $('splitDocContent');
els.openSplitDocAsMainBtn = $('openSplitDocAsMainBtn');
  
  els.editSplitPaneBtn =
  $('editSplitPaneBtn');

els.saveSplitPaneBtn =
  $('saveSplitPaneBtn');
  
  els.splitResizeHandle = $('splitResizeHandle');
  
  els.sourcesModeBtn = $('sourcesModeBtn');
els.sourcesPanel = $('sourcesPanel');
els.addSourceBtn = $('addSourceBtn');
els.sourcesList = $('sourcesList');

els.sourceModal = $('sourceModal');
els.sourceModalTitle = $('sourceModalTitle');
els.closeSourceModalBtn = $('closeSourceModalBtn');
els.cancelSourceModalBtn = $('cancelSourceModalBtn');
els.submitSourceModalBtn = $('submitSourceModalBtn');

els.sourceTitleInput = $('sourceTitleInput');
els.sourceUrlInput = $('sourceUrlInput');
els.sourceAuthorInput = $('sourceAuthorInput');
els.sourceDateInput = $('sourceDateInput');
els.sourceTagsInput = $('sourceTagsInput');
els.sourceNotesInput = $('sourceNotesInput');
  
  els.openCollectionsBtn = $('openCollectionsBtn');
els.collectionsModal = $('collectionsModal');
els.closeCollectionsModalBtn = $('closeCollectionsModalBtn');
els.newCollectionBtn = $('newCollectionBtn');
els.addCurrentDocToCollectionBtn = $('addCurrentDocToCollectionBtn');
els.collectionsList = $('collectionsList');
els.collectionDetailTitle = $('collectionDetailTitle');
els.collectionDetailMeta = $('collectionDetailMeta');
els.collectionDocsList = $('collectionDocsList');
els.renameCollectionBtn = $('renameCollectionBtn');
els.deleteCollectionBtn = $('deleteCollectionBtn');
  
  els.addDocsToCollectionBtn = $('addDocsToCollectionBtn');

els.collectionDocPickerModal = $('collectionDocPickerModal');
els.collectionPickerSubtitle = $('collectionPickerSubtitle');
els.closeCollectionDocPickerBtn = $('closeCollectionDocPickerBtn');
els.cancelCollectionDocPickerBtn = $('cancelCollectionDocPickerBtn');
els.submitCollectionDocPickerBtn = $('submitCollectionDocPickerBtn');
els.collectionDocPickerSearch = $('collectionDocPickerSearch');
els.collectionDocPickerTypeFilter = $('collectionDocPickerTypeFilter');
els.collectionDocPickerList = $('collectionDocPickerList');
  
  els.relationshipOutgoing = $('relationshipOutgoing');

els.relationshipBacklinks = $('relationshipBacklinks');
  
  els.createRelationshipBtn = $('createRelationshipBtn');

els.relationshipModal = $('relationshipModal');
els.closeRelationshipModalBtn = $('closeRelationshipModalBtn');
els.cancelRelationshipModalBtn = $('cancelRelationshipModalBtn');
els.submitRelationshipModalBtn = $('submitRelationshipModalBtn');

els.relationshipTargetTypeSelect = $('relationshipTargetTypeSelect');
els.relationshipTargetSelect = $('relationshipTargetSelect');
els.relationshipTypeSelect = $('relationshipTypeSelect');
els.relationshipStrengthSelect = $('relationshipStrengthSelect');
els.relationshipNoteInput = $('relationshipNoteInput');
  
  els.outlinerViewSelect = $('outlinerViewSelect');
  
  els.manageRelationshipTypesBtn =
  $('manageRelationshipTypesBtn');

els.relationshipTypesModal =
  $('relationshipTypesModal');

els.closeRelationshipTypesModalBtn =
  $('closeRelationshipTypesModalBtn');

els.cancelRelationshipTypesModalBtn =
  $('cancelRelationshipTypesModalBtn');

els.relationshipTypesList =
  $('relationshipTypesList');

els.relationshipTypeNameInput =
  $('relationshipTypeNameInput');

els.addRelationshipTypeBtn =
  $('addRelationshipTypeBtn');
  
  els.outlinerShowExplicitRelationships =
  $('outlinerShowExplicitRelationships');

els.outlinerShowCollectionRelationships =
  $('outlinerShowCollectionRelationships');

els.outlinerShowFolderRelationships =
  $('outlinerShowFolderRelationships');
  
  els.outlinerShowSourceRelationships =
  $('outlinerShowSourceRelationships');

els.outlinerShowTagRelationships =
  $('outlinerShowTagRelationships');
  
  els.openLocalGraphBtn =
  $('openLocalGraphBtn');

els.localGraphModal =
  $('localGraphModal');

els.closeLocalGraphModalBtn =
  $('closeLocalGraphModalBtn');

els.localGraphSubtitle =
  $('localGraphSubtitle');

els.localGraphSurface =
  $('localGraphSurface');

els.localGraphViewport =
  $('localGraphViewport');

els.localGraphEdges =
  $('localGraphEdges');

els.localGraphNodes =
  $('localGraphNodes');

els.localGraphZoomOutBtn =
  $('localGraphZoomOutBtn');

els.localGraphZoomInBtn =
  $('localGraphZoomInBtn');

els.localGraphZoomLabel =
  $('localGraphZoomLabel');

els.localGraphResetBtn =
  $('localGraphResetBtn');
  
  els.localGraphShowExplicit =
  $('localGraphShowExplicit');

els.localGraphShowCollections =
  $('localGraphShowCollections');

els.localGraphShowFolders =
  $('localGraphShowFolders');

els.localGraphShowSources =
  $('localGraphShowSources');

els.localGraphShowTags =
  $('localGraphShowTags');
  
  els.localGraphDetailsPanel =
  $('localGraphDetailsPanel');

els.localGraphDetailsTitle =
  $('localGraphDetailsTitle');

els.localGraphDetailsMeta =
  $('localGraphDetailsMeta');

els.localGraphDetailsBody =
  $('localGraphDetailsBody');

els.closeLocalGraphDetailsBtn =
  $('closeLocalGraphDetailsBtn');

els.centerLocalGraphNodeBtn =
  $('centerLocalGraphNodeBtn');

els.openLocalGraphNodeBtn =
  $('openLocalGraphNodeBtn');
  
  els.openRelationshipDashboardBtn =
  $('openRelationshipDashboardBtn');

els.relationshipDashboardModal =
  $('relationshipDashboardModal');

els.closeRelationshipDashboardBtn =
  $('closeRelationshipDashboardBtn');

els.refreshRelationshipDashboardBtn =
  $('refreshRelationshipDashboardBtn');

els.openOutlinerFromDashboardBtn =
  $('openOutlinerFromDashboardBtn');

els.relationshipDashboardSubtitle =
  $('relationshipDashboardSubtitle');

els.relationshipDashboardBody =
  $('relationshipDashboardBody');
  
  els.openGlobalGraphBtn =
  $('openGlobalGraphBtn');
  
  els.localGraphTitle =
  $('localGraphTitle');
  
  els.showBoardMinimapBtn =
  $('showBoardMinimapBtn');

els.boardMinimap =
  $('boardMinimap');

els.toggleBoardMinimapBtn =
  $('toggleBoardMinimapBtn');

els.boardMinimapBody =
  $('boardMinimapBody');

els.boardMinimapWorld =
  $('boardMinimapWorld');

els.boardMinimapViewport =
  $('boardMinimapViewport');
  
  els.localGraphMinimap =
  $('localGraphMinimap');

els.toggleLocalGraphMinimapBtn =
  $('toggleLocalGraphMinimapBtn');

els.localGraphMinimapBody =
  $('localGraphMinimapBody');

els.localGraphMinimapWorld =
  $('localGraphMinimapWorld');

els.localGraphMinimapViewport =
  $('localGraphMinimapViewport');
  
  els.documentMapPanel =
  $('documentMapPanel');

els.documentMapList =
  $('documentMapList');

els.refreshDocumentMapBtn =
  $('refreshDocumentMapBtn');
  
  els.manageCustomMetadataFieldsBtn =
  $('manageCustomMetadataFieldsBtn');

els.customMetadataFieldsModal =
  $('customMetadataFieldsModal');

els.closeCustomMetadataFieldsModalBtn =
  $('closeCustomMetadataFieldsModalBtn');

els.customMetadataFieldNameInput =
  $('customMetadataFieldNameInput');

els.customMetadataFieldTypeSelect =
  $('customMetadataFieldTypeSelect');

els.customMetadataOptionsWrap =
  $('customMetadataOptionsWrap');

els.customMetadataFieldOptionsInput =
  $('customMetadataFieldOptionsInput');
els.customMetadataFieldOrderInput = $('customMetadataFieldOrderInput');
els.customMetadataFieldVisibleInput = $('customMetadataFieldVisibleInput');
els.customMetadataConversionNote = $('customMetadataConversionNote');
els.tagChipInput = $('tagChipInput');
els.tagChipList = $('tagChipList');
els.tagSuggestions = $('tagSuggestions');
els.detailsSaveFeedback = $('detailsSaveFeedback');

els.addCustomMetadataFieldBtn =
  $('addCustomMetadataFieldBtn');

els.customMetadataFieldsList =
  $('customMetadataFieldsList');

els.customMetadataFieldsCount =
  $('customMetadataFieldsCount');
  
  els.manageCustomMetadataFieldsInlineBtn =
  $('manageCustomMetadataFieldsInlineBtn');

els.customMetadataValuesList =
  $('customMetadataValuesList');
  
  els.manageOutlinerCustomColumnsBtn =
  $('manageOutlinerCustomColumnsBtn');

els.outlinerCustomColumnsModal =
  $('outlinerCustomColumnsModal');

els.closeOutlinerCustomColumnsBtn =
  $('closeOutlinerCustomColumnsBtn');

els.outlinerCustomColumnsList =
  $('outlinerCustomColumnsList');
  
  els.addInlineCommentBtn =
  $('addInlineCommentBtn');

els.inlineCommentsSummary =
  $('inlineCommentsSummary');

els.openCommentsDrawerBtn =
  $('openCommentsDrawerBtn');

els.commentsDrawer =
  $('commentsDrawer');

els.commentsDrawerHead =
  $('commentsDrawerHead');

els.commentsDrawerSubtitle =
  $('commentsDrawerSubtitle');

els.commentsDrawerList =
  $('commentsDrawerList');

els.closeCommentsDrawerBtn =
  $('closeCommentsDrawerBtn');

els.toggleResolvedCommentsBtn =
  $('toggleResolvedCommentsBtn');
  
  els.toggleResolvedCommentsBtn =
  $('toggleResolvedCommentsBtn');
  
  els.renameSplitPaneDocBtn =
  $('renameSplitPaneDocBtn');
  
  els.openProjectCommentsBtn =
  $('openProjectCommentsBtn');

els.projectCommentsPanel =
  $('projectCommentsPanel');

els.projectCommentsSummary =
  $('projectCommentsSummary');

els.projectCommentsList =
  $('projectCommentsList');

els.closeProjectCommentsBtn =
  $('closeProjectCommentsBtn');
  
  els.projectCommentsPanelHead =
  $('projectCommentsPanelHead');
  
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/'/g, '&#39;')
    .replace(/"/g, '&quot;');
}

function normalizeCustomMetadataFieldType(type = 'text') {
  const cleanType =
    String(type || 'text').trim();

  return CUSTOM_METADATA_FIELD_TYPES.includes(cleanType)
    ? cleanType
    : 'text';
}

function normalizeCustomMetadataFieldName(value = '') {
  return String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, 64);
}

function parseCustomMetadataOptions(value = '') {
  return String(value || '')
    .split('\n')
    .map(option => {
      return option.trim();
    })
    .filter(Boolean)
    .filter((option, index, list) => {
      return list.indexOf(option) === index;
    })
    .slice(0, 60);
}

function getCustomMetadataFieldTypeLabel(type = 'text') {
  if (type === 'text') return 'Text';
  if (type === 'longText') return 'Long Text';
  if (type === 'dropdown') return 'Dropdown';
  if (type === 'checkbox') return 'Checkbox';
  if (type === 'number') return 'Number';
  if (type === 'date') return 'Date';

  return 'Text';
}

function loadCommentsDrawerPosition() {
  try {
    const raw =
      localStorage.getItem(
        COMMENTS_DRAWER_POSITION_KEY
      );

    return raw
      ? JSON.parse(raw)
      : null;
  } catch {
    return null;
  }
}

function saveCommentsDrawerPosition() {
  if (!els.commentsDrawer) {
    return;
  }

  try {
    localStorage.setItem(
      COMMENTS_DRAWER_POSITION_KEY,
      JSON.stringify({
        x: Number.parseFloat(
          els.commentsDrawer.style.left || '0'
        ),
        y: Number.parseFloat(
          els.commentsDrawer.style.top || '0'
        )
      })
    );
  } catch {}
}

function clampCommentsDrawerPosition(x, y) {
  if (!els.commentsDrawer) {
    return {
      x,
      y
    };
  }

  const width =
    els.commentsDrawer.offsetWidth || 380;

  const height =
    els.commentsDrawer.offsetHeight || 520;

  return {
    x:
      Math.max(
        8,
        Math.min(
          x,
          window.innerWidth - width - 8
        )
      ),

    y:
      Math.max(
        8,
        Math.min(
          y,
          window.innerHeight - height - 8
        )
      )
  };
}

function placeCommentsDrawerDefaultIfNeeded() {
  if (!els.commentsDrawer) {
    return;
  }

  const saved =
    loadCommentsDrawerPosition();

  if (saved) {
    const pos =
      clampCommentsDrawerPosition(
        Number(saved.x || 0),
        Number(saved.y || 0)
      );

    els.commentsDrawer.style.left =
      `${pos.x}px`;

    els.commentsDrawer.style.top =
      `${pos.y}px`;

    return;
  }

  const width =
    els.commentsDrawer.offsetWidth || 380;

  const pos =
    clampCommentsDrawerPosition(
      window.innerWidth - width - 22,
      86
    );

  els.commentsDrawer.style.left =
    `${pos.x}px`;

  els.commentsDrawer.style.top =
    `${pos.y}px`;
}

function getInlineCommentCounts(comments = []) {
  const open =
    comments.filter(comment => {
      return !comment.resolved;
    }).length;

  const resolved =
    comments.filter(comment => {
      return comment.resolved;
    }).length;

  return {
    open,
    resolved,
    total:
      comments.length
  };
}

function getAllProjectInlineComments() {
  return documentsCache.flatMap(doc => {
    const comments =
      Array.isArray(doc.inlineComments)
        ? doc.inlineComments
        : [];

    return comments.map(comment => ({
      ...comment,
      documentId: doc.id,
      documentTitle:
        doc.title ||
        'Untitled Document'
    }));
  });
}

function renderProjectCommentsPanel() {
  if (
    !els.projectCommentsList
  ) {
    return;
  }

  const comments =
    getAllProjectInlineComments();

  const open =
    comments.filter(
      comment => !comment.resolved
    );

  const resolved =
    comments.filter(
      comment => comment.resolved
    );

  els.projectCommentsSummary.textContent =
    `${open.length} open · ${resolved.length} resolved`;

  if (!comments.length) {
    els.projectCommentsList.innerHTML =
      '<div class="empty-note">No comments yet.</div>';
    return;
  }

  const sorted =
    comments
      .slice()
      .sort((a, b) => {
        if (a.resolved !== b.resolved) {
          return a.resolved ? 1 : -1;
        }

        return (
          Number(b.createdAt || 0) -
          Number(a.createdAt || 0)
        );
      });

  els.projectCommentsList.innerHTML = '';

  sorted.forEach(comment => {
    const card =
      document.createElement('article');

    card.className =
      'project-comment-card';

    card.innerHTML = `
      <div class="project-comment-doc">
        ${escapeHtml(
          comment.documentTitle
        )}
      </div>

      <div class="project-comment-quote">
        "${escapeHtml(
          comment.quote || ''
        )}"
      </div>

      <div class="project-comment-note">
        ${escapeHtml(
          comment.note || ''
        )}
      </div>

      <div class="project-comment-actions">
        <button
          data-project-comment-jump="${escapeHtml(comment.id)}"
          data-project-comment-doc="${escapeHtml(comment.documentId)}"
        >
          Jump
        </button>
      </div>
    `;

    card
      .querySelector(
        '[data-project-comment-jump]'
      )
      ?.addEventListener(
        'click',
        async event => {
          const button =
            event.currentTarget;

          await openDocument(
            button.dataset.projectCommentDoc
          );

          setTimeout(() => {
            jumpToInlineComment(
              button.dataset.projectCommentJump
            );
          }, 120);
        }
      );

    els.projectCommentsList.appendChild(
      card
    );
  });
}

function openProjectCommentsPanel() {
  if (!els.projectCommentsPanel) {
    return;
  }

  renderProjectCommentsPanel();

 els.projectCommentsPanel.classList.remove(
  'hidden'
);

if (
  !els.projectCommentsPanel.style.left
) {
  els.projectCommentsPanel.style.left =
    '80px';

  els.projectCommentsPanel.style.top =
    '80px';
}
}

function closeProjectCommentsPanel() {
  els.projectCommentsPanel?.classList.add(
    'hidden'
  );
}

function renderInlineCommentsSummary(doc = null) {
  if (!els.inlineCommentsSummary) {
    return;
  }

  const comments =
    getInlineComments(doc);

  const counts =
    getInlineCommentCounts(comments);

  if (!counts.total) {
    els.inlineCommentsSummary.innerHTML =
      '<div class="empty-note">No comments yet.</div>';
    return;
  }

  els.inlineCommentsSummary.innerHTML = `
    <div class="inline-comments-summary-row">
      <span>
        <strong>${counts.open}</strong>
        open
      </span>

      <span>
        <strong>${counts.resolved}</strong>
        resolved
      </span>
    </div>
  `;
}

function renderInlineCommentCardsInto(container, allComments = []) {
  if (!container) {
    return;
  }

  const comments =
    allComments.filter(comment => {
      return showResolvedInlineComments
        ? true
        : !comment.resolved;
    });

  if (!allComments.length) {
    container.innerHTML =
      '<div class="empty-note">No comments yet.</div>';
    return;
  }

  if (!comments.length) {
    container.innerHTML =
      '<div class="empty-note">No open comments. Resolved comments are hidden.</div>';
    return;
  }

  container.innerHTML = '';

  comments
    .slice()
    .sort((a, b) => {
      return Number(b.createdAt || 0) -
        Number(a.createdAt || 0);
    })
    .forEach(comment => {
      const card =
        document.createElement('article');

      const targetStatus =
        getInlineCommentTargetStatus(comment.id);

      card.className = [
        'inline-comment-card',
        comment.resolved ? 'resolved' : '',
        targetStatus === 'missing' ? 'missing-target' : ''
      ]
        .filter(Boolean)
        .join(' ');

      const quote =
        String(comment.quote || '')
          .trim();

      const shortQuote =
        quote.length > 90
          ? `${quote.slice(0, 87)}...`
          : quote;

      card.innerHTML = `
        <button
          type="button"
          class="inline-comment-jump-btn"
          data-inline-comment-jump="${escapeHtml(comment.id)}"
        >
          <strong>${escapeHtml(shortQuote || 'Comment')}</strong>
        </button>

        <div class="inline-comment-note">
          ${escapeHtml(comment.note || '')}
        </div>

        <div class="inline-comment-meta">
          ${
            comment.resolved
              ? '<span class="inline-comment-status resolved">Resolved</span>'
              : '<span class="inline-comment-status open">Open</span>'
          }

          ${
            targetStatus === 'missing'
              ? '<span class="inline-comment-status missing">Target missing</span>'
              : ''
          }
        </div>

        <div class="inline-comment-actions">
          <button
            type="button"
            data-inline-comment-toggle-resolved="${escapeHtml(comment.id)}"
          >
            ${comment.resolved ? 'Reopen' : 'Resolve'}
          </button>

          <button
            type="button"
            data-inline-comment-delete="${escapeHtml(comment.id)}"
          >
            Delete
          </button>
        </div>
      `;

      card
        .querySelector('[data-inline-comment-jump]')
        ?.addEventListener('click', event => {
          jumpToInlineComment(
            event.currentTarget.dataset.inlineCommentJump
          );
        });

      card
        .querySelector('[data-inline-comment-toggle-resolved]')
        ?.addEventListener('click', async event => {
          await toggleInlineCommentResolved(
            event.currentTarget.dataset.inlineCommentToggleResolved
          );
        });

      card
        .querySelector('[data-inline-comment-delete]')
        ?.addEventListener('click', async event => {
          await deleteInlineComment(
            event.currentTarget.dataset.inlineCommentDelete
          );
        });

      container.appendChild(card);
    });
}

async function getCustomMetadataFields() {
  const saved =
    await NaviStorage.getSetting(
      CUSTOM_METADATA_FIELDS_KEY,
      []
    );

  if (!Array.isArray(saved)) {
    return [];
  }

  return saved
    .map(field => {
      const type =
        normalizeCustomMetadataFieldType(field.type);

      return {
        id:
          field.id ||
          crypto.randomUUID(),

        name:
          normalizeCustomMetadataFieldName(field.name) ||
          'Untitled Field',

        type,

        sortOrder: Number.isFinite(Number(field.sortOrder)) ? Number(field.sortOrder) : 0,

        visible: field.visible !== false,

        options:
          type === 'dropdown' && Array.isArray(field.options)
            ? field.options.map(String).filter(Boolean)
            : [],

        createdAt:
          Number(field.createdAt || Date.now()),

        updatedAt:
          Number(field.updatedAt || field.createdAt || Date.now())
      };
    })
    .filter(field => {
      return Boolean(field.id && field.name);
    });
}

function getInlineCommentTargetStatus(commentId) {
  return findInlineCommentMark(commentId)
    ? 'found'
    : 'missing';
}

function updateResolvedCommentsToggle() {
  if (!els.toggleResolvedCommentsBtn) {
    return;
  }

  els.toggleResolvedCommentsBtn.textContent =
    showResolvedInlineComments
      ? 'Hide Resolved'
      : 'Show Resolved';

  els.toggleResolvedCommentsBtn.classList.toggle(
    'active',
    showResolvedInlineComments
  );
}

function toggleResolvedInlineComments() {
  showResolvedInlineComments =
    !showResolvedInlineComments;

  updateResolvedCommentsToggle();
  renderInlineCommentsPanel();
}

async function saveCustomMetadataFields(fields = []) {
  const cleanFields =
    Array.isArray(fields)
      ? fields.map(field => {
          const type =
            normalizeCustomMetadataFieldType(field.type);

          return {
            id:
              field.id ||
              crypto.randomUUID(),

            name:
              normalizeCustomMetadataFieldName(field.name) ||
              'Untitled Field',

            type,

            options:
              type === 'dropdown'
                ? Array.isArray(field.options)
                  ? field.options.map(String).filter(Boolean)
                  : []
                : [],

            createdAt:
              Number(field.createdAt || Date.now()),

            updatedAt:
              Number(field.updatedAt || Date.now())
          };
        })
      : [];

  await NaviStorage.saveSetting(
    CUSTOM_METADATA_FIELDS_KEY,
    cleanFields
  );

  return cleanFields;
}

async function addCustomMetadataField({
  name,
  type,
  options = [],
  sortOrder = 0,
  visible = true
} = {}) {
  const cleanName =
    normalizeCustomMetadataFieldName(name);

  if (!cleanName) {
    showAppNotice(
      'Enter a field name.',
      'Missing field name'
    );
    return null;
  }

  const cleanType =
    normalizeCustomMetadataFieldType(type);

  const fields =
    await getCustomMetadataFields();

  const duplicate =
    fields.some(field => {
      return field.name.toLowerCase() === cleanName.toLowerCase();
    });

  if (duplicate) {
    showAppNotice(
      `"${cleanName}" already exists.`,
      'Duplicate field'
    );
    return null;
  }

  const now =
    Date.now();

  const field = {
    id:
      crypto.randomUUID(),

    name:
      cleanName,

    type:
      cleanType,

    options:
      cleanType === 'dropdown'
        ? options
        : [],

    sortOrder: Number(sortOrder || 0),
      visible: visible !== false,
      createdAt:
      now,

    updatedAt:
      now
  };

  fields.push(field);

  await saveCustomMetadataFields(fields);

  return field;
}

function getInlineComments(doc) {
  return Array.isArray(doc?.inlineComments)
    ? doc.inlineComments
    : [];
}

function getEditorContentRoot() {
  if (!els.editor) {
    return null;
  }

  return (
    els.editor.querySelector('.ProseMirror') ||
    els.editor
  );
}

function getCurrentSelectedEditorText() {
  if (window.NaviTiptap?.getEditor) {
    const editor =
      window.NaviTiptap.getEditor();

    if (editor) {
      const { state } =
        editor;

      const { from, to } =
        state.selection;

      if (from !== to) {
        return state.doc
          .textBetween(from, to, ' ')
          .trim();
      }
    }
  }

  const selection =
    window.getSelection();

  if (
    !selection ||
    selection.rangeCount === 0
  ) {
    return '';
  }

  const root =
    getEditorContentRoot();

  const range =
    selection.getRangeAt(0);

  if (
    root &&
    root.contains(range.commonAncestorContainer)
  ) {
    return selection.toString().trim();
  }

  return '';
}

function applyInlineCommentMark(commentId) {
  if (!commentId) {
    return false;
  }

  if (window.NaviTiptap?.run) {
    return window.NaviTiptap.run(
      'inlineComment',
      commentId
    );
  }

  const selection =
    window.getSelection();

  if (
    !selection ||
    selection.rangeCount === 0 ||
    selection.isCollapsed
  ) {
    return false;
  }

  const range =
    selection.getRangeAt(0);

  const root =
    getEditorContentRoot();

  if (
    !root ||
    !root.contains(range.commonAncestorContainer)
  ) {
    return false;
  }

  const span =
    document.createElement('span');

  span.className =
    'inline-comment-mark';

  span.dataset.inlineCommentId =
    commentId;

  try {
    range.surroundContents(span);
  } catch {
    const contents =
      range.extractContents();

    span.appendChild(contents);
    range.insertNode(span);
  }

  selection.removeAllRanges();

  window.dispatchEvent(
    new CustomEvent('naviwriter:editor-input')
  );

  return true;
}

function findInlineCommentMark(commentId) {
  const root =
    getEditorContentRoot();

  if (!root || !commentId) {
    return null;
  }

  return root.querySelector(
    `[data-inline-comment-id="${CSS.escape(commentId)}"]`
  );
}

function flashInlineCommentTarget(target) {
  if (!target) {
    return;
  }

  target.classList.add(
    'inline-comment-jump-highlight'
  );

  setTimeout(() => {
    target.classList.remove(
      'inline-comment-jump-highlight'
    );
  }, 1300);
}

function jumpToInlineComment(commentId) {
  const target =
    findInlineCommentMark(commentId);

  if (!target) {
    showAppNotice(
      'Could not find the marked text. The text may have been edited.',
      'Comment target missing'
    );
    return;
  }

  target.scrollIntoView({
    behavior: 'smooth',
    block: 'center'
  });

  flashInlineCommentTarget(target);
}

async function renderInlineCommentsPanel(doc = null) {
  updateResolvedCommentsToggle();

  const currentDoc =
    doc ||
    (
      currentDocumentId
        ? await NaviStorage.getDocument(currentDocumentId)
        : null
    );

  const comments =
    getInlineComments(currentDoc);

  renderInlineCommentsSummary(currentDoc);

  if (els.commentsDrawerSubtitle) {
    const counts =
      getInlineCommentCounts(comments);

    els.commentsDrawerSubtitle.textContent =
      `${counts.open} open · ${counts.resolved} resolved`;
  }

  renderInlineCommentCardsInto(
    els.commentsDrawerList,
    comments
  );
}

async function openCommentsDrawer() {
  if (!els.commentsDrawer) {
    return;
  }

  els.commentsDrawer.classList.remove('hidden');

  requestAnimationFrame(() => {
    placeCommentsDrawerDefaultIfNeeded();
  });

  await renderInlineCommentsPanel();
  
  renderProjectCommentsPanel();
  
}

function closeCommentsDrawer() {
  if (els.commentsDrawer) {
    els.commentsDrawer.classList.add('hidden');
  }

  commentsDrawerDragging = false;
}

async function addInlineCommentFromSelection() {
  if (!currentDocumentId) {
    showAppNotice(
      'Open a document first.',
      'No document selected'
    );
    return;
  }

  const quote =
    getCurrentSelectedEditorText();

  if (!quote) {
    showAppNotice(
      'Select text in the editor before adding a comment.',
      'No text selected'
    );
    return;
  }

  const note =
    await openTextInputModal({
      title: 'Add Comment',
      message: 'Write a note for the selected text.',
      label: 'Comment',
      defaultValue: '',
      placeholder: 'Why does this line matter?',
      submitText: 'Add Comment'
    });

  if (!note || !note.trim()) {
    return;
  }

  const commentId =
    crypto.randomUUID();

  const marked =
    applyInlineCommentMark(commentId);

  if (!marked) {
    showAppNotice(
      'Could not mark the selected text.',
      'Comment not added'
    );
    return;
  }

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) {
    return;
  }

  const snapshot =
    NaviEditor.getEditorSnapshot();

  const comments =
    getInlineComments(doc);

  const now =
    Date.now();

  const nextComment = {
    id: commentId,
    quote,
    note: note.trim(),
    createdAt: now,
    updatedAt: now,
    resolved: false
  };

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      ...snapshot,
      inlineComments: [
        ...comments,
        nextComment
      ],
      updatedAt: now
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  await renderInlineCommentsPanel(saved);
  
  renderProjectCommentsPanel();
  
  renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus(
    'Comment added'
  );
}

async function toggleInlineCommentResolved(commentId) {
  if (!currentDocumentId || !commentId) {
    return;
  }

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) {
    return;
  }

  const comments =
    getInlineComments(doc);

  let changed = false;

  const nextComments =
    comments.map(comment => {
      if (comment.id !== commentId) {
        return comment;
      }

      changed = true;

      return {
        ...comment,
        resolved:
          !comment.resolved,
        updatedAt:
          Date.now()
      };
    });

  if (!changed) {
    return;
  }

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      inlineComments:
        nextComments,
      updatedAt:
        Date.now()
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  await renderInlineCommentsPanel(saved);
  
  renderProjectCommentsPanel();

  NaviEditor.setSaveStatus(
    'Comment updated'
  );
}

async function deleteInlineComment(commentId) {
  if (!currentDocumentId || !commentId) {
    return;
  }

  const ok =
    await openConfirmModal({
      title: 'Delete Comment',
      message: 'Delete this inline comment?',
      confirmText: 'Delete',
      cancelText: 'Cancel',
      danger: true
    });

  if (!ok) {
    return;
  }

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) {
    return;
  }

  const comments =
    getInlineComments(doc)
      .filter(comment => {
        return comment.id !== commentId;
      });

  /*
    Try to remove the visible mark in the editor DOM.
    Tiptap state cleanup is intentionally conservative:
    if the mark remains visually, saving after deletion will still
    preserve document content safely.
  */
  const mark =
    findInlineCommentMark(commentId);

  if (mark) {
    const parent =
      mark.parentNode;

    while (mark.firstChild) {
      parent.insertBefore(
        mark.firstChild,
        mark
      );
    }

    mark.remove();
  }

  const snapshot =
    NaviEditor.getEditorSnapshot();

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      ...snapshot,
      inlineComments:
        comments,
      updatedAt:
        Date.now()
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  await renderInlineCommentsPanel(saved);
  
  renderProjectCommentsPanel();
  
  renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus(
    'Comment deleted'
  );
}

let editingCustomMetadataFieldId = null;
let activeTagValues = [];

function getAllProjectTags() {
  return Array.from(new Set((documentsCache || []).flatMap(doc => Array.isArray(doc.tags) ? doc.tags : []).map(tag => String(tag).trim()).filter(Boolean).map(tag => tag.toLowerCase())))
    .map(lower => (documentsCache || []).flatMap(doc => doc.tags || []).find(tag => String(tag).toLowerCase() === lower))
    .sort((a,b) => String(a).localeCompare(String(b)));
}
function syncTagStorageInput() { if (els.tagsInput) els.tagsInput.value = activeTagValues.join(', '); }
function addTagChip(value) {
  const clean=String(value||'').trim().replace(/^,+|,+$/g,''); if(!clean) return;
  if(activeTagValues.some(tag=>tag.toLowerCase()===clean.toLowerCase())) return;
  activeTagValues.push(clean); syncTagStorageInput(); renderTagChipEditor();
}
function removeTagChip(value) { activeTagValues=activeTagValues.filter(tag=>tag.toLowerCase()!==String(value).toLowerCase()); syncTagStorageInput(); renderTagChipEditor(); }
function renderTagChipEditor() {
  if(!els.tagChipList) return; syncTagStorageInput(); els.tagChipList.innerHTML='';
  activeTagValues.forEach(tag=>{const chip=document.createElement('span');chip.className='tag-chip';chip.innerHTML=`<span>${escapeHtml(tag)}</span><button type="button" aria-label="Remove ${escapeHtml(tag)}">×</button>`;chip.querySelector('button').onclick=()=>removeTagChip(tag);els.tagChipList.appendChild(chip);});
  renderTagSuggestions();
}
function renderTagSuggestions() {
  if(!els.tagSuggestions||!els.tagChipInput)return; const query=els.tagChipInput.value.trim().toLowerCase();
  const suggestions=getAllProjectTags().filter(tag=>!activeTagValues.some(value=>value.toLowerCase()===String(tag).toLowerCase())).filter(tag=>!query||String(tag).toLowerCase().includes(query)).slice(0,8);
  els.tagSuggestions.innerHTML=''; els.tagSuggestions.classList.toggle('hidden',!suggestions.length||!document.activeElement?.isSameNode(els.tagChipInput));
  suggestions.forEach(tag=>{const button=document.createElement('button');button.type='button';button.textContent=tag;button.onmousedown=e=>{e.preventDefault();addTagChip(tag);els.tagChipInput.value='';renderTagSuggestions();};els.tagSuggestions.appendChild(button);});
}
function loadTagChips(tags) { activeTagValues=Array.from(new Map((Array.isArray(tags)?tags:parseTags(tags||'')).map(tag=>[String(tag).toLowerCase(),String(tag)])).values()); renderTagChipEditor(); }
function wireTagChipEditor() {
  if(!els.tagChipInput)return;
  els.tagChipInput.addEventListener('input',()=>{if(/[;,]$/.test(els.tagChipInput.value)){addTagChip(els.tagChipInput.value.slice(0,-1));els.tagChipInput.value='';}renderTagSuggestions();});
  els.tagChipInput.addEventListener('focus',renderTagSuggestions); els.tagChipInput.addEventListener('blur',()=>setTimeout(()=>els.tagSuggestions?.classList.add('hidden'),120));
  els.tagChipInput.addEventListener('keydown',event=>{if(['Enter','Tab',',',';'].includes(event.key)){if(els.tagChipInput.value.trim()){event.preventDefault();addTagChip(els.tagChipInput.value);els.tagChipInput.value='';}}else if(event.key==='Backspace'&&!els.tagChipInput.value&&activeTagValues.length){removeTagChip(activeTagValues[activeTagValues.length-1]);}});
}
async function beginEditCustomMetadataField(fieldId) {
  const fields=await getCustomMetadataFields(); const field=fields.find(item=>item.id===fieldId); if(!field)return;
  editingCustomMetadataFieldId=field.id; els.customMetadataFieldNameInput.value=field.name; els.customMetadataFieldTypeSelect.value=field.type;
  els.customMetadataFieldOptionsInput.value=(field.options||[]).join('\n'); if(els.customMetadataFieldOrderInput)els.customMetadataFieldOrderInput.value=Number(field.sortOrder||0);
  if(els.customMetadataFieldVisibleInput)els.customMetadataFieldVisibleInput.checked=field.visible!==false;
  els.addCustomMetadataFieldBtn.textContent='Save Field'; els.addCustomMetadataFieldBtn.dataset.mode='edit'; updateCustomMetadataOptionsVisibility(); els.customMetadataFieldNameInput.focus();
}
function resetCustomMetadataFieldEditor(){editingCustomMetadataFieldId=null;if(els.addCustomMetadataFieldBtn){els.addCustomMetadataFieldBtn.textContent='Add Field';els.addCustomMetadataFieldBtn.dataset.mode='add';}if(els.customMetadataFieldNameInput)els.customMetadataFieldNameInput.value='';if(els.customMetadataFieldTypeSelect)els.customMetadataFieldTypeSelect.value='text';if(els.customMetadataFieldOptionsInput)els.customMetadataFieldOptionsInput.value='';if(els.customMetadataFieldOrderInput)els.customMetadataFieldOrderInput.value='0';if(els.customMetadataFieldVisibleInput)els.customMetadataFieldVisibleInput.checked=true;updateCustomMetadataOptionsVisibility();}
function canSafelyConvertMetadataValue(value,toType,options=[]){if(value===undefined||value===null||value==='')return true;if(toType==='text'||toType==='longText')return true;if(toType==='number')return Number.isFinite(Number(value));if(toType==='date')return !Number.isNaN(Date.parse(value));if(toType==='checkbox')return ['true','false','1','0','yes','no'].includes(String(value).toLowerCase());if(toType==='dropdown')return options.some(option=>option.toLowerCase()===String(value).toLowerCase());return true;}
async function saveEditedCustomMetadataField(){const fields=await getCustomMetadataFields();const index=fields.findIndex(field=>field.id===editingCustomMetadataFieldId);if(index<0)return;const current=fields[index];const name=normalizeCustomMetadataFieldName(els.customMetadataFieldNameInput?.value);const type=normalizeCustomMetadataFieldType(els.customMetadataFieldTypeSelect?.value);const options=type==='dropdown'?parseCustomMetadataOptions(els.customMetadataFieldOptionsInput?.value):[];if(!name){els.customMetadataFieldNameInput?.focus();return;}const docs=await NaviStorage.getAllDocuments();const unsafe=docs.filter(doc=>doc.customMetadata?.[current.id]!==undefined&&!canSafelyConvertMetadataValue(doc.customMetadata[current.id],type,options));if(unsafe.length){await showAppNotice(`Cannot convert this field to ${getCustomMetadataFieldTypeLabel(type)} because ${unsafe.length} document value${unsafe.length===1?' is':'s are'} incompatible. Convert those values first.`,'Unsafe field conversion');return;}fields[index]={...current,name,type,options,sortOrder:Number(els.customMetadataFieldOrderInput?.value||0),visible:els.customMetadataFieldVisibleInput?.checked!==false};await saveCustomMetadataFields(fields);resetCustomMetadataFieldEditor();await renderCustomMetadataFieldsModal();await renderCustomMetadataValues();NaviEditor.setSaveStatus('Custom field updated');}

async function deleteCustomMetadataField(fieldId) {
  if (!fieldId) {
    return;
  }

  const fields =
    await getCustomMetadataFields();

  const field =
    fields.find(item => {
      return item.id === fieldId;
    });

  if (!field) {
    return;
  }

  const ok =
    await openConfirmModal({
      title: 'Delete Custom Field',
      message:
        `Delete "${field.name}"? This removes the field definition from the interface. Existing keyed values will no longer be shown. Export a backup first if those values may be needed.`,
      confirmText: 'Delete',
      cancelText: 'Cancel',
      danger: true
    });

  if (!ok) {
    return;
  }

  const nextFields =
    fields.filter(item => {
      return item.id !== fieldId;
    });

  await saveCustomMetadataFields(nextFields);
  
  await renderCustomMetadataValues();

  NaviEditor.setSaveStatus('Custom field deleted');
}

function updateCustomMetadataOptionsVisibility() {
  const type =
    els.customMetadataFieldTypeSelect?.value || 'text';

  if (els.customMetadataOptionsWrap) {
    els.customMetadataOptionsWrap.classList.toggle(
      'hidden',
      type !== 'dropdown'
    );
  }
}

async function renderCustomMetadataFieldsModal() {
  if (!els.customMetadataFieldsList) {
    return;
  }

  const fields =
    await getCustomMetadataFields();

  if (els.customMetadataFieldsCount) {
    els.customMetadataFieldsCount.textContent =
      `${fields.length} field${fields.length === 1 ? '' : 's'}`;
  }

  if (!fields.length) {
    els.customMetadataFieldsList.innerHTML =
      '<div class="empty-note">No custom fields yet.</div>';
    return;
  }

  els.customMetadataFieldsList.innerHTML = '';

  fields.slice().sort((a,b)=>Number(a.sortOrder||0)-Number(b.sortOrder||0)).forEach(field => {
    const row =
      document.createElement('article');

    row.className =
      'custom-metadata-field-row';

    const optionsText =
      field.type === 'dropdown' && field.options.length
        ? field.options.join(', ')
        : '';

    row.innerHTML = `
      <div class="custom-metadata-field-main">
        <strong>${escapeHtml(field.name)}</strong>

        <div class="custom-metadata-field-meta">
          <span>${escapeHtml(getCustomMetadataFieldTypeLabel(field.type))}</span>

          ${
            optionsText
              ? `<span>Options: ${escapeHtml(optionsText)}</span>`
              : ''
          }
        </div>
      </div>

      <button
        type="button"
        class="custom-metadata-field-edit-btn" data-custom-metadata-edit-id="${escapeHtml(field.id)}">Edit</button><button type="button" class="custom-metadata-field-delete-btn"
        data-custom-metadata-field-id="${escapeHtml(field.id)}"
        title="Delete field"
      >
        ×
      </button>
    `;

    row.querySelector('[data-custom-metadata-edit-id]')
      ?.addEventListener('click', event => {
        beginEditCustomMetadataField(event.currentTarget.dataset.customMetadataEditId);
      });

    row
      .querySelector('[data-custom-metadata-field-id]')
      ?.addEventListener('click', async event => {
        const fieldId =
          event.currentTarget.dataset.customMetadataFieldId;

        if (!fieldId) {
          return;
        }

        await deleteCustomMetadataField(fieldId);

        await renderCustomMetadataFieldsModal();
      });

    els.customMetadataFieldsList.appendChild(row);
  });
}

async function openCustomMetadataFieldsModal() {
  if (!els.customMetadataFieldsModal) {
    return;
  }

  if (els.customMetadataFieldNameInput) {
    els.customMetadataFieldNameInput.value = '';
  }

  if (els.customMetadataFieldTypeSelect) {
    els.customMetadataFieldTypeSelect.value = 'text';
  }

  if (els.customMetadataFieldOptionsInput) {
    els.customMetadataFieldOptionsInput.value = '';
  }

  updateCustomMetadataOptionsVisibility();

  await renderCustomMetadataFieldsModal();

  els.customMetadataFieldsModal.classList.remove('hidden');

  setTimeout(() => {
    els.customMetadataFieldNameInput?.focus();
  }, 0);
}

function closeCustomMetadataFieldsModal() {
  if (els.customMetadataFieldsModal) {
    els.customMetadataFieldsModal.classList.add('hidden');
  }
}

async function submitCustomMetadataFieldAdd() {
  if (editingCustomMetadataFieldId) { await saveEditedCustomMetadataField(); return; }
  const name =
    els.customMetadataFieldNameInput?.value || '';

  const type =
    els.customMetadataFieldTypeSelect?.value || 'text';

  const options =
    type === 'dropdown'
      ? parseCustomMetadataOptions(
          els.customMetadataFieldOptionsInput?.value || ''
        )
      : [];

  if (type === 'dropdown' && !options.length) {
    showAppNotice(
      'Add at least one dropdown option.',
      'Missing dropdown options'
    );
    return;
  }

  const field =
    await addCustomMetadataField({
      name,
      type,
      options,
      sortOrder: Number(els.customMetadataFieldOrderInput?.value || 0),
      visible: els.customMetadataFieldVisibleInput?.checked !== false
    });

  if (!field) {
    return;
  }

  if (els.customMetadataFieldNameInput) {
    els.customMetadataFieldNameInput.value = '';
  }

  if (els.customMetadataFieldOptionsInput) {
    els.customMetadataFieldOptionsInput.value = '';
  }

  if (els.customMetadataFieldTypeSelect) {
    els.customMetadataFieldTypeSelect.value = 'text';
  }

  updateCustomMetadataOptionsVisibility();

  await renderCustomMetadataFieldsModal();
  
  await renderCustomMetadataValues();
  
  if (
  els.outlinerCustomColumnsModal &&
  !els.outlinerCustomColumnsModal.classList.contains('hidden')
) {
  await renderOutlinerCustomColumnsModal();
}

if (
  els.outlinerModal &&
  !els.outlinerModal.classList.contains('hidden')
) {
  await renderOutliner();
}

  NaviEditor.setSaveStatus('Custom field added');
}

async function getOutlinerCustomMetadataColumnIds() {
  const saved =
    await NaviStorage.getSetting(
      OUTLINER_CUSTOM_METADATA_COLUMNS_KEY,
      []
    );

  if (!Array.isArray(saved)) {
    return [];
  }

  return saved
    .map(id => String(id || ''))
    .filter(Boolean);
}

async function saveOutlinerCustomMetadataColumnIds(ids = []) {
  const cleanIds =
    Array.from(
      new Set(
        Array.isArray(ids)
          ? ids.map(id => String(id || '')).filter(Boolean)
          : []
      )
    );

  await NaviStorage.saveSetting(
    OUTLINER_CUSTOM_METADATA_COLUMNS_KEY,
    cleanIds
  );

  return cleanIds;
}

async function getVisibleOutlinerCustomMetadataFields() {
  const fields =
    await getCustomMetadataFields();

  const selectedIds =
    await getOutlinerCustomMetadataColumnIds();

  const fieldMap =
    new Map(
      fields.map(field => {
        return [field.id, field];
      })
    );

  const visibleFields =
    selectedIds
      .map(id => {
        return fieldMap.get(id);
      })
      .filter(Boolean);

  /*
    If fields were deleted, prune dead IDs quietly.
  */
  const prunedIds =
    visibleFields.map(field => field.id);

  if (prunedIds.length !== selectedIds.length) {
    await saveOutlinerCustomMetadataColumnIds(prunedIds);
  }

  return visibleFields;
}

function formatCustomMetadataOutlinerValue(field, value) {
  const cleanValue =
    normalizeCustomMetadataValue(
      field,
      value
    );

  if (
    cleanValue === '' ||
    cleanValue === null ||
    cleanValue === undefined
  ) {
    return '<span class="outliner-muted">—</span>';
  }

  if (field.type === 'checkbox') {
    return cleanValue
      ? '<span class="outliner-custom-check yes">Yes</span>'
      : '<span class="outliner-custom-check no">No</span>';
  }

  if (field.type === 'date') {
    return escapeHtml(
      String(cleanValue || '')
    );
  }

  if (field.type === 'number') {
    return escapeHtml(
      String(cleanValue)
    );
  }

  const text =
    String(cleanValue || '');

  const shortText =
    text.length > 80
      ? `${text.slice(0, 77)}...`
      : text;

  return escapeHtml(shortText);
}

async function renderOutlinerCustomColumnsModal() {
  if (!els.outlinerCustomColumnsList) {
    return;
  }

  const fields =
    await getCustomMetadataFields();

  const selectedIds =
    new Set(
      await getOutlinerCustomMetadataColumnIds()
    );

  if (!fields.length) {
    els.outlinerCustomColumnsList.innerHTML =
      '<div class="empty-note">No custom fields yet. Create fields from Document Details first.</div>';
    return;
  }

  els.outlinerCustomColumnsList.innerHTML = '';

  fields.forEach(field => {
    const row =
      document.createElement('label');

    row.className =
      'outliner-custom-column-row';

    row.innerHTML = `
      <input
        type="checkbox"
        value="${escapeHtml(field.id)}"
        ${selectedIds.has(field.id) ? 'checked' : ''}
      />

      <span class="outliner-custom-column-main">
        <strong>${escapeHtml(field.name)}</strong>
        <small>${escapeHtml(getCustomMetadataFieldTypeLabel(field.type))}</small>
      </span>
    `;

    row
      .querySelector('input')
      ?.addEventListener('change', async () => {
        const checkedIds =
          Array.from(
            els.outlinerCustomColumnsList
              .querySelectorAll('input[type="checkbox"]:checked')
          )
            .map(input => input.value)
            .filter(Boolean);

        await saveOutlinerCustomMetadataColumnIds(
          checkedIds
        );

        if (
          els.outlinerModal &&
          !els.outlinerModal.classList.contains('hidden')
        ) {
          await renderOutliner();
        }
      });

    els.outlinerCustomColumnsList.appendChild(row);
  });
}

async function openOutlinerCustomColumnsModal() {
  if (!els.outlinerCustomColumnsModal) {
    return;
  }

  await renderOutlinerCustomColumnsModal();

  els.outlinerCustomColumnsModal.classList.remove('hidden');
}

function closeOutlinerCustomColumnsModal() {
  if (els.outlinerCustomColumnsModal) {
    els.outlinerCustomColumnsModal.classList.add('hidden');
  }
}

function renderOutlinerCustomMetadataCells(doc, fields = []) {
  const values =
    getDocumentCustomMetadata(doc);

  return fields
    .map(field => {
      return `
        <td class="outliner-custom-metadata-cell">
          ${formatCustomMetadataOutlinerValue(
            field,
            values[field.id]
          )}
        </td>
      `;
    })
    .join('');
}

async function renameSplitPaneDocument() {
  if (!splitPaneDocId) {
    showAppNotice(
      'Choose a split document first.',
      'No split document selected'
    );
    return;
  }

  if (splitPaneEditable) {
    await saveSplitPaneDocument();
  }

  const doc =
    await NaviStorage.getDocument(splitPaneDocId);

  if (!doc) {
    showAppNotice(
      'Split document not found.',
      'Document missing'
    );
    return;
  }

  const nextTitle =
    await openTextInputModal({
      title: 'Rename Split Document',
      message: 'Give this split document a new title.',
      label: 'Document title',
      defaultValue: doc.title || 'Untitled Document',
      placeholder: 'Untitled Document',
      submitText: 'Rename'
    });

  if (!nextTitle || !nextTitle.trim()) {
    return;
  }

  const cleanTitle =
    nextTitle.trim();

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      title: cleanTitle,
      updatedAt: Date.now()
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  renderDocumentList(documentsCache);

  if (els.splitDocSelect) {
    await populateSplitDocSelect();
    els.splitDocSelect.value =
      saved.id;
  }

  await renderSplitPaneDocument();

  NaviEditor.setSaveStatus(
    'Split document renamed'
  );
}

function getSplitPaneEditorElements() {
  return {
    titleInput:
      els.splitDocContent?.querySelector(
        '[data-split-title-input]'
      ) || null,

    body:
      els.splitDocContent?.querySelector(
        '[data-split-edit-body]'
      ) || null
  };
}

function getSplitPanePlainTextFromHtml(html = '') {
  const wrapper =
    document.createElement('div');

  wrapper.innerHTML =
    html || '';

  return wrapper.innerText || '';
}

function updateSplitPaneEditButtons() {
  if (els.editSplitPaneBtn) {
    els.editSplitPaneBtn.classList.toggle(
      'active',
      splitPaneEditable
    );

    els.editSplitPaneBtn.textContent =
      splitPaneEditable
        ? 'Editing'
        : 'Edit';
  }

  if (els.saveSplitPaneBtn) {
    els.saveSplitPaneBtn.classList.toggle(
      'hidden',
      !splitPaneEditable
    );
  }
}

function setSplitPaneEditable(enabled) {
  splitPaneEditable =
    Boolean(enabled);

  updateSplitPaneEditButtons();

  renderSplitPaneDocument();
}

function toggleSplitPaneEditable() {
  setSplitPaneEditable(
    !splitPaneEditable
  );
}

async function buildGlobalGraphData() {
  const docs =
    documentsCache.length
      ? documentsCache
      : await NaviStorage.getAllDocuments();

  const filters =
    getLocalGraphFilterState();

  const nodeMap =
    new Map();

  function addNode(type, id, label = '') {
    const key =
      `${type}:${id}`;

    if (nodeMap.has(key)) {
      return nodeMap.get(key);
    }

    const node = {
      id: key,
      entityType: type,
      entityId: id,
      label,
      isCurrent:
        type === 'document' &&
        id === currentDocumentId
    };

    nodeMap.set(key, node);

    return node;
  }

  function addDocumentNode(doc) {
    return addNode(
      'document',
      doc.id,
      doc.title || 'Untitled Document'
    );
  }

  const edges = [];

  function addEdge({
    id,
    sourceEntityType,
    sourceEntityId,
    sourceLabel,
    targetEntityType,
    targetEntityId,
    targetLabel,
    relationType = 'related',
    strength = 1,
    note = '',
    isImplicit = false
  }) {
    const sourceNode =
      addNode(
        sourceEntityType,
        sourceEntityId,
        sourceLabel
      );

    const targetNode =
      addNode(
        targetEntityType,
        targetEntityId,
        targetLabel
      );

    edges.push({
      id,
      sourceNodeId: sourceNode.id,
      targetNodeId: targetNode.id,
      relationType,
      strength: Number(strength || 1) || 1,
      note,
      isImplicit
    });
  }

  const docsById =
    new Map(
      docs.map(doc => [doc.id, doc])
    );

  /*
    Always include document nodes.
    This makes orphan docs visible in the global graph.
  */
  docs.forEach(doc => {
    addDocumentNode(doc);
  });

  if (filters.explicit) {
    const relationships =
      await getRelationships();

    for (const rel of relationships) {
      const sourceName =
        await getEntityName(
          rel.sourceEntityType,
          rel.sourceEntityId
        );

      const targetName =
        await getEntityName(
          rel.targetEntityType,
          rel.targetEntityId
        );

      addEdge({
        id: rel.id,
        sourceEntityType: rel.sourceEntityType,
        sourceEntityId: rel.sourceEntityId,
        sourceLabel: sourceName,
        targetEntityType: rel.targetEntityType,
        targetEntityId: rel.targetEntityId,
        targetLabel: targetName,
        relationType: rel.relationType || 'related',
        strength: rel.strength,
        note: rel.note || '',
        isImplicit: false
      });
    }
  }

  if (filters.collections) {
    const collections =
      await getCollections();

    collections.forEach(collection => {
      const documentIds =
        Array.isArray(collection.documentIds)
          ? collection.documentIds
          : [];

      documentIds.forEach(docId => {
        const doc =
          docsById.get(docId);

        if (!doc) {
          return;
        }

        addEdge({
          id: `global-implicit-collection-${collection.id}-${docId}`,
          sourceEntityType: 'collection',
          sourceEntityId: collection.id,
          sourceLabel: collection.name || 'Untitled Collection',
          targetEntityType: 'document',
          targetEntityId: docId,
          targetLabel: doc.title || 'Untitled Document',
          relationType: 'contains',
          strength: 1,
          note: 'Implicit: collection membership',
          isImplicit: true
        });
      });
    });
  }

  if (filters.folders) {
    docs.forEach(doc => {
      const folder =
        getDocumentFolderName(doc);

      if (!folder || folder === 'Unfiled') {
        return;
      }

      addEdge({
        id: `global-implicit-folder-${folder}-${doc.id}`,
        sourceEntityType: 'folder',
        sourceEntityId: folder,
        sourceLabel: folder,
        targetEntityType: 'document',
        targetEntityId: doc.id,
        targetLabel: doc.title || 'Untitled Document',
        relationType: 'contains',
        strength: 1,
        note: 'Implicit: folder membership',
        isImplicit: true
      });
    });
  }

  if (filters.sources) {
    docs.forEach(doc => {
      const sources =
        getCurrentSourceList(doc);

      sources.forEach(source => {
        addEdge({
          id: `global-implicit-source-${doc.id}-${source.id}`,
          sourceEntityType: 'document',
          sourceEntityId: doc.id,
          sourceLabel: doc.title || 'Untitled Document',
          targetEntityType: 'source',
          targetEntityId: getSourceEntityId(
            doc.id,
            source.id
          ),
          targetLabel: source.title || 'Untitled Source',
          relationType: 'has source',
          strength: 1,
          note: 'Implicit: research source',
          isImplicit: true
        });
      });
    });
  }

  if (filters.tags) {
    docs.forEach(doc => {
      const tags =
        Array.isArray(doc.tags)
          ? doc.tags
          : [];

      tags
        .map(tag => String(tag || '').trim())
        .filter(Boolean)
        .forEach(tag => {
          addEdge({
            id: `global-implicit-tag-${tag}-${doc.id}`,
            sourceEntityType: 'tag',
            sourceEntityId: tag,
            sourceLabel: `#${tag}`,
            targetEntityType: 'document',
            targetEntityId: doc.id,
            targetLabel: doc.title || 'Untitled Document',
            relationType: 'includes',
            strength: 1,
            note: 'Implicit: document tag',
            isImplicit: true
          });
        });
    });
  }

  return {
    nodes: Array.from(nodeMap.values()),
    edges
  };
}

async function buildLocalGraphData(docId) {
  if (!docId) {
    return {
      nodes: [],
      edges: []
    };
  }

  const currentDoc =
    await NaviStorage.getDocument(docId);

  if (!currentDoc) {
    return {
      nodes: [],
      edges: []
    };
  }

  const filters =
    getLocalGraphFilterState();

  const nodeMap =
    new Map();

  function addNode(type, id, label = '') {
    const key =
      `${type}:${id}`;

    if (nodeMap.has(key)) {
      return nodeMap.get(key);
    }

    const node = {
      id: key,
      entityType: type,
      entityId: id,
      label,
      isCurrent:
        type === 'document' &&
        id === docId
    };

    nodeMap.set(key, node);

    return node;
  }

  const currentNode =
    addNode(
      'document',
      currentDoc.id,
      currentDoc.title || 'Untitled Document'
    );

  const edges = [];

  function addEdge({
    id,
    sourceEntityType,
    sourceEntityId,
    sourceLabel,
    targetEntityType,
    targetEntityId,
    targetLabel,
    relationType = 'related',
    strength = 1,
    note = '',
    isImplicit = false
  }) {
    const sourceNode =
      addNode(
        sourceEntityType,
        sourceEntityId,
        sourceLabel
      );

    const targetNode =
      addNode(
        targetEntityType,
        targetEntityId,
        targetLabel
      );

    edges.push({
      id,
      sourceNodeId: sourceNode.id,
      targetNodeId: targetNode.id,
      relationType,
      strength: Number(strength || 1) || 1,
      note,
      isImplicit
    });
  }

  if (filters.explicit) {
    const relationships =
      await getRelationships();

    const localRelationships =
      relationships.filter(rel => {
        return (
          rel.sourceEntityType === 'document' &&
          rel.sourceEntityId === docId
        ) || (
          rel.targetEntityType === 'document' &&
          rel.targetEntityId === docId
        );
      });

    for (const rel of localRelationships) {
      const sourceName =
        await getEntityName(
          rel.sourceEntityType,
          rel.sourceEntityId
        );

      const targetName =
        await getEntityName(
          rel.targetEntityType,
          rel.targetEntityId
        );

      addEdge({
        id: rel.id,
        sourceEntityType: rel.sourceEntityType,
        sourceEntityId: rel.sourceEntityId,
        sourceLabel: sourceName,
        targetEntityType: rel.targetEntityType,
        targetEntityId: rel.targetEntityId,
        targetLabel: targetName,
        relationType: rel.relationType || 'related',
        strength: rel.strength,
        note: rel.note || '',
        isImplicit: false
      });
    }
  }

  if (filters.collections) {
    const collections =
      await getCollections();

    collections.forEach(collection => {
      const documentIds =
        Array.isArray(collection.documentIds)
          ? collection.documentIds
          : [];

      if (!documentIds.includes(docId)) {
        return;
      }

      addEdge({
        id: `local-implicit-collection-${collection.id}-${docId}`,
        sourceEntityType: 'collection',
        sourceEntityId: collection.id,
        sourceLabel: collection.name || 'Untitled Collection',
        targetEntityType: 'document',
        targetEntityId: docId,
        targetLabel: currentDoc.title || 'Untitled Document',
        relationType: 'contains',
        strength: 1,
        note: 'Implicit: collection membership',
        isImplicit: true
      });
    });
  }

  if (filters.folders) {
    const folder =
      getDocumentFolderName(currentDoc);

    if (folder && folder !== 'Unfiled') {
      addEdge({
        id: `local-implicit-folder-${folder}-${docId}`,
        sourceEntityType: 'folder',
        sourceEntityId: folder,
        sourceLabel: folder,
        targetEntityType: 'document',
        targetEntityId: docId,
        targetLabel: currentDoc.title || 'Untitled Document',
        relationType: 'contains',
        strength: 1,
        note: 'Implicit: folder membership',
        isImplicit: true
      });
    }
  }

  if (filters.sources) {
    const sources =
      getCurrentSourceList(currentDoc);

    sources.forEach(source => {
      addEdge({
        id: `local-implicit-source-${docId}-${source.id}`,
        sourceEntityType: 'document',
        sourceEntityId: docId,
        sourceLabel: currentDoc.title || 'Untitled Document',
        targetEntityType: 'source',
        targetEntityId: getSourceEntityId(
          docId,
          source.id
        ),
        targetLabel: source.title || 'Untitled Source',
        relationType: 'has source',
        strength: 1,
        note: 'Implicit: research source',
        isImplicit: true
      });
    });
  }

  if (filters.tags) {
    const tags =
      Array.isArray(currentDoc.tags)
        ? currentDoc.tags
        : [];

    tags
      .map(tag => String(tag || '').trim())
      .filter(Boolean)
      .forEach(tag => {
        addEdge({
          id: `local-implicit-tag-${tag}-${docId}`,
          sourceEntityType: 'tag',
          sourceEntityId: tag,
          sourceLabel: `#${tag}`,
          targetEntityType: 'document',
          targetEntityId: docId,
          targetLabel: currentDoc.title || 'Untitled Document',
          relationType: 'includes',
          strength: 1,
          note: 'Implicit: document tag',
          isImplicit: true
        });
      });
  }

  return {
    nodes: Array.from(nodeMap.values()),
    edges
  };
}

function resetLocalGraphState() {
  localGraphZoom = 1;

  localGraphPan = {
    x: 0,
    y: 0
  };

  localGraphPositions = {};
  localGraphSelectedNodeId = null;
}

function renderLocalGraphMinimap() {
  if (
    !els.localGraphMinimap ||
    els.localGraphMinimap.classList.contains('hidden') ||
    !els.localGraphMinimapBody ||
    !els.localGraphMinimapWorld ||
    !els.localGraphMinimapViewport
  ) {
    return;
  }

  const bounds =
    getLocalGraphBounds();

  if (!bounds) {
    return;
  }

  const bodyRect =
    els.localGraphMinimapBody.getBoundingClientRect();

  const padding =
    8;

  const paddedWidth =
    bounds.width + 260;

  const paddedHeight =
    bounds.height + 260;

  const scaleX =
    (bodyRect.width - padding * 2) /
    Math.max(1, paddedWidth);

  const scaleY =
    (bodyRect.height - padding * 2) /
    Math.max(1, paddedHeight);

  localGraphMinimapScale =
    Math.max(
      0.01,
      Math.min(scaleX, scaleY)
    );

  const offsetX =
    bounds.minX - 130;

  const offsetY =
    bounds.minY - 130;

  els.localGraphMinimapWorld.dataset.offsetX =
    String(offsetX);

  els.localGraphMinimapWorld.dataset.offsetY =
    String(offsetY);

  els.localGraphMinimapWorld.style.left =
    `${padding}px`;

  els.localGraphMinimapWorld.style.top =
    `${padding}px`;

  els.localGraphMinimapWorld.style.width =
    `${paddedWidth * localGraphMinimapScale}px`;

  els.localGraphMinimapWorld.style.height =
    `${paddedHeight * localGraphMinimapScale}px`;

  els.localGraphMinimapWorld.innerHTML = '';

  localGraphData.nodes.forEach(node => {
    const pos =
      getLocalGraphNodePosition(node.id);

    const dot =
      document.createElement('div');

    dot.className = [
      'local-graph-minimap-node',
      node.isCurrent ? 'current' : '',
      node.id === localGraphSelectedNodeId ? 'selected' : '',
      `entity-${node.entityType}`
    ]
      .filter(Boolean)
      .join(' ');

    dot.style.left =
      `${(pos.x - offsetX) * localGraphMinimapScale}px`;

    dot.style.top =
      `${(pos.y - offsetY) * localGraphMinimapScale}px`;

    els.localGraphMinimapWorld.appendChild(dot);
  });

  updateLocalGraphMinimapViewport();
}

function updateLocalGraphMinimapViewport() {
  if (
    !els.localGraphMinimap ||
    els.localGraphMinimap.classList.contains('hidden') ||
    !els.localGraphMinimapViewport ||
    !els.localGraphSurface ||
    !els.localGraphMinimapWorld
  ) {
    return;
  }

  const offsetX =
    Number(els.localGraphMinimapWorld.dataset.offsetX || 0);

  const offsetY =
    Number(els.localGraphMinimapWorld.dataset.offsetY || 0);

  const surfaceRect =
    els.localGraphSurface.getBoundingClientRect();

  const viewX =
    (-localGraphPan.x / localGraphZoom) - offsetX;

  const viewY =
    (-localGraphPan.y / localGraphZoom) - offsetY;

  const viewW =
    surfaceRect.width / localGraphZoom;

  const viewH =
    surfaceRect.height / localGraphZoom;

  els.localGraphMinimapViewport.style.left =
    `${8 + viewX * localGraphMinimapScale}px`;

  els.localGraphMinimapViewport.style.top =
    `${8 + viewY * localGraphMinimapScale}px`;

  els.localGraphMinimapViewport.style.width =
    `${Math.max(12, viewW * localGraphMinimapScale)}px`;

  els.localGraphMinimapViewport.style.height =
    `${Math.max(12, viewH * localGraphMinimapScale)}px`;
}

function panLocalGraphToMinimapPoint(clientX, clientY) {
  if (
    !els.localGraphMinimapBody ||
    !els.localGraphMinimapWorld ||
    !els.localGraphSurface
  ) {
    return;
  }

  const rect =
    els.localGraphMinimapBody.getBoundingClientRect();

  const offsetX =
    Number(els.localGraphMinimapWorld.dataset.offsetX || 0);

  const offsetY =
    Number(els.localGraphMinimapWorld.dataset.offsetY || 0);

  const localX =
    clientX - rect.left - 8;

  const localY =
    clientY - rect.top - 8;

  const graphX =
    offsetX + localX / localGraphMinimapScale;

  const graphY =
    offsetY + localY / localGraphMinimapScale;

  const surfaceRect =
    els.localGraphSurface.getBoundingClientRect();

  localGraphPan = {
    x:
      surfaceRect.width / 2 -
      graphX * localGraphZoom,

    y:
      surfaceRect.height / 2 -
      graphY * localGraphZoom
  };

  updateLocalGraphTransform();
}

function getEditorHeadingRoot() {
  if (!els.editor) {
    return null;
  }

  /*
    In Tiptap mode, headings live inside .ProseMirror.
    In fallback mode, headings live directly inside #editor.
  */
  return (
    els.editor.querySelector('.ProseMirror') ||
    els.editor
  );
}

function getEditorHeadingNodes() {
  const root =
    getEditorHeadingRoot();

  if (!root) {
    return [];
  }

  return Array.from(
    root.querySelectorAll('h1, h2, h3, h4, h5, h6')
  ).filter(heading => {
    return Boolean(
      heading.textContent?.trim()
    );
  });
}

function getScrollableAncestor(element) {
  let node =
    element?.parentElement || null;

  while (
    node &&
    node !== document.body &&
    node !== document.documentElement
  ) {
    const style =
      window.getComputedStyle(node);

    const overflowY =
      style.overflowY;

    const canScroll =
      (
        overflowY === 'auto' ||
        overflowY === 'scroll'
      ) &&
      node.scrollHeight > node.clientHeight;

    if (canScroll) {
      return node;
    }

    node = node.parentElement;
  }

  return (
    document.scrollingElement ||
    document.documentElement
  );
}

function flashDocumentMapTarget(target) {
  if (!target) {
    return;
  }

  target.classList.add(
    'document-map-jump-highlight'
  );

  setTimeout(() => {
    target.classList.remove(
      'document-map-jump-highlight'
    );
  }, 1200);
}

function jumpToDocumentHeading(index) {
  const headings =
    getEditorHeadingNodes();

  const target =
    headings[Number(index)];

  if (!target) {
    return;
  }

  const scrollContainer =
    getScrollableAncestor(target);

  if (
    scrollContainer &&
    scrollContainer !== document.scrollingElement &&
    scrollContainer !== document.documentElement &&
    scrollContainer !== document.body
  ) {
    const containerRect =
      scrollContainer.getBoundingClientRect();

    const targetRect =
      target.getBoundingClientRect();

    const nextTop =
      scrollContainer.scrollTop +
      targetRect.top -
      containerRect.top -
      18;

    scrollContainer.scrollTo({
      top: Math.max(0, nextTop),
      behavior: 'smooth'
    });
  } else {
    target.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  }

  flashDocumentMapTarget(target);
}

let documentMapRenderTimer = null;

function safelyRenderDocumentMap() {
  if (typeof renderDocumentMap !== 'function') {
    return;
  }

  try {
    renderDocumentMap();
  } catch (error) {
    console.warn(
      'Document map render failed:',
      error
    );
  }
}

function scheduleDocumentMapRender() {
  clearTimeout(documentMapRenderTimer);

  documentMapRenderTimer = setTimeout(() => {
    safelyRenderDocumentMap();
  }, 120);
}

function renderDocumentMap() {
  const list =
    els.documentMapList || els.outlineList;

  if (!list) {
    return;
  }

  const headings =
    getEditorHeadingNodes();

  if (!headings.length) {
    list.innerHTML =
      '<div class="empty-note">No headings yet.</div>';
    return;
  }

  list.innerHTML = '';

  headings.forEach((heading, index) => {
    const level =
      Number(
        heading.tagName.replace('H', '')
      ) || 1;

    const button =
      document.createElement('button');

    button.type = 'button';

    button.className =
      `document-map-item level-${Math.min(level, 6)}`;

    button.dataset.headingIndex =
      String(index);

    const headingText = heading.textContent?.trim() || `Heading ${index + 1}`;
    button.innerHTML = `<span class="document-map-level">H${Math.min(level, 6)}</span><span class="document-map-text">${escapeHtml(headingText)}</span>`;

    /*
      Prevent the outline button from stealing editor selection/focus
      before the click runs. Tiny but helpful.
    */
    button.addEventListener('pointerdown', event => {
      event.preventDefault();
    });

    button.addEventListener('click', event => {
      event.preventDefault();

      jumpToDocumentHeading(
        event.currentTarget.dataset.headingIndex
      );
    });

    list.appendChild(button);
  });
}

async function refreshLocalGraphData({
  keepLayout = false
} = {}) {
  const previousPositions =
    {
      ...localGraphPositions
    };

  if (localGraphMode === 'global') {
    localGraphData =
      await buildGlobalGraphData();
  } else {
    if (!currentDocumentId) {
      return;
    }

    localGraphData =
      await buildLocalGraphData(
        currentDocumentId
      );
  }

  if (keepLayout) {
    localGraphPositions = {};

    localGraphData.nodes.forEach(node => {
      if (previousPositions[node.id]) {
        localGraphPositions[node.id] =
          previousPositions[node.id];
      }
    });
  } else {
    localGraphPositions = {};
  }

  autoLayoutLocalGraph();

  renderLocalGraph();
}

function autoLayoutLocalGraph() {
  const nodes =
    localGraphData.nodes || [];

  if (!nodes.length) {
    return;
  }

  const centerX = 1000;
  const centerY = 700;

  const currentNode =
    nodes.find(node => node.isCurrent) ||
    nodes.find(node => node.entityType === 'document') ||
    nodes[0];

  if (!localGraphPositions[currentNode.id]) {
    localGraphPositions[currentNode.id] = {
      x: centerX,
      y: centerY
    };
  }

  const neighbors =
    nodes.filter(node => {
      return node.id !== currentNode.id;
    });

  /*
    Global graph gets rings.
    Local graph gets one simple ring.
  */
  if (localGraphMode === 'global') {
    const documentNodes =
      neighbors.filter(node => {
        return node.entityType === 'document';
      });

    const entityNodes =
      neighbors.filter(node => {
        return node.entityType !== 'document';
      });

    const documentRadius =
      Math.max(
        280,
        Math.min(
          760,
          190 + documentNodes.length * 18
        )
      );

    const entityRadius =
      documentRadius + 260;

    documentNodes.forEach((node, index) => {
      if (localGraphPositions[node.id]) {
        return;
      }

      const angle =
        (Math.PI * 2 * index) /
        Math.max(1, documentNodes.length);

      localGraphPositions[node.id] = {
        x: centerX + Math.cos(angle) * documentRadius,
        y: centerY + Math.sin(angle) * documentRadius
      };
    });

    entityNodes.forEach((node, index) => {
      if (localGraphPositions[node.id]) {
        return;
      }

      const angle =
        (Math.PI * 2 * index) /
        Math.max(1, entityNodes.length);

      localGraphPositions[node.id] = {
        x: centerX + Math.cos(angle) * entityRadius,
        y: centerY + Math.sin(angle) * entityRadius
      };
    });

    return;
  }

  const radius =
    Math.max(
      220,
      Math.min(
        460,
        130 + neighbors.length * 34
      )
    );

  neighbors.forEach((node, index) => {
    if (localGraphPositions[node.id]) {
      return;
    }

    const angle =
      (Math.PI * 2 * index) /
      Math.max(1, neighbors.length);

    localGraphPositions[node.id] = {
      x: centerX + Math.cos(angle) * radius,
      y: centerY + Math.sin(angle) * radius
    };
  });
}

async function buildRelationshipDashboardData() {
  const docs =
    documentsCache.length
      ? documentsCache
      : await NaviStorage.getAllDocuments();

  const explicitRelationships =
    await getRelationships();

  const collections =
    await getCollections();

  const docConnectionCounts =
    new Map();

  docs.forEach(doc => {
    docConnectionCounts.set(doc.id, 0);
  });

  explicitRelationships.forEach(rel => {
    if (
      rel.sourceEntityType === 'document' &&
      docConnectionCounts.has(rel.sourceEntityId)
    ) {
      docConnectionCounts.set(
        rel.sourceEntityId,
        docConnectionCounts.get(rel.sourceEntityId) + 1
      );
    }

    if (
      rel.targetEntityType === 'document' &&
      docConnectionCounts.has(rel.targetEntityId)
    ) {
      docConnectionCounts.set(
        rel.targetEntityId,
        docConnectionCounts.get(rel.targetEntityId) + 1
      );
    }
  });

  const relationshipTypeCounts =
    new Map();

  explicitRelationships.forEach(rel => {
    const type =
      rel.relationType || 'related';

    relationshipTypeCounts.set(
      type,
      (relationshipTypeCounts.get(type) || 0) + 1
    );
  });

  const collectionImplicitCount =
    collections.reduce((total, collection) => {
      return total + (
        Array.isArray(collection.documentIds)
          ? collection.documentIds.length
          : 0
      );
    }, 0);

  const folderImplicitCount =
    docs.filter(doc => {
      const folder =
        getDocumentFolderName(doc);

      return folder && folder !== 'Unfiled';
    }).length;

  const sourceImplicitCount =
    docs.reduce((total, doc) => {
      return total + getCurrentSourceList(doc).length;
    }, 0);

  const tagImplicitCount =
    docs.reduce((total, doc) => {
      return total + (
        Array.isArray(doc.tags)
          ? doc.tags.filter(Boolean).length
          : 0
      );
    }, 0);

  const mostConnectedDocs =
    docs
      .map(doc => {
        return {
          doc,
          count:
            docConnectionCounts.get(doc.id) || 0
        };
      })
      .filter(item => item.count > 0)
      .sort((a, b) => {
        return b.count - a.count;
      })
      .slice(0, 8);

  const orphanDocs =
    docs
      .filter(doc => {
        return (docConnectionCounts.get(doc.id) || 0) === 0;
      })
      .slice(0, 10);

  const brokenRelationships = [];

  for (const rel of explicitRelationships) {
    const source =
      await resolveEntity(
        rel.sourceEntityType,
        rel.sourceEntityId
      );

    const target =
      await resolveEntity(
        rel.targetEntityType,
        rel.targetEntityId
      );

    if (!source || !target) {
      brokenRelationships.push({
        relationship: rel,
        missingSource: !source,
        missingTarget: !target
      });
    }
  }

  const recentRelationships =
    explicitRelationships
      .slice()
      .sort((a, b) => {
        return Number(b.updatedAt || b.createdAt || 0) -
          Number(a.updatedAt || a.createdAt || 0);
      })
      .slice(0, 8);

  return {
    docs,
    explicitRelationships,
    relationshipTypeCounts,
    collectionImplicitCount,
    folderImplicitCount,
    sourceImplicitCount,
    tagImplicitCount,
    mostConnectedDocs,
    orphanDocs,
    brokenRelationships,
    recentRelationships
  };
}

function renderDashboardStatCard(label, value, note = '') {
  return `
    <article class="relationship-dashboard-stat">
      <strong>${escapeHtml(value)}</strong>
      <span>${escapeHtml(label)}</span>
      ${
        note
          ? `<small>${escapeHtml(note)}</small>`
          : ''
      }
    </article>
  `;
}

function renderDashboardSection(title, bodyHtml) {
  return `
    <section class="relationship-dashboard-section">
      <h4>${escapeHtml(title)}</h4>
      ${bodyHtml}
    </section>
  `;
}

async function renderRelationshipDashboard() {
  if (!els.relationshipDashboardBody) {
    return;
  }

  const data =
    await buildRelationshipDashboardData();

  const implicitTotal =
    data.collectionImplicitCount +
    data.folderImplicitCount +
    data.sourceImplicitCount +
    data.tagImplicitCount;

  if (els.relationshipDashboardSubtitle) {
    els.relationshipDashboardSubtitle.textContent =
      `${data.explicitRelationships.length} explicit · ${implicitTotal} implicit relationship${implicitTotal === 1 ? '' : 's'}`;
  }

  const typeRows =
    Array.from(data.relationshipTypeCounts.entries())
      .sort((a, b) => {
        return b[1] - a[1];
      })
      .map(([type, count]) => {
        return `
          <div class="relationship-dashboard-row">
            <span class="relationship-type-pill">
              ${escapeHtml(type)}
            </span>
            <strong>${count}</strong>
          </div>
        `;
      })
      .join('');

  const connectedRows =
    data.mostConnectedDocs.length
      ? data.mostConnectedDocs
          .map(item => {
            return `
              <button
                type="button"
                class="relationship-dashboard-link-row"
                data-relationship-entity-type="document"
                data-relationship-entity-id="${escapeHtml(item.doc.id)}"
              >
                <span>
                  ${escapeHtml(getDocumentTypeIcon(item.doc))}
                </span>

                <strong>
                  ${escapeHtml(item.doc.title || 'Untitled Document')}
                </strong>

                <em>${item.count} link${item.count === 1 ? '' : 's'}</em>
              </button>
            `;
          })
          .join('')
      : '<div class="empty-note">No connected documents yet.</div>';

  const orphanRows =
    data.orphanDocs.length
      ? data.orphanDocs
          .map(doc => {
            return `
              <button
                type="button"
                class="relationship-dashboard-link-row muted"
                data-relationship-entity-type="document"
                data-relationship-entity-id="${escapeHtml(doc.id)}"
              >
                <span>
                  ${escapeHtml(getDocumentTypeIcon(doc))}
                </span>

                <strong>
                  ${escapeHtml(doc.title || 'Untitled Document')}
                </strong>

                <em>No explicit links</em>
              </button>
            `;
          })
          .join('')
      : '<div class="empty-note">No orphan documents. Fancy. Suspiciously organized. ✨</div>';

  const brokenRows =
    data.brokenRelationships.length
      ? data.brokenRelationships
          .map(item => {
            const rel =
              item.relationship;

            return `
              <div class="relationship-dashboard-warning-row">
                <strong>
                  ${escapeHtml(rel.relationType || 'related')}
                </strong>

                <span>
                  ${
                    item.missingSource
                      ? 'Missing source'
                      : ''
                  }
                  ${
                    item.missingSource && item.missingTarget
                      ? ' · '
                      : ''
                  }
                  ${
                    item.missingTarget
                      ? 'Missing target'
                      : ''
                  }
                </span>
              </div>
            `;
          })
          .join('')
      : '<div class="empty-note">No broken explicit relationships found.</div>';

  let recentRows = '';

  for (const rel of data.recentRelationships) {
    const sourceName =
      await getEntityName(
        rel.sourceEntityType,
        rel.sourceEntityId
      );

    const targetName =
      await getEntityName(
        rel.targetEntityType,
        rel.targetEntityId
      );

    recentRows += `
      <div class="relationship-dashboard-recent-row">
        <button
          type="button"
          class="relationship-dashboard-mini-link"
          data-relationship-entity-type="${escapeHtml(rel.sourceEntityType)}"
          data-relationship-entity-id="${escapeHtml(rel.sourceEntityId)}"
        >
          ${escapeHtml(sourceName)}
        </button>

        <span class="relationship-type-pill">
          ${escapeHtml(rel.relationType || 'related')}
        </span>

        <button
          type="button"
          class="relationship-dashboard-mini-link"
          data-relationship-entity-type="${escapeHtml(rel.targetEntityType)}"
          data-relationship-entity-id="${escapeHtml(rel.targetEntityId)}"
        >
          ${escapeHtml(targetName)}
        </button>
      </div>
    `;
  }

  if (!recentRows) {
    recentRows =
      '<div class="empty-note">No explicit relationships yet.</div>';
  }

  els.relationshipDashboardBody.innerHTML = `
    <div class="relationship-dashboard-stats">
      ${renderDashboardStatCard(
        'Explicit',
        data.explicitRelationships.length,
        'Saved links'
      )}

      ${renderDashboardStatCard(
        'Collections',
        data.collectionImplicitCount,
        'Implicit'
      )}

      ${renderDashboardStatCard(
        'Folders',
        data.folderImplicitCount,
        'Implicit'
      )}

      ${renderDashboardStatCard(
        'Sources',
        data.sourceImplicitCount,
        'Implicit'
      )}

      ${renderDashboardStatCard(
        'Tags',
        data.tagImplicitCount,
        'Implicit'
      )}

      ${renderDashboardStatCard(
        'Broken',
        data.brokenRelationships.length,
        'Needs attention'
      )}
    </div>

    <div class="relationship-dashboard-grid">
      ${renderDashboardSection(
        'Relationship Types',
        typeRows || '<div class="empty-note">No explicit relationship types yet.</div>'
      )}

      ${renderDashboardSection(
        'Most Connected Documents',
        connectedRows
      )}

      ${renderDashboardSection(
        'Orphan Documents',
        orphanRows
      )}

      ${renderDashboardSection(
        'Broken Links',
        brokenRows
      )}

      ${renderDashboardSection(
        'Recent Explicit Relationships',
        recentRows
      )}
    </div>
  `;

  wireRelationshipEntityLinks(
    els.relationshipDashboardBody
  );
}

async function openRelationshipDashboardModal() {
  if (!els.relationshipDashboardModal) {
    return;
  }

  els.relationshipDashboardModal.classList.remove('hidden');

  await renderRelationshipDashboard();
}

function closeRelationshipDashboardModal() {
  if (els.relationshipDashboardModal) {
    els.relationshipDashboardModal.classList.add('hidden');
  }
}

function getSelectedLocalGraphNode() {
  if (!localGraphSelectedNodeId) {
    return null;
  }

  return localGraphData.nodes.find(node => {
    return node.id === localGraphSelectedNodeId;
  }) || null;
}

function getLocalGraphEdgesForNode(nodeId) {
  if (!nodeId) {
    return [];
  }

  return localGraphData.edges.filter(edge => {
    return (
      edge.sourceNodeId === nodeId ||
      edge.targetNodeId === nodeId
    );
  });
}

function getOtherLocalGraphNode(edge, nodeId) {
  const otherNodeId =
    edge.sourceNodeId === nodeId
      ? edge.targetNodeId
      : edge.sourceNodeId;

  return localGraphData.nodes.find(node => {
    return node.id === otherNodeId;
  }) || null;
}

function selectLocalGraphNode(nodeId) {
  localGraphSelectedNodeId =
    nodeId || null;

  renderLocalGraph();
}

function closeAllTopMenus() {
  document
    .querySelectorAll('.top-menu[open]')
    .forEach(menu => {
      menu.removeAttribute('open');
    });
}

function clearLocalGraphSelection() {
  localGraphSelectedNodeId = null;

  if (els.localGraphDetailsPanel) {
    els.localGraphDetailsPanel.classList.add('hidden');
  }

  renderLocalGraphEdges();
  renderLocalGraphNodes();
}

function getLocalGraphNodePosition(nodeId) {
  return (
    localGraphPositions[nodeId] || {
      x: 1000,
      y: 700
    }
  );
}

function setLocalGraphNodePosition(nodeId, x, y) {
  localGraphPositions[nodeId] = {
    x,
    y
  };
}

function updateLocalGraphTransform() {
  if (!els.localGraphViewport) {
    return;
  }

  els.localGraphViewport.style.transform =
    `translate(${localGraphPan.x}px, ${localGraphPan.y}px) scale(${localGraphZoom})`;

  if (els.localGraphZoomLabel) {
    els.localGraphZoomLabel.textContent =
      `${Math.round(localGraphZoom * 100)}%`;
  }
  updateLocalGraphMinimapViewport();
}

function screenToLocalGraphPoint(clientX, clientY) {
  const rect =
    els.localGraphSurface.getBoundingClientRect();

  return {
    x:
      (clientX - rect.left - localGraphPan.x) /
      localGraphZoom,

    y:
      (clientY - rect.top - localGraphPan.y) /
      localGraphZoom
  };
}

function clampLocalGraphZoom(value) {
  return Math.max(
    0.35,
    Math.min(
      2.5,
      value
    )
  );
}

function getLocalGraphEdgeGroupKey(edge) {
  return [
    edge.sourceNodeId,
    edge.targetNodeId
  ]
    .sort()
    .join('::');
}

function getBundledRelationshipLabel(edges = []) {
  const labels =
    Array.from(
      new Set(
        edges
          .map(edge => edge.relationType || 'related')
          .filter(Boolean)
      )
    );

  if (!labels.length) {
    return 'related';
  }

  if (labels.length <= 3) {
    return labels.join(' · ');
  }

  return `${labels.slice(0, 3).join(' · ')} +${labels.length - 3}`;
}

function renderLocalGraphEdges() {
  if (!els.localGraphEdges) {
    return;
  }

  els.localGraphEdges.innerHTML = '';

  const edgeGroups =
    new Map();

  localGraphData.edges.forEach(edge => {
    const key =
      getLocalGraphEdgeGroupKey(edge);

    if (!edgeGroups.has(key)) {
      edgeGroups.set(key, []);
    }

    edgeGroups.get(key).push(edge);
  });

  edgeGroups.forEach(groupEdges => {
    const firstEdge =
      groupEdges[0];

    const source =
      getLocalGraphNodePosition(
        firstEdge.sourceNodeId
      );

    const target =
      getLocalGraphNodePosition(
        firstEdge.targetNodeId
      );

    const dx =
      target.x - source.x;

    const dy =
      target.y - source.y;

    const length =
      Math.max(
        1,
        Math.hypot(dx, dy)
      );

    const normalX =
      -dy / length;

    const normalY =
      dx / length;

    /*
      If this bundle contains multiple relationships,
      give the curve a bigger bend so the label does not sit
      directly on top of the straight edge.
    */
    const bundleOffset =
      groupEdges.length > 1
        ? 46
        : 0;

    const midX =
      (source.x + target.x) / 2;

    const midY =
      (source.y + target.y) / 2;

    const controlX =
      midX + normalX * bundleOffset;

    const controlY =
      midY + normalY * bundleOffset;

    const path =
      document.createElementNS(
        'http://www.w3.org/2000/svg',
        'path'
      );

    path.setAttribute(
      'd',
      `
        M ${source.x} ${source.y}
        Q ${controlX} ${controlY}
          ${target.x} ${target.y}
      `
    );

    path.classList.add(
      'local-graph-edge'
    );
    
    if (
  groupEdges.some(edge => {
    return isLocalGraphEdgeConnectedToSelected(edge);
  })
) {
  path.classList.add('selected');
}

    const allImplicit =
      groupEdges.every(edge => edge.isImplicit);

    const hasImplicit =
      groupEdges.some(edge => edge.isImplicit);

    const hasExplicit =
      groupEdges.some(edge => !edge.isImplicit);

    if (allImplicit) {
      path.classList.add('implicit');
    }

    if (hasImplicit && hasExplicit) {
      path.classList.add('mixed');
    }

    const strongest =
      Math.max(
        ...groupEdges.map(edge => {
          return Number(edge.strength || 1) || 1;
        })
      );

    path.setAttribute(
      'stroke-width',
      String(
        Math.max(
          1.5,
          Math.min(
            4,
            strongest
          )
        )
      )
    );

    path.setAttribute('fill', 'none');

    els.localGraphEdges.appendChild(path);

    const label =
      document.createElementNS(
        'http://www.w3.org/2000/svg',
        'text'
      );

    /*
      Push label slightly farther off the line than the control point.
      This is the part that stops it from sitting directly on the edge.
    */
    label.setAttribute(
      'x',
      controlX + normalX * 12
    );

    label.setAttribute(
      'y',
      controlY + normalY * 12 - 8
    );

    label.setAttribute(
      'text-anchor',
      'middle'
    );

    label.classList.add(
      'local-graph-edge-label'
    );
    
    if (
  groupEdges.some(edge => {
    return isLocalGraphEdgeConnectedToSelected(edge);
  })
) {
  label.classList.add('selected');
}

    if (allImplicit) {
      label.classList.add('implicit');
    }

    if (hasImplicit && hasExplicit) {
      label.classList.add('mixed');
    }

    label.textContent =
      getBundledRelationshipLabel(groupEdges);

    els.localGraphEdges.appendChild(label);
  });
}

function renderLocalGraphNodes() {
  if (!els.localGraphNodes) {
    return;
  }

  els.localGraphNodes.innerHTML = '';

  localGraphData.nodes.forEach(node => {
    const position =
      getLocalGraphNodePosition(node.id);

    const button =
      document.createElement('button');

    button.type = 'button';

    button.className = [
  'local-graph-node',
  node.isCurrent ? 'current' : '',
  node.id === localGraphSelectedNodeId ? 'selected' : '',
  isLocalGraphNodeNeighborOfSelected(node.id) ? 'neighbor' : '',
  localGraphSelectedNodeId &&
    node.id !== localGraphSelectedNodeId &&
    !isLocalGraphNodeNeighborOfSelected(node.id)
      ? 'dimmed'
      : '',
  `entity-${node.entityType}`
]
  .filter(Boolean)
  .join(' ');

    button.dataset.nodeId =
      node.id;

    button.dataset.relationshipEntityType =
      node.entityType;

    button.dataset.relationshipEntityId =
      node.entityId;

    button.style.left =
      `${position.x}px`;

    button.style.top =
      `${position.y}px`;

    button.innerHTML = `
      <span class="local-graph-node-icon">
        ${escapeHtml(getRelationshipEntityIcon(node.entityType))}
      </span>

      <span class="local-graph-node-label">
        ${escapeHtml(node.label || 'Untitled')}
      </span>

      <span class="local-graph-node-type">
        ${escapeHtml(getRelationshipEntityLabel(node.entityType))}
      </span>
    `;

    button.addEventListener(
      'pointerdown',
      event => {
        event.stopPropagation();

        const point =
          screenToLocalGraphPoint(
            event.clientX,
            event.clientY
          );

        const currentPosition =
          getLocalGraphNodePosition(node.id);

        localGraphDragNodeId =
          node.id;
        
        localGraphNodeDragStart = {
  x: event.clientX,
  y: event.clientY
};

localGraphSuppressNextNodeClick = false;

        localGraphDragOffset = {
          x: point.x - currentPosition.x,
          y: point.y - currentPosition.y
        };

        button.setPointerCapture(
          event.pointerId
        );
      }
    );

button.addEventListener(
  'click',
  event => {
    if (localGraphSuppressNextNodeClick) {
      localGraphSuppressNextNodeClick = false;
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    event.stopPropagation();

    selectLocalGraphNode(node.id);
  }
);
    
   button.addEventListener(
  'dblclick',
  async event => {
    event.preventDefault();
    event.stopPropagation();

    if (node.isCurrent) {
      closeLocalGraphModal();
      return;
    }

    const entityType =
      node.entityType;

    const entityId =
      node.entityId;

    closeLocalGraphModal();

    await openRelationshipEntity(
      entityType,
      entityId,
      {
        suppressNotice: false
      }
    );
  }
);

    els.localGraphNodes.appendChild(button);
  });
}

function centerLocalGraphOnNode(nodeId) {
  if (!els.localGraphSurface || !nodeId) {
    return;
  }

  const position =
    getLocalGraphNodePosition(nodeId);

  const rect =
    els.localGraphSurface.getBoundingClientRect();

  localGraphPan = {
    x:
      rect.width / 2 -
      position.x * localGraphZoom,

    y:
      rect.height / 2 -
      position.y * localGraphZoom
  };

  updateLocalGraphTransform();
}

async function openSelectedLocalGraphNode() {
  const node =
    getSelectedLocalGraphNode();

  if (!node) {
    return;
  }

  if (node.isCurrent) {
    closeLocalGraphModal();
    return;
  }

  const entityType =
    node.entityType;

  const entityId =
    node.entityId;

  closeLocalGraphModal();

  await openRelationshipEntity(
    entityType,
    entityId,
    {
      suppressNotice: false
    }
  );
}

function getLocalGraphFilterState() {
  return {
    explicit:
      els.localGraphShowExplicit?.checked !== false,

    collections:
      Boolean(
        els.localGraphShowCollections?.checked
      ),

    folders:
      Boolean(
        els.localGraphShowFolders?.checked
      ),

    sources:
      Boolean(
        els.localGraphShowSources?.checked
      ),

    tags:
      Boolean(
        els.localGraphShowTags?.checked
      )
  };
}

function renderLocalGraph() {
  renderLocalGraphEdges();
  renderLocalGraphNodes();
  renderLocalGraphDetails();
  renderLocalGraphMinimap();
  updateLocalGraphTransform();

  if (els.localGraphSubtitle) {
    const nodeCount =
      localGraphData.nodes.length;

    const edgeCount =
      localGraphData.edges.length;

    els.localGraphSubtitle.textContent =
  `${localGraphMode === 'global' ? 'Project-wide' : 'Local'} · ${nodeCount} node${nodeCount === 1 ? '' : 's'} · ${edgeCount} relationship${edgeCount === 1 ? '' : 's'}`;
  }
}

function renderLocalGraphDetails() {
  if (
    !els.localGraphDetailsPanel ||
    !els.localGraphDetailsTitle ||
    !els.localGraphDetailsMeta ||
    !els.localGraphDetailsBody
  ) {
    return;
  }

  const node =
    getSelectedLocalGraphNode();

  if (!node) {
    els.localGraphDetailsPanel.classList.add('hidden');
    return;
  }

  const connectedEdges =
    getLocalGraphEdgesForNode(node.id);

  els.localGraphDetailsPanel.classList.remove('hidden');

  els.localGraphDetailsTitle.textContent =
    node.label || 'Untitled';

  els.localGraphDetailsMeta.textContent =
    `${getRelationshipEntityLabel(node.entityType)} · ${connectedEdges.length} connection${connectedEdges.length === 1 ? '' : 's'}`;

  if (!connectedEdges.length) {
    els.localGraphDetailsBody.innerHTML =
      '<div class="empty-note">No connected relationships.</div>';
    return;
  }

  let html = '';

  connectedEdges.forEach(edge => {
    const otherNode =
      getOtherLocalGraphNode(
        edge,
        node.id
      );

    const direction =
      edge.sourceNodeId === node.id
        ? 'outgoing'
        : 'incoming';

    html += `
      <div class="local-graph-detail-relationship">
        <div class="local-graph-detail-main">
          <span class="relationship-type-pill">
            ${escapeHtml(edge.relationType || 'related')}
          </span>

          <span class="outliner-muted">
            ${escapeHtml(direction)}
          </span>
        </div>

        <button
          type="button"
          class="local-graph-detail-node-link"
          data-local-graph-select-node="${escapeHtml(otherNode?.id || '')}"
        >
          <span>
            ${escapeHtml(getRelationshipEntityIcon(otherNode?.entityType || ''))}
          </span>

          <strong>
            ${escapeHtml(otherNode?.label || 'Missing Item')}
          </strong>
        </button>

        ${
          edge.note
            ? `<div class="local-graph-detail-note">${escapeHtml(edge.note)}</div>`
            : ''
        }

        ${
          edge.isImplicit
            ? '<div class="relationship-implicit-badge">Implicit</div>'
            : ''
        }
      </div>
    `;
  });

  els.localGraphDetailsBody.innerHTML =
    html;

  els.localGraphDetailsBody
    .querySelectorAll('[data-local-graph-select-node]')
    .forEach(button => {
      button.addEventListener('click', event => {
        const nodeId =
          event.currentTarget.dataset.localGraphSelectNode;

        if (!nodeId) {
          return;
        }

        selectLocalGraphNode(nodeId);
        centerLocalGraphOnNode(nodeId);
      });
    });
}

function isLocalGraphEdgeConnectedToSelected(edge) {
  if (!localGraphSelectedNodeId) {
    return false;
  }

  return (
    edge.sourceNodeId === localGraphSelectedNodeId ||
    edge.targetNodeId === localGraphSelectedNodeId
  );
}

function isLocalGraphNodeNeighborOfSelected(nodeId) {
  if (!localGraphSelectedNodeId || nodeId === localGraphSelectedNodeId) {
    return false;
  }

  return localGraphData.edges.some(edge => {
    return (
      edge.sourceNodeId === localGraphSelectedNodeId &&
      edge.targetNodeId === nodeId
    ) || (
      edge.targetNodeId === localGraphSelectedNodeId &&
      edge.sourceNodeId === nodeId
    );
  });
}

function getLocalGraphBounds() {
  const nodes =
    localGraphData.nodes || [];

  if (!nodes.length) {
    return null;
  }

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  nodes.forEach(node => {
    const pos =
      getLocalGraphNodePosition(
        node.id
      );

    minX =
      Math.min(minX, pos.x);

    minY =
      Math.min(minY, pos.y);

    maxX =
      Math.max(maxX, pos.x);

    maxY =
      Math.max(maxY, pos.y);
  });

  return {
    minX,
    minY,
    maxX,
    maxY,
    width:
      Math.max(1, maxX - minX),

    height:
      Math.max(1, maxY - minY),

    centerX:
      (minX + maxX) / 2,

    centerY:
      (minY + maxY) / 2
  };
}

function fitLocalGraphToView() {
  if (!els.localGraphSurface) {
    return;
  }

  const bounds =
    getLocalGraphBounds();

  if (!bounds) {
    return;
  }

  const rect =
    els.localGraphSurface.getBoundingClientRect();

  const padding =
    220;

  const fitZoomX =
    rect.width / (bounds.width + padding);

  const fitZoomY =
    rect.height / (bounds.height + padding);

  localGraphZoom =
    clampLocalGraphZoom(
      Math.min(
        1,
        fitZoomX,
        fitZoomY
      )
    );

  localGraphPan = {
    x:
      rect.width / 2 -
      bounds.centerX * localGraphZoom,

    y:
      rect.height / 2 -
      bounds.centerY * localGraphZoom
  };

  updateLocalGraphTransform();
}

function zoomLocalGraph(delta) {
  localGraphZoom =
    clampLocalGraphZoom(
      localGraphZoom + delta
    );

  updateLocalGraphTransform();
}

async function openGlobalGraphModal() {
  if (!els.localGraphModal) {
    return;
  }

  localGraphMode = 'global';

  resetLocalGraphState();

  if (els.localGraphShowExplicit) {
    els.localGraphShowExplicit.checked = true;
  }

  localGraphData =
    await buildGlobalGraphData();

  autoLayoutLocalGraph();

  if (els.localGraphTitle) {
    els.localGraphTitle.textContent =
      'Global Graph';
  }

  if (els.localGraphModal) {
    els.localGraphModal.classList.add(
      'global-graph-mode'
    );
  }

  els.localGraphModal.classList.remove(
    'hidden'
  );
  els.localGraphMinimap?.classList.remove('hidden');
  const mapButton = document.getElementById('showLocalGraphMinimapBtn'); if (mapButton) mapButton.hidden = true;

  renderLocalGraph();

  requestAnimationFrame(() => {
    fitLocalGraphToView();
  });
}

async function openLocalGraphModal() {
  if (!currentDocumentId) {
    showAppNotice(
      'Open a document first.',
      'No document selected'
    );
    return;
  }

  if (!els.localGraphModal) {
    return;
  }
  
  localGraphMode = 'local';

resetLocalGraphState();

if (els.localGraphShowExplicit) {
  els.localGraphShowExplicit.checked = true;
}

localGraphData =
  await buildLocalGraphData(
    currentDocumentId
  );

autoLayoutLocalGraph();
  
  if (els.localGraphTitle) {
  els.localGraphTitle.textContent =
    'Local Graph';
}

if (els.localGraphModal) {
  els.localGraphModal.classList.remove(
    'global-graph-mode'
  );
}

els.localGraphModal.classList.remove(
  'hidden'
);
els.localGraphMinimap?.classList.remove('hidden');
{ const mapButton = document.getElementById('showLocalGraphMinimapBtn'); if (mapButton) mapButton.hidden = true; }

renderLocalGraph();
  
  requestAnimationFrame(() => {
  fitLocalGraphToView();
});
  
}

function closeLocalGraphModal() {
  els.localGraphMinimap?.classList.add('hidden');
  const mapButton = document.getElementById('showLocalGraphMinimapBtn'); if (mapButton) mapButton.hidden = false;
  if (els.localGraphModal) {
    els.localGraphModal.classList.add(
      'hidden'
    );

    els.localGraphModal.classList.remove(
      'global-graph-mode'
    );
  }

  if (els.localGraphDetailsPanel) {
    els.localGraphDetailsPanel.classList.add(
      'hidden'
    );
  }

  localGraphMode = 'local';
  localGraphDragNodeId = null;
  localGraphIsPanning = false;
  localGraphSelectedNodeId = null;
}

function setupLocalGraphInteractions() {
  if (!els.localGraphSurface) {
    return;
  }

  els.localGraphSurface.addEventListener(
    'pointerdown',
    event => {
      if (
  event.target.closest('.local-graph-node') ||
  event.target.closest('.local-graph-details-panel') ||
  event.target.closest('.local-graph-minimap')
) {
  return;
}

      localGraphIsPanning = true;

      localGraphPanStart = {
        x: event.clientX - localGraphPan.x,
        y: event.clientY - localGraphPan.y
      };

      els.localGraphSurface.setPointerCapture(
        event.pointerId
      );
    }
  );

  els.localGraphSurface.addEventListener(
    'pointermove',
    event => {
      if (localGraphDragNodeId) {
        
        const dragDx =
  event.clientX - localGraphNodeDragStart.x;

const dragDy =
  event.clientY - localGraphNodeDragStart.y;

if (
  Math.hypot(dragDx, dragDy) > 6
) {
  localGraphSuppressNextNodeClick = true;
}
        
        const point =
          screenToLocalGraphPoint(
            event.clientX,
            event.clientY
          );

        setLocalGraphNodePosition(
          localGraphDragNodeId,
          point.x - localGraphDragOffset.x,
          point.y - localGraphDragOffset.y
        );

        renderLocalGraphEdges();

        const nodeEl =
          els.localGraphNodes
            ?.querySelector(
              `[data-node-id="${CSS.escape(localGraphDragNodeId)}"]`
            );

        const position =
          getLocalGraphNodePosition(
            localGraphDragNodeId
          );

        if (nodeEl) {
          nodeEl.style.left =
            `${position.x}px`;

          nodeEl.style.top =
            `${position.y}px`;
        }

        return;
      }

      if (localGraphIsPanning) {
        localGraphPan = {
          x: event.clientX - localGraphPanStart.x,
          y: event.clientY - localGraphPanStart.y
        };

        updateLocalGraphTransform();
      }
    }
  );

  els.localGraphSurface.addEventListener(
    'pointerup',
    event => {
      localGraphDragNodeId = null;
      localGraphIsPanning = false;

      try {
        els.localGraphSurface.releasePointerCapture(
          event.pointerId
        );
      } catch {}
    }
  );

  els.localGraphSurface.addEventListener(
    'wheel',
    event => {
      event.preventDefault();

      const delta =
        event.deltaY > 0
          ? -0.08
          : 0.08;

      zoomLocalGraph(delta);
    },
    {
      passive: false
    }
  );
}

async function renderOutgoingRelationships(docId) {
  if (!els.relationshipOutgoing) {
    return;
  }

  const relationships =
    await getRelationshipsForEntity(
      'document',
      docId
    );

  if (!relationships.length) {
    els.relationshipOutgoing.innerHTML =
      '<div class="empty-note relationship-empty">No relationships.</div>';
    return;
  }

  let html = '';

  for (const rel of relationships) {
    const targetName =
      await getEntityName(
        rel.targetEntityType,
        rel.targetEntityId
      );

    html += `
      <div class="relationship-item">
        <div class="relationship-main">
          <span class="relationship-type-pill">
            ${escapeHtml(rel.relationType || 'related')}
          </span>

          <span class="relationship-arrow">→</span>

          <button
  type="button"
  class="relationship-entity-link relationship-target"
  data-relationship-entity-type="${escapeHtml(rel.targetEntityType)}"
  data-relationship-entity-id="${escapeHtml(rel.targetEntityId)}"
  title="Open linked ${escapeHtml(getRelationshipEntityLabel(rel.targetEntityType))}"
>
  ${escapeHtml(targetName)}
</button>
        </div>

        <div class="relationship-meta">
          <span
            class="relationship-strength"
            title="${escapeHtml(getRelationshipStrengthLabel(rel.strength))}"
          >
            ${escapeHtml(getRelationshipStrengthStars(rel.strength))}
          </span>

          <button
            type="button"
            class="relationship-delete-btn"
            data-relationship-id="${escapeHtml(rel.id)}"
            title="Delete relationship"
          >
            ×
          </button>
        </div>

        ${
          rel.note
            ? `<div class="relationship-note">${escapeHtml(rel.note)}</div>`
            : ''
        }
      </div>
    `;
  }

  els.relationshipOutgoing.innerHTML =
    html;
  
  wireRelationshipEntityLinks(
  els.relationshipOutgoing
);

  els.relationshipOutgoing
    .querySelectorAll('[data-relationship-id]')
    .forEach(button => {
      button.addEventListener('click', async event => {
        event.stopPropagation();

        await deleteRelationship(
          event.currentTarget.dataset.relationshipId
        );

        relationshipsCache =
          await getRelationships();

        await renderRelationshipPanel(docId);

        NaviEditor.setSaveStatus('Relationship deleted');
      });
    });
}

async function renderBacklinks(docId) {
  if (!els.relationshipBacklinks) {
    return;
  }

  const backlinks =
    await getBacklinksForEntity(
      'document',
      docId
    );

  if (!backlinks.length) {
    els.relationshipBacklinks.innerHTML =
      '<div class="empty-note relationship-empty">No references.</div>';
    return;
  }

  let html = '';

  for (const rel of backlinks) {
    const sourceName =
      await getEntityName(
        rel.sourceEntityType,
        rel.sourceEntityId
      );

    html += `
      <div class="relationship-item backlink-item">
        <div class="relationship-main">
          <button
  type="button"
  class="relationship-entity-link relationship-source"
  data-relationship-entity-type="${escapeHtml(rel.sourceEntityType)}"
  data-relationship-entity-id="${escapeHtml(rel.sourceEntityId)}"
  title="Open linked ${escapeHtml(getRelationshipEntityLabel(rel.sourceEntityType))}"
>
  ${escapeHtml(sourceName)}
</button>

          <span class="relationship-arrow">→</span>

          <span class="relationship-type-pill">
            ${escapeHtml(rel.relationType || 'related')}
          </span>

          <span class="relationship-arrow">→</span>

          <span class="relationship-target">
            this
          </span>
        </div>

        <div class="relationship-meta">
          <span
            class="relationship-strength"
            title="${escapeHtml(getRelationshipStrengthLabel(rel.strength))}"
          >
            ${escapeHtml(getRelationshipStrengthStars(rel.strength))}
          </span>

          <button
            type="button"
            class="relationship-delete-btn"
            data-relationship-id="${escapeHtml(rel.id)}"
            title="Delete relationship"
          >
            ×
          </button>
        </div>

        ${
          rel.note
            ? `<div class="relationship-note">${escapeHtml(rel.note)}</div>`
            : ''
        }
      </div>
    `;
  }

  els.relationshipBacklinks.innerHTML =
    html;
  
  wireRelationshipEntityLinks(
  els.relationshipBacklinks
);

  els.relationshipBacklinks
    .querySelectorAll('[data-relationship-id]')
    .forEach(button => {
      button.addEventListener('click', async event => {
        event.stopPropagation();

        await deleteRelationship(
          event.currentTarget.dataset.relationshipId
        );

        relationshipsCache =
          await getRelationships();

        await renderRelationshipPanel(docId);

        NaviEditor.setSaveStatus('Relationship deleted');
      });
    });
}

function safeFileName(name) {
  return String(name || 'Untitled Document')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'Untitled Document';
}

function parseTags(value) {
  return String(value || '')
    .split(',')
    .map(tag => tag.trim())
    .filter(Boolean);
}

function formatDate(timestamp) {
  if (!timestamp) return 'Unknown date';

  const date = new Date(timestamp);

  return date.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

async function getOrderedManuscriptDocs(rootDoc) {
  const allDocs = await NaviStorage.getAllDocuments();

  const children = allDocs.filter(doc => doc.parentId === rootDoc.id);

  const orderedChildren = sortDocumentsForDisplay(children);

  return [
    rootDoc,
    ...orderedChildren.filter(doc => doc.docType === 'chapter'),
    ...orderedChildren.filter(doc => doc.docType !== 'chapter')
  ];
}

function getActiveCollectionFromCache() {
  return getCollectionById(collectionsCache, activeCollectionId);
}

function docMatchesCollectionPickerSearch(doc, query = '') {
  const needle =
    String(query || '').trim().toLowerCase();

  if (!needle) return true;

  const haystack = [
    doc.title,
    doc.docType,
    doc.folder,
    doc.status,
    doc.pov,
    doc.location,
    doc.timeline,
    doc.characters,
    doc.summary,
    Array.isArray(doc.tags) ? doc.tags.join(', ') : ''
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();

  return haystack.includes(needle);
}

function renderCollectionDocPickerList() {
  if (!els.collectionDocPickerList) return;

  const collection =
    getActiveCollectionFromCache();

  if (!collection) {
    els.collectionDocPickerList.innerHTML =
      '<div class="empty-note">Choose a collection first.</div>';
    return;
  }

  const query =
    els.collectionDocPickerSearch?.value || '';

  const typeFilter =
    els.collectionDocPickerTypeFilter?.value || '';

  const existingIds =
    new Set(collection.documentIds || []);

  const docs =
    documentsCache
      .filter(doc => {
        if (existingIds.has(doc.id)) return false;

        if (typeFilter && (doc.docType || 'general') !== typeFilter) {
          return false;
        }

        return docMatchesCollectionPickerSearch(doc, query);
      })
      .sort((a, b) => {
        return String(a.title || '').localeCompare(String(b.title || ''));
      });

  if (!docs.length) {
    els.collectionDocPickerList.innerHTML =
      '<div class="empty-note">No matching documents to add.</div>';
    return;
  }

  els.collectionDocPickerList.innerHTML = '';

  docs.forEach(doc => {
    const row =
      document.createElement('label');

    row.className = 'collection-picker-row';

    const checked =
      pendingCollectionPickerSelectedIds.has(doc.id);

    row.innerHTML = `
      <input
        type="checkbox"
        value="${escapeHtml(doc.id)}"
        ${checked ? 'checked' : ''}
      />

      <span class="collection-picker-doc-icon">
        ${escapeHtml(getDocumentTypeIcon(doc))}
      </span>

      <span class="collection-picker-doc-main">
        <strong>${escapeHtml(doc.title || 'Untitled Document')}</strong>
        <span>
          ${escapeHtml(getReadableDocType(doc))}
          • ${Number(doc.wordCount || 0).toLocaleString()} words
          ${
            doc.folder
              ? ` • 📁 ${escapeHtml(doc.folder)}`
              : ''
          }
        </span>
      </span>
    `;

    row.querySelector('input')?.addEventListener('change', event => {
      const id =
        event.currentTarget.value;

      if (event.currentTarget.checked) {
        pendingCollectionPickerSelectedIds.add(id);
      } else {
        pendingCollectionPickerSelectedIds.delete(id);
      }
    });

    els.collectionDocPickerList.appendChild(row);
  });
}

async function openCollectionDocPicker() {
  collectionsCache =
    await getCollections();

  const collection =
    getActiveCollectionFromCache();

  if (!collection) {
    showAppNotice(
      'Choose or create a collection first.',
      'No collection selected'
    );
    return;
  }

  pendingCollectionPickerSelectedIds =
    new Set();

  if (els.collectionPickerSubtitle) {
    els.collectionPickerSubtitle.textContent =
      `Add documents to "${collection.name || 'Untitled Collection'}".`;
  }

  if (els.collectionDocPickerSearch) {
    els.collectionDocPickerSearch.value = '';
  }

  if (els.collectionDocPickerTypeFilter) {
    els.collectionDocPickerTypeFilter.value = '';
  }

  if (els.collectionsModal) {
  els.collectionsModal.classList.add('collection-picker-open');
}

if (els.collectionDocPickerModal) {
  els.collectionDocPickerModal.classList.remove('hidden');
}

  renderCollectionDocPickerList();

  setTimeout(() => {
    els.collectionDocPickerSearch?.focus();
  }, 0);
}

function closeCollectionDocPicker() {
  pendingCollectionPickerSelectedIds.clear();

 if (els.collectionDocPickerModal) {
  els.collectionDocPickerModal.classList.add('hidden');
}

if (els.collectionsModal) {
  els.collectionsModal.classList.remove('collection-picker-open');
}
}


async function submitCollectionDocPicker() {
  const selectedIds =
    Array.from(pendingCollectionPickerSelectedIds);

  if (!selectedIds.length) {
    showAppNotice(
      'Select at least one document to add.',
      'No documents selected'
    );
    return;
  }

  const collections =
    await getCollections();

  const collection =
    getCollectionById(collections, activeCollectionId);

  if (!collection) {
    showAppNotice(
      'Choose a collection first.',
      'No collection selected'
    );
    return;
  }

  const existingIds =
    new Set(collection.documentIds || []);

  selectedIds.forEach(id => {
    existingIds.add(id);
  });

  collection.documentIds =
    Array.from(existingIds);

  collection.updatedAt =
    Date.now();

  await saveCollections(collections);

  collectionsCache =
    await getCollections();

  closeCollectionDocPicker();

  await renderCollectionsModal();
  renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Documents added to collection');
}

async function loadDocuments() {
  documentsCache = await NaviStorage.getAllDocuments();
  collectionsCache = await getCollections();
  renderDocumentList(documentsCache);
  
  if (
  els.splitPane &&
  !els.splitPane.classList.contains('hidden')
) {
  populateSplitDocSelect();
}


  if (els.docCount) {
    const count = documentsCache.length;
    els.docCount.textContent = `${count} ${count === 1 ? 'doc' : 'docs'}`;
  }

  return documentsCache;
}

async function saveSplitStateForDocument(docId, splitDocId = '') {
  if (!docId) return;

  const doc =
    await NaviStorage.getDocument(docId);

  if (!doc) return;

  const updated = {
    ...doc,
    splitPaneDocId:
      splitDocId || '',
    updatedAt:
      Date.now()
  };

  const saved =
    await NaviStorage.saveDocument(updated);

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  renderDocumentList(documentsCache);
}

function isSplitOpen() {
  return Boolean(
    els.splitPane &&
    !els.splitPane.classList.contains('hidden')
  );
}

function showSplitShell() {
  if (els.workspace) {
    els.workspace.classList.add('split-active');els.workspace.classList.toggle('split-vertical',matchMedia('(min-width:721px) and (max-width:1050px)').matches);
  }

  const vertical=matchMedia('(min-width:721px) and (max-width:1050px)').matches;els.workspace?.classList.toggle('split-vertical',vertical);els.workspace?.style.setProperty('--split-width-ratio',Math.max(.22,Math.min(.72,Number(localStorage.getItem('naviwriter-split-width-ratio')||.42))));els.workspace?.style.setProperty('--split-height-ratio',Math.max(.25,Math.min(.72,Number(localStorage.getItem('naviwriter-split-height-ratio')||.46))));

  if (els.splitPane) {
    els.splitPane.classList.remove('hidden');
  }

  if (els.splitResizeHandle) {
    els.splitResizeHandle.classList.remove('hidden');
  }

  if (els.openSplitEditorBtn) {
    els.openSplitEditorBtn.classList.add('active');
  }
}



function cleanupSplitViewer(){clearTimeout(splitPaneAutosaveTimer);const viewer=els.splitDocContent?.querySelector('.split-reference-viewer');try{viewer?._naviCleanup?.();}catch{}if(els.splitDocContent){els.splitDocContent.replaceChildren(Object.assign(document.createElement('div'),{className:'empty-note',textContent:'Select a document to preview it here.'}));}if(els.splitPane){els.splitPane.scrollTop=0;}if(els.workspace){els.workspace.classList.remove('split-active','split-rendering','split-reference-active','split-vertical');els.workspace.style.removeProperty('grid-template-columns');}document.body.classList.remove('split-pane-open','split-reference-pane-open');}

function hideSplitShell(){cleanupSplitViewer();els.splitPane?.classList.add('hidden');els.splitResizeHandle?.classList.add('hidden');els.openSplitEditorBtn?.classList.remove('active');requestAnimationFrame(()=>{window.dispatchEvent(new Event('resize'));window.NaviEditor?.focusEditor?.();});}

function normalizeSourceList(sources) {
  if (!Array.isArray(sources)) {
    return [];
  }

  return sources.map(source => {
    return {
      id: source.id || crypto.randomUUID(),
      title: source.title || '',
      url: source.url || '',
      author: source.author || '',
      dateAccessed: source.dateAccessed || '',
      tags: Array.isArray(source.tags)
        ? source.tags
        : parseTags(source.tags || ''),
      notes: source.notes || '',
      createdAt: source.createdAt || Date.now(),
      updatedAt: source.updatedAt || Date.now()
    };
  });
}

function getRelationshipStrengthLabel(
  strength = 1
) {
  switch (Number(strength) || 1) {
    case 5:
      return 'Critical';

    case 4:
      return 'Strong';

    case 3:
      return 'Normal';

    case 2:
      return 'Light';

    default:
      return 'Weak';
  }
}

function getRelationshipStrengthStars(
  strength = 1
) {
  return '★'.repeat(
    Math.max(
      1,
      Math.min(
        5,
        Number(strength) || 1
      )
    )
  );
}

function getCurrentSourceList(doc) {
  return normalizeSourceList(doc?.sources || []);
}

function formatSourceDate(value) {
  if (!value) return '';

  try {
    return new Date(`${value}T00:00:00`).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  } catch {
    return value;
  }
}

async function resolveEntity(type, id) {
  if (!type || !id) {
    return null;
  }

  if (type === 'document') {
    return await NaviStorage.getDocument(id);
  }

  if (type === 'collection') {
    const collections =
      await getCollections();

    return collections.find(collection => {
      return collection.id === id;
    }) || null;
  }

  if (type === 'folder') {
    const docs =
      documentsCache.length
        ? documentsCache
        : await NaviStorage.getAllDocuments();

    const folderName =
      String(id || '').trim();

    const count =
      docs.filter(doc => {
        return getDocumentFolderName(doc) === folderName;
      }).length;

    if (!folderName) {
      return null;
    }

    return {
      id: folderName,
      name: folderName,
      title: folderName,
      type: 'folder',
      count
    };
  }

  if (type === 'source') {
    const docs =
      documentsCache.length
        ? documentsCache
        : await NaviStorage.getAllDocuments();

    for (const doc of docs) {
      const sources =
        getCurrentSourceList(doc);

      const found =
        sources.find(source => {
          return getSourceEntityId(doc.id, source.id) === id;
        });

      if (found) {
        return {
          ...found,
          title: found.title || 'Untitled Source',
          parentDocumentId: doc.id,
          parentDocumentTitle: doc.title || 'Untitled Document'
        };
      }
    }

    return null;
  }
  
  if (type === 'tag') {
  const tagName =
    String(id || '').trim();

  if (!tagName) {
    return null;
  }

  return {
    id: tagName,
    name: `#${tagName}`,
    title: `#${tagName}`,
    type: 'tag'
  };
}

  return null;
}


function parseSourceEntityId(entityId = '') {
  const parts =
    String(entityId || '').split('::');

  return {
    docId: parts[0] || '',
    sourceId: parts[1] || ''
  };
}

async function openRelationshipEntity(
  entityType,
  entityId,
  options = {}
) {
  const closeOutliner =
    Boolean(options.closeOutliner);
  
  const suppressNotice =
  Boolean(options.suppressNotice);

  if (!entityType || !entityId) {
    return;
  }

  if (entityType === 'document') {
    if (
      closeOutliner &&
      typeof closeOutlinerModal === 'function'
    ) {
      closeOutlinerModal();
    }

    await openDocument(entityId);
    return;
  }

  if (entityType === 'collection') {
    activeCollectionId =
      entityId;

    if (
      closeOutliner &&
      typeof closeOutlinerModal === 'function'
    ) {
      closeOutlinerModal();
    }

    await openCollectionsModal();
    return;
  }

  if (entityType === 'folder') {
    activeFolderFilter =
      entityId;

    if (
      closeOutliner &&
      typeof closeOutlinerModal === 'function'
    ) {
      closeOutlinerModal();
    }

    renderDocumentList(
      documentsCache
    );

    showAppNotice(
      `Filtered sidebar to folder "${entityId}".`,
      'Folder opened'
    );

    return;
  }

  if (entityType === 'source') {
    const parsed =
      parseSourceEntityId(entityId);

    if (!parsed.docId) {
      showAppNotice(
        'Could not find the source document.',
        'Source not found'
      );
      return;
    }

    if (
      closeOutliner &&
      typeof closeOutlinerModal === 'function'
    ) {
      closeOutlinerModal();
    }

    await openDocument(
      parsed.docId
    );

    if (typeof setSourcesMode === 'function') {
      setSourcesMode(true);
    }

    const doc =
      await NaviStorage.getDocument(
        parsed.docId
      );

    if (!doc) {
      return;
    }

    const source =
      getCurrentSourceList(doc)
        .find(item => {
          return getSourceEntityId(
            parsed.docId,
            item.id
          ) === entityId;
        });

    if (
      source &&
      typeof openSourceModal === 'function'
    ) {
      openSourceModal(source);
    }

    return;
  }
  
  if (entityType === 'tag') {
  if (
    closeOutliner &&
    typeof closeOutlinerModal === 'function'
  ) {
    closeOutlinerModal();
  }

  showAppNotice(
    `Tag "${entityId}" is an implicit relationship. Tag filtering can be added in a later UI pass.`,
    'Tag relationship'
  );

  return;
}

  showAppNotice(
    'This relationship target cannot be opened directly yet.',
    'Link not available'
  );
}

function wireRelationshipEntityLinks(
  container,
  options = {}
) {
  if (!container) {
    return;
  }

  container
    .querySelectorAll(
      '[data-relationship-entity-type][data-relationship-entity-id]'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        async event => {
          event.stopPropagation();

          const entityType =
            event.currentTarget.dataset.relationshipEntityType;

          const entityId =
            event.currentTarget.dataset.relationshipEntityId;

          await openRelationshipEntity(
            entityType,
            entityId,
            options
          );
        }
      );
    });
}

async function getEntityName(type, id) {
  const entity =
    await resolveEntity(type, id);

  if (!entity) {
    return 'Missing Item';
  }

  if (type === 'source' && entity.parentDocumentTitle) {
    return `${entity.title || 'Untitled Source'} · ${entity.parentDocumentTitle}`;
  }

  return (
    entity.title ||
    entity.name ||
    'Untitled'
  );
}

async function getRelationshipTargetOptions(type = 'document') {
  if (type === 'document') {
    const docs =
      documentsCache.length
        ? documentsCache
        : await NaviStorage.getAllDocuments();

    return docs
      .filter(doc => doc.id !== currentDocumentId)
      .sort((a, b) => {
        return String(a.title || '').localeCompare(String(b.title || ''));
      })
      .map(doc => ({
        id: doc.id,
        label: `${getDocumentTypeIcon(doc)} ${doc.title || 'Untitled Document'}`,
        desc: getReadableDocType(doc)
      }));
  }

  if (type === 'collection') {
    const collections =
      await getCollections();

    return collections
      .slice()
      .sort((a, b) => {
        return String(a.name || '').localeCompare(String(b.name || ''));
      })
      .map(collection => ({
        id: collection.id,
        label: `🗂 ${collection.name || 'Untitled Collection'}`,
        desc: getCollectionDocCountLabel(collection)
      }));
  }

  if (type === 'folder') {
    const docs =
      documentsCache.length
        ? documentsCache
        : await NaviStorage.getAllDocuments();

    return getFolderNamesFromDocuments(docs)
      .map(folder => ({
        id: folder,
        label: `📁 ${folder}`,
        desc: 'Folder'
      }));
  }

  if (type === 'source') {
    const docs =
      documentsCache.length
        ? documentsCache
        : await NaviStorage.getAllDocuments();

    const options = [];

    docs.forEach(doc => {
      getCurrentSourceList(doc).forEach(source => {
        options.push({
          id: getSourceEntityId(doc.id, source.id),
          label: `🔬 ${source.title || 'Untitled Source'}`,
          desc: doc.title || 'Untitled Document'
        });
      });
    });

    return options.sort((a, b) => {
      return String(a.label || '').localeCompare(String(b.label || ''));
    });
  }

  return [];
}

async function populateRelationshipTypeSelect(selectedType = '') {
  if (!els.relationshipTypeSelect) {
    return;
  }

  const types =
    await getRelationshipTypes();

  const selected =
    normalizeRelationshipTypeName(selectedType) ||
    els.relationshipTypeSelect.value ||
    'related';

  els.relationshipTypeSelect.innerHTML = '';

  types.forEach(type => {
    const option =
      document.createElement('option');

    option.value = type;
    option.textContent = type;

    els.relationshipTypeSelect.appendChild(option);
  });

  if (!types.includes(selected)) {
    const option =
      document.createElement('option');

    option.value = selected;
    option.textContent = selected;

    els.relationshipTypeSelect.appendChild(option);
  }

  els.relationshipTypeSelect.value =
    selected;
}

async function populateRelationshipTargetSelect() {
  if (
    !els.relationshipTargetTypeSelect ||
    !els.relationshipTargetSelect
  ) {
    return;
  }

  const type =
    els.relationshipTargetTypeSelect.value || 'document';

  const options =
    await getRelationshipTargetOptions(type);

  els.relationshipTargetSelect.innerHTML =
    '<option value="">Choose target...</option>';

  options.forEach(option => {
    const item =
      document.createElement('option');

    item.value =
      option.id;

    item.textContent =
      option.desc
        ? `${option.label} — ${option.desc}`
        : option.label;

    els.relationshipTargetSelect.appendChild(item);
  });

  if (!options.length) {
    const empty =
      document.createElement('option');

    empty.value = '';
    empty.textContent = 'No targets available';
    els.relationshipTargetSelect.appendChild(empty);
  }
}

async function renderRelationshipTypesModal() {
  if (!els.relationshipTypesList) {
    return;
  }

  const customTypes =
    await getCustomRelationshipTypes();

  const defaultHtml =
    DEFAULT_RELATIONSHIP_TYPES
      .map(type => {
        return `
          <div class="relationship-type-row default-type">
            <span>${escapeHtml(type)}</span>
            <span class="relationship-type-badge">Default</span>
          </div>
        `;
      })
      .join('');

  const customHtml =
    customTypes.length
      ? customTypes
          .map(type => {
            return `
              <div class="relationship-type-row">
                <span>${escapeHtml(type)}</span>

                <button
                  type="button"
                  class="relationship-type-delete-btn"
                  data-relationship-type="${escapeHtml(type)}"
                  title="Delete custom type"
                >
                  ×
                </button>
              </div>
            `;
          })
          .join('')
      : `
          <div class="empty-note relationship-type-empty">
            No custom types yet.
          </div>
        `;

  els.relationshipTypesList.innerHTML = `
    <div class="relationship-type-group">
      <div class="relationship-type-group-title">Default Types</div>
      ${defaultHtml}
    </div>

    <div class="relationship-type-group">
      <div class="relationship-type-group-title">Custom Types</div>
      ${customHtml}
    </div>
  `;

  els.relationshipTypesList
    .querySelectorAll('[data-relationship-type]')
    .forEach(button => {
      button.addEventListener('click', async event => {
        const type =
          event.currentTarget.dataset.relationshipType;

        if (!type) {
          return;
        }

        await deleteCustomRelationshipType(type);

        await renderRelationshipTypesModal();
        await populateRelationshipTypeSelect(
          els.relationshipTypeSelect?.value || 'related'
        );

        NaviEditor.setSaveStatus('Relationship type deleted');
      });
    });
}

async function openRelationshipTypesModal() {
  if (!els.relationshipTypesModal) {
    return;
  }

  if (els.relationshipTypeNameInput) {
    els.relationshipTypeNameInput.value = '';
  }

  await renderRelationshipTypesModal();

  els.relationshipTypesModal.classList.remove('hidden');

  setTimeout(() => {
    els.relationshipTypeNameInput?.focus();
  }, 0);
}

function closeRelationshipTypesModal() {
  if (els.relationshipTypesModal) {
    els.relationshipTypesModal.classList.add('hidden');
  }
}

async function submitRelationshipTypeAdd() {
  const value =
    els.relationshipTypeNameInput?.value || '';

  const createdType =
    await addCustomRelationshipType(value);

  if (!createdType) {
    return;
  }

  if (els.relationshipTypeNameInput) {
    els.relationshipTypeNameInput.value = '';
  }

  await renderRelationshipTypesModal();
  await populateRelationshipTypeSelect(createdType);

  NaviEditor.setSaveStatus('Relationship type added');
}

async function openRelationshipModal() {
  if (!currentDocumentId) {
    showAppNotice(
      'Open a document first.',
      'No document selected'
    );
    return;
  }

  if (!els.relationshipModal) {
    return;
  }

  if (els.relationshipTargetTypeSelect) {
    els.relationshipTargetTypeSelect.value = 'document';
  }

  await populateRelationshipTypeSelect('related');

  if (els.relationshipStrengthSelect) {
    els.relationshipStrengthSelect.value = '3';
  }

  if (els.relationshipNoteInput) {
    els.relationshipNoteInput.value = '';
  }

  await populateRelationshipTargetSelect();

  els.relationshipModal.classList.remove('hidden');

  setTimeout(() => {
    els.relationshipTargetSelect?.focus();
  }, 0);
}

function closeRelationshipModal() {
  if (els.relationshipModal) {
    els.relationshipModal.classList.add('hidden');
  }
}

async function submitRelationshipModal() {
  if (!currentDocumentId) {
    return;
  }

  const targetType =
    els.relationshipTargetTypeSelect?.value || 'document';

  const targetId =
    els.relationshipTargetSelect?.value || '';

  const relationType =
    els.relationshipTypeSelect?.value || 'related';

  const strength =
    Number(els.relationshipStrengthSelect?.value || 1) || 1;

  const note =
    els.relationshipNoteInput?.value.trim() || '';

  if (!targetId) {
    showAppNotice(
      'Choose something to link to.',
      'No target selected'
    );
    return;
  }

  await createRelationship({
    sourceEntityType: 'document',
    sourceEntityId: currentDocumentId,

    targetEntityType: targetType,
    targetEntityId: targetId,

    relationType,
    note,
    strength
  });

  relationshipsCache =
    await getRelationships();

  closeRelationshipModal();

  await renderRelationshipPanel(currentDocumentId);

  NaviEditor.setSaveStatus('Relationship created');
}

function getSourceEntityId(docId, sourceId) {
  return `${docId}::${sourceId}`;
}

async function
getBacklinksForEntity(
  entityType,
  entityId
) {
  const relationships =
    await getRelationships();

  return relationships.filter(
    r =>
      r.targetEntityType === entityType &&
      r.targetEntityId === entityId
  );
}

async function getRelationships() {
  const saved =
    await NaviStorage.getSetting(
      RELATIONSHIPS_KEY,
      []
    );

  return Array.isArray(saved)
    ? saved.map(r => ({
        strength: 1,
        note: '',
        ...r
      }))
    : [];
}

function normalizeRelationshipTypeName(value = '') {
  return String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, 48);
}

async function getCustomRelationshipTypes() {
  const saved =
    await NaviStorage.getSetting(
      RELATIONSHIP_TYPES_KEY,
      []
    );

  if (!Array.isArray(saved)) {
    return [];
  }

  return saved
    .map(normalizeRelationshipTypeName)
    .filter(Boolean);
}

async function saveCustomRelationshipTypes(types = []) {
  const cleanTypes =
    Array.from(
      new Set(
        types
          .map(normalizeRelationshipTypeName)
          .filter(Boolean)
      )
    )
      .filter(type => {
        return !DEFAULT_RELATIONSHIP_TYPES.includes(type);
      })
      .sort((a, b) => {
        return a.localeCompare(b);
      });

  await NaviStorage.saveSetting(
    RELATIONSHIP_TYPES_KEY,
    cleanTypes
  );

  return cleanTypes;
}

async function getRelationshipTypes() {
  const customTypes =
    await getCustomRelationshipTypes();

  return Array.from(
    new Set([
      ...DEFAULT_RELATIONSHIP_TYPES,
      ...customTypes
    ])
  );
}

async function addCustomRelationshipType(name) {
  const cleanName =
    normalizeRelationshipTypeName(name);

  if (!cleanName) {
    showAppNotice(
      'Enter a relationship type name.',
      'Missing relationship type'
    );
    return null;
  }

  const currentTypes =
    await getCustomRelationshipTypes();

  const allTypes =
    await getRelationshipTypes();

  if (allTypes.includes(cleanName)) {
    showAppNotice(
      `"${cleanName}" already exists.`,
      'Duplicate relationship type'
    );
    return cleanName;
  }

  currentTypes.push(cleanName);

  await saveCustomRelationshipTypes(currentTypes);

  return cleanName;
}

async function deleteCustomRelationshipType(name) {
  const cleanName =
    normalizeRelationshipTypeName(name);

  if (!cleanName) {
    return;
  }

  if (DEFAULT_RELATIONSHIP_TYPES.includes(cleanName)) {
    showAppNotice(
      'Default relationship types cannot be deleted.',
      'Protected type'
    );
    return;
  }

  const currentTypes =
    await getCustomRelationshipTypes();

  const nextTypes =
    currentTypes.filter(type => {
      return type !== cleanName;
    });

  await saveCustomRelationshipTypes(nextTypes);
}

async function saveRelationships(
  relationships
) {
  await NaviStorage.saveSetting(
    RELATIONSHIPS_KEY,
    Array.isArray(relationships)
      ? relationships
      : []
  );
}

async function createRelationship(
  relationship
) {
  const relationships =
    await getRelationships();

  const newRelationship = {
    id: crypto.randomUUID(),

    sourceEntityType: 'document',
    sourceEntityId: '',

    targetEntityType: 'document',
    targetEntityId: '',

    relationType: 'related',

    note: '',

    // FUTURE GRAPH SUPPORT
    strength: 1,

    createdAt: Date.now(),
    updatedAt: Date.now(),

    ...relationship
  };

  relationships.push(
    newRelationship
  );

  await saveRelationships(
    relationships
  );

  relationshipsCache =
    relationships;

  return newRelationship;
}

async function updateRelationship(
  id,
  updates
) {
  const relationships =
    await getRelationships();

  const index =
    relationships.findIndex(
      r => r.id === id
    );

  if (index < 0) {
    return null;
  }

  relationships[index] = {
    ...relationships[index],
    ...updates,
    updatedAt: Date.now()
  };

  await saveRelationships(
    relationships
  );

  relationshipsCache =
    relationships;

  return relationships[index];
}

async function deleteRelationship(
  id
) {
  const relationships =
    await getRelationships();

  const filtered =
    relationships.filter(
      r => r.id !== id
    );

  await saveRelationships(
    filtered
  );

  relationshipsCache = filtered;
}

async function
getRelationshipsForEntity(
  entityType,
  entityId
) {
  const relationships =
    await getRelationships();

  return relationships.filter(
    r =>
      r.sourceEntityType === entityType &&
      r.sourceEntityId === entityId
  );
}

function makeEntityRef(
  type,
  id
) {
  return {
    entityType: String(type),
    entityId: String(id)
  };
}

function isResearchDocument(doc) {
  return doc?.docType === 'research';
}

function openChoiceModal({
  title = 'Choose Option',
  subtitle = 'Select an option.',
  options = []
} = {}) {
  if (
    !els.choiceModal ||
    !els.choiceModalGrid
  ) {
    return Promise.resolve(null);
  }

  if (els.choiceModalTitle) {
    els.choiceModalTitle.textContent = title;
  }

  if (els.choiceModalSubtitle) {
    els.choiceModalSubtitle.textContent = subtitle;
  }

  els.choiceModalGrid.innerHTML = '';

  if (!options.length) {
    els.choiceModalGrid.innerHTML =
      '<div class="empty-note">No options available.</div>';
  }

  options.forEach(option => {
    const card = document.createElement('button');

    card.type = 'button';
    card.className = 'choice-card';
    card.dataset.choiceValue = option.value;

    const iconHtml = option.color
      ? `<span class="choice-card-color-swatch" style="background:${option.color}"></span>`
      : `<span class="choice-card-icon">${option.icon || '•'}</span>`;

    card.innerHTML = `
      ${iconHtml}
      <span class="choice-card-title">${escapeHtml(option.title || option.value)}</span>
      <span class="choice-card-desc">${escapeHtml(option.desc || '')}</span>
    `;

    card.onclick = () => {
      resolveChoiceModal(option.value);
    };

    els.choiceModalGrid.appendChild(card);
  });

  els.choiceModal.classList.remove('hidden');

  return new Promise(resolve => {
    pendingChoiceResolve = resolve;
  });
}

function resolveChoiceModal(value = null) {
  if (els.choiceModal) {
    els.choiceModal.classList.add('hidden');
  }

  const resolver = pendingChoiceResolve;

  pendingChoiceResolve = null;

  if (resolver) {
    resolver(value);
  }
}

function getSplitCandidateDocuments() {
  return documentsCache
    .slice()
    .sort((a, b) => {
      const titleA = String(a.title || '').toLowerCase();
      const titleB = String(b.title || '').toLowerCase();

      return titleA.localeCompare(titleB);
    });
}

function getSplitDocOptionLabel(doc) {
  const icon =
    typeof getDocumentTypeIcon === 'function'
      ? getDocumentTypeIcon(doc)
      : '📄';

  const type =
    typeof getReadableDocType === 'function'
      ? getReadableDocType(doc)
      : doc.docType || 'Doc';

  return `${icon} ${doc.title || 'Untitled Document'} — ${type}`;
}

async function populateSplitDocSelect(){if(!els.splitDocSelect)return;const previousValue=splitPaneDocId||els.splitDocSelect.value||'';const currentDocs=await NaviStorage.getAllDocuments();documentsCache=Array.isArray(currentDocs)?currentDocs:documentsCache;const liveIds=new Set(documentsCache.map(doc=>doc.id));if(splitPaneDocId&&!liveIds.has(splitPaneDocId))splitPaneDocId=null;const query=String(els.splitDocSearch?.value||'').trim().toLowerCase(),model=NaviDocumentTree?.build?.(documentsCache);const docs=getSplitCandidateDocuments().filter(doc=>doc.id!==currentDocumentId).filter(doc=>{if(!query)return true;const node=model?.nodes?.get(doc.id),breadcrumb=node?.ancestors?.map(id=>documentsCache.find(item=>item.id===id)?.title||'').filter(Boolean).join(' / ')||'';return[doc.title,getReadableDocType(doc),breadcrumb].filter(Boolean).join(' ').toLowerCase().includes(query);});els.splitDocSelect.innerHTML='<option value=>Choose document...</option>';docs.forEach(doc=>{const option=document.createElement('option');option.value=doc.id;option.textContent=getSplitDocOptionLabel(doc);els.splitDocSelect.appendChild(option);});if(docs.some(doc=>doc.id===previousValue))els.splitDocSelect.value=previousValue;else els.splitDocSelect.value='';}

function getFallbackSplitDocumentId() {
  const docs =
    getSplitCandidateDocuments();

  const firstOther =
    docs.find(doc => doc.id !== currentDocumentId);

  return firstOther?.id || docs[0]?.id || '';
}

function installPointerCenteredZoom(host,getZoom,setZoom,rerender=null){let frame=0;host.addEventListener('wheel',event=>{if(!(event.ctrlKey||event.metaKey))return;event.preventDefault();event.stopPropagation();const rect=host.getBoundingClientRect(),px=event.clientX-rect.left,py=event.clientY-rect.top,old=Number(getZoom()||1),delta=Math.max(-.12,Math.min(.12,-event.deltaY*.0015)),next=Math.max(.25,Math.min(4,Math.round(old*(1+delta)*100)/100));if(next===old)return;const cx=host.scrollLeft+px,cy=host.scrollTop+py;setZoom(next);cancelAnimationFrame(frame);frame=requestAnimationFrame(async()=>{if(rerender)await rerender();const ratio=next/old;host.scrollLeft=cx*ratio-px;host.scrollTop=cy*ratio-py;});},{passive:false});}

async function renderSplitReferenceViewer(doc,host,asset){const ext=String(asset.originalName||'').split('.').pop().toLowerCase();host.className='split-reference-viewer';host.dataset.readerFormat=ext;host.dataset.readerFilename=asset.originalName||doc.title||'';host.dataset.readerDocumentId=doc.id||'';host.dataset.readerAssetId=asset.id||'';if(ext==='pdf'){const controls=document.createElement('div');controls.className='split-reference-toolbar';controls.innerHTML='<button data-prev>‹</button><span data-page>1/1</span><button data-next>›</button><button data-minus>−</button><span data-zoom>100%</span><button data-plus>+</button><button data-fit>Fit Width</button><button data-rotate>Rotate</button><button data-download>Download</button>';const stage=document.createElement('div');stage.className='split-reference-stage';const canvas=document.createElement('canvas');stage.appendChild(canvas);host.replaceChildren(controls,stage);const pdf=await NaviPdfViewer.loadBlob(asset.blob),state={page:1,zoom:1,fit:'width',rotation:0,...(doc.sourceViewerState||{})};if(state.fit==='custom'&&Math.abs(Number(state.zoom||1)-1)<.001)state.fit='width';stage._naviReaderGoToPage=page=>{state.page=Math.max(1,Math.min(pdf.numPages,Number(page)||1));render();};let epoch=0;const render=async()=>{const mine=++epoch;state.page=Math.max(1,Math.min(pdf.numPages,Number(state.page)||1));controls.querySelector('[data-page]').textContent=`${state.page}/${pdf.numPages}`;controls.querySelector('[data-zoom]').textContent=`${Math.round((state.zoom||1)*100)}%`;controls.querySelector('[data-fit]').textContent=state.fit==='page'?'Fit Width':'Fit Page';let scale=state.fit==='custom'?state.zoom:null;if(state.fit==='page'){const p=await pdf.getPage(state.page),base=p.getViewport({scale:1,rotation:state.rotation||0});scale=Math.min(Math.max(260,stage.clientWidth-22)/base.width,Math.max(220,stage.clientHeight-22)/base.height);}if(mine!==epoch)return;const result=await NaviPdfViewer.renderPage(pdf,state.page,canvas,{fit:state.fit,width:Math.max(260,stage.clientWidth-22),height:Math.max(180,stage.clientHeight-22),scale,rotation:state.rotation||0,gutter:22});if(result)controls.querySelector('[data-zoom]').textContent=`${state.fit==='custom'?'':state.fit==='page'?'Fit · ':'Width · '}${Math.round(result.scale*100)}%`; };const zoom=d=>{state.fit='custom';state.zoom=Math.max(.25,Math.min(4,Math.round(((state.zoom||1)+d)*100)/100));render();};controls.querySelector('[data-prev]').onclick=()=>{state.page--;render();};controls.querySelector('[data-next]').onclick=()=>{state.page++;render();};controls.querySelector('[data-minus]').onclick=()=>zoom(-.1);controls.querySelector('[data-plus]').onclick=()=>zoom(.1);controls.querySelector('[data-fit]').onclick=()=>{state.fit=state.fit==='page'?'width':'page';state.zoom=1;render();};controls.querySelector('[data-rotate]').onclick=()=>{state.rotation=((state.rotation||0)+90)%360;render();};controls.querySelector('[data-download]').onclick=()=>{retainedSourceViewerAssetId=asset.id;downloadRetainedSource();};installPointerCenteredZoom(stage,()=>state.zoom,value=>{state.fit='custom';state.zoom=value;},render);let resizeFrame=0;const onResize=()=>{if(state.fit==='custom')return;cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(render);};addEventListener('resize',onResize,{passive:true});host._naviCleanup=()=>{removeEventListener('resize',onResize);cancelAnimationFrame(resizeFrame);NaviPdfViewer.cancelCanvas?.(canvas);};await render();return;}if(String(asset.mimeType||'').startsWith('image/')){const stage=document.createElement('div');stage.className='split-reference-stage';const image=document.createElement('img');image.src=await NaviAssets.objectUrl(asset.id);stage.appendChild(image);host.replaceChildren(stage);return;}let html=String(doc.referencePreviewHtml||'').trim();if(!html&&window.NaviOfficeParserAdapter?.parseFile&&['docx','odt','rtf','rtfd','epub'].includes(ext)){try{const file=new File([asset.blob],asset.originalName||`reference.${ext}`,{type:asset.mimeType||asset.blob.type}),parsed=await NaviOfficeParserAdapter.parseFile(file,{fileType:ext,readOnly:true});html=String(parsed?.sourceHtml||parsed?.html||'').trim();if(html){doc.referencePreviewHtml=html;await NaviStorage.saveDocument({...doc,referencePreviewHtml:html,updatedAt:Date.now()});}}catch(error){NaviDiagnostics?.report?.({severity:'warning',subsystem:'Split reference viewer',message:error?.message||String(error),error,recovered:true});}}if(html){const shell=document.createElement('article');shell.className=`split-reference-paper reference-${ext}-paper`;shell.innerHTML=html;shell.querySelectorAll('script,iframe,object,embed,form,input,button,textarea,select').forEach(node=>node.remove());host.replaceChildren(shell);}else host.innerHTML='<div class="empty-note">Preview unavailable. Open the Reference View or download the original.</div>'; }

async function renderSplitPaneDocument() {
  if (!els.splitDocContent || !els.splitDocMeta) {
    return;
  }

  clearTimeout(splitPaneAutosaveTimer);
  try{els.splitDocContent?.querySelector('.split-reference-viewer')?._naviCleanup?.();}catch{}
  els.workspace?.classList.toggle('split-reference-active',false);

  if (!splitPaneDocId) {
    els.splitDocContent.innerHTML = `
      <div class="empty-note">
        Select a document to preview it here.
      </div>
    `;

    els.splitDocMeta.textContent =
      'Choose a document to view beside your current draft.';

    updateSplitPaneEditButtons();
    return;
  }

  const doc =
    await NaviStorage.getDocument(splitPaneDocId);

  if (!doc) {
    els.splitDocContent.innerHTML = `
      <div class="empty-note">
        Split document not found.
      </div>
    `;

    els.splitDocMeta.textContent =
      'Document could not be loaded.';

    updateSplitPaneEditButtons();
    return;
  }

  const words =
    Number(doc.wordCount || 0);

  const type =
    typeof getReadableDocType === 'function'
      ? getReadableDocType(doc)
      : doc.docType || 'Doc';

  const status =
    typeof renderStatusChip === 'function'
      ? renderStatusChip(
          typeof getDocStatusForDisplay === 'function'
            ? getDocStatusForDisplay(doc)
            : doc.status || ''
        )
      : '';

  els.splitDocMeta.innerHTML = `
    <span>${escapeHtml(type)}</span>
    <span>•</span>
    <span>${words.toLocaleString()} ${words === 1 ? 'word' : 'words'}</span>
    ${
      doc.folder
        ? `<span>•</span><span>📁 ${escapeHtml(doc.folder)}</span>`
        : ''
    }
    ${
      status
        ? `<span class="split-meta-status">${status}</span>`
        : ''
    }
    ${
      splitPaneEditable
        ? `<span class="split-meta-editing">Editing split document</span>`
        : ''
    }
  `;

  const splitIsReference=doc.docType==='reference-view'&&doc.sourceAttachmentId;
  els.workspace?.classList.toggle('split-reference-active',Boolean(splitIsReference)); els.editSplitPaneBtn?.classList.toggle('hidden',splitIsReference); els.renameSplitPaneDocBtn?.classList.toggle('hidden',splitIsReference); if(splitIsReference){splitPaneEditable=false;updateSplitPaneEditButtons();els.splitDocContent.innerHTML='<div class="split-reference-viewer"><div class="empty-note">Loading retained source…</div></div>';const host=els.splitDocContent.querySelector('.split-reference-viewer'),asset=await NaviStorage.getAsset(doc.sourceAttachmentId);if(asset?.blob)await renderSplitReferenceViewer(doc,host,asset);return;} els.editSplitPaneBtn?.classList.remove('hidden');els.renameSplitPaneDocBtn?.classList.remove('hidden');

  if (splitPaneEditable) {
    els.splitDocContent.innerHTML = `
      <article class="split-doc-preview split-doc-editable">
        <input
          class="split-doc-title-input"
          data-split-title-input
          value="${escapeHtml(doc.title || 'Untitled Document')}"
          aria-label="Split document title"
        />

        <div
          class="split-doc-body split-doc-edit-body"
          data-split-edit-body
          contenteditable="true"
          spellcheck="true"
        >
          ${getExportSafeDocumentContent(doc)}
        </div>
      </article>
    `;

    const {
      titleInput,
      body
    } =
      getSplitPaneEditorElements();

    if (titleInput) {
      titleInput.addEventListener(
        'input',
        scheduleSplitPaneAutosave
      );
    }

    if (body) {
      body.addEventListener(
        'input',
        scheduleSplitPaneAutosave
      );

      body.addEventListener('paste', event => {
        event.preventDefault();

        const text =
          event.clipboardData?.getData('text/plain') || '';

        document.execCommand(
          'insertText',
          false,
          text
        );
      });
    }

    return;
  }

  els.splitDocContent.innerHTML = `
    <article class="split-doc-preview">
      <h2>${escapeHtml(doc.title || 'Untitled Document')}</h2>

      <div class="split-doc-body">
        ${getExportSafeDocumentContent(doc)}
      </div>
    </article>
  `;

  /*
    Keep preview read-only even if imported HTML contains editable pieces.
  */
  els.splitDocContent
    .querySelectorAll('[contenteditable]')
    .forEach(node => {
      node.setAttribute(
        'contenteditable',
        'false'
      );
    });

  updateSplitPaneEditButtons();
}

function scheduleSplitPaneAutosave() {
  clearTimeout(splitPaneAutosaveTimer);

  splitPaneAutosaveTimer =
    setTimeout(() => {
      saveSplitPaneDocument();
    }, SPLIT_PANE_AUTOSAVE_DELAY);

  if (els.saveSplitPaneBtn) {
    els.saveSplitPaneBtn.textContent =
      'Saving...';
  }
}

async function saveSplitPaneDocument() {
  if (!splitPaneEditable || !splitPaneDocId) {
    return;
  }

  const {
    titleInput,
    body
  } =
    getSplitPaneEditorElements();

  if (!body) {
    return;
  }

  const doc =
    await NaviStorage.getDocument(splitPaneDocId);

  if (!doc) {
    return;
  }

  const nextTitle =
    titleInput?.value.trim() ||
    doc.title ||
    'Untitled Document';

  const nextContent =
    body.innerHTML && body.innerHTML.trim()
      ? body.innerHTML
      : '<p></p>';

  const plainText =
    getSplitPanePlainTextFromHtml(
      nextContent
    );

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      title:
        nextTitle,
      content:
        nextContent,
      plainText,
      wordCount:
        NaviEditor.countWords(plainText),
      charCount:
        plainText.length,
      updatedAt:
        Date.now()
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  renderDocumentList(documentsCache);

  if (els.splitDocSelect) {
    await populateSplitDocSelect();
    els.splitDocSelect.value =
      saved.id;
  }

  if (els.saveSplitPaneBtn) {
    els.saveSplitPaneBtn.textContent =
      'Saved';
  }

  els.splitDocMeta.innerHTML = `
    <span>${escapeHtml(
      typeof getReadableDocType === 'function'
        ? getReadableDocType(saved)
        : saved.docType || 'Doc'
    )}</span>
    <span>•</span>
    <span>${Number(saved.wordCount || 0).toLocaleString()} ${
      Number(saved.wordCount || 0) === 1 ? 'word' : 'words'
    }</span>
    ${
      saved.folder
        ? `<span>•</span><span>📁 ${escapeHtml(saved.folder)}</span>`
        : ''
    }
    <span class="split-meta-editing">Editing split document</span>
  `;

  setTimeout(() => {
    if (els.saveSplitPaneBtn && splitPaneEditable) {
      els.saveSplitPaneBtn.textContent =
        'Save Split';
    }
  }, 900);

  NaviEditor.setSaveStatus(
    'Split document saved'
  );
}

async function openSplitEditor(docId = null) {
  if (!els.splitPane || !els.workspace || !currentDocumentId) return;

  await populateSplitDocSelect();

  const current =
    await NaviStorage.getDocument(currentDocumentId);

  splitOwnerDocumentId =
    currentDocumentId;

  splitPaneDocId =
    docId ||
    current?.splitPaneDocId ||
    splitPaneDocId ||
    getFallbackSplitDocumentId();

  if (splitPaneDocId === currentDocumentId) {
    splitPaneDocId = getFallbackSplitDocumentId();
  }

  if (els.splitDocSelect) {
    els.splitDocSelect.value = splitPaneDocId || '';
  }

  showSplitShell();
  
  splitPaneEditable = false;
updateSplitPaneEditButtons();

  await renderSplitPaneDocument();

  await saveSplitStateForDocument(
    splitOwnerDocumentId,
    splitPaneDocId || ''
  );
}

async function closeSplitEditor({
  clearSaved = true
} = {}) {
  const ownerId =
    splitOwnerDocumentId || currentDocumentId;
  
  if (splitPaneEditable) {
  await saveSplitPaneDocument();
}

splitPaneEditable = false;
clearTimeout(splitPaneAutosaveTimer);

  hideSplitShell();

  if (clearSaved && ownerId) {
    await saveSplitStateForDocument(ownerId, '');
  }

  splitPaneDocId = null;
  splitOwnerDocumentId = null;
}

async function handleSplitDocSelectChange() {
  
  if (splitPaneEditable) {
  await saveSplitPaneDocument();
}
  
  splitPaneDocId =
    els.splitDocSelect?.value || null;
  
  splitPaneEditable = false;
updateSplitPaneEditButtons();

  if (
    splitOwnerDocumentId &&
    splitPaneDocId
  ) {
    await saveSplitStateForDocument(
      splitOwnerDocumentId,
      splitPaneDocId
    );
  }

  await renderSplitPaneDocument();
}

async function restoreSplitForDocument(doc){if(!doc?.id||!doc.splitPaneDocId||doc.splitPaneDocId===doc.id){await closeSplitEditor({clearSaved:false});return;}const target=await NaviStorage.getDocument(doc.splitPaneDocId);if(!target){await saveSplitStateForDocument(doc.id,'');await closeSplitEditor({clearSaved:false});return;}splitOwnerDocumentId=doc.id;splitPaneDocId=target.id;await populateSplitDocSelect();if(currentDocumentId!==doc.id)return;if(els.splitDocSelect)els.splitDocSelect.value=target.id;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));if(currentDocumentId!==doc.id)return;showSplitShell();splitPaneEditable=false;updateSplitPaneEditButtons();await renderSplitPaneDocument();}

async function openSplitDocAsMain() {
  if (!splitPaneDocId) {
    showAppNotice(
      'Choose a split document first.',
      'No split document selected'
    );
    return;
  }

  const targetId =
    splitPaneDocId;

  /*
    Opening the reference as main should close the split UI,
    but should NOT erase the split saved on the original document.
  */
  
  if (splitPaneEditable) {
  await saveSplitPaneDocument();
}
  
  await closeSplitEditor({
    clearSaved: false
  });

  await openDocument(targetId);
}

function openBoardLinkModal(existingItem = null) {
  if (!els.boardLinkModal) {
    return Promise.resolve(null);
  }

  editingBoardLinkId = existingItem?.id || null;

  if (els.boardLinkTitleInput) {
    els.boardLinkTitleInput.value = existingItem?.title || '';
    els.boardLinkTitleInput.placeholder = 'New Link';
  }

  if (els.boardLinkUrlInput) {
    els.boardLinkUrlInput.value = existingItem?.url || '';
    els.boardLinkUrlInput.placeholder = 'https://';
  }

  if (els.submitBoardLinkModalBtn) {
    els.submitBoardLinkModalBtn.textContent =
      editingBoardLinkId ? 'Save Link' : 'Add Link';
  }

  els.boardLinkModal.classList.remove('hidden');

  setTimeout(() => {
    els.boardLinkTitleInput?.focus();
  }, 0);

  return new Promise(resolve => {
    pendingBoardLinkResolve = resolve;
  });
}

function resolveBoardLinkModal(value = null) {
  if (els.boardLinkModal) {
    els.boardLinkModal.classList.add('hidden');
  }

  const resolver = pendingBoardLinkResolve;

  pendingBoardLinkResolve = null;

  if (resolver) {
    resolver(value);
  }
}

function submitBoardLinkModal() {
  const title =
    els.boardLinkTitleInput?.value.trim() || 'New Link';

  const url =
    els.boardLinkUrlInput?.value.trim() || '';

  if (!url) {
    showAppNotice(
      'Add a URL before creating the link.',
      'Missing URL'
    );
    return;
  }

  if (editingBoardLinkId) {
    const existing =
      currentBoardData.items.find(item => {
        return item.id === editingBoardLinkId;
      });

    if (existing) {
      pushBoardUndoState();
      existing.title = title;
      existing.url = url;
      existing.docId = '';
      renderBoard();
      scheduleAutosave();
    }

    editingBoardLinkId = null;
    resolveBoardLinkModal(null);
    return;
  }

  resolveBoardLinkModal({
    title,
    url
  });
}

function getBoardItemDisplayName(item){const explicit=String(item?.title||item?.name||item?.originalName||'').trim();if(explicit)return explicit.slice(0,72);const raw=String(item?.description||item?.role||item?.text||item?.notes||'').replace(/\s+/g,' ').trim();if(raw)return `${item?.type==='note'?'Note':item?.type==='person'?'Person':'Chip'} · ${raw.slice(0,48)}${raw.length>48?'…':''}`;return item?.type==='document-view'?'Untitled document':item?.type==='image'?'Untitled image':item?.type==='link'?'Untitled link':'Untitled note';}
function populateBoardConnectionEndpointSelects(existing=null){const options=currentBoardData.items.map(item=>({id:item.id,label:getBoardItemDisplayName(item),type:item.type||'chip'}));const configs=[[els.boardConnectionFromSelect,'boardConnectionFromSearch',existing?.fromId||boardConnectStartId||options[0]?.id||''],[els.boardConnectionToSelect,'boardConnectionToSearch',existing?.toId||options.find(option=>option.id!==(existing?.fromId||boardConnectStartId))?.id||options[0]?.id||'']];configs.forEach(([select,inputId,value])=>{if(!select)return;select.innerHTML='';options.forEach(option=>{const node=document.createElement('option');node.value=option.id;node.textContent=option.label;select.appendChild(node);});select.value=value;select.classList.add('connection-hidden-select');let input=document.getElementById(inputId);if(!input){input=document.createElement('input');input.id=inputId;input.type='search';input.className='board-chip-search';input.placeholder='Search chip titles…';input.autocomplete='off';select.parentElement.insertBefore(input,select);const results=document.createElement('div');results.className='board-chip-search-results hidden';input.insertAdjacentElement('afterend',results);const render=()=>{const query=input.value.trim().toLowerCase();const matches=options.filter(option=>!query||option.label.toLowerCase().includes(query)||option.type.toLowerCase().includes(query)).slice(0,8);results.replaceChildren(...matches.map(option=>{const button=document.createElement('button');button.type='button';button.className='board-chip-search-result';button.innerHTML=`<strong>${escapeHtml(option.label)}</strong><span>${escapeHtml(option.type)}</span>`;button.onclick=()=>{select.value=option.id;input.value=option.label;results.classList.add('hidden');};return button;}));results.classList.toggle('hidden',!matches.length);};input.addEventListener('input',render);input.addEventListener('focus',render);input.addEventListener('keydown',event=>{if(event.key==='Escape')results.classList.add('hidden');});document.addEventListener('pointerdown',event=>{if(!input.parentElement.contains(event.target))results.classList.add('hidden');});}const chosen=options.find(option=>option.id===select.value);input.value=chosen?.label||'';});}
function openBoardConnectionModal(existing = null) {
  if (!els.boardConnectionModal) return Promise.resolve(null);
  if (els.boardConnectionLabelInput) els.boardConnectionLabelInput.value = existing?.label || 'related';
  if (els.boardConnectionTypeSelect) els.boardConnectionTypeSelect.value = existing?.type || 'straight';
  if (els.boardConnectionColorInput) els.boardConnectionColorInput.value = existing?.color || getBoardConnectorColor(existing || {label:'related'});
  if (els.boardConnectionWidthInput) els.boardConnectionWidthInput.value = String(Math.max(1, Math.min(8, Number(existing?.width || 3))));
  if (els.boardConnectionWidthOutput) els.boardConnectionWidthOutput.value = `${Math.max(1, Math.min(8, Number(existing?.width || 3)))} px`;
  if (els.boardConnectionDirectionSelect) els.boardConnectionDirectionSelect.value = existing?.direction || 'none';
  populateBoardConnectionEndpointSelects(existing);
  editingBoardConnectorId = existing?.id || null;
  els.deleteBoardConnectionBtn?.classList.toggle('hidden', !editingBoardConnectorId);
  els.boardConnectionModal.classList.remove('hidden');
  setTimeout(() => { els.boardConnectionLabelInput?.focus(); els.boardConnectionLabelInput?.select(); }, 0);
  return new Promise(resolve => { pendingBoardConnectionResolve = resolve; });
}

function resolveBoardConnectionModal(value=null){els.boardConnectionModal?.classList.add('hidden');const resolver=pendingBoardConnectionResolve;pendingBoardConnectionResolve=null;editingBoardConnectorId=null;if(resolver)resolver(value);if(boardConnectMode)setBoardConnectMode(false);}

function submitBoardConnectionModal() {
  const fromId = els.boardConnectionFromSelect?.value || boardConnectStartId || '';
  const toId = els.boardConnectionToSelect?.value || '';
  if (!fromId || !toId || fromId === toId) {
    if(fromId && toId && fromId===toId) showMessage?.('A connection must link two different chips.');
    showMessageModal({ title:'Choose two different chips', message:'A connection needs a different source and destination chip.', kind:'warning' });
    return;
  }
  resolveBoardConnectionModal({
    label: els.boardConnectionLabelInput?.value.trim() || '',
    type: els.boardConnectionTypeSelect?.value || 'straight',
    color: els.boardConnectionColorInput?.value || '#ff5f86',
    width: Math.max(1, Math.min(8, Number(els.boardConnectionWidthInput?.value || 3))),
    direction: els.boardConnectionDirectionSelect?.value || 'none',
    fromId,
    toId
  });
}

function closeBoardConnectionModal() {
  resolveBoardConnectionModal(null);
}

function closeBoardLinkModal() {
  editingBoardLinkId = null;
  resolveBoardLinkModal(null);
}

function closeChoiceModal() {
  resolveChoiceModal(null);
}

function showMessageModal({
  title = 'Message',
  message = '',
  kind = 'info'
} = {}) {
  if (!els.messageModal) {
    alert(message || title);
    return Promise.resolve();
  }

  els.messageModal.classList.remove(
    'error-message',
    'warning-message'
  );

  if (kind === 'error') {
    els.messageModal
      .querySelector('.subdoc-modal')
      ?.classList.add('error-message');
  }

  if (kind === 'warning') {
    els.messageModal
      .querySelector('.subdoc-modal')
      ?.classList.add('warning-message');
  }

  if (els.messageModalTitle) {
    els.messageModalTitle.textContent = title;
  }

  if (els.messageModalText) {
    els.messageModalText.textContent = message;
  }

  els.messageModal.classList.remove('hidden');

  return new Promise(resolve => {
    pendingMessageResolve = resolve;
  });
}

function closeMessageModal() {
  if (els.messageModal) {
    els.messageModal.classList.add('hidden');
  }

  const resolver = pendingMessageResolve;

  pendingMessageResolve = null;

  if (resolver) {
    resolver();
  }
}

function showAppError(message, title = 'Something went wrong') {
  return showMessageModal({
    title,
    message,
    kind: 'error'
  });
}

function showAppNotice(message, title = 'NaviWriter') {
  return showMessageModal({
    title,
    message,
    kind: 'info'
  });
}



function loadCollapsedDocIds() {
  try {
    const raw = localStorage.getItem('naviwriter-collapsed-docs');
    const parsed = raw ? JSON.parse(raw) : [];

    collapsedDocIds = new Set(Array.isArray(parsed) ? parsed : []);
  } catch {
    collapsedDocIds = new Set();
  }
}

function saveCollapsedDocIds() {
  try {
    localStorage.setItem(
      'naviwriter-collapsed-docs',
      JSON.stringify(Array.from(collapsedDocIds))
    );
  } catch {}
}

function toggleDocCollapsed(id) {
  if (!id) return;

  if (collapsedDocIds.has(id)) {
    collapsedDocIds.delete(id);
  } else {
    collapsedDocIds.add(id);
  }

  saveCollapsedDocIds();
  renderDocumentList(documentsCache);
}

function getImportPlainText(html = '') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html || '';
  return (wrapper.innerText || wrapper.textContent || '').trim();
}

function isImportedChapterHeadingText(value = '') {
  const text = String(value || '').trim().replace(/\s+/g, ' ');
  return /^(?:chapter|part|book|section)\s+(?:\d+|[ivxlcdm]+)\b(?:\s*[:.\-—]?\s*.*)?$/i.test(text) ||
    /^(?:prologue|epilogue|introduction|preface|foreword|afterword|conclusion)$/i.test(text);
}

function normalizeImportedStructuralHtml(html = '') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html || '<p></p>';

  // Importers frequently preserve a chapter title as an ordinary paragraph.
  // Promote a standalone chapter-looking block to H1 before splitting and
  // before the document is shown in Tiptap, so it appears bold and in Outline.
  Array.from(wrapper.querySelectorAll('p, div')).forEach(node => {
    if (node.querySelector('p, div, h1, h2, h3, h4, h5, h6, table, ul, ol')) return;
    const text = node.textContent?.trim() || '';
    if (!isImportedChapterHeadingText(text)) return;
    const heading = document.createElement('h1');
    heading.innerHTML = node.innerHTML;
    node.replaceWith(heading);
  });

  return wrapper.innerHTML || '<p></p>';
}

function splitImportedHtmlByHeadings(html = '', documentTitle = 'Imported Document') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = normalizeImportedStructuralHtml(html);

  const allHeadings = Array.from(
    wrapper.querySelectorAll('h1, h2, h3, h4, h5, h6')
  ).filter(node => Boolean(node.textContent?.trim()));
  if (!allHeadings.length) return [];

  const normalizedTitle = String(documentTitle || '')
    .trim().replace(/\s+/g, ' ').toLowerCase();
  const isDocumentTitle = node =>
    node.textContent.trim().replace(/\s+/g, ' ').toLowerCase() === normalizedTitle;

  const contentHeadings = allHeadings.filter((node, index) =>
    !(index === 0 && isDocumentTitle(node))
  );
  if (!contentHeadings.length) return [];

  // Prefer a repeated heading level. If the source mixes heading levels
  // (common in HTML exports), split at the shallowest content heading level
  // and include its peers. If that still yields only one heading, that one
  // heading still becomes a subdocument instead of being silently ignored.
  let splitLevel = null;
  for (let level = 1; level <= 6; level++) {
    if (contentHeadings.filter(node => node.tagName === `H${level}`).length >= 2) {
      splitLevel = level;
      break;
    }
  }
  if (!splitLevel) {
    splitLevel = Math.min(...contentHeadings.map(node => Number(node.tagName.slice(1))));
  }
  let splitHeadings = contentHeadings.filter(node =>
    Number(node.tagName.slice(1)) === splitLevel
  );
  if (!splitHeadings.length) splitHeadings = contentHeadings;

  const htmlFromRange = (startNode, endNode = null) => {
    const range = document.createRange();
    if (startNode) range.setStartBefore(startNode);
    else range.setStart(wrapper, 0);
    if (endNode) range.setEndBefore(endNode);
    else range.setEnd(wrapper, wrapper.childNodes.length);
    const box = document.createElement('div');
    box.appendChild(range.cloneContents());
    return box.innerHTML.trim() || '<p></p>';
  };

  const sections = [];
  const prefaceHtml = htmlFromRange(null, splitHeadings[0]);
  if (getImportPlainText(prefaceHtml)) {
    sections.push({ title: 'Front Matter', html: prefaceHtml });
  }
  splitHeadings.forEach((heading, index) => {
    sections.push({
      title: heading.textContent.trim().replace(/\s+/g, ' ') || `Part ${index + 1}`,
      html: htmlFromRange(heading, splitHeadings[index + 1] || null)
    });
  });
  return sections;
}

async function saveImportedHtmlStructure({
  title,
  html,
  fileName = '',
  parentId = null,
  singleDocType = 'general'
}) {
  const normalizedHtml = normalizeImportedStructuralHtml(html);
  const sections = splitImportedHtmlByHeadings(normalizedHtml, title);

  if (sections.length < 1) {
    const doc = NaviStorage.createBlankDocument(title);
    const plainText = getImportPlainText(normalizedHtml);
    doc.docType = singleDocType;
    doc.parentId = parentId;
    doc.content = normalizedHtml || '<p></p>';
    doc.plainText = plainText;
    doc.wordCount = NaviEditor.countWords(plainText);
    doc.charCount = plainText.length;
    doc.importedFrom = fileName;
    doc.importDate = Date.now();
    return {
      root: await NaviStorage.saveDocument(doc),
      sectionCount: 0
    };
  }

  const manuscript = NaviStorage.createBlankDocument(title);
  manuscript.docType = 'manuscript';
  manuscript.parentId = parentId;
  manuscript.content = `<h1>${escapeHtml(title)}</h1><p>Imported document</p>`;
  manuscript.plainText = title;
  manuscript.wordCount = NaviEditor.countWords(title);
  manuscript.charCount = title.length;
  manuscript.importedFrom = fileName;
  manuscript.importDate = Date.now();
  const savedManuscript = await NaviStorage.saveDocument(manuscript);

  for (let index = 0; index < sections.length; index++) {
    const section = sections[index];
    const plainText = getImportPlainText(section.html);
    const child = NaviStorage.createBlankDocument(section.title || `Part ${index + 1}`);
    child.parentId = savedManuscript.id;
    child.docType = section.title === 'Front Matter' ? 'front-matter' : 'chapter';
    child.sortOrder = index;
    child.content = section.html || '<p></p>';
    child.plainText = plainText;
    child.wordCount = NaviEditor.countWords(plainText);
    child.charCount = plainText.length;
    child.importedFrom = fileName;
    child.importDate = Date.now();
    await NaviStorage.saveDocument(child);
  }

  const savedChildren = (await NaviStorage.getAllDocuments())
    .filter(doc => doc.parentId === savedManuscript.id);
  if (savedChildren.length !== sections.length) {
    throw new Error(`Import created the manuscript but saved ${savedChildren.length} of ${sections.length} subdocuments.`);
  }
  collapseImportedManuscript(savedManuscript.id);
  return { root: savedManuscript, sectionCount: sections.length };
}

async function importDocxFile(file) {



  if (!window.mammoth) {
    throw new Error('DOCX tools are not loaded.');
  }

  const arrayBuffer = await file.arrayBuffer();

  const result = await mammoth.convertToHtml(
    {
      arrayBuffer
    },
    {
      styleMap: [
        "p[style-name='Title'] => h1:fresh",
        "p[style-name='Subtitle'] => h2:fresh",
        "p[style-name='Heading 1'] => h1:fresh",
        "p[style-name='Heading 2'] => h2:fresh",
        "p[style-name='Heading 3'] => h3:fresh",
        "p[style-name='heading 1'] => h1:fresh",
        "p[style-name='heading 2'] => h2:fresh",
        "p[style-name='heading 3'] => h3:fresh"
      ],

      includeDefaultStyleMap: true,

      convertImage: mammoth.images.imgElement(async image => {
        let base64 = '';

        if (typeof image.readAsBase64String === 'function') {
          base64 = await image.readAsBase64String();
        } else if (typeof image.read === 'function') {
          base64 = await image.read('base64');
        }

        return {
          src: `data:${image.contentType};base64,${base64}`,
          alt: image.altText || ''
        };
      })
    }
  );

  const title =
    file.name.replace(/\.docx$/i, '') ||
    'Imported DOCX';

  const content =
    result.value && result.value.trim()
      ? result.value
      : '<p></p>';

  const importedResult = await saveImportedHtmlStructure({
    title,
    html: content,
    fileName: file.name,
    singleDocType: 'general'
  });

  await loadDocuments();
  await openDocument(importedResult.root.id);

  if (importedResult.sectionCount) {
    NaviEditor.setSaveStatus(`Imported ${importedResult.sectionCount} parts`);
  }

  if (result.messages && result.messages.length) {
    console.warn('DOCX import messages:', result.messages);
  }

console.log('DOCX HTML:', result.value);

}

function getBoardMinimapParentRect() {
  const parent =
    els.boardMinimap?.offsetParent ||
    document.body;

  return parent.getBoundingClientRect();
}

function clampBoardMinimapPosition(x, y) {
  if (!els.boardMinimap) {
    return {
      x,
      y
    };
  }

  const parentRect =
    getBoardMinimapParentRect();

  const width =
    els.boardMinimap.offsetWidth || 230;

  const height =
    els.boardMinimap.offsetHeight || 170;

  return {
    x:
      Math.max(
        8,
        Math.min(
          x,
          parentRect.width - width - 8
        )
      ),

    y:
      Math.max(
        8,
        Math.min(
          y,
          parentRect.height - height - 8
        )
      )
  };
}

function applyBoardMinimapPosition(position) {
  if (!els.boardMinimap || !position) {
    return;
  }

  const clamped =
    clampBoardMinimapPosition(
      Number(position.x || 0),
      Number(position.y || 0)
    );

  els.boardMinimap.style.left =
    `${clamped.x}px`;

  els.boardMinimap.style.top =
    `${clamped.y}px`;

  els.boardMinimap.style.right =
    'auto';

  els.boardMinimap.style.bottom =
    'auto';
}

function saveBoardMinimapPosition() {
  if (!els.boardMinimap) {
    return;
  }

  try {
    localStorage.setItem(
      BOARD_MINIMAP_POSITION_KEY,
      JSON.stringify({
        x: Number.parseFloat(
          els.boardMinimap.style.left || '18'
        ),
        y: Number.parseFloat(
          els.boardMinimap.style.top || '18'
        )
      })
    );
  } catch {}
}

function loadBoardMinimapPosition() {
  try {
    const raw =
      localStorage.getItem(
        BOARD_MINIMAP_POSITION_KEY
      );

    return raw
      ? JSON.parse(raw)
      : null;
  } catch {
    return null;
  }
}

function placeBoardMinimapDefaultIfNeeded() {
  if (!els.boardMinimap) {
    return;
  }

  const saved =
    loadBoardMinimapPosition();

  if (saved) {
    applyBoardMinimapPosition(saved);
    return;
  }

  /*
    Default position: bottom-left-ish.
    We convert it to explicit left/top so dragging has a stable base.
  */
  const parentRect =
    getBoardMinimapParentRect();

  const width =
    els.boardMinimap.offsetWidth || 230;

  const height =
    els.boardMinimap.offsetHeight || 170;

  applyBoardMinimapPosition({
    x: 18,
    y: parentRect.height - height - 18
  });
}

function showBoardMinimap() {
  if (!els.boardMinimap) {
    return;
  }

  els.boardMinimap.classList.remove('hidden');

  requestAnimationFrame(() => {
    placeBoardMinimapDefaultIfNeeded();
    renderBoardMinimap();
  });
}

function hideBoardMinimap() {
  if (!els.boardMinimap) {
    return;
  }

  els.boardMinimap.classList.add('hidden');
}

function toggleBoardMinimap() {
  if (!els.boardMinimap) {
    return;
  }

  if (els.boardMinimap.classList.contains('hidden')) {
    showBoardMinimap();
  } else {
    hideBoardMinimap();
  }
}

async function colorSelectedBoardItem() {
  if (!activeBoardItemId) {
    showAppNotice(
      'Select a board item first.',
      'No board item selected'
    );
    return;
  }

  const item =
    currentBoardData.items.find(existing => {
      return existing.id === activeBoardItemId;
    });

  if (!item) return;

  const colorChoice =
    await openChoiceModal({
      title: 'Choose Board Item Color',
      subtitle: 'Pick a color for the selected board item.',
      options: [
        {
          value: '#fff8b5',
          color: '#fff8b5',
          title: 'Yellow',
          desc: 'Classic sticky note.'
        },
        {
          value: '#dbeafe',
          color: '#dbeafe',
          title: 'Blue',
          desc: 'Cool reference card.'
        },
        {
          value: '#dcfce7',
          color: '#dcfce7',
          title: 'Green',
          desc: 'Linked or resolved idea.'
        },
        {
          value: '#fce7f3',
          color: '#fce7f3',
          title: 'Pink',
          desc: 'Character or emotional beat.'
        },
        {
          value: '#ede9fe',
          color: '#ede9fe',
          title: 'Purple',
          desc: 'Lore, magic, or special note.'
        },
        {
          value: '#fee2e2',
          color: '#fee2e2',
          title: 'Red',
          desc: 'Conflict, warning, or danger.'
        },
        {
          value: '#ffffff',
          color: '#ffffff',
          title: 'White',
          desc: 'Neutral/default card.'
        }
      ]
    });

  if (!colorChoice) return;

  pushBoardUndoState();

  item.color = colorChoice;

  renderBoard();
  scheduleAutosave();
}

function cloneBoardData(board) {
  return JSON.parse(
    JSON.stringify(
      normalizeBoardData(board)
    )
  );
}



function pushBoardUndoState() {
  boardUndoStack.push(
    cloneBoardData(currentBoardData)
  );

  if (boardUndoStack.length > BOARD_UNDO_LIMIT) {
    boardUndoStack.shift();
  }

  // Once the user makes a new change, redo history should reset.
  boardRedoStack = [];
}

function restoreBoardState(board) {
  currentBoardData = normalizeBoardData(board);

  activeBoardItemId = null;
selectedBoardItemIds.clear();
  boardConnectMode = false;
  boardConnectStartId = null;

  document.body.classList.remove('board-connect-mode');

  renderBoard();
  scheduleAutosave();
}

function undoBoardChange() {
  if (!boardUndoStack.length) {
    return;
  }

  boardRedoStack.push(
    cloneBoardData(currentBoardData)
  );

  const previousState = boardUndoStack.pop();

  restoreBoardState(previousState);
}

function redoBoardChange() {
  if (!boardRedoStack.length) {
    return;
  }

  boardUndoStack.push(
    cloneBoardData(currentBoardData)
  );

  const nextState = boardRedoStack.pop();

  restoreBoardState(nextState);
}


function getChapterNumberFromTitle(title) {
  const match = String(title || '').match(/chapter\s+(\d+)/i);

  if (!match) return null;

  return Number(match[1]);
}

function compareDocumentsByAuthoritativeOrder(a, b) {
  const aSort = Number.isFinite(Number(a?.sortOrder)) ? Number(a.sortOrder) : null;
  const bSort = Number.isFinite(Number(b?.sortOrder)) ? Number(b.sortOrder) : null;
  if (aSort !== null || bSort !== null) {
    if (aSort === null) return 1;
    if (bSort === null) return -1;
    if (aSort !== bSort) return aSort - bSort;
  }
  const aLegacy = Number.isFinite(Number(a?.order)) ? Number(a.order) : null;
  const bLegacy = Number.isFinite(Number(b?.order)) ? Number(b.order) : null;
  if (aLegacy !== null && bLegacy !== null && aLegacy !== bLegacy) return aLegacy - bLegacy;
  const aCreated = Number(a?.createdAt || 0), bCreated = Number(b?.createdAt || 0);
  if (aCreated !== bCreated) return aCreated - bCreated;
  return String(a?.title || '').localeCompare(String(b?.title || ''));
}

function sortDocumentsForDisplay(list = []) {
  return list.slice().sort(compareDocumentsByAuthoritativeOrder);
}


function getDocumentTypeIcon(doc) {
  if (doc?.icon) return String(doc.icon);

  const type = doc?.docType || 'general';

  if (type === 'manuscript') return '📘';
  if (type === 'chapter') return '§';
  if (type === 'front-matter') return '📑';
  if (type === 'body-matter') return '📄';
  if (type === 'back-matter') return '📚';
  if (type === 'cover') return '🖼️';
  if (type === 'notes') return '📝';
  if (type === 'research') return '🔬';
  if (type === 'pdf' || type === 'reference-view') return '📎';
  if (type === 'compiled') return '📦';

  return '📋';
}

function getDocStatusForDisplay(doc) {
  if (
    doc?.status !== undefined &&
    doc?.status !== null
  ) {
    return doc.status;
  }

  if (typeof getDefaultStatusForDoc === 'function') {
    return getDefaultStatusForDoc(doc);
  }

  return '';
}

function buildOutlinerRows(documents = []) {
  const sortMode =
    els.outlinerSortSelect?.value || 'structure';

  /*
    Non-structure sorts intentionally flatten the outline.
    Otherwise "Words High-Low" would be trapped inside each parent,
    which feels fake. Structure mode preserves hierarchy.
  */
  if (sortMode !== 'structure') {
    return sortDocumentsForOutliner(documents).map(doc => {
      return {
        doc,
        depth: 0
      };
    });
  }

  const byParent = new Map();
  const visibleIds = new Set(documents.map(doc => doc.id));

  documents.forEach(doc => {
    const parentIsVisible =
      doc.parentId && visibleIds.has(doc.parentId);

    const key =
      parentIsVisible
        ? doc.parentId
        : 'root';

    if (!byParent.has(key)) {
      byParent.set(key, []);
    }

    byParent.get(key).push(doc);
  });

  const rows = [];

  function walk(parentId = 'root', depth = 0) {
    const group =
      sortDocumentsForDisplay(byParent.get(parentId) || []);

    group.forEach((doc, siblingIndex) => {
      rows.push({
        doc,
        depth
      });

      walk(doc.id, depth + 1);
    });
  }

  walk();

  return rows;
}

function outlinerMatchesSearch(doc, query) {
  const needle =
    String(query || '').trim().toLowerCase();

  if (!needle) return true;

  const haystack = [
    doc.title,
    doc.docType,
    doc.status,
    doc.pov,
    doc.location,
    doc.timeline,
    doc.characters,
    doc.tags?.join?.(', '),
    doc.folder,
    doc.summary
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();

  return haystack.includes(needle);
}

async function getOutlinerDocuments() {
  const baseDocs =
    await getOutlinerBaseDocuments();

  populateOutlinerFolderFilter(baseDocs);

  const query =
    els.outlinerSearchInput?.value || '';

  const statusFilter =
    els.outlinerStatusFilterSelect?.value || '';

  const typeFilter =
    els.outlinerTypeFilterSelect?.value || '';

  const folderFilter =
    els.outlinerFolderFilterSelect?.value || '';

  return baseDocs.filter(doc => {
    if (!outlinerMatchesSearch(doc, query)) {
      return false;
    }

    if (statusFilter) {
      const status =
        normalizeStatus(getDocStatusForDisplay(doc));

      if (statusFilter === '__none') {
        if (status) return false;
      } else if (status !== statusFilter) {
        return false;
      }
    }

    if (typeFilter) {
      if ((doc.docType || 'general') !== typeFilter) {
        return false;
      }
    }

    if (folderFilter) {
      if (getDocumentFolderName(doc) !== folderFilter) {
        return false;
      }
    }

    return true;
  });
}

function setOutlinerTableHeader(
  mode = 'table',
  customFields = []
) {
  if (!els.outlinerTableBody) {
    return;
  }

  const headerRow =
    els.outlinerTableBody
      .closest('table')
      ?.querySelector('thead tr');

  if (!headerRow) {
    return;
  }

  if (mode === 'relationships') {
    headerRow.innerHTML = `
      <th>Source</th>
      <th>Relationship</th>
      <th>Target</th>
      <th>Strength</th>
      <th>Note</th>
      <th>Actions</th>
    `;
    return;
  }

  const customHeaders =
    customFields
      .map(field => {
        return `
          <th
            class="outliner-custom-metadata-head"
            title="${escapeHtml(getCustomMetadataFieldTypeLabel(field.type))}"
          >
            ${escapeHtml(field.name)}
          </th>
        `;
      })
      .join('');

  headerRow.innerHTML = `
    <th>Title</th>
    <th>Type</th>
    <th>Status</th>
    <th>Words</th>
    <th>POV</th>
    <th>Location</th>
    <th>Folder</th>
    <th>Collections</th>
    ${customHeaders}
    <th>Updated</th>
  `;
}

function getRelationshipEntityIcon(type = '') {
  if (type === 'document') return '📄';
  if (type === 'collection') return '🗂';
  if (type === 'folder') return '📁';
  if (type === 'source') return '🔬';
  if (type === 'tag') return '#';
  if (type === 'customField') return '◆';
  if (type === 'boardItem') return '📌';
  if (type === 'relationshipType') return '↔';
  return '•';
}

function getRelationshipEntityLabel(type = '') {
  if (type === 'document') return 'Document';
  if (type === 'collection') return 'Collection';
  if (type === 'folder') return 'Folder';
  if (type === 'source') return 'Source';
  if (type === 'tag') return 'Tag';
  if (type === 'customField') return 'Custom Field';
  if (type === 'boardItem') return 'Board Item';
  if (type === 'relationshipType') return 'Relationship Type';

  return 'Entity';
}

async function renderOutlinerRelationships() {
  if (!els.outlinerTableBody) {
    return;
  }

  const docs =
    await getOutlinerDocuments();

  const visibleDocIds =
    new Set(
      docs.map(doc => doc.id)
    );

  const toggles =
    getOutlinerRelationshipToggleState();

  let visibleRelationships = [];

  if (toggles.explicit) {
    const explicitRelationships =
      await getRelationships();

    const matchingExplicitRelationships =
      explicitRelationships.filter(rel => {
        const sourceVisible =
          rel.sourceEntityType === 'document' &&
          visibleDocIds.has(rel.sourceEntityId);

        const targetVisible =
          rel.targetEntityType === 'document' &&
          visibleDocIds.has(rel.targetEntityId);

        return sourceVisible || targetVisible;
      });

    visibleRelationships.push(
      ...matchingExplicitRelationships
    );
  }

  if (toggles.collections) {
    const collectionRelationships =
      await buildImplicitCollectionRelationships(docs);

    visibleRelationships.push(
      ...collectionRelationships
    );
  }

  if (toggles.folders) {
    const folderRelationships =
      buildImplicitFolderRelationships(docs);

    visibleRelationships.push(
      ...folderRelationships
    );
  }
  
  if (toggles.sources) {
  const sourceRelationships =
    buildImplicitSourceRelationships(docs);

  visibleRelationships.push(
    ...sourceRelationships
  );
}

if (toggles.tags) {
  const tagRelationships =
    buildImplicitTagRelationships(docs);

  visibleRelationships.push(
    ...tagRelationships
  );
}

  if (!visibleRelationships.length) {
    els.outlinerTableBody.innerHTML = `
      <tr>
        <td colspan="6" class="outliner-empty">
          No relationships found for this view.
        </td>
      </tr>
    `;

    return;
  }

  els.outlinerTableBody.innerHTML = '';

  for (const rel of visibleRelationships) {
    const sourceName =
      await getEntityName(
        rel.sourceEntityType,
        rel.sourceEntityId
      );

    const targetName =
      await getEntityName(
        rel.targetEntityType,
        rel.targetEntityId
      );

    const row =
      document.createElement('tr');

    row.className =
      'outliner-row relationship-outliner-row';

    row.innerHTML = `
      <td class="relationship-outliner-entity-cell">
        <button
          type="button"
          class="outliner-title-btn relationship-entity-link"
          data-relationship-entity-type="${escapeHtml(rel.sourceEntityType)}"
          data-relationship-entity-id="${escapeHtml(rel.sourceEntityId)}"
        >
          <span class="outliner-type-icon">
            ${escapeHtml(getRelationshipEntityIcon(rel.sourceEntityType))}
          </span>

          <span>
            ${escapeHtml(sourceName)}
          </span>
        </button>

        <div class="outliner-muted">
          ${escapeHtml(getRelationshipEntityLabel(rel.sourceEntityType))}
        </div>
      </td>

      <td>
        <span class="relationship-type-pill">
          ${escapeHtml(rel.relationType || 'related')}
        </span>
      </td>

      <td class="relationship-outliner-entity-cell">
        <button
          type="button"
          class="outliner-title-btn relationship-entity-link"
          data-relationship-entity-type="${escapeHtml(rel.targetEntityType)}"
          data-relationship-entity-id="${escapeHtml(rel.targetEntityId)}"
        >
          <span class="outliner-type-icon">
            ${escapeHtml(getRelationshipEntityIcon(rel.targetEntityType))}
          </span>

          <span>
            ${escapeHtml(targetName)}
          </span>
        </button>

        <div class="outliner-muted">
          ${escapeHtml(getRelationshipEntityLabel(rel.targetEntityType))}
        </div>
      </td>

      <td>
        <span
          class="relationship-strength"
          title="${escapeHtml(getRelationshipStrengthLabel(rel.strength))}"
        >
          ${escapeHtml(getRelationshipStrengthStars(rel.strength))}
        </span>
      </td>

      <td class="relationship-outliner-note">
        ${
          rel.note
            ? escapeHtml(rel.note)
            : '<span class="outliner-muted">—</span>'
        }
      </td>

      <td>
        ${
          rel.isImplicit
            ? `<span class="relationship-implicit-badge">Implicit</span>`
            : `
              <button
                type="button"
                class="relationship-delete-btn"
                data-relationship-id="${escapeHtml(rel.id)}"
                title="Delete relationship"
              >
                ×
              </button>
            `
        }
      </td>
    `;

    wireRelationshipEntityLinks(
      row,
      {
        closeOutliner: true
      }
    );

    row
      .querySelector('[data-relationship-id]')
      ?.addEventListener('click', async event => {
        event.stopPropagation();

        const relationshipId =
          event.currentTarget.dataset.relationshipId;

        if (!relationshipId) {
          return;
        }

        await deleteRelationship(relationshipId);

        relationshipsCache =
          await getRelationships();

        await renderOutlinerRelationships();

        if (currentDocumentId) {
          await renderRelationshipPanel(currentDocumentId);
        }

        NaviEditor.setSaveStatus('Relationship deleted');
      });

    els.outlinerTableBody.appendChild(row);
  }
}


async function renderOutliner() {
  syncOutlinerViewModeClass();
  if (!els.outlinerTableBody) {
    return;
  }

const viewMode =
  els.outlinerViewSelect?.value || 'table';

if (els.outlinerModal) {
  els.outlinerModal.classList.toggle(
    'relationship-view',
    viewMode === 'relationships'
  );
}

const customFields =
  viewMode === 'relationships'
    ? []
    : await getVisibleOutlinerCustomMetadataFields();

setOutlinerTableHeader(
  viewMode,
  customFields
);

  if (viewMode === 'relationships') {
    await renderOutlinerRelationships();
    return;
  }

  const docs =
    await getOutlinerDocuments();

  collectionsCache =
    await getCollections();

if (!docs.length) {
  els.outlinerTableBody.innerHTML = `
    <tr>
      <td colspan="${9 + customFields.length}" class="outliner-empty">
        No matching documents.
      </td>
    </tr>
  `;

  return;
}

  const rows =
    buildOutlinerRows(docs);

  els.outlinerTableBody.innerHTML = '';

  rows.forEach(({ doc, depth }) => {
    const row =
      document.createElement('tr');

    row.className =
      doc.id === currentDocumentId
        ? 'outliner-row active'
        : 'outliner-row';

    row.dataset.docId = doc.id;

    const words =
      Number(doc.wordCount || 0);

    const statusChip =
      renderStatusChip(
        getDocStatusForDisplay(doc)
      );

    const tagsText =
      Array.isArray(doc.tags) && doc.tags.length
        ? ` • ${doc.tags.join(', ')}`
        : '';
    
    const customMetadataCells =
  renderOutlinerCustomMetadataCells(
    doc,
    customFields
  );

    row.innerHTML = `
      <td class="outliner-title-cell">
        <button
          class="outliner-title-btn depth-${Math.min(depth, 5)}"
          data-open-doc-id="${escapeHtml(doc.id)}"
          type="button"
        >
          <span class="outliner-type-icon">
            ${escapeHtml(getDocumentTypeIcon(doc))}
          </span>

          <span>
            ${escapeHtml(doc.title || 'Untitled Document')}
          </span>
        </button>

        ${
          doc.summary
            ? `<div class="outliner-summary">${escapeHtml(doc.summary)}</div>`
            : ''
        }
      </td>

      <td>
        ${escapeHtml(getReadableDocType(doc))}
      </td>

      <td>
        ${
          statusChip
            ? statusChip
            : '<span class="outliner-muted">—</span>'
        }
      </td>

      <td>
        ${words.toLocaleString()}
      </td>

      <td>
        ${
          doc.pov
            ? escapeHtml(doc.pov)
            : '<span class="outliner-muted">—</span>'
        }
      </td>

      <td>
        ${
          doc.location
            ? escapeHtml(doc.location)
            : '<span class="outliner-muted">—</span>'
        }
      </td>

      <td>
        ${
          doc.folder
            ? `
              <button
                class="outliner-folder-link"
                data-outliner-folder="${escapeHtml(doc.folder)}"
                type="button"
              >
                ${escapeHtml(doc.folder)}
              </button>

              ${
                tagsText
                  ? `<span class="outliner-muted">${escapeHtml(tagsText)}</span>`
                  : ''
              }
            `
            : `
              <button
                class="outliner-folder-link muted"
                data-outliner-folder="Unfiled"
                type="button"
              >
                Unfiled
              </button>
            `
        }
      </td>

     <td class="outliner-collections-cell">
  ${renderOutlinerCollectionLinks(doc)}
</td>

${customMetadataCells}

<td>
  ${formatDate(doc.updatedAt)}
</td>
    `;

    row
      .querySelector('[data-open-doc-id]')
      ?.addEventListener('click', async event => {
        const docId =
          event.currentTarget.dataset.openDocId;

        if (!docId) {
          return;
        }

        closeOutlinerModal();
        await openDocument(docId);
      });

    row
      .querySelector('[data-outliner-folder]')
      ?.addEventListener('click', event => {
        event.stopPropagation();

        const folderName =
          event.currentTarget.dataset.outlinerFolder || '';

        activeFolderFilter =
          folderName === 'Unfiled'
            ? 'Unfiled'
            : folderName;

        closeOutlinerModal();
        renderDocumentList(documentsCache);
      });

    row
      .querySelectorAll('[data-outliner-collection]')
      .forEach(button => {
        button.addEventListener('click', async event => {
          event.stopPropagation();

          activeCollectionId =
            event.currentTarget.dataset.outlinerCollection || null;

          closeOutlinerModal();

          await openCollectionsModal();
        });
      });

    els.outlinerTableBody.appendChild(row);
  });
}

async function openOutlinerModal() {
  if (!els.outlinerModal) return;

  els.outlinerModal.classList.remove('hidden');
  
   syncOutlinerViewModeClass();

  await renderOutliner();
}

function closeOutlinerModal() {
  if (!els.outlinerModal) return;

  els.outlinerModal.classList.add('hidden');
}

function getDefaultStatusForDoc(doc) {
  const type = doc?.docType || 'general';

  if (
    type === 'cover' ||
    type === 'notes' ||
    type === 'research' ||
    type === 'pdf'
  ) {
    return '';
  }

  return 'Drafting';
}

function normalizeStatus(status = '') {
  return String(status || '').trim();
}

function getStatusClass(status = '') {
  const normalized =
    normalizeStatus(status)
      .toLowerCase()
      .replace(/\s+/g, '-');

  return normalized
    ? `status-${normalized}`
    : 'status-none';
}

function getStatusDot(status = '') {
  const normalized =
    normalizeStatus(status);

  if (normalized === 'Idea') return '⚪';
  if (normalized === 'Drafting') return '🔵';
  if (normalized === 'Needs Rewrite') return '🟠';
  if (normalized === 'Revising') return '🟣';
  if (normalized === 'Final') return '🟢';
  if (normalized === 'Reference') return '⚫';

  return '';
}

function renderSidebarStatusDot(status = '') {
  const safeStatus = normalizeStatus(status);

  if (!safeStatus) {
    return '';
  }

  const statusClass = getStatusClass(safeStatus);

  return `
    <span
      class="sidebar-status-dot ${statusClass}"
      title="${escapeHtml(safeStatus)}"
      aria-label="${escapeHtml(safeStatus)}"
    ></span>
  `;
}

function renderStatusChip(status = '') {
  const safeStatus = normalizeStatus(status);

  if (!safeStatus) {
    return '';
  }

  return `
    <span class="status-chip ${getStatusClass(safeStatus)}">
      <span class="status-chip-label">${escapeHtml(safeStatus)}</span>
    </span>
  `;
}

function getDocumentFolderName(doc) {
  const folder =
    String(doc?.folder || '').trim();

  return folder || 'Unfiled';
}

function getFolderNamesFromDocuments(documents = []) {
  const folders =
    new Set();

  documents.forEach(doc => {
    folders.add(getDocumentFolderName(doc));
  });

  return Array.from(folders).sort((a, b) => {
    if (a === 'Unfiled') return 1;
    if (b === 'Unfiled') return -1;

    return a.localeCompare(b);
  });
}

function getFolderFilteredDocuments(documents = []) {
  if (!activeFolderFilter) {
    return documents;
  }

  const byId = new Map();
  const childrenByParent = new Map();

  documents.forEach(doc => {
    byId.set(doc.id, doc);

    const key = doc.parentId || 'root';

    if (!childrenByParent.has(key)) {
      childrenByParent.set(key, []);
    }

    childrenByParent.get(key).push(doc);
  });

  const directlyMatched = documents.filter(doc => {
    return getDocumentFolderName(doc) === activeFolderFilter;
  });

  const includeIds = new Set();

  function includeDescendants(docId) {
    const children = childrenByParent.get(docId) || [];

    children.forEach(child => {
      includeIds.add(child.id);
      includeDescendants(child.id);
    });
  }

  function includeAncestors(doc) {
    let current = doc;

    while (current?.parentId) {
      const parent = byId.get(current.parentId);

      if (!parent) break;

      includeIds.add(parent.id);
      current = parent;
    }
  }

  directlyMatched.forEach(doc => {
    includeIds.add(doc.id);

    /*
      If the document itself is foldered and has children,
      show its children underneath it. This makes foldering
      a manuscript/parent doc behave like a grouped project view.
    */
    includeDescendants(doc.id);

    /*
      If only a subdoc is foldered, parent context is optional.
      Context OFF = show the subdoc by itself.
      Context ON = show parent chain above it.
    */
    if (showFolderParentContext) {
      includeAncestors(doc);
    }
  });

  const filtered = documents.filter(doc => {
    return includeIds.has(doc.id);
  });

  const visibleIds = new Set(filtered.map(doc => doc.id));

  /*
    If a visible doc's parent is not visible, show that doc at root
    level for this filtered view. This keeps separately-foldered
    subdocs accessible without forcing the parent to appear.
  */
  return filtered.map(doc => {
    if (!doc.parentId) {
      return doc;
    }

    if (visibleIds.has(doc.parentId)) {
      return doc;
    }

    return {
      ...doc,
      parentId: null
    };
  });
}

function renderFolderShelf(documents = []) {
  if (!els.documentList) return;

  const folders = getFolderNamesFromDocuments(documents);

  const shelf = document.createElement('div');
  shelf.className = 'folder-filter-row';

  const label = document.createElement('label');
  label.className = 'folder-filter-label';
  label.textContent = 'Folder';

  const select = document.createElement('select');
  select.className = 'folder-filter-select';

  const allOption = document.createElement('option');
  allOption.value = '';
  allOption.textContent = 'All Documents';
  select.appendChild(allOption);

  folders.forEach(folder => {
    const option = document.createElement('option');

    option.value = folder;
    option.textContent = folder;

    select.appendChild(option);
  });

  select.value = activeFolderFilter || '';

  select.onchange = event => {
    activeFolderFilter = event.target.value || null;
    refreshDocumentsPanel();
  };

  const count = document.createElement('span');
  count.className = 'folder-filter-count';

  const folderVisibleDocs = getFolderFilteredDocuments(documents);
  const activeQuery = String(els.docSearch?.value || '').trim();
  const visibleDocs = activeQuery
    ? filterDocumentsBySmartSearch(folderVisibleDocs, activeQuery)
    : folderVisibleDocs;

  count.textContent =
    `${visibleDocs.length} ${activeQuery ? (visibleDocs.length === 1 ? 'match' : 'matches') : (visibleDocs.length === 1 ? 'doc' : 'docs')}`;

  const contextLabel = document.createElement('label');
  contextLabel.className = 'folder-context-toggle';

  const contextInput = document.createElement('input');
  contextInput.type = 'checkbox';
  contextInput.checked = showFolderParentContext;

  contextInput.onchange = event => {
    showFolderParentContext = Boolean(event.target.checked);
    refreshDocumentsPanel();
  };

  const contextText = document.createElement('span');
  contextText.textContent = 'Context';

  contextLabel.appendChild(contextInput);
  contextLabel.appendChild(contextText);

  shelf.appendChild(label);
  shelf.appendChild(select);
  shelf.appendChild(count);

  if (activeFolderFilter || String(els.docSearch?.value || '').trim()) {
    shelf.appendChild(contextLabel);
  }

  const stickyControls = document.querySelector('.documents-sticky-controls');
  stickyControls?.querySelector('.folder-filter-row')?.remove();
  if (stickyControls) {
    stickyControls.appendChild(shelf);
  } else {
    els.documentList.appendChild(shelf);
  }
}

function getDocumentsPanelScrollContainer() {
  if (!els.documentList) return null;
  const listStyle = window.getComputedStyle(els.documentList);
  if (['auto', 'scroll'].includes(listStyle.overflowY)) {
    return els.documentList;
  }
  let node = els.documentList.parentElement;
  while (node && node !== document.body) {
    const style = window.getComputedStyle(node);
    if (['auto', 'scroll'].includes(style.overflowY)) return node;
    node = node.parentElement;
  }
  return els.documentList;
}

function scrollSelectedDocumentIntoView(docId = currentDocumentId) {
  if (!docId || !els.documentList) return false;
  const escapedId = window.CSS?.escape ? CSS.escape(String(docId)) : String(docId).replace(/["\\]/g, '\\$&');
  const card = els.documentList.querySelector(`.doc-card[data-id="${escapedId}"]`);
  if (!card) return false;
  const container = getDocumentsPanelScrollContainer();
  if (!container) return false;
  const containerRect = container.getBoundingClientRect();
  const cardRect = card.getBoundingClientRect();
  const padding = 12;
  let nextTop = container.scrollTop;
  if (cardRect.top < containerRect.top + padding) {
    nextTop -= (containerRect.top + padding) - cardRect.top;
  } else if (cardRect.bottom > containerRect.bottom - padding) {
    nextTop += cardRect.bottom - (containerRect.bottom - padding);
  } else {
    return true;
  }
  container.scrollTo({ top: Math.max(0, nextTop), behavior: 'auto' });
  return true;
}

function scheduleSelectedDocumentVisibility(docId = currentDocumentId) {
  requestAnimationFrame(() => {
    requestAnimationFrame(() => scrollSelectedDocumentIntoView(docId));
  });
}

function collapseImportedManuscript(manuscriptId) {
  if (!manuscriptId) return;
  collapsedDocIds.add(manuscriptId);
  saveCollapsedDocIds();
}

let draggedDocumentId = null;

async function persistSiblingDocumentOrder(parentId, orderedIds) {
  const allDocs = await NaviStorage.getAllDocuments();
  const siblings = allDocs.filter(doc => (doc.parentId || null) === (parentId || null));
  const siblingMap = new Map(siblings.map(doc => [doc.id, doc]));
  const completeIds = [...orderedIds.filter(id => siblingMap.has(id)), ...sortDocumentsForDisplay(siblings).map(doc => doc.id).filter(id => !orderedIds.includes(id))];
  await Promise.all(completeIds.map((id, index) => {
    const doc = siblingMap.get(id); doc.sortOrder = index; return NaviStorage.saveDocument(doc);
  }));
  documentsCache = await NaviStorage.getAllDocuments();
  renderDocumentList(documentsCache);
  if (els.compileModal && !els.compileModal.classList.contains('hidden')) renderCompilePreview();
  if (els.outlinerModal && !els.outlinerModal.classList.contains('hidden')) renderOutliner();
}

async function reorderSiblingDocument(sourceId, targetId, placeAfter = false) {
  return moveDocumentInTree(sourceId, targetId, placeAfter ? 'after' : 'before');
}

function clearDocumentDropIndicators() {
  document.querySelectorAll('.doc-tree-drop-before,.doc-tree-drop-inside,.doc-tree-drop-after')
    .forEach(node => node.classList.remove('doc-tree-drop-before','doc-tree-drop-inside','doc-tree-drop-after'));
}

async function moveDocumentInTree(sourceId, targetId, position) {
  try {
    const result = await NaviDocumentTree.move({
      sourceId,
      targetId,
      position,
      confirmSubtree: async ({source,target,position,descendantCount}) => openConfirmModal({
        title: 'Move Document Tree?',
        message: `Move “${source.title || 'Untitled Document'}” and ${descendantCount} descendant${descendantCount === 1 ? '' : 's'} ${position === 'inside' ? `inside “${target?.title || 'Untitled Document'}”` : position === 'root' ? 'to the top level' : `${position} “${target?.title || 'Untitled Document'}”`}?`,
        confirmText: 'Move Tree', cancelText: 'Cancel', danger: false
      })
    });
    if (!result || result.cancelled) return false;
    documentsCache = result.documents;
    renderDocumentList(documentsCache);
    window.dispatchEvent(new CustomEvent('naviwriter:documents-reordered',{detail:{documentId:sourceId,targetId,position}}));
    NaviEditor.setSaveStatus(position==='inside'?'Document nested':'Document order updated');
    return true;
  } catch (error) {
    showAppNotice(error?.message || String(error), 'Cannot Move Document');
    NaviDiagnostics?.report?.({severity:'warning',subsystem:'Document tree',message:error?.message || String(error),error,recovered:true});
    return false;
  }
}

function wireDocumentOrderDrag(card, doc) {
  const handle = card.querySelector('.doc-type-icon');
  if (!handle) return;
  card.draggable = true;
  card.classList.add('doc-order-draggable');
  handle.classList.add('doc-order-handle');
  handle.title = 'Drag anywhere on this card to reorganize it';
  card.addEventListener('dragstart', event => {
    if (event.target.closest('button,input,select,textarea,a,[contenteditable="true"]')) { event.preventDefault(); return; }
    draggedDocumentId = doc.id;
    card.classList.add('doc-order-dragging');
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', doc.id);
  });
  card.addEventListener('dragend', () => {
    draggedDocumentId = null;
    card.classList.remove('doc-order-dragging');
    clearDocumentDropIndicators();
  });
  card.addEventListener('dragover', event => {
    const sourceId = draggedDocumentId || event.dataTransfer.getData('text/plain');
    if (!sourceId || sourceId === doc.id) return;
    const rect = card.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (event.clientY - rect.top) / Math.max(1, rect.height)));
    const position = event.shiftKey ? 'inside' : ratio < .34 ? 'before' : ratio > .66 ? 'after' : 'inside';
    const check = NaviDocumentTree.validateMove(documentsCache, sourceId, doc.id, position);
    if (!check.ok) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    clearDocumentDropIndicators();
    card.classList.add(`doc-tree-drop-${position}`);
    card.dataset.treeDropPosition = position;
    const verb = position === 'inside' ? 'Move inside' : position === 'before' ? 'Place before' : 'Place after';
    card.dataset.orderDropLabel = `${verb} ${doc.title || 'Untitled Document'}`;
  });
  card.addEventListener('dragleave', event => {
    if (event.relatedTarget && card.contains(event.relatedTarget)) return;
    clearDocumentDropIndicators();
    delete card.dataset.treeDropPosition;
    delete card.dataset.orderDropLabel;
  });
  card.addEventListener('drop', async event => {
    event.preventDefault();
    const sourceId = draggedDocumentId || event.dataTransfer.getData('text/plain');
    const rect=card.getBoundingClientRect(),ratio=Math.max(0,Math.min(1,(event.clientY-rect.top)/Math.max(1,rect.height)));
    const position=card.dataset.treeDropPosition||(event.shiftKey?'inside':ratio<.42?'before':ratio>.58?'after':'inside');
    clearDocumentDropIndicators();
    delete card.dataset.treeDropPosition;
    delete card.dataset.orderDropLabel;
    await moveDocumentInTree(sourceId, doc.id, position);
  });
}


function documentTreeBreadcrumb(model,node){return [...(node.ancestors||[]).map(id=>model.byId.get(id)?.title||'Untitled Document'),node.doc.title||'Untitled Document'].join(' › ');}
function openMovePositionDialog(sourceDoc){const model=NaviDocumentTree.build(documentsCache),invalid=NaviDocumentTree.descendants(sourceDoc.id,documentsCache),candidates=model.rows.filter(n=>n.id!==sourceDoc.id&&!invalid.has(n.id));return new Promise(resolve=>{const modal=document.createElement('div');modal.className='move-position-backdrop';modal.innerHTML=`<section class="move-position-dialog"><header><div><h2>Move & Position</h2><p>Move “${escapeHtml(sourceDoc.title||'Untitled Document')}” and its complete branch.</p></div><button data-close>×</button></header><div class="move-position-body"><label class="move-position-search"><span>Reference document</span><input data-search type="search" placeholder="Search titles, paths, types, folders, or tags…"></label><div class="move-position-results" data-results></div><section class="move-position-placement" data-placement hidden><strong>Exact placement relative to <span data-title></span></strong><div class="move-position-options">${[['before','Directly before'],['after','Directly after'],['inside-first','First child'],['inside-last','Last child'],['parent','Make parent of'],['group-first','First among siblings'],['group-last','Last among siblings']].map(([v,l],i)=>`<label><input type="radio" name="movePosition" value="${v}" ${i?'':'checked'}><span><b>${l}</b></span></label>`).join('')}</div><div class="move-position-preview" data-preview></div></section></div><footer><button data-cancel>Cancel</button><button data-confirm disabled>Choose a reference</button></footer></section>`;document.body.appendChild(modal);let target=null;const search=modal.querySelector('[data-search]'),results=modal.querySelector('[data-results]'),placement=modal.querySelector('[data-placement]'),confirm=modal.querySelector('[data-confirm]'),close=value=>{modal.remove();resolve(value)},labels={before:'directly before',after:'directly after','inside-first':'as first child of','inside-last':'as last child of',parent:'as parent of','group-first':'first among siblings of','group-last':'last among siblings of'};const preview=()=>{if(!target)return;const pos=modal.querySelector('input[name=movePosition]:checked').value;modal.querySelector('[data-preview]').innerHTML=`<small>Result</small><strong>${escapeHtml(sourceDoc.title||'Untitled Document')}</strong><span>${labels[pos]} <b>${escapeHtml(target.doc.title||'Untitled Document')}</b></span>`;confirm.textContent=`Move ${labels[pos]}`};const select=node=>{target=node;results.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.id===node.id));placement.hidden=false;modal.querySelector('[data-title]').textContent=node.doc.title||'Untitled Document';confirm.disabled=false;preview()};const render=()=>{const q=search.value.trim().toLowerCase(),found=candidates.filter(n=>{const d=n.doc,path=documentTreeBreadcrumb(model,n),tags=Array.isArray(d.tags)?d.tags.join(' '):d.tags||'';return !q||`${path} ${d.docType||d.type||''} ${d.folder||''} ${tags} ${n.outlineNumber}`.toLowerCase().includes(q)});results.innerHTML=found.length?found.map(n=>`<button type="button" data-id="${escapeHtml(n.id)}"><span>${escapeHtml(getDocumentTypeIcon(n.doc))}</span><span><b>${escapeHtml(n.doc.title||'Untitled Document')}</b><small>${escapeHtml(documentTreeBreadcrumb(model,n))}</small><em>${n.outlineNumber} · ${escapeHtml(getReadableDocType(n.doc))}</em></span></button>`).join(''):'<p class="empty-note">No valid destination matches.</p>';results.querySelectorAll('button').forEach(b=>b.onclick=()=>select(model.nodes.get(b.dataset.id)))};search.oninput=render;modal.querySelectorAll('input[name=movePosition]').forEach(i=>i.onchange=preview);modal.querySelector('[data-close]').onclick=modal.querySelector('[data-cancel]').onclick=()=>close(null);modal.onclick=e=>{if(e.target===modal)close(null)};confirm.onclick=()=>close({targetId:target.id,position:modal.querySelector('input[name=movePosition]:checked').value});render();search.focus()})}
async function applyPreciseDocumentMove(source,choice){if(!choice)return;const model=NaviDocumentTree.build(documentsCache),target=model.nodes.get(choice.targetId);let position=choice.position,targetId=choice.targetId;if(position==='inside-first'){if(target.children[0]){targetId=target.children[0].id;position='before'}else position='inside'}else if(position==='inside-last')position='inside';else if(position==='group-first'){targetId=(model.children.get(target.parentId||null)||[])[0]?.id||targetId;position='before'}else if(position==='group-last'){targetId=(model.children.get(target.parentId||null)||[]).at(-1)?.id||targetId;position='after'}if(position==='parent'){const result=await NaviDocumentTree.makeParent({sourceId:source.id,targetId});documentsCache=result.documents;renderDocumentList(documentsCache);if(els.compileModal&&!els.compileModal.classList.contains('hidden'))renderCompilePreview();return}await moveDocumentInTree(source.id,targetId,position)}

async function openDocumentTreeActions(doc) {
  const model = NaviDocumentTree.build(documentsCache);
  const node = model.nodes.get(doc.id);
  const invalid = NaviDocumentTree.descendants(doc.id, documentsCache);
  const choice = await openChoiceModal({
    title: 'Move Document',
    subtitle: `Change the position of “${doc.title || 'Untitled Document'}”.`,
    options: [
      {value:'icon', icon:'🙂', title:'Change Icon…', description:'Use a custom emoji, or clear it to restore the document-type icon.'},
      {value:'inside', icon:'↕', title:'Move & Position…', description:'Search the tree and choose an exact relationship and order.'},
      ...(doc.parentId ? [{value:'out', icon:'↰', title:'Move Out One Level', description:'Place this document immediately after its current parent.'}] : []),
      ...(doc.parentId ? [{value:'root', icon:'⌂', title:'Move to Top Level', description:'Remove the document tree from its current parent.'}] : []),
      ...(NaviDocumentTree.canUndo() ? [{value:'undo', icon:'↶', title:'Undo Tree Move', description:'Restore the previous parent and sibling order.'}] : []),
      ...(NaviDocumentTree.canRedo() ? [{value:'redo', icon:'↷', title:'Redo Tree Move', description:'Reapply the last undone tree move.'}] : [])
    ]
  });
  if (!choice) return;
  if (choice === 'icon') {
    const nextIcon = prompt('Enter one emoji or short symbol. Leave blank to restore the default icon.', doc.icon || '');
    if (nextIcon === null) return;
    const updated = { ...doc, icon: String(nextIcon).trim().slice(0, 8), updatedAt: Date.now() };
    await NaviStorage.saveDocument(updated);
    documentsCache = documentsCache.map(item => item.id === updated.id ? updated : item);
    refreshDocumentsPanel();
    if (els.compileModal && !els.compileModal.classList.contains('hidden')) renderCompilePreview();
    return;
  }
  if (choice === 'undo') { await NaviDocumentTree.undo(); return; }
  if (choice === 'redo') { await NaviDocumentTree.redo(); return; }
  if (choice === 'root') { await moveDocumentInTree(doc.id, null, 'root'); return; }
  if (choice === 'out') {
    const parent = model.byId.get(doc.parentId);
    if (parent) await moveDocumentInTree(doc.id, parent.id, 'after');
    return;
  }
  if (choice === 'inside') {
    const placement=await openMovePositionDialog(doc);
    if(placement)await applyPreciseDocumentMove(doc,placement);
  }}

function expandAllDocumentTrees() {
  collapsedDocIds.clear();
  saveCollapsedDocIds();
  renderDocumentList(documentsCache);
}

function collapseAllDocumentTrees() {
  const model = NaviDocumentTree.build(documentsCache);
  collapsedDocIds = new Set(model.rows.filter(node => node.hasChildren).map(node => node.id));
  saveCollapsedDocIds();
  renderDocumentList(documentsCache);
}

function getDocumentsPanelResults() {
  const all = Array.isArray(documentsCache) ? documentsCache : [];
  const folderResults = getFolderFilteredDocuments(all);
  const query = String(els.docSearch?.value || '').trim();
  if (!query) return folderResults;

  const matches = filterDocumentsBySmartSearch(folderResults, query);
  if (!showFolderParentContext) return matches;

  const byId = new Map(all.map(doc => [String(doc.id), doc]));
  const keep = new Map(matches.map(doc => [String(doc.id), doc]));
  for (const match of matches) {
    let parentId = match.parentId;
    const seen = new Set();
    while (parentId && byId.has(String(parentId)) && !seen.has(String(parentId))) {
      seen.add(String(parentId));
      const parent = byId.get(String(parentId));
      keep.set(String(parent.id), parent);
      parentId = parent.parentId;
    }
  }
  return all.filter(doc => keep.has(String(doc.id)));
}

function refreshDocumentsPanel() {
  renderDocumentList(documentsCache);
}

function renderDocumentList(documents) {
  if (!els.documentList) return;

  const allDocuments =
    Array.isArray(documentsCache)
      ? documentsCache
      : (Array.isArray(documents) ? documents : []);

  const displayDocuments = getDocumentsPanelResults();
  const treeModel = NaviDocumentTree.build(allDocuments);

  els.documentList.innerHTML = '';
  els.documentList.setAttribute('role', 'tree');

  renderFolderShelf(allDocuments);

  if (!displayDocuments.length) {
    const empty =
      document.createElement('div');

    empty.className = 'empty-note';

    empty.textContent = activeFolderFilter
      ? `No documents in ${activeFolderFilter}.`
      : 'No documents yet.';

    els.documentList.appendChild(empty);
    return;
  }

  const byParent = new Map();
  const byId = new Map(allDocuments.map(doc => [doc.id, doc]));
  const visibleIds = new Set(displayDocuments.map(doc => doc.id));

 displayDocuments.forEach(doc => {
    const key = doc.parentId && visibleIds.has(doc.parentId)
      ? doc.parentId
      : 'root';

    if (!byParent.has(key)) {
      byParent.set(key, []);
    }

    byParent.get(key).push(doc);
  });

  function sortDocs(list) {
    return sortDocumentsForDisplay(list);
  }

  function renderGroup(parentId = 'root', depth = 0, mount = els.documentList, inheritedRootId = null) {
    const group = sortDocs(byParent.get(parentId) || []);

    group.forEach((doc, siblingIndex) => {
      const children = byParent.get(doc.id) || [];
      const rootId = inheritedRootId || doc.id;
      const hasChildren = children.length > 0;
      const isCollapsed = collapsedDocIds.has(doc.id);

      const card = document.createElement('div');
      const activeSearchQuery = String(els.docSearch?.value || '').trim();
      const isSearchMatch = !activeSearchQuery || filterDocumentsBySmartSearch([doc], activeSearchQuery).length > 0;

      card.className = [
        'doc-card',
        activeSearchQuery && !isSearchMatch ? 'search-context-card' : '',
        doc.id === currentDocumentId ? 'active' : '',
        depth > 0 ? 'nested-doc' : '',
        `depth-${Math.min(depth, 3)}`,
        doc.docType ? `type-${doc.docType}` : ''
      ].filter(Boolean).join(' ');

      card.dataset.id = doc.id;
      card.dataset.treeRootId = rootId;
      card.dataset.treeDepth = String(depth);
      card.dataset.hasChildren = hasChildren ? 'true' : 'false';
      card.dataset.lastSibling = siblingIndex === group.length - 1 ? 'true' : 'false';
      card.style.setProperty('--doc-tree-depth', String(depth));
      card.setAttribute('role', 'treeitem');
      card.setAttribute('aria-level', String(depth + 1));
      card.setAttribute('aria-setsize', String(group.length));
      card.setAttribute('aria-posinset', String(siblingIndex + 1));
      if (hasChildren) card.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
      const treeNode = treeModel.nodes.get(doc.id);
      if (treeNode) card.dataset.treePath = treeNode.outlineNumber;

      const words = Number(doc.wordCount || 0);
      const updated = formatDate(doc.updatedAt);

      const typeLabel =
            doc.docType === 'cover' ? 'Cover' :
doc.docType === 'body-matter' ? 'Body Matter' :
  doc.docType === 'chapter' ? 'Chapter' :
  doc.docType === 'manuscript' ? 'Manuscript' :
  doc.docType === 'front-matter' ? 'Front Matter' :
  doc.docType === 'back-matter' ? 'Back Matter' :
  doc.docType === 'pdf' ? 'Imported PDF' :
  doc.docType === 'research' ? 'Research' :
  doc.docType === 'notes' ? 'Notes' :
  doc.docType === 'general' ? 'General' :
  doc.docType === 'subdocument' ? 'Subdoc' :
  'Doc';

      const parentDoc =
        doc.parentId
          ? byId.get(doc.parentId)
          : null;
      
      const parentLabel =
  parentDoc && ((els.docSearch?.value || '').trim() || activeFolderFilter)
    ? `${parentDoc.title || 'Untitled'} • `
    : activeFolderFilter
      ? ''
      : doc.folder
        ? `📁 ${doc.folder} • `
        : '';
      
      const docStatus =
  doc.status !== undefined && doc.status !== null
    ? doc.status
    : getDefaultStatusForDoc(doc);

const statusChip =
  renderStatusChip(docStatus);

const sidebarStatusDot =
  renderSidebarStatusDot(docStatus);
      
      const splitLabel =
  doc.splitPaneDocId
    ? getDocumentTitleById(doc.splitPaneDocId, documentsCache)
    : '';

const splitIndicator =
  splitLabel
    ? `<div class="doc-card-split-indicator">Split: ${escapeHtml(splitLabel)}</div>`
    : '';
      
      const typeIcon =
  getDocumentTypeIcon(doc);
      
      const sourceCount =
  Array.isArray(doc.sources)
    ? doc.sources.length
    : 0;

const sourceIndicator =
  doc.docType === 'research' && sourceCount
    ? `<div class="doc-card-extra">🔬 ${sourceCount} source${sourceCount === 1 ? '' : 's'}</div>`
    : '';
      
      const docCollections =
  getCollectionsForDocument(collectionsCache, doc.id);

const collectionIndicator =
  docCollections.length
    ? `<div class="doc-card-extra">🗂 ${docCollections.map(collection => escapeHtml(collection.name)).join(', ')}</div>`
    : '';

      card.innerHTML = `
  <div class="doc-card-topline">
    ${
      hasChildren
        ? `<button class="doc-collapse-btn" data-collapse-id="${escapeHtml(doc.id)}">${isCollapsed ? '▸' : '▾'}</button>`
        : `<span class="doc-collapse-spacer"></span>`
    }

    <div class="doc-card-title">
      <span class="doc-type-icon type-${escapeHtml(doc.docType || 'general')}">
        ${escapeHtml(typeIcon)}
      </span>

      <span class="doc-card-title-text">
        ${escapeHtml(doc.title || 'Untitled Document')}
      </span>

      ${treeNode?.descendantCount ? `<span class="doc-descendant-count" title="${treeNode.descendantCount} descendant${treeNode.descendantCount === 1 ? '' : 's'}">${treeNode.descendantCount}</span>` : ''}
      ${sidebarStatusDot}
    </div>
  </div>

  ${splitIndicator}
  ${sourceIndicator}
  ${collectionIndicator}

  ${
    doc.pov
      ? `<div class="doc-card-extra">POV: ${escapeHtml(doc.pov)}</div>`
      : ''
  }

  <div class="doc-card-meta">
    ${escapeHtml(parentLabel)}${escapeHtml(typeLabel)} • ${words} ${words === 1 ? 'word' : 'words'} • ${escapeHtml(updated)}
  </div>
`;

      wireDocumentOrderDrag(card, doc);
      card.addEventListener('contextmenu', event => {
        event.preventDefault();
        event.stopPropagation();
        openDocumentTreeActions(doc);
      });

      card.onclick = event => {
        const eventElement=event.target instanceof Element?event.target:event.target?.parentElement;const collapseButton=eventElement?.closest('[data-collapse-id]');

        if (collapseButton) {
          event.stopPropagation();
          toggleDocCollapsed(collapseButton.dataset.collapseId);
          return;
        }

        openDocument(doc.id);
      };

      const branch = document.createElement('section');
      branch.className = `document-tree-branch${depth === 0 ? ' document-tree-root-group' : ''}`;
      branch.dataset.branchId = doc.id;
      branch.dataset.rootId = rootId;
      branch.dataset.depth = String(depth);
      branch.appendChild(card);
      mount.appendChild(branch);

      if (hasChildren) {
        const childGroup = document.createElement('div');
        childGroup.className = 'document-tree-children';
        childGroup.setAttribute('role', 'group');
        childGroup.dataset.parentId = doc.id;
        branch.appendChild(childGroup);
        if (!isCollapsed) renderGroup(doc.id, depth + 1, childGroup, rootId);
      }
    });
  }

  renderGroup();
  const rootDrop = document.createElement('div');
  rootDrop.className = 'document-tree-root-drop';
  rootDrop.textContent = 'Move to top level';
  rootDrop.addEventListener('dragover', event => { if (!draggedDocumentId) return; event.preventDefault(); rootDrop.classList.add('active'); });
  rootDrop.addEventListener('dragleave', () => rootDrop.classList.remove('active'));
  rootDrop.addEventListener('drop', async event => { event.preventDefault(); rootDrop.classList.remove('active'); await moveDocumentInTree(draggedDocumentId || event.dataTransfer.getData('text/plain'), null, 'root'); });
  els.documentList.appendChild(rootDrop);
  scheduleSelectedDocumentVisibility(currentDocumentId);
}

async function applyCurrentStatusToSubdocs() {
  if (!currentDocumentId) return;

  const current =
    await NaviStorage.getDocument(currentDocumentId);

  if (!current) return;

  const status =
    els.docStatusSelect?.value || '';

  const allDocs =
    await NaviStorage.getAllDocuments();

  const descendantIds =
    getDescendantDocumentIds(currentDocumentId, allDocs);

  if (!descendantIds.length) {
    showAppNotice(
      'This document has no subdocuments.',
      'No subdocs found'
    );
    return;
  }

  const statusLabel =
    status || 'None';

  const ok =
    await openConfirmModal({
      title: 'Apply Status to Subdocs',
      message:
        `Apply "${statusLabel}" to ${descendantIds.length} subdocument${descendantIds.length === 1 ? '' : 's'} under "${current.title || 'Untitled Document'}"?`,
      confirmText: 'Apply',
      cancelText: 'Cancel',
      danger: false
    });

  if (!ok) return;

  for (const id of descendantIds) {
    const doc =
      await NaviStorage.getDocument(id);

    if (!doc) continue;

    await NaviStorage.saveDocument({
      ...doc,
      status,
      updatedAt: Date.now()
    });
  }

  await loadDocuments();

  NaviEditor.setSaveStatus('Status applied to subdocs');
}

function getFrequentWordsFromText(text, limit = 10) {
  const stopWords = new Set([
    'the','and','but','for','are','was','were','with','that','this','from',
    'you','your','her','his','they','them','she','him','had','has','have',
    'not','all','out','who','what','when','where','why','how','into','over',
    'there','their','then','than','too','very','just','like','said','says',
    'can','could','would','should','will','shall','did','does','done','been',
    'being','about','after','before','because','through'
  ]);

  const words = String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9'\s-]/gi, ' ')
    .split(/\s+/)
    .map(word => word.trim())
    .filter(word => word.length > 2 && !stopWords.has(word));

  const map = new Map();

  words.forEach(word => {
    map.set(word, (map.get(word) || 0) + 1);
  });

  return Array.from(map.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([text, count]) => ({
      text,
      count
    }));
}

function clearActiveFindHighlight() {
  if (window.CSS && CSS.highlights) {
    CSS.highlights.delete('navi-find-active');
  }
}

function showActiveFindHighlight(range, fallbackElement) {
  clearActiveFindHighlight();

  if (window.CSS && CSS.highlights && window.Highlight) {
    const highlight = new Highlight(range);
    CSS.highlights.set('navi-find-active', highlight);

    setTimeout(() => {
      clearActiveFindHighlight();
    }, 1800);

    return;
  }

  flashFindResult(fallbackElement);
}

function getFrequentPhrasesFromText(text, size = 3, limit = 10) {
  const words = String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9'\s-]/gi, ' ')
    .split(/\s+/)
    .map(word => word.trim())
    .filter(word => word.length > 2);

  const map = new Map();

  for (let i = 0; i <= words.length - size; i++) {
    const phrase = words.slice(i, i + size).join(' ');

    if (!phrase.trim()) continue;

    map.set(phrase, (map.get(phrase) || 0) + 1);
  }

  return Array.from(map.entries())
    .filter(([, count]) => count > 1)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([text, count]) => ({
      text,
      count
    }));
}


const DOCUMENT_SCOPE_POLICY = Object.freeze({
  manuscript: false,
  chapter: true,
  'front-matter': true,
  'body-matter': true,
  'back-matter': true,
  general: true,
  notes: false,
  research: false,
  pdf: false,
  cover: false
});

function isGeneratedManuscriptOverview(doc, text = '') {
  if ((doc?.docType || doc?.type) !== 'manuscript') return false;
  const normalized = String(text || '').replace(/\s+/g, ' ').trim().toLowerCase();
  return !normalized || normalized === 'manuscript overview' ||
    normalized.startsWith('imported from pdf') || normalized.startsWith('manuscript overview');
}

function documentIncludedByScopePolicy(doc) {
  return DOCUMENT_SCOPE_POLICY[doc?.docType || doc?.type || 'general'] !== false;
}

function orderScopedDocuments(allDocs, rootId) {
  const byParent = new Map();
  allDocs.forEach(doc => {
    const key = doc.parentId || null;
    if (!byParent.has(key)) byParent.set(key, []);
    byParent.get(key).push(doc);
  });
  const ordered = [];
  const walk = id => {
    const children = (byParent.get(id) || []).slice().sort((a,b) =>
      Number(a.order ?? a.sortOrder ?? 0) - Number(b.order ?? b.sortOrder ?? 0) ||
      String(a.title || '').localeCompare(String(b.title || ''))
    );
    children.forEach(child => { ordered.push(child); walk(child.id); });
  };
  const root = allDocs.find(doc => doc.id === rootId);
  if (root) ordered.push(root);
  walk(rootId);
  return ordered;
}

async function resolveDocumentScope(targetDocumentId = currentDocumentId, requestedScope = 'current') {
  const allDocs = await NaviStorage.getAllDocuments();
  const byId = new Map(allDocs.map(doc => [String(doc.id), doc]));
  const target = byId.get(String(targetDocumentId));
  const validScopes = ['current', 'branch', 'root', 'project'];
  const labels = {
    current:'Current document',
    branch:'Current document + descendants',
    root:'Current root tree',
    project:'Entire project'
  };
  if (!target) return { valid:false, requestedScope, scope:'current', validScopes, targetDocumentId, ids:[], docs:[], label:'Unavailable scope', warning:'The target document was deleted or is unavailable.' };

  let root = target;
  const seen = new Set();
  while (root.parentId && byId.has(String(root.parentId)) && !seen.has(String(root.parentId))) {
    seen.add(String(root.id));
    root = byId.get(String(root.parentId));
  }

  const scope = validScopes.includes(requestedScope) ? requestedScope : 'current';
  const descendants = orderScopedDocuments(allDocs, target.id).slice(1);
  let candidates;
  if (scope === 'current') candidates = [target];
  else if (scope === 'branch') candidates = [target, ...descendants];
  else if (scope === 'root') candidates = orderScopedDocuments(allDocs, root.id);
  else candidates = allDocs.slice();

  candidates = candidates.filter((doc, index, list) => list.findIndex(item => String(item.id) === String(doc.id)) === index);
  const docs = candidates.filter(doc => {
    const text = getDocPlainTextForStats(doc);
    if (isGeneratedManuscriptOverview(doc, text)) return false;
    return documentIncludedByScopePolicy(doc);
  });
  return { valid:true, requestedScope, scope, validScopes, targetDocumentId:target.id, rootId:root.id, ids:docs.map(doc=>doc.id), docs, label:labels[scope], warning:'', excluded:candidates.filter(doc=>!docs.some(item=>String(item.id)===String(doc.id))) };
}

function populateScopeSelect(select, resolution, selectedScope) {
  if (!select || !resolution?.valid) return;
  const labels = {
    current:'Current document',
    branch:'Current document + descendants',
    root:'Current root tree',
    project:'Entire project'
  };
  const value = resolution.validScopes.includes(selectedScope) ? selectedScope : resolution.scope;
  select.innerHTML = '';
  resolution.validScopes.forEach(scope => {
    const option = document.createElement('option');
    option.value = scope;
    option.textContent = labels[scope];
    select.appendChild(option);
  });
  select.value = value;
}

async function getScopeStatistics(targetId, scope) {
  const resolution = await resolveDocumentScope(targetId, scope);
  let words=0, chars=0, paragraphs=0, headings=0;
  resolution.docs.forEach(doc => {
    const text=getDocPlainTextForStats(doc); words+=NaviEditor.countWords(text); chars+=text.length;
    const html=doc.id===currentDocumentId && NaviEditor.getEditorHTML ? NaviEditor.getEditorHTML() : (doc.content || doc.html || '');
    paragraphs += (String(html).match(/<p\b/gi)||[]).length || (text.trim()?text.split(/\n\s*\n/).filter(Boolean).length:0);
    headings += (String(html).match(/<h[1-6]\b/gi)||[]).length;
  });
  return { ...resolution, words, chars, paragraphs, headings, readingMinutes:Math.ceil(words/200) };
}

async function getAnalysisText() {
  const scope = els.analysisScopeSelect?.value || 'current';
  const result = await resolveDocumentScope(currentDocumentId, scope);
  populateScopeSelect(els.analysisScopeSelect, result, scope);
  return result.docs.map(doc => getDocPlainTextForStats(doc)).join('\n\n');
}


async function findOccurrencesAcrossScope(query, scope, options = {}) {
  const resolution = await resolveDocumentScope(currentDocumentId, scope);
  if (!resolution.valid || !resolution.docs.length) return [];
  const results = [];
  resolution.docs.forEach(doc => {
    const text = getDocPlainTextForStats(doc);
    const occurrences = findOccurrencesInText(text, query, 8, options);
    occurrences.forEach((occurrence, occurrenceIndex) => {
      results.push({ ...occurrence, occurrenceIndex, docId:doc.id, docTitle:doc.title || 'Untitled Document', scope });
    });
  });
  return results;
}

function getFindScope() {
  return els.floatingFindScopeSelect?.value || 'current';
}

function getFindOptions() {
  return {
    matchCase: Boolean(els.floatingFindMatchCase?.checked),
    wholeWord: Boolean(els.floatingFindWholeWord?.checked)
  };
}

function applyDocumentTypePreset(doc) {
  const type =
    doc?.docType || 'standard';

  document.body.classList.remove(
    'doc-type-standard',
    'doc-type-manuscript',
    'doc-type-chapter',
    'doc-type-front-matter',
    'doc-type-back-matter',
    'doc-type-body-matter',
    'doc-type-cover',
    'doc-type-notes',
    'doc-type-research',
    'doc-type-pdf',
    'doc-type-general'
  );

  document.body.classList.add(`doc-type-${type}`);

  if (!els.docTitle) {
    return;
  }

  if (type === 'chapter') {
    els.docTitle.placeholder = 'Chapter title...';
  } else if (type === 'front-matter') {
    els.docTitle.placeholder = 'Front matter title...';
  } else if (type === 'back-matter') {
    els.docTitle.placeholder = 'Back matter title...';
  } else if (type === 'body-matter') {
    els.docTitle.placeholder = 'Body matter title...';
  } else if (type === 'cover') {
    els.docTitle.placeholder = 'Cover title...';
  } else if (type === 'notes') {
    els.docTitle.placeholder = 'Notes title...';
  } else if (type === 'research') {
    els.docTitle.placeholder = 'Research title...';
  } else if (type === 'pdf') {
    els.docTitle.placeholder = 'PDF title...';
  } else {
    els.docTitle.placeholder = 'Untitled Document';
  }

  if (els.writeModeBtn) {
    els.writeModeBtn.textContent = type === 'research' ? 'Notes' : 'Write';
    els.writeModeBtn.title = type === 'research'
      ? 'Edit the research document notes'
      : 'Write in the document editor';
  }
  if (els.sourcesModeBtn) {
    els.sourcesModeBtn.textContent = 'Sources';
    els.sourcesModeBtn.title = 'Manage structured sources attached to this research document';
  }
}

function createEmptyBoard() {
  return {
    items: []
  };
}

function normalizeBoardData(board) {
  if (!board || !Array.isArray(board.items)) {
    return {
      items: [],
      connectors: [],
      canvas: {
        width: 5000,
        height: 3500
      }
    };
  }

  return {
    items: board.items.map(item => { const isViewer=item.type==='document-view'; const migrate=isViewer&&Number(item.viewerLayoutVersion||0)<3; let width=Number(item.width||(isViewer?430:220)); let height=Number(item.height||(isViewer?330:140)); if(migrate){const imageLike=String(item.mimeType||'').startsWith('image/');width=imageLike?Math.max(260,Math.min(460,width)):Math.max(300,Math.min(440,width));height=imageLike?Math.max(220,Math.min(420,height)):Math.max(220,Math.min(340,height));} return ({
      id: item.id || crypto.randomUUID(),
      type: item.type || 'note',
      x: Number(item.x || 40),
      y: Number(item.y || 40),
      width,
      height,
      viewerLayoutVersion: isViewer ? 3 : Number(item.viewerLayoutVersion || 0),
      text: item.text || '',
      src: item.src || '',
      attachmentId: item.attachmentId || '', originalName: item.originalName || '', mimeType: item.mimeType || '', viewerState: item.viewerState || { page: 1, zoom: 1, fit: 'width', rotation: 0 },
      previewHtml: item.previewHtml || '',
      title: item.title || '',
      description: item.description || '',
      url: item.url || '',
      docId: item.docId || '',
      name: item.name || '',
      role: item.role || '',
      notes: item.notes || '',
      color: item.color || '#fff8b5',
      zIndex: Number(item.zIndex || 2),
      fontSize: Number(item.fontSize || 13),
    }); }),

    connectors: Array.isArray(board.connectors)
  ? board.connectors.filter(connector => connector?.fromId && connector?.toId && connector.fromId !== connector.toId).map(connector => ({
      id: connector.id || crypto.randomUUID(),
      fromId: connector.fromId || '',
      toId: connector.toId || '',
      label: connector.label || '',
      type: connector.type || 'straight',
      color: connector.color || '',
      width: Math.max(1, Math.min(8, Number(connector.width || 3))),
      direction: ['none','forward','backward','both'].includes(connector.direction) ? connector.direction : 'none'
    }))
  : [],

    canvas: {
      width: Number(board.canvas?.width || 5000),
      height: Number(board.canvas?.height || 3500)
    },
    ownership: {
      scope: board.ownership?.scope || 'document',
      documentId: board.ownership?.documentId || null,
      projectId: board.ownership?.projectId || null
    },
    schemaVersion: Number(board.schemaVersion || 2)
  };
}

function getBoardSnapshot() {
  const board = normalizeBoardData(currentBoardData);
  return {
    ...board,
    ownership: {
      scope: 'document',
      documentId: currentDocumentId || null
    },
    schemaVersion: 2
  };
}

function updateWorkspaceModeButtons(mode = 'write') {
  const activeDoc=documentsCache.find(item=>item.id===currentDocumentId),isReference=activeDoc?.docType==='reference-view';
  if(isReference){if(els.writeModeBtn){els.writeModeBtn.hidden=false;els.writeModeBtn.textContent='Viewer';els.writeModeBtn.classList.toggle('active',mode==='viewer');}if(els.boardModeBtn){els.boardModeBtn.hidden=false;els.boardModeBtn.textContent='Notes';els.boardModeBtn.classList.toggle('active',mode==='notes');}if(els.sourcesModeBtn){els.sourcesModeBtn.hidden=true;els.sourcesModeBtn.classList.remove('active');}return;}
  if(els.writeModeBtn){els.writeModeBtn.hidden=false;els.writeModeBtn.textContent=isResearchDocument(activeDoc)?'Notes':'Write';els.writeModeBtn.classList.toggle('active',mode==='write');}
  if(els.boardModeBtn){els.boardModeBtn.hidden=false;els.boardModeBtn.textContent='Board';els.boardModeBtn.classList.toggle('active',mode==='board');}
  if(els.sourcesModeBtn){els.sourcesModeBtn.hidden=false;els.sourcesModeBtn.textContent='Sources';els.sourcesModeBtn.classList.toggle('active',mode==='sources');}
}
function setSourcesMode(enabled) {
  const isSources =
    Boolean(enabled);

  document.body.classList.toggle(
    'sources-mode-active',
    isSources
  );
  document.body.dataset.workspaceMode = isSources ? 'sources' : 'write';

  if (isSources) {
    /*
      Do NOT call setBoardMode(false) here, because setBoardMode(false)
      marks Write active. We only need to leave board mode quietly.
    */
    document.body.classList.remove('board-mode-active');
    boardConnectMode = false;
    boardConnectStartId = null;
    document.body.classList.remove('board-connect-mode');

    if (els.connectBoardItemsBtn) {
      els.connectBoardItemsBtn.classList.remove('active');
      els.connectBoardItemsBtn.textContent = 'Connect';
    }

    updateWorkspaceModeButtons('sources');
    renderSourcesPanel();
  } else {
    updateWorkspaceModeButtons('write');
  }
}

function exitSourcesMode() {
  setSourcesMode(false);
}

function setBoardMode(enabled) {
  const isBoard = Boolean(enabled);
  
  if (isBoard) {
  document.body.classList.remove('sources-mode-active');

  if (els.sourcesModeBtn) {
    els.sourcesModeBtn.classList.remove('active');
  }
}
  
  if (!isBoard) {
  hideBoardMinimap();
}

  document.body.classList.toggle('board-mode-active', isBoard);
  document.body.dataset.workspaceMode = isBoard ? 'board' : 'write';

 updateWorkspaceModeButtons(isBoard ? 'board' : 'write');

  if (isBoard) {
    renderBoard();
  } else {
    boardConnectMode = false;
    boardConnectStartId = null;
    hideBoardMinimap();

    document.body.classList.remove('board-connect-mode');

    if (els.connectBoardItemsBtn) {
      els.connectBoardItemsBtn.classList.remove('active');
      els.connectBoardItemsBtn.textContent = 'Connect';
    }
  }
}

async function renderSourcesPanel() {
  if (!els.sourcesList) return;

  if (!currentDocumentId) {
    els.sourcesList.innerHTML = `
      <div class="empty-note">Open a research document first.</div>
    `;
    return;
  }

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) {
    els.sourcesList.innerHTML = `
      <div class="empty-note">Document not found.</div>
    `;
    return;
  }

  if (!isResearchDocument(doc)) {
    els.sourcesList.innerHTML = `
      <div class="empty-note">
        Sources are available for Research documents.
      </div>
    `;
    return;
  }

  const sources =
    getCurrentSourceList(doc);

  if (!sources.length) {
    els.sourcesList.innerHTML = `
      <div class="empty-note">
        No sources yet. Add links, articles, books, videos, or reference notes here.
      </div>
    `;
    return;
  }

  els.sourcesList.innerHTML = '';

  sources
    .slice()
    .sort((a, b) => {
      return Number(b.updatedAt || 0) - Number(a.updatedAt || 0);
    })
    .forEach(source => {
      const card =
        document.createElement('article');

      card.className = 'source-card';
      card.dataset.sourceId = source.id;

      const host =
        source.url
          ? getHostnameFromUrl(source.url)
          : '';

      const tags =
        Array.isArray(source.tags) && source.tags.length
          ? source.tags.map(tag => {
              return `<span class="source-tag">${escapeHtml(tag)}</span>`;
            }).join('')
          : '';

      card.innerHTML = `
        <div class="source-card-head">
          <div>
            <strong>${escapeHtml(source.title || 'Untitled Source')}</strong>
            <div class="source-card-meta">
              ${
                source.author
                  ? `<span>${escapeHtml(source.author)}</span>`
                  : ''
              }
              ${
                source.dateAccessed
                  ? `<span>${escapeHtml(formatSourceDate(source.dateAccessed))}</span>`
                  : ''
              }
              ${
                host
                  ? `<span>${escapeHtml(host)}</span>`
                  : ''
              }
            </div>
          </div>

          <div class="source-card-actions">
            ${
              source.url
                ? `<button class="source-open-btn">Open</button>`
                : ''
            }
            <button class="source-edit-btn">Edit</button>
            <button class="source-delete-btn">Delete</button>
          </div>
        </div>

        ${
  source.url
    ? `
      <a
        class="source-url"
        href="${escapeHtml(normalizeExternalUrl(source.url))}"
        target="_blank"
        rel="noopener noreferrer"
      >
        ${escapeHtml(source.url)}
      </a>
    `
    : ''
}

        ${
          source.notes
            ? `<p class="source-notes">${escapeHtml(source.notes)}</p>`
            : ''
        }

        ${
          tags
            ? `<div class="source-tags">${tags}</div>`
            : ''
        }
      `;

      card.querySelector('.source-open-btn')?.addEventListener('click', event => {
        event.stopPropagation();

        if (source.url) {
          window.open(
            normalizeExternalUrl(source.url),
            '_blank',
            'noopener,noreferrer'
          );
        }
      });

      card.querySelector('.source-edit-btn')?.addEventListener('click', event => {
        event.stopPropagation();
        openSourceModal(source);
      });

      card.querySelector('.source-delete-btn')?.addEventListener('click', async event => {
        event.stopPropagation();
        await deleteSource(source.id);
      });

      els.sourcesList.appendChild(card);
    });
}

async function saveSourcesForCurrentDocument(sources) {
  if (!currentDocumentId) return;

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) return;

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      sources: normalizeSourceList(sources),
      updatedAt: Date.now()
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  await renderSourcesPanel();
  renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Sources saved');
}

function openSourceModal(source = null) {
  if (!els.sourceModal) return;

  editingSourceId =
    source?.id || null;

  if (els.sourceModalTitle) {
    els.sourceModalTitle.textContent =
      editingSourceId ? 'Edit Source' : 'Add Source';
  }

  if (els.sourceTitleInput) {
    els.sourceTitleInput.value = source?.title || '';
  }

  if (els.sourceUrlInput) {
    els.sourceUrlInput.value = source?.url || '';
  }

  if (els.sourceAuthorInput) {
    els.sourceAuthorInput.value = source?.author || '';
  }

  if (els.sourceDateInput) {
    els.sourceDateInput.value = source?.dateAccessed || '';
  }

  if (els.sourceTagsInput) {
    els.sourceTagsInput.value = Array.isArray(source?.tags)
      ? source.tags.join(', ')
      : '';
  }

  if (els.sourceNotesInput) {
    els.sourceNotesInput.value = source?.notes || '';
  }

  if (els.submitSourceModalBtn) {
    els.submitSourceModalBtn.textContent =
      editingSourceId ? 'Save Source' : 'Add Source';
  }

  els.sourceModal.classList.remove('hidden');

  setTimeout(() => {
    els.sourceTitleInput?.focus();
  }, 0);
}

function closeSourceModal() {
  editingSourceId = null;

  if (els.sourceModal) {
    els.sourceModal.classList.add('hidden');
  }
}

async function submitSourceModal() {
  if (!currentDocumentId) return;

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) return;

  if (!isResearchDocument(doc)) {
    showAppNotice(
      'Sources are only available for Research documents.',
      'Not a research document'
    );
    return;
  }

  const title =
    els.sourceTitleInput?.value.trim() || 'Untitled Source';

  const url =
    els.sourceUrlInput?.value.trim() || '';

  const nextSource = {
    id: editingSourceId || crypto.randomUUID(),
    title,
    url,
    author: els.sourceAuthorInput?.value.trim() || '',
    dateAccessed: els.sourceDateInput?.value || '',
    tags: parseTags(els.sourceTagsInput?.value || ''),
    notes: els.sourceNotesInput?.value.trim() || '',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  const sources =
    getCurrentSourceList(doc);

  const existingIndex =
    sources.findIndex(source => {
      return source.id === editingSourceId;
    });

  if (existingIndex >= 0) {
    nextSource.createdAt =
      sources[existingIndex].createdAt || Date.now();

    sources[existingIndex] = nextSource;
  } else {
    sources.push(nextSource);
  }

  closeSourceModal();

  await saveSourcesForCurrentDocument(sources);
}

async function deleteSource(sourceId) {
  if (!currentDocumentId || !sourceId) return;

  const ok =
    await openConfirmModal({
      title: 'Delete Source',
      message: 'Delete this research source?',
      confirmText: 'Delete',
      cancelText: 'Cancel',
      danger: true
    });

  if (!ok) return;

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) return;

  const sources =
    getCurrentSourceList(doc)
      .filter(source => source.id !== sourceId);

  await saveSourcesForCurrentDocument(sources);
}

function getBoardCanvasBounds(){const canvas=currentBoardData?.canvas||{width:5000,height:3500},width=Math.max(1,Number(canvas.width||5000)),height=Math.max(1,Number(canvas.height||3500));return{minX:0,minY:0,maxX:width,maxY:height,width,height,padding:0};}

function renderBoardMinimap() {
  if (
    !els.boardMinimap ||
    els.boardMinimap.classList.contains('hidden') ||
    !els.boardMinimapBody ||
    !els.boardMinimapWorld ||
    !els.boardMinimapViewport ||
    !els.boardSurface
  ) {
    return;
  }

  const bounds =
    getBoardCanvasBounds();

  const bodyRect =
    els.boardMinimapBody.getBoundingClientRect();

  const padding =
    8;

  const scaleX =
    (bodyRect.width - padding * 2) /
    Math.max(1, bounds.width);

  const scaleY =
    (bodyRect.height - padding * 2) /
    Math.max(1, bounds.height);

  boardMinimapScale =
    Math.max(
      0.01,
      Math.min(scaleX, scaleY)
    );

  const worldWidth =
    bounds.width * boardMinimapScale;

  const worldHeight =
    bounds.height * boardMinimapScale;

  els.boardMinimapWorld.style.width =
    `${worldWidth}px`;

  els.boardMinimapWorld.style.height =
    `${worldHeight}px`;

  els.boardMinimapWorld.style.left =
    `${padding}px`;

  els.boardMinimapWorld.style.top =
    `${padding}px`;

  els.boardMinimapWorld.innerHTML = '';

  const items =
    Array.isArray(currentBoardData.items)
      ? currentBoardData.items
      : [];

  items.forEach(item => {
    const node =
      document.createElement('div');

    node.className = [
      'board-minimap-item',
      item.id === activeBoardItemId ? 'active' : '',
      item.type ? `type-${item.type}` : ''
    ]
      .filter(Boolean)
      .join(' ');

    node.style.left =
      `${(getRenderedBoardItemRect(item).x-bounds.minX)*boardMinimapScale}px`;

    node.style.top =
      `${(getRenderedBoardItemRect(item).y-bounds.minY)*boardMinimapScale}px`;

    node.style.width =
      `${Math.max(1,getRenderedBoardItemRect(item).width*boardMinimapScale)}px`;

    node.style.height =
      `${Math.max(1,getRenderedBoardItemRect(item).height*boardMinimapScale)}px`;

    els.boardMinimapWorld.appendChild(node);
  });

  els.boardMinimap.dataset.minX=String(bounds.minX);
  els.boardMinimap.dataset.minY=String(bounds.minY);
  updateBoardMinimapViewport();
}

function updateBoardMinimapViewport(){if(!els.boardMinimap||els.boardMinimap.classList.contains('hidden')||!els.boardMinimapViewport||!els.boardSurface)return;const zoom=Math.max(.1,Number(boardZoom||1)),scrollX=(els.boardSurface.scrollLeft||0)/zoom,scrollY=(els.boardSurface.scrollTop||0)/zoom,vw=(els.boardSurface.clientWidth||1)/zoom,vh=(els.boardSurface.clientHeight||1)/zoom,worldW=parseFloat(els.boardMinimapWorld.style.width)||1,worldH=parseFloat(els.boardMinimapWorld.style.height)||1,width=Math.max(6,Math.min(worldW,vw*boardMinimapScale)),height=Math.max(6,Math.min(worldH,vh*boardMinimapScale)),left=8+scrollX*boardMinimapScale,top=8+scrollY*boardMinimapScale;els.boardMinimapViewport.style.left=`${Math.max(8,Math.min(8+worldW-width,left))}px`;els.boardMinimapViewport.style.top=`${Math.max(8,Math.min(8+worldH-height,top))}px`;els.boardMinimapViewport.style.width=`${width}px`;els.boardMinimapViewport.style.height=`${height}px`;}

function panBoardToMinimapPoint(clientX,clientY){if(!els.boardMinimapBody||!els.boardSurface)return;const rect=els.boardMinimapBody.getBoundingClientRect(),localX=Math.max(0,clientX-rect.left-8),localY=Math.max(0,clientY-rect.top-8),boardX=localX/Math.max(.0001,boardMinimapScale),boardY=localY/Math.max(.0001,boardMinimapScale);els.boardSurface.scrollLeft=Math.max(0,boardX*boardZoom-els.boardSurface.clientWidth/2);els.boardSurface.scrollTop=Math.max(0,boardY*boardZoom-els.boardSurface.clientHeight/2);updateBoardMinimapViewport();}



function renderBoard() {
  if (!els.boardSurface) return;

  els.boardSurface.innerHTML = '';

  currentBoardData = normalizeBoardData(currentBoardData);

  expandBoardCanvasToFitItems();

  const scaledWidth = currentBoardData.canvas.width * boardZoom;
  const scaledHeight = currentBoardData.canvas.height * boardZoom;

  const viewport = document.createElement('div');
  viewport.className = 'board-canvas-viewport';
  viewport.style.width = `${scaledWidth}px`;
  viewport.style.height = `${scaledHeight}px`;

  const world = document.createElement('div');
  world.className = 'board-canvas-world';
  world.style.width = `${currentBoardData.canvas.width}px`;
  world.style.height = `${currentBoardData.canvas.height}px`;
  world.style.transform = `scale(${boardZoom})`;

  const svg = document.createElementNS(
    'http://www.w3.org/2000/svg',
    'svg'
  );

  svg.id = 'boardConnectorsLayer';
  svg.classList.add('board-connectors-layer');
  svg.setAttribute('width', currentBoardData.canvas.width);
  svg.setAttribute('height', currentBoardData.canvas.height);

  world.appendChild(svg);

  currentBoardData.items.forEach(item => {
    const node = createBoardItemElement(item);
    world.appendChild(node);
  });

  viewport.appendChild(world);
  els.boardSurface.appendChild(viewport);

  renderBoardConnectors(svg);
  updateBoardConnectModeUI();
  updateBoardZoomLabel();
  renderBoardMinimap();
}


function expandBoardCanvasToFitItems() {
  const padding = 900;

  let maxX = 5000;
  let maxY = 3500;

  currentBoardData.items.forEach(item => {
    maxX = Math.max(maxX, item.x + item.width + padding);
    maxY = Math.max(maxY, item.y + item.height + padding);
  });

  currentBoardData.canvas.width = maxX;
  currentBoardData.canvas.height = maxY;
}

function getRenderedBoardItemRect(item){const node=els.boardSurface?.querySelector(`.board-item[data-id="${CSS.escape(item.id)}"]`),world=els.boardSurface?.querySelector('.board-canvas-world')||els.boardSurface;if(node&&world){const nr=node.getBoundingClientRect(),wr=world.getBoundingClientRect(),zoom=Math.max(.01,Number(boardZoom||1));return{x:(nr.left-wr.left)/zoom,y:(nr.top-wr.top)/zoom,width:nr.width/zoom,height:nr.height/zoom};}return{x:Number(item.x||0),y:Number(item.y||0),width:Math.max(1,Number(item.width||240)),height:Math.max(1,Number(item.height||140))};}

function getBoardItemCenter(item){const r=getRenderedBoardItemRect(item);return{x:r.x+r.width/2,y:r.y+r.height/2};}

function getBoardRectEdgePoint(item,toward){const r=getRenderedBoardItemRect(item),c={x:r.x+r.width/2,y:r.y+r.height/2},dx=Number(toward.x||0)-c.x,dy=Number(toward.y||0)-c.y;if(!dx&&!dy)return c;const scale=1/Math.max(Math.abs(dx)/(r.width/2),Math.abs(dy)/(r.height/2));return{x:c.x+dx*scale,y:c.y+dy*scale};}

function getBoardConnectorEndpoints(from,to,connector={}){const fc=getBoardItemCenter(from),tc=getBoardItemCenter(to),start=getBoardRectEdgePoint(from,tc),end=getBoardRectEdgePoint(to,fc),direction=connector.direction||'none',stroke=Math.max(1,Number(connector.width||3)),si=(direction==='backward'||direction==='both')?Math.max(2,stroke*.55):0,ei=(direction==='forward'||direction==='both')?Math.max(2,stroke*.55):0,dx=end.x-start.x,dy=end.y-start.y,len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len;return{start:{x:start.x+ux*si,y:start.y+uy*si},end:{x:end.x-ux*ei,y:end.y-uy*ei}};}

function renderBoardConnectors(svg){if(!svg)return;const defs=document.createElementNS('http://www.w3.org/2000/svg','defs');defs.innerHTML='<marker id="boardConnectorArrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker><marker id="boardConnectorArrowStart" viewBox="0 0 10 10" refX="1" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 10 0 L 0 5 L 10 10 z" fill="context-stroke"/></marker>';svg.appendChild(defs);const map=new Map(currentBoardData.items.map(item=>[item.id,item]));currentBoardData.connectors.forEach(connector=>{const from=map.get(connector.fromId),to=map.get(connector.toId);if(!from||!to)return;const{start,end}=getBoardConnectorEndpoints(from,to,connector),d=getConnectorPath(start,end,connector.type),edit=event=>{event.preventDefault();event.stopPropagation();editBoardConnector(connector.id);};const hit=document.createElementNS('http://www.w3.org/2000/svg','path');hit.setAttribute('d',d);hit.setAttribute('fill','none');hit.setAttribute('stroke','rgba(0,0,0,.001)');hit.setAttribute('stroke-width',String(Math.max(16,Number(connector.width||3)+12)));hit.setAttribute('stroke-linecap','round');hit.classList.add('board-connector-hit');hit.style.pointerEvents='stroke';hit.dataset.connectorId=connector.id;hit.addEventListener('pointerdown',edit);svg.appendChild(hit);const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d',d);path.setAttribute('fill','none');path.setAttribute('stroke',getBoardConnectorColor(connector));path.setAttribute('stroke-width',String(Math.max(1,Math.min(8,Number(connector.width||3)))));path.setAttribute('stroke-linecap','round');path.setAttribute('stroke-linejoin','round');const direction=connector.direction||'none';if(direction==='forward'||direction==='both')path.setAttribute('marker-end','url(#boardConnectorArrow)');if(direction==='backward'||direction==='both')path.setAttribute('marker-start','url(#boardConnectorArrowStart)');path.classList.add('board-connector-path');path.style.pointerEvents='stroke';path.dataset.connectorId=connector.id;path.addEventListener('click',edit);svg.appendChild(path);if(connector.label){const pos=getConnectorLabelPosition(start,end),text=document.createElementNS('http://www.w3.org/2000/svg','text');text.classList.add('board-connector-label');text.style.pointerEvents='all';text.setAttribute('x',pos.x);text.setAttribute('y',pos.y);text.setAttribute('text-anchor','middle');text.textContent=connector.label;text.dataset.connectorId=connector.id;text.addEventListener('click',edit);svg.appendChild(text);}});}



function getConnectorPath(start, end, type = 'straight') {
  if (type === 'curve') {
    const distance = Math.abs(end.x - start.x);
    const curve = Math.max(80, distance * 0.35);

    return [
      `M ${start.x} ${start.y}`,
      `C ${start.x + curve} ${start.y}`,
      `${end.x - curve} ${end.y}`,
      `${end.x} ${end.y}`
    ].join(' ');
  }

  if (type === 'elbow') {
    const midX = (start.x + end.x) / 2;

    return [
      `M ${start.x} ${start.y}`,
      `L ${midX} ${start.y}`,
      `L ${midX} ${end.y}`,
      `L ${end.x} ${end.y}`
    ].join(' ');
  }

  return [
    `M ${start.x} ${start.y}`,
    `L ${end.x} ${end.y}`
  ].join(' ');
}

function getConnectorLabelPosition(start, end) {
  return {
    x: (start.x + end.x) / 2,
    y: (start.y + end.y) / 2 - 8
  };
}


function isBoardItemSelected(id) {
  return selectedBoardItemIds.has(id);
}

function updateBoardSelectionClasses() {
  if (!els.boardSurface) return;

  els.boardSurface
    .querySelectorAll('.board-item')
    .forEach(node => {
      const id = node.dataset.id;

      node.classList.toggle(
        'selected',
        Boolean(id && selectedBoardItemIds.has(id))
      );

      node.classList.toggle(
        'multi-selected',
        Boolean(id && selectedBoardItemIds.has(id) && selectedBoardItemIds.size > 1)
      );
    });
}

function clearBoardSelection() {
  selectedBoardItemIds.clear();
  activeBoardItemId = null;
  updateBoardSelectionClasses();
}

function selectBoardItem(id, additive = false) {
  if (!id) return;

  if (additive) {
    if (selectedBoardItemIds.has(id)) {
      selectedBoardItemIds.delete(id);
    } else {
      selectedBoardItemIds.add(id);
    }
  } else {
    selectedBoardItemIds.clear();
    selectedBoardItemIds.add(id);
  }

  activeBoardItemId =
    selectedBoardItemIds.has(id)
      ? id
      : Array.from(selectedBoardItemIds)[0] || null;

  updateBoardSelectionClasses();
}



function createBoardItemElement(item) {
  const el = document.createElement('div');

  el.className = [
    'board-item',
    selectedBoardItemIds.has(item.id) ? 'selected' : '',
selectedBoardItemIds.has(item.id) && selectedBoardItemIds.size > 1 ? 'multi-selected' : '',
    `board-item-${item.type}`
  ].filter(Boolean).join(' ');

  el.dataset.id = item.id;
  el.style.left = `${item.x}px`;
  el.style.top = `${item.y}px`;
  el.style.width = `${item.width}px`;
  el.style.height = `${item.height}px`;
  el.style.minHeight = `${item.height}px`;
  el.style.zIndex = String(item.zIndex || 2);

  if (item.color) {
    el.style.background = item.color;
  }
  
  el.style.setProperty(
  '--board-card-font-size',
  `${Number(item.fontSize || 13)}px`
);

  const head = document.createElement('div');
  head.className = 'board-item-head';

  const badge = document.createElement('span');
  badge.className = [
    'board-card-badge',
    `board-card-badge-${item.type || 'note'}`
  ].join(' ');

  badge.textContent =
    item.type === 'audio'
      ? 'Audio Memo'
      : item.type === 'document-view'
      ? 'Document View'
      : item.type === 'image'
      ? 'Image'
      : item.type === 'person'
        ? 'Person'
        : item.type === 'link' && item.docId
          ? 'Doc Link'
          : item.type === 'link'
            ? 'Link'
            : 'Note';

  head.appendChild(badge);

  if (item.type === 'person') {
    const editBtn = document.createElement('button');
    editBtn.className = 'board-item-edit';
    editBtn.title = 'Edit person';
    editBtn.textContent = '✎';
    head.appendChild(editBtn);
  }

  if (item.type === 'link' && !item.docId) {
    const editBtn = document.createElement('button');
    editBtn.className = 'board-item-edit board-link-edit';
    editBtn.title = 'Edit link';
    editBtn.textContent = '✎';
    head.appendChild(editBtn);
  }

  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'board-item-delete';
  deleteBtn.title = 'Delete';
  deleteBtn.textContent = '×';

  head.appendChild(deleteBtn);
  el.appendChild(head);

  if (item.type === 'document-view') {
    const body=document.createElement('div');body.className='board-document-view-body';
    const controls=document.createElement('div');controls.className='board-document-view-controls';
    const prev=document.createElement('button');prev.textContent='‹';prev.title='Previous page';const page=document.createElement('span');page.className='board-document-view-page';const next=document.createElement('button');next.textContent='›';next.title='Next page';
    const minus=document.createElement('button');minus.textContent='−';minus.title='Zoom out';const plus=document.createElement('button');plus.textContent='+';plus.title='Zoom in';const fit=document.createElement('button');fit.textContent='Fit';fit.title='Toggle fit width / fit page';const rotate=document.createElement('button');rotate.textContent='↻';rotate.title='Rotate';const edit=document.createElement('button');edit.textContent='Edit';edit.title='Edit NaviWriter title and description';const expand=document.createElement('button');expand.textContent='Open';expand.title='Open expanded viewer';controls.append(prev,page,next,minus,plus,fit,rotate,edit,expand);
    const preview=document.createElement('div');preview.className='board-document-view-preview';const canvas=document.createElement('canvas');canvas.className='board-document-view-canvas';preview.appendChild(canvas);
    const caption=document.createElement('div');caption.className='board-document-view-caption';const title=document.createElement('strong');title.textContent=item.title||'Attachment';const description=document.createElement('span');description.className='board-document-view-description';description.textContent=item.description||'';const meta=document.createElement('small');meta.textContent=item.originalName||item.mimeType||'Original file';caption.append(title,description,meta);body.append(controls,preview,caption);el.appendChild(body);
    let pdf=null,renderToken=0;const renderEmbedded=async()=>{const token=++renderToken;try{const asset=await NaviStorage.getAsset(item.attachmentId);if(!asset?.blob)return;const state=item.viewerState||(item.viewerState={page:1,zoom:1,fit:'width',rotation:0});const resolvedMime=String(asset.mimeType||asset.blob.type||item.mimeType||'').toLowerCase();const resolvedName=String(asset.originalName||item.originalName||'');body.classList.remove('is-pdf-viewer','is-image-viewer','is-document-viewer','is-generic-viewer');[prev,next,minus,plus,fit,rotate,edit,expand].forEach(btn=>{btn.hidden=false;btn.disabled=false;});fit.textContent='Fit';page.textContent='';if(resolvedMime==='application/pdf'||/\.pdf$/i.test(resolvedName)){pdf=pdf||await NaviPdfViewer.loadBlob(asset.blob);if(token!==renderToken)return;state.page=Math.max(1,Math.min(pdf.numPages,Number(state.page)||1));page.textContent=`${state.page}/${pdf.numPages}`;const aw=Math.max(180,item.width-28),ah=Math.max(120,item.height-106);let scale=null;if(state.fit==='page'){const pp=await pdf.getPage(state.page),base=pp.getViewport({scale:1,rotation:state.rotation||0});scale=Math.min(aw/base.width,ah/base.height);}else if(state.fit==='custom')scale=state.zoom||1;await NaviPdfViewer.renderPage(pdf,state.page,canvas,{width:aw,scale,rotation:state.rotation||0});preview.classList.add('is-pdf');body.classList.add('is-pdf-viewer');fit.textContent=state.fit==='page'?'Fit Width':'Fit Page';}else if(resolvedMime.startsWith('image/')||/\.(png|jpe?g|gif|webp|bmp|svg|avif)$/i.test(resolvedName)){const image=document.createElement('img');let imageUrl=await NaviAssets.objectUrl(asset.id);if(!imageUrl&&asset.blob){imageUrl=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(reader.error);reader.onload=()=>resolve(String(reader.result||''));reader.readAsDataURL(asset.blob);});}image.src=imageUrl;image.alt=asset.originalName||'Attachment image';image.decoding='async';image.draggable=false;image.onerror=()=>{preview.replaceChildren(Object.assign(document.createElement('div'),{className:'board-document-view-error',textContent:'Image preview unavailable'}));};image.style.transform=`scale(${state.zoom||1}) rotate(${state.rotation||0}deg)`;image.style.objectFit='contain';preview.replaceChildren(image);body.classList.add('is-image-viewer');page.textContent=`${Math.round((state.zoom||1)*100)}%`;prev.hidden=next.hidden=true;fit.textContent='Reset';}else{const extension=String(asset.originalName||item.originalName||'').split('.').pop().toLowerCase();let cached=String(item.previewHtml||'').trim();if(!cached&&item.docId){const owner=documentsCache.find(doc=>doc.id===item.docId);cached=String(owner?.referencePreviewHtml||'').trim();}if(!cached&&window.NaviOfficeParserAdapter?.parseFile&&['docx','odt','rtf','rtfd','epub'].includes(extension)){const sourceFile=new File([asset.blob],asset.originalName||`attachment.${extension}`,{type:asset.mimeType||asset.blob.type});const parsed=await window.NaviOfficeParserAdapter.parseFile(sourceFile,{fileType:extension,readOnly:true});cached=String(parsed?.sourceHtml||parsed?.html||'').trim();if(cached){item.previewHtml=cached;scheduleAutosave();}}if(cached){const shell=document.createElement('article');shell.className='board-attachment-document-paper';shell.innerHTML=cached;shell.querySelectorAll('script,iframe,object,embed,form,input,button,textarea,select').forEach(node=>node.remove());const zoom=Math.max(.5,Math.min(2.5,Number(state.zoom||1)));shell.style.zoom=String(zoom);shell.style.width=state.fit==='width'?`${100/zoom}%`:'760px';shell.style.minHeight=`${100/zoom}%`;preview.replaceChildren(shell);page.textContent=`${extension.toUpperCase()||'Document'} · ${Math.round(zoom*100)}%`;body.classList.add('is-document-viewer');prev.hidden=next.hidden=true;rotate.hidden=true;fit.textContent=state.fit==='width'?'Actual':'Reflow';}else{preview.textContent=(extension||'FILE').toUpperCase();page.textContent='File';body.classList.add('is-generic-viewer');prev.hidden=next.hidden=minus.hidden=plus.hidden=fit.hidden=rotate.hidden=true;} }}catch(error){preview.textContent='Preview unavailable';NaviDiagnostics?.report?.({severity:'warning',subsystem:'Board attachment viewer',message:error?.message||String(error),error,recovered:true});}};
    prev.onclick=e=>{e.stopPropagation();item.viewerState.page=Math.max(1,(item.viewerState.page||1)-1);renderEmbedded();scheduleAutosave();};next.onclick=e=>{e.stopPropagation();item.viewerState.page=(item.viewerState.page||1)+1;renderEmbedded();scheduleAutosave();};minus.onclick=e=>{e.stopPropagation();item.viewerState.fit='custom';item.viewerState.zoom=Math.max(.25,Math.round(((item.viewerState.zoom||1)-.1)*100)/100);renderEmbedded();scheduleAutosave();};plus.onclick=e=>{e.stopPropagation();item.viewerState.fit='custom';item.viewerState.zoom=Math.min(body.classList.contains('is-image-viewer')?32:4,Math.round(((item.viewerState.zoom||1)+(body.classList.contains('is-image-viewer')?.25:.1))*100)/100);renderEmbedded();scheduleAutosave();};fit.onclick=e=>{e.stopPropagation();if(body.classList.contains('is-image-viewer')){item.viewerState.fit='width';item.viewerState.zoom=1;renderEmbedded();scheduleAutosave();return;}const continuous=body.classList.contains('is-document-viewer');item.viewerState.fit=continuous?(item.viewerState.fit==='width'?'custom':'width'):(item.viewerState.fit==='page'?'width':'page');if(item.viewerState.fit!=='custom')item.viewerState.zoom=1;renderEmbedded();scheduleAutosave();};rotate.onclick=e=>{e.stopPropagation();item.viewerState.rotation=((item.viewerState.rotation||0)+90)%360;renderEmbedded();scheduleAutosave();};edit.onclick=e=>{e.stopPropagation();openAttachmentMetadataModal(item,{titleNode:title,descriptionNode:description});};expand.onclick=e=>{e.stopPropagation();openRetainedSourceViewer(item.attachmentId,null);};preview.addEventListener('wheel',e=>{if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();e.stopPropagation();const state=item.viewerState||(item.viewerState={page:1,zoom:1,fit:'width',rotation:0});state.fit='custom';const delta=Math.max(-.12,Math.min(.12,-e.deltaY*.0015));state.zoom=Math.max(.1,Math.min(16,Math.round(((state.zoom||1)*(1+delta))*100)/100));renderEmbedded();scheduleAutosave();},{passive:false});requestAnimationFrame(renderEmbedded);el._renderEmbeddedAttachment=renderEmbedded;
  } else if (item.type === 'image') {
    const body = document.createElement('div');
    body.className = 'board-image-body';

    const img = document.createElement('img');
    img.src = item.src || '';
    img.alt = item.title || 'Board image';

    body.appendChild(img);
    el.appendChild(body);
  } else if (item.type === 'link') {
    const body = document.createElement('div');
    body.className = 'board-link-body';

    const title = document.createElement('div');
    title.className = 'board-link-title';
    title.textContent = item.title || 'Untitled link';

    body.appendChild(title);

    if (item.docId) {
      const button = document.createElement('button');
      button.className = 'board-doc-link-btn';
      button.dataset.docId = item.docId;
      button.textContent = 'Open linked document';

      body.appendChild(button);
    } else {
      const url = normalizeExternalUrl(item.url || '');
      const host = getHostnameFromUrl(url);

      const preview = document.createElement('div');
      preview.className = 'board-link-preview';

      const domain = document.createElement('div');
      domain.className = 'board-link-domain';
      domain.textContent = host || 'External link';

      const link = document.createElement('a');
      link.className = 'board-link-url';
      link.href = url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = item.url || url;

      preview.appendChild(domain);
      preview.appendChild(link);
      body.appendChild(preview);
    }

    el.appendChild(body);
  } else if (item.type === 'audio') {
    const body=document.createElement('div');body.className='board-audio-body';
    const title=document.createElement('input');title.className='board-audio-title';title.value=item.title||'Audio memo';title.setAttribute('aria-label','Audio memo name');
    const player=document.createElement('audio');player.className='board-audio-player';player.controls=true;player.preload='metadata';player.setAttribute('aria-label',item.title||'Audio memo');
    const meta=document.createElement('div');meta.className='board-audio-meta';meta.textContent=formatAudioDuration(item.duration||0);
    const actions=document.createElement('div');actions.className='board-audio-actions';
    const rerecord=document.createElement('button');rerecord.type='button';rerecord.textContent='Rerecord';rerecord.title='Replace this recording';
    actions.append(rerecord,meta);body.append(title,player,actions);el.appendChild(body);
    title.addEventListener('pointerdown',event=>event.stopPropagation());title.addEventListener('click',event=>event.stopPropagation());title.addEventListener('change',()=>{item.title=title.value.trim()||'Audio memo';player.setAttribute('aria-label',item.title);scheduleAutosave();});
    player.addEventListener('pointerdown',event=>event.stopPropagation());player.addEventListener('click',event=>event.stopPropagation());
    rerecord.addEventListener('pointerdown',event=>event.stopPropagation());rerecord.onclick=async event=>{event.stopPropagation();const ok=await openConfirmModal({title:'Rerecord Audio Memo?',message:'The current recording will be replaced after the new recording is stopped.',confirmText:'Rerecord',cancelText:'Cancel',danger:false});if(ok)await recordBoardAudioMemo(item);};
    (async()=>{const asset=await NaviStorage.getAsset(item.assetId);if(!asset?.blob)return;player.src=await NaviAssets.objectUrl(asset.id);const duration=Number(item.duration||asset.duration||0);meta.textContent=formatAudioDuration(duration);})();
  } else if (item.type === 'person') {
    const body = document.createElement('div');
    body.className = 'board-person-body';

    const name = document.createElement('div');
    name.className = 'board-person-name';
    name.textContent = item.name || item.title || 'Unnamed Person';

    const role = document.createElement('div');
    role.className = 'board-person-role';
    role.textContent = item.role || 'Character';

    const notes = document.createElement('div');
    notes.className = 'board-person-notes';
    notes.textContent = item.notes || '';

    body.appendChild(name);
    body.appendChild(role);

    if (item.notes) {
      body.appendChild(notes);
    }

    el.appendChild(body);
  } else {
  const noteBody = document.createElement('div');

  noteBody.className = 'board-note-body';
  noteBody.contentEditable = 'true';
  noteBody.spellcheck = true;
  noteBody.textContent = item.text || '';

  el.appendChild(noteBody);
}

  const resizeHandle = document.createElement('div');
  resizeHandle.className = 'board-resize-handle';
  resizeHandle.title = 'Resize card';
  el.appendChild(resizeHandle);

  wireBoardItemEvents(el, item);

  return el;
}

function normalizeExternalUrl(url) {
  const value = String(url || '').trim();

  if (!value) return '#';

  if (
    value.startsWith('http://') ||
    value.startsWith('https://') ||
    value.startsWith('mailto:')
  ) {
    return value;
  }

  return `https://${value}`;
}

function getPersonBoardItems() {
  return currentBoardData.items.filter(item => {
    return item.type === 'person';
  });
}

async function chooseBoardPerson(title, subtitle, excludeIds = []) {
  const people =
    getPersonBoardItems()
      .filter(item => !excludeIds.includes(item.id));

  if (!people.length) {
    showAppNotice(
      'Add person cards first.',
      'No person cards'
    );
    return null;
  }

  const pickedId =
    await openChoiceModal({
      title,
      subtitle,
      options: people.map(item => ({
        value: item.id,
        icon: 'Person',
        title: item.name || item.title || 'Unnamed Person',
        desc: item.role || 'Character'
      }))
    });

  if (!pickedId) return null;

  return people.find(item => item.id === pickedId) || null;
}

async function createFamilyConnector() {
  const parentA =
    await chooseBoardPerson(
      'Family Link',
      'Choose the first parent / source person.'
    );

  if (!parentA) return;

  const parentB =
    await chooseBoardPerson(
      'Family Link',
      'Choose the second parent / source person.',
      [parentA.id]
    );

  if (!parentB) return;

  const child =
    await chooseBoardPerson(
      'Family Link',
      'Choose the child / target person.',
      [parentA.id, parentB.id]
    );

  if (!child) return;

  pushBoardUndoState();

  currentBoardData.connectors.push({
    id: crypto.randomUUID(),
    fromId: parentA.id,
    toId: child.id,
    label: 'Parent',
    type: 'elbow'
  });

  currentBoardData.connectors.push({
    id: crypto.randomUUID(),
    fromId: parentB.id,
    toId: child.id,
    label: 'Parent',
    type: 'elbow'
  });

  renderBoard();
  scheduleAutosave();

  NaviEditor.setSaveStatus('Family link added');
}

function connectBoardItems() {
  setBoardConnectMode(!boardConnectMode);
}

function setBoardConnectMode(enabled) {
  boardConnectMode = Boolean(enabled);
  boardConnectStartId = null;

  document.body.classList.toggle(
    'board-connect-mode',
    boardConnectMode
  );

  updateBoardConnectModeUI();
}

function updateBoardConnectModeUI() {
  if (els.connectBoardItemsBtn) {
    els.connectBoardItemsBtn.classList.toggle(
      'active',
      boardConnectMode
    );

    els.connectBoardItemsBtn.textContent =
      boardConnectMode
        ? 'Connecting...'
        : 'Connect';
  }

  if (!els.boardSurface) return;

  els.boardSurface
    .querySelectorAll('.board-item')
    .forEach(node => {
      node.classList.toggle(
        'connect-start',
        node.dataset.id === boardConnectStartId
      );
    });
}

async function handleBoardConnectionClick(itemId) {
  if (!boardConnectMode || !itemId) return;

  if (!boardConnectStartId) {
    boardConnectStartId = itemId;
    updateBoardConnectModeUI();
    return;
  }

  if (boardConnectStartId === itemId) {
    boardConnectStartId = null;
    updateBoardConnectModeUI();
    return;
  }

  const connection =
    await openBoardConnectionModal({fromId:boardConnectStartId,toId:itemId,label:'related',type:'straight',color:'#ff5f86',width:3,direction:'none'});

  if (!connection) {
    boardConnectStartId = null;
    updateBoardConnectModeUI();
    return;
  }

  pushBoardUndoState();

  currentBoardData.connectors.push({
    id: crypto.randomUUID(),
    fromId: connection.fromId || boardConnectStartId,
    toId: connection.toId || itemId,
    label: connection.label || '',
    type: ['straight', 'curve', 'elbow'].includes(connection.type) ? connection.type : 'straight',
    color: connection.color || '#ff5f86',
    width: Math.max(1, Math.min(8, Number(connection.width || 3))),
    direction: ['none','forward','backward','both'].includes(connection.direction) ? connection.direction : 'none'
  });

  boardConnectStartId = null;
  setBoardConnectMode(false);
  renderBoard();
  scheduleAutosave();
}

function escapeSvgText(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function getReadableBoardType(type) {
  if (type === 'audio') return 'Audio Memo';
  if (type === 'person') return 'Person';
  if (type === 'image') return 'Image';
  if (type === 'link') return 'Link';
  if (type === 'note') return 'Note';

  return String(type || 'Item')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase());
}

function getSvgCardText(item) {
  if (item.type === 'person') {
    return {
      title: item.name || item.title || 'Unnamed Person',
      meta: item.role || 'Character',
      body: item.notes || ''
    };
  }

  if (item.type === 'link') {
    return {
      title: item.title || 'Untitled Link',
      meta: item.docId ? 'Linked NaviWriter document' : getHostnameFromUrl(item.url || '') || 'External link',
      body: item.docId ? 'Open from NaviWriter board.' : item.url || ''
    };
  }

  if (item.type === 'image') {
    return {
      title: item.title || 'Image',
      meta: 'Board image',
      body: ''
    };
  }

  return {
    title: item.title || 'Note',
    meta: '',
    body: item.text || ''
  };
}

function getSvgExportItemLayout(item) {
  const width = Math.max(190, Number(item.width || 240));

  const text = getSvgCardText(item);

  const titleMaxChars = Math.max(18, Math.floor((width - 24) / 8));
  const bodyMaxChars = Math.max(24, Math.floor((width - 24) / 7));

  const titleLines = wrapSvgText(text.title, titleMaxChars, 3);
  const metaLines = wrapSvgText(text.meta, bodyMaxChars, 2);
  const bodyLines = wrapSvgText(text.body, bodyMaxChars, 6);

  const headerHeight = 28;
  const topPadding = 14;
  const titleLineHeight = 16;
  const metaLineHeight = 14;
  const bodyLineHeight = 14;
  const sectionGap = 7;
  const bottomPadding = 18;

  const neededHeight =
    headerHeight +
    topPadding +
    titleLines.length * titleLineHeight +
    (metaLines.length ? sectionGap + metaLines.length * metaLineHeight : 0) +
    (bodyLines.length ? sectionGap + bodyLines.length * bodyLineHeight : 0) +
    bottomPadding;

  const height = Math.max(
    Number(item.height || 140),
    neededHeight,
    item.type === 'person' ? 150 : 120
  );

  return {
    width,
    height,
    text,
    titleLines,
    metaLines,
    bodyLines
  };
}

function getBoardExportLayout(board) {
  const itemLayouts = new Map();

  board.items.forEach(item => {
    itemLayouts.set(item.id, getSvgExportItemLayout(item));
  });

  return itemLayouts;
}

function getBoardExportBounds(board, itemLayouts = null) {
  const padding = 80;

  if (!board.items.length) {
    return {
      minX: 0,
      minY: 0,
      maxX: 1200,
      maxY: 800,
      width: 1200,
      height: 800
    };
  }

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  board.items.forEach(item => {
    const layout =
      itemLayouts?.get(item.id) ||
      getSvgExportItemLayout(item);

    const x = Number(item.x || 0);
    const y = Number(item.y || 0);

    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x + layout.width);
    maxY = Math.max(maxY, y + layout.height);
  });

  minX -= padding;
  minY -= padding;
  maxX += padding;
  maxY += padding;

  return {
    minX,
    minY,
    maxX,
    maxY,
    width: maxX - minX,
    height: maxY - minY
  };
}

function wrapSvgText(text, maxChars = 28, maxLines = 4) {
  const words =
    String(text || '')
      .split(/\s+/)
      .filter(Boolean);

  const lines = [];
  let current = '';

  words.forEach(word => {
    const next =
      current ? `${current} ${word}` : word;

    if (next.length > maxChars && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  });

  if (current) {
    lines.push(current);
  }

  return lines.slice(0, maxLines);
}

function buildBoardExportSvg(title, board) {
  const safeTitle =
    escapeSvgText(title || 'Board');

  const itemLayouts =
    getBoardExportLayout(board);

  const bounds =
    getBoardExportBounds(board, itemLayouts);

  const offsetX =
    -bounds.minX;

  const offsetY =
    -bounds.minY;

  const itemMap =
    new Map();

  board.items.forEach(item => {
    itemMap.set(item.id, item);
  });

  const connectorsSvg =
    board.connectors.map(connector => {
      const from =
        itemMap.get(connector.fromId);

      const to =
        itemMap.get(connector.toId);

      if (!from || !to) return '';

      const fromLayout =
        itemLayouts.get(from.id) || getSvgExportItemLayout(from);

      const toLayout =
        itemLayouts.get(to.id) || getSvgExportItemLayout(to);

      const start = {
        x: Number(from.x || 0) + fromLayout.width / 2 + offsetX,
        y: Number(from.y || 0) + fromLayout.height / 2 + offsetY
      };

      const end = {
        x: Number(to.x || 0) + toLayout.width / 2 + offsetX,
        y: Number(to.y || 0) + toLayout.height / 2 + offsetY
      };

      const pathData =
        getConnectorPath(start, end, connector.type);

      const labelPosition =
        getConnectorLabelPosition(start, end);

      return `
        <path
          d="${escapeSvgText(pathData)}"
          fill="none"
          stroke="${escapeSvgText(getBoardConnectorColor(connector))}"
          stroke-width="3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />

        ${
          connector.label
            ? `
              <text
                x="${labelPosition.x}"
                y="${labelPosition.y}"
                text-anchor="middle"
                font-family="Arial, Helvetica, sans-serif"
                font-size="12"
                font-weight="800"
                fill="#ffffff"
                stroke="#111827"
                stroke-width="3"
                paint-order="stroke"
              >${escapeSvgText(connector.label)}</text>
            `
            : ''
        }
      `;
    }).join('\n');

  const itemsSvg =
    board.items.map(item => {
      const layout =
        itemLayouts.get(item.id) || getSvgExportItemLayout(item);

      const x =
        Number(item.x || 0) + offsetX;

      const y =
        Number(item.y || 0) + offsetY;

      const width =
        layout.width;

      const height =
        layout.height;

      const fill =
        item.color || '#fff8b5';

      const typeLabel =
        getReadableBoardType(item.type);

      let cursorY =
        y + 48;

      const titleSvg =
        layout.titleLines.map(line => {
          const output = `
            <text
              x="${x + 12}"
              y="${cursorY}"
              font-family="Arial, Helvetica, sans-serif"
              font-size="14"
              font-weight="900"
              fill="${item.type === 'person' ? '#831843' : '#0f172a'}"
            >${escapeSvgText(line)}</text>
          `;

          cursorY += 16;

          return output;
        }).join('');

      if (layout.metaLines.length) {
        cursorY += 5;
      }

      const metaSvg =
        layout.metaLines.map(line => {
          const output = `
            <text
              x="${x + 12}"
              y="${cursorY}"
              font-family="Arial, Helvetica, sans-serif"
              font-size="12"
              font-weight="700"
              fill="${item.type === 'person' ? '#9d174d' : '#475569'}"
            >${escapeSvgText(line)}</text>
          `;

          cursorY += 14;

          return output;
        }).join('');

      if (layout.bodyLines.length) {
        cursorY += 6;
      }

      const bodySvg =
        layout.bodyLines.map(line => {
          const output = `
            <text
              x="${x + 12}"
              y="${cursorY}"
              font-family="Arial, Helvetica, sans-serif"
              font-size="12"
              fill="#111827"
            >${escapeSvgText(line)}</text>
          `;

          cursorY += 14;

          return output;
        }).join('');

      return `
        <g>
          <rect
            x="${x}"
            y="${y}"
            width="${width}"
            height="${height}"
            rx="14"
            fill="${escapeSvgText(fill)}"
            stroke="rgba(0,0,0,0.18)"
          />

          <rect
            x="${x}"
            y="${y}"
            width="${width}"
            height="28"
            rx="14"
            fill="rgba(0,0,0,0.08)"
          />

          <text
            x="${x + 10}"
            y="${y + 19}"
            font-family="Arial, Helvetica, sans-serif"
            font-size="11"
            font-weight="900"
            fill="#111827"
          >${escapeSvgText(typeLabel)}</text>

          ${titleSvg}
          ${metaSvg}
          ${bodySvg}
        </g>
      `;
    }).join('\n');

  return `
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="${bounds.width}"
      height="${bounds.height}"
      viewBox="0 0 ${bounds.width} ${bounds.height}"
    >
      <title>${safeTitle}</title>

      <defs>
        <pattern id="dotGrid" width="22" height="22" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="1" fill="#334155"/>
        </pattern>
      </defs>

      <rect width="100%" height="100%" fill="#111827"/>
      <rect width="100%" height="100%" fill="url(#dotGrid)"/>

      ${connectorsSvg}
      ${itemsSvg}
    </svg>
  `.trim();
}

function getSvgSizeFromString(svgString) {
  const widthMatch =
    String(svgString || '').match(/\bwidth="([^"]+)"/i);

  const heightMatch =
    String(svgString || '').match(/\bheight="([^"]+)"/i);

  const width =
    widthMatch
      ? Number.parseFloat(widthMatch[1])
      : 0;

  const height =
    heightMatch
      ? Number.parseFloat(heightMatch[1])
      : 0;

  if (width > 0 && height > 0) {
    return {
      width,
      height
    };
  }

  const viewBoxMatch =
    String(svgString || '').match(/\bviewBox="([^"]+)"/i);

  if (viewBoxMatch) {
    const parts =
      viewBoxMatch[1]
        .split(/\s+/)
        .map(Number);

    if (parts.length === 4) {
      return {
        width: parts[2] || 1200,
        height: parts[3] || 800
      };
    }
  }

  return {
    width: 1200,
    height: 800
  };
}

function downloadBlobFile(fileName, blob) {
  const url =
    URL.createObjectURL(blob);

  const link =
    document.createElement('a');

  link.href = url;
  link.download = fileName;

  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 1000);
}

function convertSvgStringToPngBlob(svgString) {
  return new Promise((resolve, reject) => {
    const size =
      getSvgSizeFromString(svgString);

    const svgBlob =
      new Blob([svgString], {
        type: 'image/svg+xml;charset=utf-8'
      });

    const svgUrl =
      URL.createObjectURL(svgBlob);

    const image =
      new Image();

    image.onload = () => {
      try {
        /*
          Browser canvas limits exist, especially on school laptops.
          This keeps huge boards from creating a ridiculous PNG.
        */
        const maxDimension =
          6000;

        const scale =
          Math.min(
            1,
            maxDimension / Math.max(size.width, size.height)
          );

        const canvas =
          document.createElement('canvas');

        canvas.width =
          Math.max(1, Math.round(size.width * scale));

        canvas.height =
          Math.max(1, Math.round(size.height * scale));

        const context =
          canvas.getContext('2d');

        if (!context) {
          throw new Error('Could not create PNG canvas.');
        }

        /*
          Give transparent areas a dark board background,
          matching the exported SVG board style.
        */
        context.fillStyle = '#111827';
        context.fillRect(0, 0, canvas.width, canvas.height);

        context.drawImage(
          image,
          0,
          0,
          canvas.width,
          canvas.height
        );

        canvas.toBlob(blob => {
          URL.revokeObjectURL(svgUrl);

          if (!blob) {
            reject(new Error('PNG export failed.'));
            return;
          }

          resolve(blob);
        }, 'image/png');
      } catch (error) {
        URL.revokeObjectURL(svgUrl);
        reject(error);
      }
    };

    image.onerror = () => {
      URL.revokeObjectURL(svgUrl);
      reject(new Error('Could not render board SVG as PNG.'));
    };

    image.src =
      svgUrl;
  });
}

async function exportBoardPng() {
  try {
    const board =
      getBoardSnapshot();

    const title =
      NaviEditor.getEditorTitle
        ? NaviEditor.getEditorTitle()
        : 'Board';

    const svg =
      buildBoardExportSvg(title, board);

    const pngBlob =
      await convertSvgStringToPngBlob(svg);

    downloadBlobFile(
      `${safeFileName(title)}-board.png`,
      pngBlob
    );

    NaviEditor.setSaveStatus('Board PNG exported');
  } catch (error) {
    await showAppError(
      error?.message || String(error),
      'PNG export failed'
    );
  }
}

function exportBoardSvg() {
  const board =
    getBoardSnapshot();

  const title =
    NaviEditor.getEditorTitle
      ? NaviEditor.getEditorTitle()
      : 'Board';

  const svg =
    buildBoardExportSvg(title, board);

  downloadBoardFile(
    `${safeFileName(title)}-board.svg`,
    svg,
    'image/svg+xml'
  );
}

function getHostnameFromUrl(url) {
  try {
    return new URL(normalizeExternalUrl(url)).hostname;
  } catch {
    return '';
  }
}

function getBoardConnectorColor(connector) {
  if (connector?.color) return connector.color;
  const label =
    String(connector?.label || '').toLowerCase();

  if (
    label.includes('married') ||
    label.includes('spouse') ||
    label.includes('romance') ||
    label.includes('love')
  ) {
    return '#fb7185';
  }

  if (
    label.includes('parent') ||
    label.includes('child') ||
    label.includes('family') ||
    label.includes('mother') ||
    label.includes('father')
  ) {
    return '#22c55e';
  }

  if (
    label.includes('enemy') ||
    label.includes('rival') ||
    label.includes('betray') ||
    label.includes('conflict')
  ) {
    return '#ef4444';
  }

  if (
    label.includes('friend') ||
    label.includes('ally')
  ) {
    return '#38bdf8';
  }

  if (
    label.includes('mentor') ||
    label.includes('teacher')
  ) {
    return '#a78bfa';
  }

  return '#fb7185';
}

function buildBoardExportConnectorsSvg(board) {
  const itemMap = new Map();

  board.items.forEach(item => {
    itemMap.set(item.id, item);
  });

  const paths = board.connectors.map(connector => {
    const from = itemMap.get(connector.fromId);
    const to = itemMap.get(connector.toId);

    if (!from || !to) return '';

    const { start, end } = getBoardConnectorEndpoints(from, to);

    const pathData = getConnectorPath(start, end, connector.type);
    const labelPosition = getConnectorLabelPosition(start, end);
    const stroke = getBoardConnectorColor(connector);

    return `
      <path
        d="${escapeSvgText(pathData)}"
        fill="none"
        stroke="${escapeSvgText(stroke)}"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      />

      ${
        connector.label
          ? `
            <text
              class="board-connector-label"
              x="${labelPosition.x}"
              y="${labelPosition.y}"
              text-anchor="middle"
            >${escapeSvgText(connector.label)}</text>
          `
          : ''
      }
    `;
  }).join('\n');

  return `
    <svg
      class="export-board-connectors"
      xmlns="http://www.w3.org/2000/svg"
      width="5000"
      height="3500"
      viewBox="0 0 5000 3500"
    >
      ${paths}
    </svg>
  `;
}

function setupBoardPanning() {
  if (!els.boardSurface) return;

  let panning = false;
  let startX = 0;
  let startY = 0;
  let startScrollLeft = 0;
  let startScrollTop = 0;

  els.boardSurface.addEventListener('pointerdown', event => {
    if (event.target.closest('.board-item')) return;

    panning = true;

    startX = event.clientX;
    startY = event.clientY;
    startScrollLeft = els.boardSurface.scrollLeft;
    startScrollTop = els.boardSurface.scrollTop;

    els.boardSurface.classList.add('panning');
    els.boardSurface.setPointerCapture(event.pointerId);
  });

  els.boardSurface.addEventListener('pointermove', event => {
    if (!panning) return;

    const dx = event.clientX - startX;
    const dy = event.clientY - startY;

    els.boardSurface.scrollLeft = startScrollLeft - dx;
    els.boardSurface.scrollTop = startScrollTop - dy;
  });

  els.boardSurface.addEventListener('pointerup', event => {
    if (!panning) return;

    panning = false;

    els.boardSurface.classList.remove('panning');

    try {
      els.boardSurface.releasePointerCapture(event.pointerId);
    } catch {}
  });

  els.boardSurface.addEventListener('pointercancel', () => {
    panning = false;
    els.boardSurface.classList.remove('panning');
  });

  els.boardSurface.addEventListener('wheel', event => {
    if (event.target.closest('.board-document-view-preview,.board-image-body,.board-item-document-view')) return;
    if (!event.ctrlKey && !event.metaKey) return;

    event.preventDefault();

    if (event.deltaY < 0) {
      zoomBoardIn();
    } else {
      zoomBoardOut();
    }
  }, {
    passive: false
  });
  syncBoardModeBarState();
}



function updateBoardConnectorPositions() {
  const svg = document.getElementById('boardConnectorsLayer');

  if (!svg) return;

  svg.innerHTML = '';

  renderBoardConnectors(svg);
  renderBoardMinimap();
}


function wireBoardItemEvents(el, item) {
  const head = el.querySelector('.board-item-head');
  const deleteBtn = el.querySelector('.board-item-delete');
  const noteBody = el.querySelector('.board-note-body');
  const docLinkBtn = el.querySelector('.board-doc-link-btn');
  const resizeHandle = el.querySelector('.board-resize-handle');
  const editBtn = el.querySelector('.board-item-edit');

  function toggleOrSelectFromEvent(event) {
    selectBoardItem(item.id, Boolean(event.shiftKey));
  }

  el.addEventListener('pointerdown', event => {
    if (
      event.target.closest('.board-item-delete') ||
      event.target.closest('.board-note-body') ||
      event.target.closest('a') ||
      event.target.closest('button') ||
      event.target.closest('.board-resize-handle')
    ) {
      return;
    }

    if (boardConnectMode) {
      event.preventDefault();
      event.stopPropagation();
      handleBoardConnectionClick(item.id);
      return;
    }

    toggleOrSelectFromEvent(event);
  });

  if (noteBody) {
    noteBody.addEventListener('input', event => {
      item.text = event.currentTarget.innerText || '';
      scheduleAutosave();
    });

    noteBody.addEventListener('paste', event => {
      event.preventDefault();

      const text =
        event.clipboardData?.getData('text/plain') || '';

      document.execCommand('insertText', false, text);
    });
  }

  if (docLinkBtn) {
    docLinkBtn.onclick = event => {
      event.stopPropagation();

      const docId = docLinkBtn.dataset.docId;

      if (docId) {
        openDocument(docId);
      }
    };
  }

  if (deleteBtn) {
    deleteBtn.onclick = event => {
      event.stopPropagation();

      pushBoardUndoState();

      const idsToDelete =
        selectedBoardItemIds.has(item.id)
          ? Array.from(selectedBoardItemIds)
          : [item.id];

      currentBoardData.items =
        currentBoardData.items.filter(existing => {
          return !idsToDelete.includes(existing.id);
        });

      currentBoardData.connectors =
        currentBoardData.connectors.filter(connector => {
          return (
            !idsToDelete.includes(connector.fromId) &&
            !idsToDelete.includes(connector.toId)
          );
        });

      selectedBoardItemIds.clear();
      activeBoardItemId = null;

      renderBoard();
      scheduleAutosave();
    };
  }

  if (editBtn) {
    editBtn.onclick = event => {
      event.stopPropagation();

      if (item.type === 'person') {
        openBoardPersonModal(item);
        return;
      }

      if (item.type === 'link' && !item.docId) {
        openBoardLinkModal(item);
      }
    };
  }

  el.addEventListener('dblclick', event => {
    if (
      event.target.closest('.board-item-delete') ||
      event.target.closest('.board-resize-handle') ||
      event.target.closest('.board-note-body') ||
      event.target.closest('a') ||
      event.target.closest('button')
    ) {
      return;
    }

    if (item.type === 'person') {
      openBoardPersonModal(item);
      return;
    }

    if (item.type === 'link' && !item.docId) {
      openBoardLinkModal(item);
    }
  });

  if (resizeHandle) {
    let resizing = false;
    let startX = 0;
    let startY = 0;
    let startWidth = 0;
    let startHeight = 0;

    resizeHandle.addEventListener('pointerdown', event => {
      event.preventDefault();
      event.stopPropagation();

      pushBoardUndoState();

      resizing = true;
      startX = event.clientX;
      startY = event.clientY;
      startWidth = item.width || el.offsetWidth;
      startHeight = item.height || el.offsetHeight;

      resizeHandle.setPointerCapture(event.pointerId);
    });

    resizeHandle.addEventListener('pointermove', event => {
      if (!resizing) return;

      const dx = (event.clientX - startX) / boardZoom;
      const dy = (event.clientY - startY) / boardZoom;

      item.width = Math.max(150, Math.round(startWidth + dx));
      item.height = Math.max(90, Math.round(startHeight + dy));

      el.style.width = `${item.width}px`;
      el.style.height = `${item.height}px`;
      el.style.minHeight = `${item.height}px`;

      updateBoardConnectorPositions();
    });

    resizeHandle.addEventListener('pointerup', event => {
      if (!resizing) return;

      resizing = false;

      try {
        resizeHandle.releasePointerCapture(event.pointerId);
      } catch {}

      updateBoardConnectorPositions();
      el._renderEmbeddedAttachment?.();
      scheduleAutosave();
    });

    resizeHandle.addEventListener('pointercancel', () => {
      resizing = false;
    });
  }

  if (!head) return;

  let dragging = false;
  let startX = 0;
  let startY = 0;
  let draggedIds = [];
  let startPositions = new Map();

  head.addEventListener('pointerdown', event => {
    if (boardConnectMode) {
      event.preventDefault();
      event.stopPropagation();
      handleBoardConnectionClick(item.id);
      return;
    }

    if (event.target.closest('button')) return;

    event.preventDefault();
    event.stopPropagation();

    if (event.shiftKey) {
      selectBoardItem(item.id, true);
      return;
    }

    if (!selectedBoardItemIds.has(item.id)) {
      selectBoardItem(item.id, false);
    }

    pushBoardUndoState();

    dragging = true;
    startX = event.clientX;
    startY = event.clientY;

    draggedIds =
      selectedBoardItemIds.size
        ? Array.from(selectedBoardItemIds)
        : [item.id];

    startPositions = new Map();

    draggedIds.forEach(id => {
      const existing =
        currentBoardData.items.find(boardItem => {
          return boardItem.id === id;
        });

      if (existing) {
        startPositions.set(id, {
          x: Number(existing.x || 0),
          y: Number(existing.y || 0)
        });
      }
    });

    head.setPointerCapture(event.pointerId);
  });

  head.addEventListener('pointermove', event => {
    if (!dragging) return;

    const dx = (event.clientX - startX) / boardZoom;
    const dy = (event.clientY - startY) / boardZoom;

    draggedIds.forEach(id => {
      const existing =
        currentBoardData.items.find(boardItem => {
          return boardItem.id === id;
        });

      const start =
        startPositions.get(id);

      if (!existing || !start) return;

      existing.x = Math.max(0, start.x + dx);
      existing.y = Math.max(0, start.y + dy);

      const node =
        els.boardSurface?.querySelector(`.board-item[data-id="${CSS.escape(id)}"]`);

      if (node) {
        node.style.left = `${existing.x}px`;
        node.style.top = `${existing.y}px`;
      }
    });

    updateBoardConnectorPositions();
  });

  head.addEventListener('pointerup', event => {
    if (!dragging) return;

    dragging = false;

    try {
      head.releasePointerCapture(event.pointerId);
    } catch {}

    updateBoardConnectorPositions();
    scheduleAutosave();
  });

  head.addEventListener('pointercancel', () => {
    dragging = false;
  });
}

function setBoardZoom(nextZoom) {
  const previousZoom = boardZoom;

  boardZoom = Math.max(
    0.35,
    Math.min(2.5, Number(nextZoom) || 1)
  );

  if (!els.boardSurface) {
    renderBoard();
    return;
  }

  const centerX =
    els.boardSurface.scrollLeft +
    els.boardSurface.clientWidth / 2;

  const centerY =
    els.boardSurface.scrollTop +
    els.boardSurface.clientHeight / 2;

  const logicalCenterX = centerX / previousZoom;
  const logicalCenterY = centerY / previousZoom;

  renderBoard();

  els.boardSurface.scrollLeft =
    logicalCenterX * boardZoom -
    els.boardSurface.clientWidth / 2;

  els.boardSurface.scrollTop =
    logicalCenterY * boardZoom -
    els.boardSurface.clientHeight / 2;
}

function zoomBoardIn() {
  setBoardZoom(boardZoom + 0.1);
}

function zoomBoardOut() {
  setBoardZoom(boardZoom - 0.1);
}

function updateBoardZoomLabel() {
  if (!els.boardZoomLabel) return;

  els.boardZoomLabel.textContent =
    `${Math.round(boardZoom * 100)}%`;
}


function addBoardNote() {

  pushBoardUndoState();

const position = getBoardSpawnPosition();

  currentBoardData.items.push({
    id: crypto.randomUUID(),
    type: 'note',
    x: position.x,
y: position.y,
    width: 230,
    height: 150,
    text: 'New note...',
    color: '#fff8b5'
  });

  renderBoard();
  scheduleAutosave();
}

function openBoardPersonModal(existingItem = null) {
  if (!els.boardPersonModal) {
    addBoardPersonFallback();
    return;
  }

  editingBoardPersonId = existingItem?.id || null;

  if (els.boardPersonNameInput) {
    els.boardPersonNameInput.value =
      existingItem?.name || existingItem?.title || '';
    els.boardPersonNameInput.placeholder = 'New Person';
  }

  if (els.boardPersonRoleInput) {
    els.boardPersonRoleInput.value =
      existingItem?.role || '';
    els.boardPersonRoleInput.placeholder = 'Character';
  }

  if (els.boardPersonNotesInput) {
    els.boardPersonNotesInput.value =
      existingItem?.notes || '';
    els.boardPersonNotesInput.placeholder = 'Short notes...';
  }

  if (els.submitBoardPersonModalBtn) {
    els.submitBoardPersonModalBtn.textContent =
      editingBoardPersonId ? 'Save Person' : 'Add Person';
  }

  els.boardPersonModal.classList.remove('hidden');

  setTimeout(() => {
    els.boardPersonNameInput?.focus();
  }, 0);
}

function closeBoardPersonModal() {
  if (!els.boardPersonModal) return;

  els.boardPersonModal.classList.add('hidden');
  editingBoardPersonId = null;
}

function submitBoardPersonModal() {
  const name =
    els.boardPersonNameInput?.value.trim() || 'New Person';

  const role =
    els.boardPersonRoleInput?.value.trim() || 'Character';

  const notes =
    els.boardPersonNotesInput?.value.trim() || '';

  pushBoardUndoState();

  if (editingBoardPersonId) {
    const existing =
      currentBoardData.items.find(item => {
        return item.id === editingBoardPersonId;
      });

    if (existing) {
      existing.name = name;
      existing.title = name;
      existing.role = role;
      existing.notes = notes;
    }

    closeBoardPersonModal();
    renderBoard();
    scheduleAutosave();
    return;
  }

  const position =
    getBoardSpawnPosition();

  currentBoardData.items.push({
    id: crypto.randomUUID(),
    type: 'person',
    x: position.x,
    y: position.y,
    width: 240,
    height: 135,
    name,
    title: name,
    role,
    notes,
    color: '#fdf2f8'
  });

  closeBoardPersonModal();
  renderBoard();
  scheduleAutosave();
}

function addBoardPerson() {
  openBoardPersonModal();
}

/*
  Emergency fallback only if the modal is missing from HTML.
  Ideally this never runs.
*/
function addBoardPersonFallback() {
  const position = getBoardSpawnPosition();

  pushBoardUndoState();

  currentBoardData.items.push({
    id: crypto.randomUUID(),
    type: 'person',
    x: position.x,
    y: position.y,
    width: 240,
    height: 135,
    name: 'New Person',
    title: 'New Person',
    role: 'Character',
    notes: '',
    color: '#fdf2f8'
  });

  renderBoard();
  scheduleAutosave();
}

function getBoardSpawnPosition() {
  if (!els.boardSurface) {
    return {
      x: 80,
      y: 80
    };
  }

  return {
    x: els.boardSurface.scrollLeft + 80,
    y: els.boardSurface.scrollTop + 80
  };
}

async function createBoardAttachmentItem(file) {
  if (!file) return null;
  const isImage=String(file.type||'').startsWith('image/');
  const asset=await NaviAssets.addFile(file,{kind:isImage?'image':'original-file',sourceFormat:String(file.name.split('.').pop()||'').toLowerCase()});
  const position=getBoardSpawnPosition();
  return {id:crypto.randomUUID(),type:'document-view',x:position.x,y:position.y,width:isImage?340:520,height:isImage?320:430,title:file.name.replace(/\.[^.]+$/,'')||file.name||'Attachment',docId:'',attachmentId:asset.id,originalName:asset.originalName,mimeType:asset.mimeType,viewerState:{page:1,zoom:1,fit:'width',rotation:0},color:isImage?'#f8fafc':'#e0f2fe',zIndex:2,fontSize:13};
}
async function addBoardImageFile(file){if(!file)return;pushBoardUndoState();const item=await createBoardAttachmentItem(file);if(!item)return;currentBoardData.items.push(item);renderBoard();scheduleAutosave();}

async function addBoardLink() {
  const choice = await openChoiceModal({
    title: 'Add Board Link',
    subtitle: 'Choose what kind of link to add.',
    options: [
      {
        value: 'external',
        icon: '🔗',
        title: 'External Link',
        desc: 'Link to a website or external resource.'
      },
      {
        value: 'doc',
        icon: '📄',
        title: 'Document Link',
        desc: 'Link to another NaviWriter document.'
      }
    ]
  });

  if (choice === 'doc') {
    await addBoardDocLink();
    return;
  }

  if (choice === 'external') {
    await addBoardExternalLink();
  }
}

async function addBoardExternalLink() {
  const result =
    await openBoardLinkModal();

  if (!result) return;

  pushBoardUndoState();

  const position =
    getBoardSpawnPosition();

  currentBoardData.items.push({
    id: crypto.randomUUID(),
    type: 'link',
    x: position.x,
    y: position.y,
    width: 280,
    height: 120,
    title: result.title,
    url: result.url,
    color: '#e0f2fe'
  });

  renderBoard();
  scheduleAutosave();
}

async function addBoardDocLink() {
  const docs =
    await NaviStorage.getAllDocuments();

  if (!docs.length) {
    showAppNotice(
      'No documents found to link.',
      'No documents'
    );
    return;
  }

  const choices =
    docs
      .slice(0, 60)
      .map(doc => ({
        value: doc.id,
        icon: '📄',
        title: doc.title || 'Untitled Document',
        desc: doc.docType || 'document'
      }));

  const pickedDocId =
    await openChoiceModal({
      title: 'Choose Linked Document',
      subtitle: 'Select a document to link from the board.',
      options: choices
    });

  if (!pickedDocId) return;

  const doc =
    docs.find(item => item.id === pickedDocId);

  if (!doc) return;

  pushBoardUndoState();

  const position =
    getBoardSpawnPosition();

  currentBoardData.items.push({
    id: crypto.randomUUID(),
    type: 'link',
    x: position.x,
    y: position.y,
    width: 280,
    height: 120,
    title: doc.title || 'Untitled Document',
    url: '',
    docId: doc.id,
    color: '#dcfce7'
  });

  renderBoard();
  scheduleAutosave();
}

async function openDocument(id) {
  const requestId = ++openDocumentRequestId;
  leaveReferenceDocumentWorkspace();
  try{document.getElementById('retainedSourceModal')?.classList.add('hidden');}catch{}

  isLoadingDocument = true;
  window.NaviWriterIsLoadingDocument = true;
  clearTimeout(autosaveTimer);

  try {
    const doc = await NaviStorage.getDocument(id);

    if (requestId !== openDocumentRequestId) {
      return;
    }

    if (!doc) {
      console.warn('Document not found:', id);
      return;
    }

    currentDocumentId = doc.id;


    currentBoardData = normalizeBoardData(doc.board);
    activeBoardItemId = null;
    selectedBoardItemIds.clear();
    boardUndoStack = [];
    boardRedoStack = [];

    setBoardMode(false);
    applyDocumentTypePreset(doc);
    
    if (!isResearchDocument(doc)) {
  setSourcesMode(false);
}

    /*
      This must replace editor content, not append.
      Tiptap adapter now also clears ghost DOM.
    */
    NaviEditor.loadDocumentIntoEditor(doc);
    await window.NaviWritingHistory?.setDocument?.(doc, NaviEditor.getEditorText());

    if (requestId !== openDocumentRequestId) {
      return;
    }

    const stats = NaviEditor.getEditorStats();
    sessionStartWords = stats.words;

    if (els.folderInput) {
      els.folderInput.value = doc.folder || '';
    }

    if (els.tagsInput) {
      els.tagsInput.value = Array.isArray(doc.tags) ? doc.tags.join(', ') : '';
      loadTagChips(doc.tags || []);
    }

   if (els.docStatusSelect) {
  els.docStatusSelect.value =
    doc.status !== undefined && doc.status !== null
      ? doc.status
      : getDefaultStatusForDoc(doc);
}

if (els.docPovInput) {
  els.docPovInput.value = doc.pov || '';
}

if (els.docLocationInput) {
  els.docLocationInput.value = doc.location || '';
}

if (els.docTimelineInput) {
  els.docTimelineInput.value = doc.timeline || '';
}

if (els.docCharactersInput) {
  els.docCharactersInput.value = doc.characters || '';
}

if (els.docSummaryInput) {
  els.docSummaryInput.value = doc.summary || '';
}
    
    showOtherCustomMetadataFields = false;
    
    await renderCustomMetadataValues(doc);
    
    await loadDocumentGoal(doc.id);

    if (requestId !== openDocumentRequestId) {
      return;
    }

    updateInspector();
    await NaviStorage.saveSetting('lastDocumentId', currentDocumentId);

    renderDocumentList(documentsCache);
    scheduleSelectedDocumentVisibility(doc.id);
    
    await renderRelationshipPanel(doc.id);
    if(doc.docType==='reference-view'&&doc.sourceAttachmentId){await showReferenceDocumentWorkspace(doc,{preserveMode:true});if(requestId!==openDocumentRequestId)return;}
    
    showResolvedInlineComments = false;
    
    await renderInlineCommentsPanel(doc);
    
    renderProjectCommentsPanel();
    
    
    if (document.body.classList.contains('sources-mode-active')) {
  await renderSourcesPanel();
}
    
    await restoreSplitForDocument(doc);
    
  } finally {
    setTimeout(() => {
      if (requestId === openDocumentRequestId) {
        isLoadingDocument = false;
        window.NaviWriterIsLoadingDocument = false;
      }
    }, 350);
  }
  
  requestAnimationFrame(() => {
  safelyRenderDocumentMap();
});
}

async function getCollections() {
  const saved =
    await NaviStorage.getSetting(COLLECTIONS_KEY, []);

  return Array.isArray(saved)
    ? saved.map(collection => ({
        id: collection.id || crypto.randomUUID(),
        name: collection.name || 'Untitled Collection',
        documentIds: Array.isArray(collection.documentIds)
          ? collection.documentIds
          : [],
        createdAt: collection.createdAt || Date.now(),
        updatedAt: collection.updatedAt || Date.now()
      }))
    : [];
}

async function saveCollections(collections) {
  await NaviStorage.saveSetting(
    COLLECTIONS_KEY,
    Array.isArray(collections) ? collections : []
  );
}

function getCollectionById(collections, id) {
  return collections.find(collection => {
    return collection.id === id;
  }) || null;
}

function getCollectionsForDocument(collections, docId) {
  if (!docId) return [];

  return collections.filter(collection => {
    return collection.documentIds.includes(docId);
  });
}

function getDocumentByIdFromCache(docId) {
  return documentsCache.find(doc => doc.id === docId) || null;
}

function getCollectionDocCountLabel(collection) {
  const count =
    collection?.documentIds?.length || 0;

  return `${count} ${count === 1 ? 'doc' : 'docs'}`;
}

async function handleNewDocument() {
  const doc = await NaviStorage.createDocument('Untitled Document');

  await loadDocuments();
  await openDocument(doc.id);

  NaviEditor.focusEditor();
}

async function createCollection() {
  const name =
    await openTextInputModal({
      title: 'New Collection',
      message: 'Name this document group.',
      label: 'Collection name',
      defaultValue: 'New Collection',
      placeholder: 'Act 1 Rewrite',
      submitText: 'Create Collection'
    });

  if (!name || !name.trim()) return;

  const collections =
    await getCollections();

  const collection = {
    id: crypto.randomUUID(),
    name: name.trim(),
    documentIds: [],
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  collections.push(collection);

  activeCollectionId = collection.id;

 await saveCollections(collections);
collectionsCache = await getCollections();
await renderCollectionsModal();
renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Collection created');
}

async function renameActiveCollection() {
  const collections =
    await getCollections();

  const collection =
    getCollectionById(collections, activeCollectionId);

  if (!collection) {
    showAppNotice(
      'Choose a collection first.',
      'No collection selected'
    );
    return;
  }

  const name =
    await openTextInputModal({
      title: 'Rename Collection',
      message: 'Update this collection name.',
      label: 'Collection name',
      defaultValue: collection.name || 'Untitled Collection',
      placeholder: 'Act 1 Rewrite',
      submitText: 'Rename'
    });

  if (!name || !name.trim()) return;

  collection.name = name.trim();
  collection.updatedAt = Date.now();

  await saveCollections(collections);
collectionsCache = await getCollections();
await renderCollectionsModal();
renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Collection renamed');
}

async function deleteActiveCollection() {
  const collections =
    await getCollections();

  const collection =
    getCollectionById(collections, activeCollectionId);

  if (!collection) {
    showAppNotice(
      'Choose a collection first.',
      'No collection selected'
    );
    return;
  }

  const ok =
    await openConfirmModal({
      title: 'Delete Collection',
      message: `Delete "${collection.name || 'Untitled Collection'}"? Documents inside it will not be deleted.`,
      confirmText: 'Delete',
      cancelText: 'Cancel',
      danger: true
    });

  if (!ok) return;

  const nextCollections =
    collections.filter(item => item.id !== collection.id);

  activeCollectionId =
    nextCollections[0]?.id || null;

  await saveCollections(nextCollections);
  collectionsCache = await getCollections();
  await renderCollectionsModal();
  renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Collection deleted');
}

async function addCurrentDocumentToCollection() {
  if (!currentDocumentId) {
    showAppNotice(
      'Open a document first.',
      'No document selected'
    );
    return;
  }

  const collections =
    await getCollections();

  if (!collections.length) {
    showAppNotice(
      'Create a collection first.',
      'No collections yet'
    );
    return;
  }

  let collection =
    getCollectionById(collections, activeCollectionId);

  if (!collection) {
    collection = collections[0];
    activeCollectionId = collection.id;
  }

 if (!collection.documentIds.includes(currentDocumentId)) {
  collection.documentIds.push(currentDocumentId);
  collection.updatedAt = Date.now();

  await saveCollections(collections);
  collectionsCache = await getCollections();
}

await renderCollectionsModal();
renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Document added to collection');
}

async function removeDocumentFromActiveCollection(docId) {
  const collections =
    await getCollections();

  const collection =
    getCollectionById(collections, activeCollectionId);

  if (!collection) return;

  collection.documentIds =
    collection.documentIds.filter(id => id !== docId);

  collection.updatedAt = Date.now();

 await saveCollections(collections);
collectionsCache = await getCollections();
await renderCollectionsModal();
renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Document removed from collection');
}

async function renderCollectionsModal() {
  if (
    !els.collectionsList ||
    !els.collectionDocsList
  ) {
    return;
  }

  const collections =
    await getCollections();

  if (
    activeCollectionId &&
    !collections.some(collection => collection.id === activeCollectionId)
  ) {
    activeCollectionId = null;
  }

  if (!activeCollectionId && collections.length) {
    activeCollectionId = collections[0].id;
  }

  renderCollectionsList(collections);
  renderCollectionDetail(collections);
}

function renderCollectionsList(collections) {
  if (!els.collectionsList) return;

  if (!collections.length) {
    els.collectionsList.innerHTML =
      '<div class="empty-note">No collections yet.</div>';
    return;
  }

  els.collectionsList.innerHTML = '';

  collections
    .slice()
    .sort((a, b) => {
      return String(a.name || '').localeCompare(String(b.name || ''));
    })
    .forEach(collection => {
      const button =
        document.createElement('button');

      button.type = 'button';

      button.className = [
        'collection-list-item',
        collection.id === activeCollectionId ? 'active' : ''
      ].filter(Boolean).join(' ');

      button.innerHTML = `
        <span class="collection-list-name">${escapeHtml(collection.name)}</span>
        <span class="collection-list-meta">${escapeHtml(getCollectionDocCountLabel(collection))}</span>
      `;

      button.onclick = () => {
        activeCollectionId = collection.id;
        renderCollectionsModal();
      };

      els.collectionsList.appendChild(button);
    });
}

function renderCollectionDetail(collections) {
  if (
    !els.collectionDetailTitle ||
    !els.collectionDetailMeta ||
    !els.collectionDocsList
  ) {
    return;
  }

  const collection =
    getCollectionById(collections, activeCollectionId);

  if (!collection) {
    els.collectionDetailTitle.textContent = 'Choose a collection';
    els.collectionDetailMeta.textContent =
      'Create or select a collection to view its documents.';
    els.collectionDocsList.innerHTML =
      '<div class="empty-note">No collection selected.</div>';
    return;
  }

  els.collectionDetailTitle.textContent =
    collection.name || 'Untitled Collection';

  els.collectionDetailMeta.textContent =
    getCollectionDocCountLabel(collection);

  const docIds =
    Array.isArray(collection.documentIds)
      ? collection.documentIds
      : [];

  if (!docIds.length) {
    els.collectionDocsList.innerHTML =
      '<div class="empty-note">No documents in this collection yet.</div>';
    return;
  }

  els.collectionDocsList.innerHTML = '';

  docIds.forEach(docId => {
    const doc =
      getDocumentByIdFromCache(docId);

    const row =
      document.createElement('div');

    row.className =
      doc
        ? 'collection-doc-row'
        : 'collection-doc-row missing';

    if (!doc) {
      row.innerHTML = `
  <div>
    <strong>Missing document</strong>
    <div class="collection-doc-meta">${escapeHtml(docId)}</div>
  </div>

  <button class="collection-remove-doc-btn" type="button">Remove</button>
`;
    } else {
      const status =
        typeof getDocStatusForDisplay === 'function'
          ? getDocStatusForDisplay(doc)
          : doc.status || '';

      const statusDot =
        typeof renderSidebarStatusDot === 'function'
          ? renderSidebarStatusDot(status)
          : '';

      row.innerHTML = `
  <div class="collection-doc-main">
    <strong>
      <span class="collection-doc-icon">${escapeHtml(getDocumentTypeIcon(doc))}</span>
      <span>${escapeHtml(doc.title || 'Untitled Document')}</span>
      ${statusDot}
    </strong>

    <div class="collection-doc-meta">
      ${escapeHtml(getReadableDocType(doc))} • ${Number(doc.wordCount || 0).toLocaleString()} words
      ${
        doc.folder
          ? ` • 📁 ${escapeHtml(doc.folder)}`
          : ''
      }
    </div>
  </div>

  <div class="collection-doc-actions">
    <button class="collection-open-doc-btn" type="button">Open</button>
    <button class="collection-remove-doc-btn" type="button">Remove</button>
  </div>
`;

      row.querySelector('.collection-open-doc-btn')?.addEventListener('click', async event => {
        event.stopPropagation();

        closeCollectionsModal();
        await openDocument(doc.id);
      });
    }

    row.querySelector('.collection-remove-doc-btn')?.addEventListener('click', async event => {
      event.stopPropagation();
      await removeDocumentFromActiveCollection(docId);
    });

    els.collectionDocsList.appendChild(row);
  });
}

async function openCollectionsModal() {
  if (!els.collectionsModal) return;

  els.collectionsModal.classList.remove('hidden');

  await renderCollectionsModal();
}

function closeCollectionsModal() {
  if (!els.collectionsModal) return;

  els.collectionsModal.classList.add('hidden');
}

async function handleRenameDocument() {
  if (!currentDocumentId) return;

  const current =
    await NaviStorage.getDocument(currentDocumentId);

  if (!current) return;

  const nextTitle =
    await openTextInputModal({
      title: 'Rename Document',
      message: 'Update this document title.',
      label: 'Document title',
      defaultValue: current.title || 'Untitled Document',
      placeholder: 'Untitled Document',
      submitText: 'Rename'
    });

  if (!nextTitle || !nextTitle.trim()) return;

  const renamed =
    await NaviStorage.renameDocument(
      currentDocumentId,
      nextTitle.trim()
    );

  await loadDocuments();
  await openDocument(renamed.id);
}

function formatSnapshotDate(timestamp) {
  if (!timestamp) return 'Unknown date';

  return new Date(timestamp).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

async function handleTakeSnapshot() {
  if (!currentDocumentId) {
    showAppNotice('Open a document first.');
    return;
  }

  await saveCurrentDocument({ manual: true });

  const current = await NaviStorage.getDocument(currentDocumentId);

  if (!current) {
    showAppNotice('Could not find the current document.');
    return;
  }

  const defaultName = `Snapshot - ${formatSnapshotDate(Date.now())}`;

  const name = prompt('Snapshot name:', defaultName);

  if (name === null) return;

  await NaviStorage.createSnapshot(
    current,
    name.trim() || defaultName
  );

  NaviEditor.setSaveStatus('Snapshot saved');
}

async function openSnapshotHistory() {
  if (!currentDocumentId) {
    showAppNotice('Open a document first.');
    return;
  }

  await saveCurrentDocument({ manual: true });

  if (els.snapshotModal) {
    els.snapshotModal.classList.remove('hidden');
  }

  await renderSnapshotList();
}

function openTextInputModal({
  title = 'Input',
  message = '',
  label = 'Value',
  defaultValue = '',
  placeholder = '',
  submitText = 'Continue'
} = {}) {
  if (
    !els.textInputModal ||
    !els.textInputModalField
  ) {
    return Promise.resolve(prompt(message || title, defaultValue));
  }

  if (els.textInputModalTitle) {
    els.textInputModalTitle.textContent = title;
  }

  if (els.textInputModalMessage) {
    els.textInputModalMessage.textContent = message;
  }

  if (els.textInputModalLabel) {
    els.textInputModalLabel.textContent = label;
  }

  if (els.submitTextInputModalBtn) {
    els.submitTextInputModalBtn.textContent = submitText;
  }

  els.textInputModalField.value = defaultValue || '';
  els.textInputModalField.placeholder = placeholder || '';

  els.textInputModal.classList.remove('hidden');

  setTimeout(() => {
    els.textInputModalField.focus();
    els.textInputModalField.select();
  }, 0);

  return new Promise(resolve => {
    pendingTextInputResolve = resolve;
  });
}

function resolveTextInputModal(value = null) {
  if (els.textInputModal) {
    els.textInputModal.classList.add('hidden');
  }

  const resolver = pendingTextInputResolve;

  pendingTextInputResolve = null;

  if (resolver) {
    resolver(value);
  }
}

function submitTextInputModal() {
  const value =
    els.textInputModalField?.value || '';

  resolveTextInputModal(value);
}

function closeTextInputModal() {
  resolveTextInputModal(null);
}

function openConfirmModal({
  title = 'Confirm',
  message = 'Are you sure?',
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  danger = false
} = {}) {
  if (!els.confirmModal) {
    return Promise.resolve(confirm(message));
  }

  if (els.confirmModalTitle) {
    els.confirmModalTitle.textContent = title;
  }

  if (els.confirmModalMessage) {
    els.confirmModalMessage.textContent = message;
  }

  if (els.submitConfirmModalBtn) {
    els.submitConfirmModalBtn.textContent = confirmText;
    els.submitConfirmModalBtn.classList.toggle(
      'danger-confirm',
      Boolean(danger)
    );
  }

  if (els.cancelConfirmModalBtn) {
    els.cancelConfirmModalBtn.textContent = cancelText;
  }

  els.confirmModal.classList.remove('hidden');

  return new Promise(resolve => {
    pendingConfirmResolve = resolve;
  });
}

function resolveConfirmModal(value = false) {
  if (els.confirmModal) {
    els.confirmModal.classList.add('hidden');
  }

  const resolver = pendingConfirmResolve;

  pendingConfirmResolve = null;

  if (resolver) {
    resolver(Boolean(value));
  }
}

function closeConfirmModal() {
  resolveConfirmModal(false);
}

function closeSnapshotHistory() {
  if (!els.snapshotModal) return;

  els.snapshotModal.classList.add('hidden');
}

async function renderSnapshotList() {
  if (!els.snapshotList || !currentDocumentId) return;

  const snapshots =
    await NaviStorage.getDocumentSnapshots(currentDocumentId);

  if (!snapshots.length) {
    els.snapshotList.innerHTML =
      '<div class="empty-note">No snapshots yet.</div>';
    return;
  }

  els.snapshotList.innerHTML = '';

  snapshots.forEach(snapshot => {
    const row = document.createElement('div');
    row.className = 'snapshot-row';

    const words = Number(snapshot.wordCount || 0);

    row.innerHTML = `
      <div class="snapshot-row-main">
        <div class="snapshot-row-title">${escapeHtml(snapshot.name || 'Untitled Snapshot')}</div>
        <div class="snapshot-row-meta">
          ${escapeHtml(snapshot.title || 'Untitled Document')} •
          ${words} ${words === 1 ? 'word' : 'words'} •
          ${formatSnapshotDate(snapshot.createdAt)}
        </div>
      </div>

      <div class="snapshot-row-actions">
        <button class="restoreSnapshotBtn">Restore</button>
        <button class="deleteSnapshotBtn danger">Delete</button>
      </div>
    `;

    row.querySelector('.restoreSnapshotBtn').onclick = () => {
      restoreSnapshot(snapshot.id);
    };

    row.querySelector('.deleteSnapshotBtn').onclick = async () => {
      const ok = confirm(`Delete snapshot "${snapshot.name || 'Untitled Snapshot'}"?`);

      if (!ok) return;

      await NaviStorage.deleteSnapshot(snapshot.id);
      await renderSnapshotList();
      NaviEditor.setSaveStatus('Snapshot deleted');
    };

    els.snapshotList.appendChild(row);
  });
}

async function restoreSnapshot(snapshotId) {
  if (!currentDocumentId) return;

  const snapshot = await NaviStorage.getSnapshot(snapshotId);

  if (!snapshot) {
    showAppNotice('Snapshot not found.');
    return;
  }

  const ok = confirm(
    `Restore "${snapshot.name || 'Untitled Snapshot'}"?\n\n` +
    'This will replace the current document content. A safety snapshot will be created first.'
  );

  if (!ok) return;

  await saveCurrentDocument({ manual: true });

  const current = await NaviStorage.getDocument(currentDocumentId);

  if (!current) {
    showAppNotice('Current document not found.');
    return;
  }

  await NaviStorage.createSnapshot(
    current,
    `Before restore - ${formatSnapshotDate(Date.now())}`
  );

  const restored = {
    ...current,
    title: snapshot.title || current.title,
    content: snapshot.content || '<p></p>',
    plainText: snapshot.plainText || '',
    wordCount: snapshot.wordCount || 0,
    charCount: snapshot.charCount || 0,
    board: snapshot.board || null,
    docType: snapshot.docType || current.docType || 'standard',
    folder: snapshot.folder || current.folder || '',
    tags: Array.isArray(snapshot.tags) ? snapshot.tags : current.tags || []
  };

  const saved = await NaviStorage.saveDocument(restored);

  documentsCache = documentsCache.map(doc => {
    return doc.id === saved.id ? saved : doc;
  });

  closeSnapshotHistory();

  await loadDocuments();
  await openDocument(saved.id);

  NaviEditor.setSaveStatus('Snapshot restored');
}

async function handleDuplicateDocument() {
  if (!currentDocumentId) return;

  const duplicate = await NaviStorage.duplicateDocument(currentDocumentId);

  await loadDocuments();
  await openDocument(duplicate.id);
}

function getDescendantDocumentIds(rootId, documents) {
  const ids = [];
  const queue = [rootId];

  while (queue.length) {
    const currentId = queue.shift();

    const children = documents.filter(doc => {
      return doc.parentId === currentId;
    });

    children.forEach(child => {
      ids.push(child.id);
      queue.push(child.id);
    });
  }

  return ids;
}

function getDocumentTitleById(id, documents) {
  const doc = documents.find(item => item.id === id);

  return doc?.title || 'Untitled Document';
}

function getNextDocumentAfterDelete(deletedIds, documents) {
  return documents.find(doc => {
    return !deletedIds.includes(doc.id);
  }) || null;
}

async function deleteOrphanDocuments() {
  const docs = await NaviStorage.getAllDocuments();

  const ids = new Set(
    docs.map(doc => doc.id)
  );

  const orphans = docs.filter(doc => {
    return doc.parentId && !ids.has(doc.parentId);
  });

  if (!orphans.length) {
    showAppNotice('No orphan documents found.');
    return;
  }

  const ok = confirm(
    `Delete ${orphans.length} orphan document${orphans.length === 1 ? '' : 's'}?`
  );

  if (!ok) return;

  for (const doc of orphans) {
    await safelyDeleteSnapshotsForDocument(doc.id);
await NaviStorage.deleteDocument(doc.id);
  }

  await loadDocuments();

  if (currentDocumentId) {
    const currentStillExists =
      documentsCache.some(doc => doc.id === currentDocumentId);

    if (!currentStillExists && documentsCache.length) {
      await openDocument(documentsCache[0].id);
    }
  }

  renderDocumentList(documentsCache);
  NaviEditor.setSaveStatus('Orphans cleaned');
}

async function safelyDeleteSnapshotsForDocument(documentId) {
  if (!NaviStorage.deleteSnapshotsForDocument) {
    return;
  }

  try {
    await NaviStorage.deleteSnapshotsForDocument(documentId);
  } catch (error) {
    console.warn(
      'Could not delete snapshots for document. Continuing with document delete.',
      documentId,
      error
    );
  }
}

async function handleDeleteDocument() {
  if (!currentDocumentId) return;

  const allDocs = await NaviStorage.getAllDocuments();

  const current = allDocs.find(doc => {
    return doc.id === currentDocumentId;
  });

  if (!current) return;

  const descendantIds = getDescendantDocumentIds(
    currentDocumentId,
    allDocs
  );

  const idsToDelete = [
    currentDocumentId,
    ...descendantIds
  ];

  const childCount = descendantIds.length;

  const message =
    childCount > 0
      ? `Delete "${current.title || 'Untitled Document'}" and ${childCount} subdocument${childCount === 1 ? '' : 's'}?`
      : `Delete "${current.title || 'Untitled Document'}"?`;

  const ok = await openConfirmModal({
  title: 'Delete Document',
  message,
  confirmText: 'Delete',
  cancelText: 'Cancel',
  danger: true
});

if (!ok) return;

  clearTimeout(autosaveTimer);
  isLoadingDocument = true;

  try {
    for (const id of idsToDelete) {
      await safelyDeleteSnapshotsForDocument(id);
      await NaviStorage.deleteDocument(id);
    }

    currentDocumentId = null;

    await loadDocuments();

    const nextDoc = documentsCache.find(doc => {
      return !idsToDelete.includes(doc.id);
    }) || null;

    if (nextDoc) {
      await openDocument(nextDoc.id);
      return;
    }

    applyDocumentTypePreset(null);

    currentBoardData = normalizeBoardData(null);
    activeBoardItemId = null;
    selectedBoardItemIds.clear();
    boardUndoStack = [];
    boardRedoStack = [];

    NaviEditor.loadDocumentIntoEditor(null);
    NaviEditor.setSaveStatus('Ready');

    if (els.folderInput) {
      els.folderInput.value = '';
    }

    if (els.tagsInput) {
      els.tagsInput.value = '';
    }

    updateInspector();
    renderDocumentList(documentsCache);
  } catch (error) {
    console.error('Delete failed:', error);
    await showAppError(
  error?.message || String(error),
  'Delete Failed.'
);
    NaviEditor.setSaveStatus('Delete error');
  } finally {
    setTimeout(() => {
      isLoadingDocument = false;
    }, 350);
  }
}

async function saveCurrentDocument({ manual = false } = {}) {
  const documentIdAtSaveStart = currentDocumentId;

  if (!documentIdAtSaveStart) return;
  if (isLoadingDocument) return;
  if (window.NaviWriterIsLoadingDocument) return;
  if (isSaving) return;
  

  const editorSnapshot = NaviEditor.getEditorSnapshot();
  const boardSnapshot = getBoardSnapshot();

  isSaving = true;

  try {
    NaviEditor.setSaveStatus('Saving...');

    const current = await NaviStorage.getDocument(documentIdAtSaveStart);

    if (!current) {
      throw new Error('No current document found.');
    }

    if (currentDocumentId !== documentIdAtSaveStart) {
      return;
    }

    const updatedDoc = {
      ...current,
      ...editorSnapshot,
      board: boardSnapshot
    };

    const saved = await NaviStorage.saveDocument(updatedDoc);

    documentsCache = documentsCache.map(doc => {
      return doc.id === saved.id ? saved : doc;
    });

    documentsCache.sort((a, b) => {
      return (b.updatedAt || 0) - (a.updatedAt || 0);
    });

    renderDocumentList(documentsCache);
    updateInspector();

    NaviEditor.setSaveStatus(manual ? 'Saved manually' : 'Saved');
  } catch (error) {
    console.error(error);
    NaviEditor.setSaveStatus('Save error');
  } finally {
    isSaving = false;
  }
}



function scheduleAutosave() {
  if (isLoadingDocument || window.NaviWriterIsLoadingDocument) {
    return;
  }

  if (!currentDocumentId) {
    return;
  }

  clearTimeout(autosaveTimer);

  autosaveTimer = setTimeout(() => {
    saveCurrentDocument();
  }, AUTOSAVE_DELAY);
}

function extractSmartSearchFilters(query = '') {
  const filters = [];
  let freeText =
    String(query || '');

  const pattern =
    /\b(title|text|summary|tag|status|type|folder|collection|pov|location|character|characters):("[^"]+"|\S+)/gi;

  freeText =
    freeText.replace(pattern, (match, key, rawValue) => {
      const value =
        String(rawValue || '')
          .replace(/^"|"$/g, '')
          .trim();

      filters.push({
        key: key.toLowerCase(),
        value: value.toLowerCase()
      });

      return ' ';
    });

  return {
    filters,
    freeText: freeText.trim().toLowerCase()
  };
}

function documentMatchesSmartFilter(doc, filter) {
  const value =
    filter.value;

  if (!value) return true;

  if (filter.key === 'title') {
    return String(doc.title || '').toLowerCase().includes(value);
  }

  if (filter.key === 'text') {
    return [doc.plainText, doc.text, doc.content]
      .filter(Boolean).join(' ').replace(/<[^>]+>/g, ' ')
      .toLowerCase().includes(value);
  }

  if (filter.key === 'summary') {
    return String(doc.summary || '').toLowerCase().includes(value);
  }

  if (filter.key === 'tag') {
    return Array.isArray(doc.tags) &&
      doc.tags.some(tag => {
        return String(tag || '').toLowerCase().includes(value);
      });
  }

  if (filter.key === 'status') {
    const status =
      normalizeStatus(getDocStatusForDisplay(doc)).toLowerCase();

    if (value === 'none') {
      return !status;
    }

    return status.includes(value);
  }

  if (filter.key === 'type') {
    return String(doc.docType || 'general')
      .toLowerCase()
      .includes(value);
  }

  if (filter.key === 'folder') {
    return getDocumentFolderName(doc)
      .toLowerCase()
      .includes(value);
  }

  if (filter.key === 'collection') {
    const collections =
      getCollectionsForDocument(collectionsCache, doc.id);

    return collections.some(collection => {
      return String(collection.name || '')
        .toLowerCase()
        .includes(value);
    });
  }

  if (filter.key === 'pov') {
    return String(doc.pov || '')
      .toLowerCase()
      .includes(value);
  }

  if (filter.key === 'location') {
    return String(doc.location || '')
      .toLowerCase()
      .includes(value);
  }

  if (
    filter.key === 'character' ||
    filter.key === 'characters'
  ) {
    return String(doc.characters || '')
      .toLowerCase()
      .includes(value);
  }

  return true;
}

function documentMatchesFreeSearch(doc, freeText = '') {
  const query = String(freeText || '').trim().toLowerCase();
  if (!query) return true;
  const title = String(doc.title || '').toLowerCase();
  return title.includes(query);
}
function filterDocumentsBySmartSearch(documents = [], query = '') {
  const { filters, freeText } =
    extractSmartSearchFilters(query);

  return documents.filter(doc => {
    const passesFilters =
      filters.every(filter => {
        return documentMatchesSmartFilter(doc, filter);
      });

    if (!passesFilters) return false;

    return documentMatchesFreeSearch(doc, freeText);
  });
}

async function handleSearch() {
  const query =
    els.docSearch?.value || '';

  collectionsCache =
    await getCollections();

  renderDocumentList(documentsCache);
}

async function openInitialDocument() {
  await loadDocuments();

  const lastId = await NaviStorage.getSetting('lastDocumentId', null);

  if (lastId) {
    const lastDoc = await NaviStorage.getDocument(lastId);

    if (lastDoc) {
      await openDocument(lastId);
      return;
    }
  }

  if (documentsCache.length) {
    await openDocument(documentsCache[0].id);
    return;
  }

  await handleNewDocument();
}

function repairChapterOpeningDropCap(text) {
  const paragraphs = String(text || '')
    .split(/\n{2,}/)
    .map(paragraph => paragraph.trim())
    .filter(Boolean);

  if (paragraphs.length < 2) {
    return String(text || '');
  }

  const titleIndex = paragraphs.findIndex(paragraph =>
    /^Chapter\s+\d+\s*:/i.test(paragraph)
  );

  const bodyIndex =
    titleIndex >= 0
      ? titleIndex + 1
      : 0;

  if (!paragraphs[bodyIndex]) {
    return paragraphs.join('\n\n');
  }

  let firstBodyParagraph = paragraphs[bodyIndex];

  // Fix obvious missing opening letters.
  firstBodyParagraph = inferMissingOpeningLetter(firstBodyParagraph);

  // Fix missing spaces like "Ilooked", "Asky", etc.
  firstBodyParagraph = repairOneLetterWordSpacing(firstBodyParagraph);

  paragraphs[bodyIndex] = firstBodyParagraph;

  return paragraphs.join('\n\n');
}

function inferMissingOpeningLetter(paragraph) {
  const text = String(paragraph || '').trim();
  const lower = text.toLowerCase();

  if (!text) return text;

  // Already starts normally.
  if (/^[A-Z0-9“"‘]/.test(text)) {
    return text;
  }

  // Known broken drop-cap openings.
  if (lower.startsWith('nd ')) {
    return 'A' + text;
  }

  if (lower.startsWith('he ')) {
    return 'T' + text;
  }

  // First-person narration openings.
  const firstPersonVerbs = [
    'sat ',
    'stood ',
    'looked ',
    'wanted ',
    'felt ',
    'was ',
    'had ',
    'could ',
    'took ',
    'opened ',
    'closed ',
    'tried ',
    'hugged ',
    'walked ',
    'stared ',
    'watched ',
    'remembered ',
    'thought ',
    'heard ',
    'saw ',
    'knew ',
    'frowned ',
    'smiled ',
    'sighed ',
    'held ',
    'ran ',
    'rushed ',
    'cried ',
    'asked '
  ];

  if (firstPersonVerbs.some(prefix => lower.startsWith(prefix))) {
    return 'I ' + text;
  }

  return text;
}

function repairOneLetterWordSpacing(text) {
  let result = String(text || '');

  // Ilooked -> I looked
  result = result.replace(
    /\bI(?=(looked|wanted|sat|stood|felt|was|had|could|took|opened|closed|tried|hugged|walked|stared|watched|remembered|thought|heard|saw|knew|frowned|smiled|sighed|held|ran|rushed|cried|asked)\b)/gi,
    'I '
  );

  // Achoir -> A choir
  result = result.replace(
    /\bA(?=(choir|voice|man|woman|child|tree|family|nation|sound|few|little|large|small|person|place|moment|day|night|room|house|bench|letter|storm|sky|road|grave|coffin|flower)\b)/gi,
    'A '
  );

  return result;
}

function repairFirstWordWithDropCap(letter, paragraph) {
  const cleanLetter = String(letter || '').trim();
  const cleanParagraph = String(paragraph || '').trim();

  if (!cleanLetter || !cleanParagraph) {
    return cleanParagraph;
  }

  const combined = cleanLetter + cleanParagraph;

  /**
   * One-letter word case:
   *
   * "I" + "looked away..." should become:
   * "I looked away..."
   *
   * "A" + "choir sang..." should become:
   * "A choir sang..."
   *
   * Without this, we get:
   * "Ilooked..."
   * "Achoir..."
   */
  if (
    cleanLetter === 'I' ||
    cleanLetter === 'A'
  ) {
    return cleanLetter + ' ' + cleanParagraph;
  }

  /**
   * Normal word case:
   *
   * "A" + "nd the choir..." should become:
   * "And the choir..."
   *
   * "T" + "he trees..." should become:
   * "The trees..."
   */
  return combined;
}

async function handleExportDocument(format = 'navidoc') {
  if (!currentDocumentId) return;

  await saveCurrentDocument({ manual: true });

  const doc = await NaviStorage.getDocument(currentDocumentId);

  const isManuscriptExport =
  doc.docType === 'manuscript';

if (isManuscriptExport && window.NaviExport?.exportManuscriptHtml && format === 'html') {
  const orderedDocs = await getOrderedManuscriptDocs(doc);
  NaviExport.exportManuscriptHtml(doc, orderedDocs);
  return;
}

if (isManuscriptExport && window.NaviExport?.exportManuscriptTxt && format === 'txt') {
  const orderedDocs = await getOrderedManuscriptDocs(doc);
  NaviExport.exportManuscriptTxt(doc, orderedDocs);
  return;
}

if (isManuscriptExport && window.NaviExport?.exportManuscriptMarkdown && format === 'markdown') {
  const orderedDocs = await getOrderedManuscriptDocs(doc);
  NaviExport.exportManuscriptMarkdown(doc, orderedDocs);
  return;
}

  if (!doc) return;

  if (!window.NaviExport) {
    showAppNotice('Export tools are not loaded.');
    return;
  }

  if (format === 'html') {
    NaviExport.exportHtml(doc);
    return;
  }

  if (format === 'txt') {
    NaviExport.exportTxt(doc);
    return;
  }
  
  if (format === 'docx') {
  NaviExport.exportDocx(doc);
  return;
}

  if (format === 'markdown') {
    NaviExport.exportMarkdown(doc);
    return;
  }

  if (format === 'print') {
    NaviExport.printDocument();
    return;
  }

  NaviExport.exportNaviDoc(doc);
}



function handleImportClick() {
  if (els.importFile) {
    els.importFile.click();
  }
}

async function handleImportFile(event) {
  const file = event.target.files?.[0];

  if (!file) return;

  if (/\.pdf$/i.test(file.name)) {
    try { await window.NaviPdfImporter?.importFile?.(file); }
    finally { event.target.value=''; }
    return;
  }
  if (/\.(navidoc|nwproj|naviwriter-backup)$/i.test(file.name)) {
    try {
      const expected=/\.navidoc$/i.test(file.name)?'navidoc':(/\.nwproj$/i.test(file.name)?'nwproj':'naviwriter-backup');
      const parsed=await NaviExport.decodeNativeFile(file,expected);
      if(parsed.kind==='backup'){
        const approved=confirm('Restore this complete workspace backup? This replaces all current NaviWriter workspace data.');
        if(!approved)return;
        await NaviExport.restoreWorkspacePayload(parsed.payload);
        showAppNotice('Workspace restored. NaviWriter will reload.'); location.reload();
      }else if(parsed.kind==='project'){
        const approved=confirm('Open this NaviWriter project? This replaces the currently loaded project documents, assets, and project settings.');
        if(!approved)return;
        const result=await NaviExport.importProjectPayload(parsed.payload);
        await loadDocuments();if(result.documents?.[0])await openDocument(result.documents[0].id);
        currentProjectFileHandle=null;currentProjectFileName=file.name;setProjectFileStatus(`Project opened: ${file.name}`);
      }else{
        const imported=NaviExport.parseImportedDocument(JSON.stringify(parsed.payload),file.name);
        if(imported.__navidocAssets?.length&&window.NaviAssets?.importPortable)await NaviAssets.importPortable(imported.__navidocAssets);
        delete imported.__navidocAssets;delete imported.__navidocVersion;
        imported.id=crypto.randomUUID?crypto.randomUUID():`doc-${Date.now()}-${Math.random()}`;
        const saved=await NaviStorage.saveDocument(imported);await loadDocuments();await openDocument(saved.id);
      }
    }catch(error){await showAppError(error?.message||String(error),'Native NaviWriter file could not be opened.');}
    finally{event.target.value='';}
    return;
  }

  if (/\.docx$/i.test(file.name)) {
  try {
    NaviEditor.setSaveStatus('Importing DOCX...');
    await importDocxFile(file);
    NaviEditor.setSaveStatus('DOCX imported');
  } catch (error) {
    console.error('DOCX import failed:', error);
    await showAppError(
  error?.message || String(error),
  'DOCX import failed.'
);
    NaviEditor.setSaveStatus('DOCX import error');
  } finally {
    event.target.value = '';
  }

  return;
}

  try {
    const text = await file.text();

    let imported;

    if (window.NaviExport?.parseImportedDocument) {
      imported = NaviExport.parseImportedDocument(text, file.name);
    } else {
      imported = JSON.parse(text);
    }

    if (imported.__navidocAssets?.length && window.NaviAssets?.importPortable) { await NaviAssets.importPortable(imported.__navidocAssets); }

    const title =
      imported.title ||
      file.name.replace(/\.[^.]+$/, '') ||
      'Imported Document';

    const importedResult = await saveImportedHtmlStructure({
      title,
      html: imported.content || '<p></p>',
      fileName: file.name,
      singleDocType: imported.docType || 'general'
    });

    await loadDocuments();
    await openDocument(importedResult.root.id);

    if (importedResult.sectionCount) {
      NaviEditor.setSaveStatus(`Imported ${importedResult.sectionCount} parts`);
    }
  } catch (error) {
    console.error(error);
    showAppNotice('Import failed. This file may not be a valid NaviDoc.');
  } finally {
    event.target.value = '';
  }
}

function setFocusMode(enabled) {
  if (enabled && document.body.dataset.layoutMode !== 'desktop') setResponsivePage('editor');
  const isFocus = Boolean(enabled);

  document.body.classList.toggle('focus-mode', isFocus);

  try {
    localStorage.setItem('naviwriter-focus-mode', isFocus ? 'true' : 'false');
  } catch {}

  document.dispatchEvent(new CustomEvent('naviwriter:focus-change',{detail:isFocus}));
  if (els.focusBtn) {
    els.focusBtn.classList.toggle('active', isFocus);
    els.focusBtn.textContent = isFocus ? 'Focused' : 'Focus';
  }

  return isFocus;
}

function exitFocusMode() {
  setFocusMode(false);
}

async function loadDocumentGoal() {
  temporaryGoalSession = await NaviStorage.getSetting('temporaryGoalSession', null);
  currentGoal = Number(temporaryGoalSession?.targetWords || 0);
  if (els.goalInput) els.goalInput.value = currentGoal || '';
  const targetId = temporaryGoalSession?.targetDocumentId || currentDocumentId;
  const scope = temporaryGoalSession?.scope || 'current';
  const resolution = await resolveDocumentScope(targetId, scope);
  populateScopeSelect(els.temporaryGoalScopeSelect, resolution, scope);
}


async function saveDocumentGoal() {
  if (!currentDocumentId) return;
  const targetWords = Math.max(0, Number(els.goalInput?.value || 0));
  const scope = els.temporaryGoalScopeSelect?.value || 'current';
  if (!targetWords) { await clearTemporaryGoal(); return; }
  const stats = await getScopeStatistics(currentDocumentId, scope);
  temporaryGoalSession = { targetDocumentId:currentDocumentId, scope:stats.scope, targetWords, startingWords:stats.words, startedAt:new Date().toISOString() };
  currentGoal = targetWords;
  await NaviStorage.saveSetting('temporaryGoalSession', temporaryGoalSession);
  await updateInspector();
}


async function updateInspector() {
  if (!window.NaviEditor) return;
  const requested=els.statsScopeSelect?.value || activeStatsScope || 'current';
  const stats=await getScopeStatistics(currentDocumentId, requested);
  activeStatsScope=stats.scope;
  populateScopeSelect(els.statsScopeSelect, stats, requested);
  if (els.statWords) els.statWords.textContent=stats.words;
  if (els.statChars) els.statChars.textContent=stats.chars;
  if (els.statParagraphs) els.statParagraphs.textContent=stats.paragraphs;
  if (els.statHeadings) els.statHeadings.textContent=stats.headings;
  if (els.statReadingTime) els.statReadingTime.textContent=`${stats.readingMinutes} min`;
  if (els.statSessionWords) els.statSessionWords.textContent=`+${Math.max(0,stats.words-sessionStartWords)}`;
  if (els.statsScopeSummary) els.statsScopeSummary.textContent=`${stats.label}: ${stats.docs.length} included document${stats.docs.length===1?'':'s'}.`;
  const analysisResolution=await resolveDocumentScope(currentDocumentId,els.analysisScopeSelect?.value||stats.scope);
  populateScopeSelect(els.analysisScopeSelect,analysisResolution,els.analysisScopeSelect?.value||stats.scope);
  await updateGoalDisplay(); renderOutline(); renderRecentDocuments(); updateRepeatedTextAnalysis(); renderHeadingCounts(); updateLongGoalDisplay();
}


async function updateRepeatedTextAnalysis() {
  if (!els.topWordsList || !els.topPhrasesList) return;

  const text = await getAnalysisText();

  renderAnalysisList(
    els.topWordsList,
    getFrequentWordsFromText(text, 10)
  );

  renderAnalysisList(
    els.topPhrasesList,
    getFrequentPhrasesFromText(text, 3, 10)
  );
}

async function updateGoalDisplay() {
  if (!els.goalProgress || !els.goalBarFill) return;
  if (!temporaryGoalSession?.targetWords) { els.goalProgress.textContent='No goal set.'; els.goalBarFill.style.width='0%'; return; }
  const stats = await getScopeStatistics(temporaryGoalSession.targetDocumentId, temporaryGoalSession.scope);
  if (!stats.valid) { els.goalProgress.textContent=stats.warning; els.goalProgress.dataset.goalState='invalid'; return; }
  const added=Math.max(0,stats.words-Number(temporaryGoalSession.startingWords||0));
  const target=Number(temporaryGoalSession.targetWords||0); const percent=Math.min(100,Math.round((added/target)*100));
  els.goalProgress.textContent=`${added.toLocaleString()} / ${target.toLocaleString()} words added · ${stats.label}`;
  els.goalBarFill.style.width=`${percent}%`;
  if (els.temporaryGoalScopeSummary) els.temporaryGoalScopeSummary.textContent=`Tracking ${stats.docs.length} included document${stats.docs.length===1?'':'s'}.`;
}


function renderOutline() {
  if (!els.outlineList) return;

  const outline = NaviEditor.buildOutline();

  if (!outline.length) {
    els.outlineList.innerHTML = '<div class="empty-note">No headings yet.</div>';
    return;
  }

  els.outlineList.innerHTML = '';

  outline.forEach(item => {
    const button = document.createElement('button');

    button.className = `outline-item level-${item.level}`;
    button.innerHTML = `<span class="outline-level-badge">${item.level.toUpperCase()}</span><span class="outline-item-text">${escapeHtml(item.text)}</span>`;

    button.onclick = () => {
      NaviEditor.scrollToHeading(item.id);
    };

    els.outlineList.appendChild(button);
  });
}

function renderRecentDocuments() {
  if (!els.recentDocsList) return;

  const recent = documentsCache
    .filter(doc => doc.id !== currentDocumentId)
    .slice(0, 5);

  if (!recent.length) {
    els.recentDocsList.innerHTML = '<div class="empty-note">No other recent documents.</div>';
    return;
  }

  els.recentDocsList.innerHTML = '';

  recent.forEach(doc => {
    const card = document.createElement('button');

    card.className = 'recent-doc-item';

    card.innerHTML = `
      <div>${escapeHtml(doc.title || 'Untitled Document')}</div>
      <div class="recent-doc-meta">${Number(doc.wordCount || 0)} words • ${formatDate(doc.updatedAt)}</div>
    `;

    card.onclick = () => {
      openDocument(doc.id);
    };

    els.recentDocsList.appendChild(card);
  });
}

function getDefaultCustomMetadataValueForType(type = 'text') {
  if (type === 'checkbox') {
    return false;
  }

  return '';
}

function normalizeCustomMetadataValue(field, value) {
  const type =
    normalizeCustomMetadataFieldType(field?.type || 'text');

  if (type === 'checkbox') {
    return Boolean(value);
  }

  if (type === 'number') {
    if (value === '' || value === null || value === undefined) {
      return '';
    }

    const number =
      Number(value);

    return Number.isFinite(number)
      ? number
      : '';
  }

  if (type === 'dropdown') {
    const cleanValue =
      String(value || '');

    const options =
      Array.isArray(field.options)
        ? field.options
        : [];

    return options.includes(cleanValue)
      ? cleanValue
      : '';
  }

  if (type === 'date') {
    return String(value || '').slice(0, 10);
  }

  return String(value || '');
}

function customMetadataValueHasContent(field, value) {
  if (!field) {
    return false;
  }

  const cleanValue =
    normalizeCustomMetadataValue(
      field,
      value
    );

  if (field.type === 'checkbox') {
    return cleanValue === true;
  }

  return !(
    cleanValue === '' ||
    cleanValue === null ||
    cleanValue === undefined
  );
}

function splitCustomMetadataFieldsForSidebar(fields = [], values = {}) {
  fields = fields.filter(field => field.visible !== false).sort((a,b)=>Number(a.sortOrder||0)-Number(b.sortOrder||0));
  const relevantFields = [];
  const otherFields = [];

  fields.forEach(field => {
    const hasValue =
      customMetadataValueHasContent(
        field,
        values[field.id]
      );

    if (hasValue) {
      relevantFields.push(field);
    } else {
      otherFields.push(field);
    }
  });

  return {
    relevantFields,
    otherFields
  };
}

function getDocumentCustomMetadata(doc) {
  if (
    doc &&
    doc.customMetadata &&
    typeof doc.customMetadata === 'object' &&
    !Array.isArray(doc.customMetadata)
  ) {
    return {
      ...doc.customMetadata
    };
  }

  return {};
}

function renderCustomMetadataValueControl(field, currentValue) {
  if (field.type === 'longText') {
    return `
      <textarea
        class="custom-metadata-value-input"
        data-custom-metadata-value-field="${escapeHtml(field.id)}"
        rows="3"
        placeholder="${escapeHtml(field.name)}"
      >${escapeHtml(currentValue)}</textarea>
    `;
  }

  if (field.type === 'dropdown') {
    const optionsHtml =
      (field.options || [])
        .map(option => {
          return `
            <option
              value="${escapeHtml(option)}"
              ${option === currentValue ? 'selected' : ''}
            >
              ${escapeHtml(option)}
            </option>
          `;
        })
        .join('');

    return `
      <select
        class="custom-metadata-value-input"
        data-custom-metadata-value-field="${escapeHtml(field.id)}"
      >
        <option value="">—</option>
        ${optionsHtml}
      </select>
    `;
  }

  if (field.type === 'checkbox') {
    return `
      <input
        type="checkbox"
        class="custom-metadata-value-input"
        data-custom-metadata-value-field="${escapeHtml(field.id)}"
        ${currentValue ? 'checked' : ''}
      />
    `;
  }

  if (field.type === 'number') {
    return `
      <input
        type="number"
        class="custom-metadata-value-input"
        data-custom-metadata-value-field="${escapeHtml(field.id)}"
        value="${escapeHtml(currentValue)}"
        placeholder="0"
      />
    `;
  }

  if (field.type === 'date') {
    return `
      <input
        type="date"
        class="custom-metadata-value-input"
        data-custom-metadata-value-field="${escapeHtml(field.id)}"
        value="${escapeHtml(currentValue)}"
      />
    `;
  }

  return `
    <input
      type="text"
      class="custom-metadata-value-input"
      data-custom-metadata-value-field="${escapeHtml(field.id)}"
      value="${escapeHtml(currentValue)}"
      placeholder="${escapeHtml(field.name)}"
    />
  `;
}

function createCustomMetadataValueRow(field, values = {}) {
  const row =
    document.createElement('label');

  row.className =
    `custom-metadata-value-row field-type-${field.type}`;

  row.dataset.customMetadataFieldId =
    field.id;

  const currentValue =
    values[field.id] !== undefined
      ? normalizeCustomMetadataValue(
          field,
          values[field.id]
        )
      : getDefaultCustomMetadataValueForType(field.type);

  row.innerHTML = `
    <span class="custom-metadata-value-label">
      <strong>${escapeHtml(field.name)}</strong>
      <small>${escapeHtml(getCustomMetadataFieldTypeLabel(field.type))}</small>
    </span>

    <span class="custom-metadata-value-control">
      ${renderCustomMetadataValueControl(field, currentValue)}
    </span>
  `;

  return row;
}

async function renderCustomMetadataValues(doc = null) {
  if (!els.customMetadataValuesList) {
    return;
  }

  const fields =
    await getCustomMetadataFields();

  if (!fields.length) {
    els.customMetadataValuesList.innerHTML =
      '<div class="empty-note">No custom fields yet. Create one with Fields.</div>';
    return;
  }

  const currentDoc =
    doc ||
    (
      currentDocumentId
        ? await NaviStorage.getDocument(currentDocumentId)
        : null
    );

  const values =
    getDocumentCustomMetadata(currentDoc);

  const {
    relevantFields,
    otherFields
  } =
    splitCustomMetadataFieldsForSidebar(
      fields,
      values
    );

  els.customMetadataValuesList.innerHTML = '';

  const relevantWrap =
    document.createElement('div');

  relevantWrap.className =
    'custom-metadata-relevant-fields';

  if (relevantFields.length) {
    relevantFields.forEach(field => {
      relevantWrap.appendChild(
        createCustomMetadataValueRow(
          field,
          values
        )
      );
    });
  } else {
    relevantWrap.innerHTML =
      '<div class="empty-note">No filled custom fields for this document yet.</div>';
  }

  els.customMetadataValuesList.appendChild(
    relevantWrap
  );

  if (otherFields.length) {
    const otherWrap =
      document.createElement('div');

    otherWrap.className =
      'custom-metadata-other-fields';

    const toggle =
      document.createElement('button');

    toggle.type =
      'button';

    toggle.className =
      'custom-metadata-other-toggle';

    toggle.innerHTML = `
      <span>
        ${showOtherCustomMetadataFields ? '▾' : '▸'}
        Other Fields
      </span>

      <small>
        ${otherFields.length}
      </small>
    `;

    toggle.addEventListener('click', () => {
      showOtherCustomMetadataFields =
        !showOtherCustomMetadataFields;

      renderCustomMetadataValues(
        currentDoc
      );
    });

    otherWrap.appendChild(toggle);

    if (showOtherCustomMetadataFields) {
      const otherList =
        document.createElement('div');

      otherList.className =
        'custom-metadata-other-list';

      otherFields.forEach(field => {
        otherList.appendChild(
          createCustomMetadataValueRow(
            field,
            values
          )
        );
      });

      otherWrap.appendChild(otherList);
    }

    els.customMetadataValuesList.appendChild(
      otherWrap
    );
  }

  wireCustomMetadataValueInputs();
}

function wireCustomMetadataValueInputs() {
  if (!els.customMetadataValuesList) {
    return;
  }

  els.customMetadataValuesList
    .querySelectorAll('[data-custom-metadata-value-field]')
    .forEach(input => {
      const eventName =
        input.type === 'checkbox'
          ? 'change'
          : 'input';

      input.addEventListener(
        eventName,
        scheduleCustomMetadataValueSave
      );

      /*
        Dropdowns should save immediately on change.
      */
      if (input.tagName === 'SELECT') {
        input.addEventListener(
          'change',
          scheduleCustomMetadataValueSave
        );
      }
    });
}

let customMetadataSaveTimer = null;

function scheduleCustomMetadataValueSave() {
  clearTimeout(customMetadataSaveTimer);

  customMetadataSaveTimer =
    setTimeout(() => {
      saveCurrentCustomMetadataValues();
    }, 350);
}

async function saveCurrentCustomMetadataValues() {
  if (!currentDocumentId || !els.customMetadataValuesList) {
    return;
  }

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) {
    return;
  }

  const fields =
    await getCustomMetadataFields();

  const fieldMap =
    new Map(
      fields.map(field => {
        return [field.id, field];
      })
    );

  const nextValues =
    getDocumentCustomMetadata(doc);

  els.customMetadataValuesList
    .querySelectorAll('[data-custom-metadata-value-field]')
    .forEach(input => {
      const fieldId =
        input.dataset.customMetadataValueField;

      const field =
        fieldMap.get(fieldId);

      if (!field) {
        return;
      }

      let rawValue = '';

      if (input.type === 'checkbox') {
        rawValue =
          input.checked;
      } else {
        rawValue =
          input.value;
      }

      const cleanValue =
        normalizeCustomMetadataValue(
          field,
          rawValue
        );

      const shouldRemove =
        cleanValue === '' ||
        cleanValue === null ||
        cleanValue === undefined ||
        (
          field.type === 'checkbox' &&
          cleanValue === false
        );

      if (shouldRemove) {
        delete nextValues[fieldId];
      } else {
        nextValues[fieldId] =
          cleanValue;
      }
    });

  const saved =
    await NaviStorage.saveDocument({
      ...doc,
      customMetadata:
        nextValues,
      updatedAt:
        Date.now()
    });

  documentsCache =
    documentsCache.map(item => {
      return item.id === saved.id
        ? saved
        : item;
    });

  renderDocumentList(documentsCache);

  NaviEditor.setSaveStatus('Custom metadata saved');
  
  await renderCustomMetadataValues(saved);
  
}

async function saveCurrentMetadata() {
  if (!currentDocumentId) return;

  const current =
    await NaviStorage.getDocument(currentDocumentId);

  if (!current) return;

  const updated = {
    ...current,

    folder:
      els.folderInput?.value.trim() || '',

    tags:
      parseTags(els.tagsInput?.value || ''),

    status:
  els.docStatusSelect?.value || '',

    pov:
      els.docPovInput?.value.trim() || '',

    location:
      els.docLocationInput?.value.trim() || '',

    timeline:
      els.docTimelineInput?.value.trim() || '',

    characters:
      els.docCharactersInput?.value.trim() || '',

    summary:
      els.docSummaryInput?.value.trim() || '',

    updatedAt:
      Date.now()
  };

  const saved =
    await NaviStorage.saveDocument(updated);

  documentsCache =
    documentsCache.map(doc => {
      return doc.id === saved.id
        ? saved
        : doc;
    });

  renderDocumentList(documentsCache);
  updateInspector();

  NaviEditor.setSaveStatus('Details saved');
  if (els.detailsSaveFeedback) { els.detailsSaveFeedback.textContent='Saved'; els.detailsSaveFeedback.classList.add('saved'); setTimeout(()=>{els.detailsSaveFeedback.textContent='Changes save when you choose Save Details.';els.detailsSaveFeedback.classList.remove('saved');},1800); }
}

function renderAnalysisList(container, items) {
  if (!container) return;

  if (!items.length) {
    container.innerHTML =
      '<div class="empty-note">Nothing found yet.</div>';
    return;
  }

  container.innerHTML = '';

  items.forEach(item => {
    const row = document.createElement('button');

    row.className = 'analysis-item';

    row.innerHTML = `
      <strong>${escapeHtml(item.text)}</strong>
      <span>${item.count}</span>
    `;

    row.onclick = () => {
      openFindPanel(item.text);
    };

    container.appendChild(row);
  });
}

function renderHeadingCounts() {
  if (!els.headingCountsList) return;
  const sections = NaviEditor.getHeadingWordCounts();
  if (!sections.length) {
    els.headingCountsList.innerHTML = '<div class="empty-note">No headings yet.</div>';
    return;
  }
  const totalWords = sections.reduce((sum, section) => sum + Math.max(0, Number(section.words) || 0), 0);
  els.headingCountsList.innerHTML = '';
  sections.forEach((section, index) => {
    const words = Math.max(0, Number(section.words) || 0);
    const percent = totalWords ? (words / totalWords) * 100 : 0;
    const previousLevel = index ? sections[index - 1].level : '';
    const nextLevel = index < sections.length - 1 ? sections[index + 1].level : '';
    const position = `${index + 1} of ${sections.length}`;
    const row = document.createElement('button');
    row.type = 'button';
    row.className = `outline-item section-count-item level-${section.level}`;
    row.dataset.sectionTooltip = `${words.toLocaleString()} words • ${percent.toFixed(percent >= 10 ? 0 : 1)}% of headed content • ${position}`;
    row.setAttribute('aria-label', `${section.title}, ${words.toLocaleString()} words, ${percent.toFixed(1)} percent of headed content, section ${position}`);
    row.innerHTML = `
      <span class="outline-level-badge">${escapeHtml(String(section.level || '').toUpperCase())}</span>
      <span class="outline-item-text">${escapeHtml(section.title)}</span>
      <span class="section-word-count">${words.toLocaleString()} words</span>
      <span class="section-count-share" aria-hidden="true"><i style="--section-share:${percent.toFixed(2)}%"></i></span>
    `;
    row.dataset.previousLevel = previousLevel || '';
    row.dataset.nextLevel = nextLevel || '';
    row.onclick = () => NaviEditor.scrollToHeading(section.id);
    els.headingCountsList.appendChild(row);
  });
}

function setLongGoalMessage(message, state = '') {
  if (!els.longGoalOutput) return;
  els.longGoalOutput.textContent = message;
  els.longGoalOutput.dataset.goalState = state;
}

function formatGoalNumber(value = 0) {
  const number = Math.max(0, Math.floor(Number(value) || 0));
  if (number >= 1000000000) return `${(number / 1000000000).toFixed(number >= 10000000000 ? 0 : 1).replace(/\.0$/, '')}B`;
  if (number >= 1000000) return `${(number / 1000000).toFixed(number >= 10000000 ? 0 : 1).replace(/\.0$/, '')}M`;
  if (number >= 1000) return `${(number / 1000).toFixed(number >= 100000 ? 0 : 1).replace(/\.0$/, '')}K`;
  return number.toLocaleString();
}

function setGoalRing(ring, valueElement, current, target) {
  const safeCurrent = Math.max(0, Number(current) || 0);
  const safeTarget = Math.max(0, Number(target) || 0);
  const percent = safeTarget > 0 ? Math.min(100, Math.max(0, (safeCurrent / safeTarget) * 100)) : 0;
  if (ring) ring.style.setProperty('--goal-percent', percent.toFixed(2));
  if (valueElement) {
    valueElement.textContent = `${formatGoalNumber(safeCurrent)} / ${formatGoalNumber(safeTarget)}`;
    valueElement.title = `${Math.floor(safeCurrent).toLocaleString()} of ${Math.floor(safeTarget).toLocaleString()} words`;
  }
}

function resetDeadlineGoalDashboard() {
  setGoalRing(els.longGoalRing, els.longGoalRingValue, 0, 0);
  setGoalRing(els.dailyGoalRing, els.dailyGoalRingValue, 0, 0);
}

function parseLocalDateInput(value = '') {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  const date = new Date(
    Number(match[1]),
    Number(match[2]) - 1,
    Number(match[3]),
    23, 59, 59, 999
  );
  return Number.isNaN(date.getTime()) ? null : date;
}

async function loadLongGoal() {
  const goal=await NaviStorage.getSetting('longGoal',null);
  if (els.longGoalWordsInput) els.longGoalWordsInput.value=goal?.targetWords || goal?.words || '';
  if (els.longGoalDateInput) els.longGoalDateInput.value=goal?.targetDate || goal?.date || '';
  const targetId=goal?.targetDocumentId || currentDocumentId;
  const scope=goal?.scope || 'project';
  const resolution=await resolveDocumentScope(targetId,scope);
  populateScopeSelect(els.longGoalScopeSelect,resolution,scope);
}


async function saveLongGoal() {
  const targetWords=Number(els.longGoalWordsInput?.value||0); const targetDate=els.longGoalDateInput?.value||'';
  if (!targetWords || targetWords<1) { setLongGoalMessage('Enter a target word count.','invalid'); return; }
  if (!targetDate) { setLongGoalMessage('Choose a target date.','invalid'); return; }
  const scope=els.longGoalScopeSelect?.value||'project';
  const resolution=await resolveDocumentScope(currentDocumentId,scope);
  await NaviStorage.saveSetting('longGoal',{ targetDocumentId:currentDocumentId, scope:resolution.scope, targetWords, targetDate, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString() });
  await updateLongGoalDisplay();
}


async function clearLongGoal() {
  await NaviStorage.saveSetting('longGoal', null);
  if (els.longGoalWordsInput) els.longGoalWordsInput.value = '';
  if (els.longGoalDateInput) els.longGoalDateInput.value = '';
  setLongGoalMessage('No deadline goal set.', 'empty');
  resetDeadlineGoalDashboard();
  if (els.dailyGoalOutput) els.dailyGoalOutput.textContent = 'No daily goal data yet.';
  if (els.dailyGoalBarFill) els.dailyGoalBarFill.style.width = '0%';
}

function getTodayKey() {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');

  return `${year}-${month}-${day}`;
}

async function getProjectRootDocumentId(docId) {
  if (!docId) return null;

  let current = await NaviStorage.getDocument(docId);

  if (!current) return null;

  while (current.parentId) {
    const parent = await NaviStorage.getDocument(current.parentId);

    if (!parent) break;

    current = parent;
  }

  return current.id;
}

async function getProjectDocuments(rootId) {
  const allDocs = await NaviStorage.getAllDocuments();

  const result = [];
  const queue = [rootId];

  while (queue.length) {
    const currentId = queue.shift();

    const doc = allDocs.find(item => item.id === currentId);

    if (doc) {
      result.push(doc);
    }

    const children = allDocs.filter(item => item.parentId === currentId);

    children.forEach(child => {
      queue.push(child.id);
    });
  }

  return result;
}

function getOrCreateFindLocationIndicator() {
  let indicator = document.getElementById('findLocationIndicator');

  if (indicator) {
    return indicator;
  }

  indicator = document.createElement('div');
  indicator.id = 'findLocationIndicator';
  indicator.className = 'find-location-indicator';

  indicator.innerHTML = `
    <div class="find-location-arrow"></div>
    <div class="find-location-pill" id="findLocationPill">Match</div>
  `;

  document.body.appendChild(indicator);

  return indicator;
}

function showFindLocationIndicator(targetElement, label = 'Match') {
  if (!targetElement) return;

  const indicator = getOrCreateFindLocationIndicator();
  const pill = document.getElementById('findLocationPill');

  if (pill) {
    pill.textContent = label;
  }

  const targetRect = targetElement.getBoundingClientRect();

  const editorPage =
    document.querySelector('.editor-page') ||
    document.getElementById('editor');

  const pageRect =
    editorPage?.getBoundingClientRect();

  const top = Math.max(
    72,
    Math.min(
      window.innerHeight - 48,
      targetRect.top + targetRect.height / 2
    )
  );

  let left = 16;

  if (pageRect) {
    left = Math.max(
      12,
      pageRect.left - 92
    );
  }

  indicator.style.top = `${top}px`;
  indicator.style.left = `${left}px`;

  indicator.classList.remove('find-location-pulse');
  void indicator.offsetWidth;

  indicator.classList.add('visible');
  indicator.classList.add('find-location-pulse');

  clearTimeout(indicator._hideTimer);

  indicator._hideTimer = setTimeout(() => {
    indicator.classList.remove('visible');
    indicator.classList.remove('find-location-pulse');
  }, 2400);
}

function hideFindLocationIndicator() {
  const indicator = document.getElementById('findLocationIndicator');

  if (!indicator) return;

  indicator.classList.remove('visible');
  indicator.classList.remove('find-location-pulse');
}

function flashFindResult(element) {
  if (!element) return;

  let marker = document.getElementById('naviFindMarker');

  if (!marker) {
    marker = document.createElement('div');
    marker.id = 'naviFindMarker';

    document.body.appendChild(marker);
  }

  const label =
    activeFindIndex >= 0 && activeFindResults.length
      ? `${activeFindIndex + 1}/${activeFindResults.length}`
      : 'Match';

  const rect = element.getBoundingClientRect();

  const page =
    document.querySelector('.editor-page') ||
    document.getElementById('editor');

  const pageRect =
    page?.getBoundingClientRect();

  const top = Math.max(
    70,
    Math.min(
      window.innerHeight - 50,
      rect.top + rect.height / 2
    )
  );

  let left = 12;

  if (pageRect) {
    left = pageRect.left - 78;

    if (left < 8) {
      left = pageRect.right + 12;
    }
  }

  marker.textContent = `▶ ${label}`;

  marker.style.position = 'fixed';
  marker.style.zIndex = '999999';
  marker.style.left = `${left}px`;
  marker.style.top = `${top}px`;
  marker.style.transform = 'translateY(-50%)';
  marker.style.background = '#7c3aed';
  marker.style.color = '#ffffff';
  marker.style.padding = '7px 10px';
  marker.style.borderRadius = '999px';
  marker.style.fontSize = '12px';
  marker.style.fontWeight = '800';
  marker.style.fontFamily = 'Arial, Helvetica, sans-serif';
  marker.style.boxShadow = '0 8px 28px rgba(124, 58, 237, 0.38)';
  marker.style.pointerEvents = 'none';
  marker.style.opacity = '1';
  marker.style.whiteSpace = 'nowrap';

  clearTimeout(marker._hideTimer);

  marker._hideTimer = setTimeout(() => {
    marker.style.opacity = '0';
  }, 2600);
}

function getDocPlainTextForStats(doc) {
  if (!doc) return '';

  if (doc.id === currentDocumentId && window.NaviEditor) {
    return NaviEditor.getEditorText();
  }

  return doc.plainText || '';
}

async function getCurrentProjectStats() {
  if (!currentDocumentId) {
    return {
      rootId: null,
      words: 0,
      chars: 0,
      docs: []
    };
  }

  const rootId = await getProjectRootDocumentId(currentDocumentId);

  if (!rootId) {
    return {
      rootId: null,
      words: 0,
      chars: 0,
      docs: []
    };
  }

  const docs = await getProjectDocuments(rootId);

  let words = 0;
  let chars = 0;

  docs.forEach(doc => {
    const text = getDocPlainTextForStats(doc);

    words += NaviEditor.countWords(text);
    chars += text.length;
  });

  return {
    rootId,
    words,
    chars,
    docs
  };
}

async function getDailyGoalState(rootId, currentWords, targetWords, targetDate) {
  const todayKey = getTodayKey();

  const settingKey = `dailyGoal:${rootId}`;

  let state = await NaviStorage.getSetting(settingKey, null);

  const target = new Date(`${targetDate}T23:59:59`);
  const now = new Date();

  const msPerDay = 1000 * 60 * 60 * 24;

  const daysLeft = Math.max(
    1,
    Math.ceil((target - now) / msPerDay)
  );

  const remainingTotal = Math.max(
    0,
    Number(targetWords || 0) - Number(currentWords || 0)
  );

  const recommendedPerDay = Math.ceil(
    remainingTotal / daysLeft
  );

  if (
    !state ||
    state.date !== todayKey ||
    state.targetWords !== Number(targetWords || 0) ||
    state.targetDate !== targetDate
  ) {
    state = {
      date: todayKey,
      rootId,
      startWords: currentWords,
      targetWords: Number(targetWords || 0),
      targetDate,
      dailyTarget: recommendedPerDay
    };

    await NaviStorage.saveSetting(settingKey, state);
  }

  const writtenToday = Math.max(
    0,
    currentWords - Number(state.startWords || 0)
  );

  const remainingToday = Math.max(
    0,
    Number(state.dailyTarget || 0) - writtenToday
  );

  const todayPercent =
    state.dailyTarget > 0
      ? Math.min(100, Math.round((writtenToday / state.dailyTarget) * 100))
      : 0;

  return {
    ...state,
    currentWords,
    writtenToday,
    remainingToday,
    remainingTotal,
    recommendedPerDay,
    daysLeft,
    todayPercent
  };
}

async function updateDailyGoalDisplay() {
  if (!els.dailyGoalOutput || !els.dailyGoalBarFill) return;

  const goal = await NaviStorage.getSetting('longGoal', null);

  if (!goal || !goal.words || !goal.date || !currentDocumentId) {
    els.dailyGoalOutput.textContent = 'No daily goal data yet.';
    els.dailyGoalBarFill.style.width = '0%';
    return;
  }

  const projectStats = await getCurrentProjectStats();

  if (!projectStats.rootId) {
    els.dailyGoalOutput.textContent = 'No project selected.';
    els.dailyGoalBarFill.style.width = '0%';
    return;
  }

  const state = await getDailyGoalState(
    projectStats.rootId,
    projectStats.words,
    Number(goal.words),
    goal.date
  );

  setGoalRing(
    els.dailyGoalRing,
    els.dailyGoalRingValue,
    state.writtenToday,
    state.dailyTarget
  );

  els.dailyGoalOutput.innerHTML = `
    <span class="goal-detail-chip"><strong>${state.remainingToday.toLocaleString()}</strong><small>left today</small></span>
    <span class="goal-detail-chip"><strong>${state.recommendedPerDay.toLocaleString()}</strong><small>words / day after</small></span>
  `;

  els.dailyGoalBarFill.style.width = `${state.todayPercent}%`;
}

async function updateLongGoalDisplay() {
  if (!els.longGoalOutput) return;
  const goal=await NaviStorage.getSetting('longGoal',null);
  if (!goal) { resetDeadlineGoalDashboard(); if(els.longGoalScopeSummary) els.longGoalScopeSummary.textContent='No deadline scope selected.'; return; }
  const targetId=goal.targetDocumentId || currentDocumentId; const scope=goal.scope || 'project';
  const stats=await getScopeStatistics(targetId,scope);
  if (!stats.valid) { resetDeadlineGoalDashboard(); setLongGoalMessage(`${stats.warning} Choose a new scope and save to recover this goal.`,'invalid'); return; }
  populateScopeSelect(els.longGoalScopeSelect,stats,scope);
  if(els.longGoalScopeSummary) els.longGoalScopeSummary.textContent=`${stats.label}: ${stats.docs.length} included document${stats.docs.length===1?'':'s'}.`;
  const targetWords=Number(goal.targetWords||goal.words||0), remaining=Math.max(0,targetWords-stats.words);
  setGoalRing(els.longGoalRing,els.longGoalRingValue,stats.words,targetWords);
  if(!remaining){ setLongGoalMessage('Deadline goal complete.','complete'); return; }
  const target=new Date(`${goal.targetDate||goal.date}T23:59:59`), now=new Date();
  if(Number.isNaN(target.getTime())){ setLongGoalMessage('The saved deadline date is invalid.','invalid'); return; }
  const days=Math.max(0,Math.ceil((target-now)/86400000));
  if(!days){ setLongGoalMessage(`Deadline passed with ${remaining.toLocaleString()} words remaining.`,'expired'); return; }
  const perDay=Math.ceil(remaining/days); setLongGoalMessage('','active');
  els.longGoalOutput.innerHTML=`<span class="goal-detail-chip"><strong>${remaining.toLocaleString()}</strong><small>remaining</small></span><span class="goal-detail-chip"><strong>${days.toLocaleString()}</strong><small>days left</small></span><span class="goal-detail-chip"><strong>${perDay.toLocaleString()}</strong><small>words / day</small></span>`;
  if(els.dailyGoalOutput) els.dailyGoalOutput.textContent=`Suggested pace: ${perDay.toLocaleString()} words per day across ${stats.label.toLowerCase()}.`;
}


async function extractTextFromPdfFile(file) {
  if (window.NaviPdfReady) {
    const ready = await window.NaviPdfReady;
    if (!ready) throw new Error('Local PDF.js failed to load. Confirm pdf.min.js and pdf.worker.min.js are in js/vendor, then reload NaviWriter.');
  }
  const pdfjs = window.pdfjsLib;
  if (!pdfjs || typeof pdfjs.getDocument !== 'function') {
    throw new Error('Local PDF.js failed to initialize. Reload NaviWriter and try again.');
  }

  const buffer = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
  const pageRecords = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
    const page = await pdf.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 1 });
    const textContent = await page.getTextContent({ disableCombineTextItems: false });
    const lines = buildLinesFromPdfItems(textContent.items);
    pageRecords.push({ pageNumber, height: viewport.height || 792, lines });
  }

  // Running furniture is positional, not just textual. A line repeated near
  // the top/bottom of multiple pages is a header/footer even when it says
  // "Chapter 2: Gone". Do this before chapter marking so furniture cannot
  // manufacture fake chapter boundaries.
  const furnitureCounts = new Map();
  const normalize = value => String(value || '').trim().replace(/\s+/g, ' ').toLowerCase();
  pageRecords.forEach(page => {
    const seenOnPage = new Set();
    page.lines.forEach(line => {
      const topBand = line.y >= page.height * 0.88;
      const bottomBand = line.y <= page.height * 0.12;
      const key = normalize(line.text);
      if (!key || (!topBand && !bottomBand) || /^\d{1,4}$/.test(key)) return;
      seenOnPage.add(`${topBand ? 'top' : 'bottom'}:${key}`);
    });
    seenOnPage.forEach(key => furnitureCounts.set(key, (furnitureCounts.get(key) || 0) + 1));
  });
  const repeatedFurniture = new Set(
    Array.from(furnitureCounts.entries())
      .filter(([, count]) => count >= 2)
      .map(([key]) => key)
  );

  const pages = pageRecords.map(page => {
    const kept = page.lines.filter(line => {
      const key = normalize(line.text);
      if (/^\d{1,4}$/.test(key) && (line.y >= page.height * 0.88 || line.y <= page.height * 0.12)) return false;
      const bandKey = `${line.y >= page.height * 0.88 ? 'top' : 'bottom'}:${key}`;
      return !repeatedFurniture.has(bandKey);
    });
    const ordinarySizes = kept
      .filter(line => line.text.trim().length > 35)
      .map(line => line.fontSize)
      .filter(size => size > 0)
      .sort((a, b) => a - b);
    const bodySize = ordinarySizes.length ? ordinarySizes[Math.floor(ordinarySizes.length / 2)] : 10;
    return kept.map(line => {
      const text = line.text.trim();
      if (!text) return '';
      const chapterLike = /^(?:chapter|part|book|section)\s+(?:\d+|[ivxlcdm]+)\b/i.test(text);
      const namedMatter = /^(?:prologue|epilogue|introduction|preface|foreword|afterword|acknowledg(?:e)?ments|appendix|conclusion)$/i.test(text);
      const fontHeading = text.length <= 100 && line.fontSize >= Math.max(bodySize * 1.22, bodySize + 1.5) && !/^\d{1,4}$/.test(text);
      return (chapterLike || namedMatter || fontHeading) ? `[[NAVIPDF_HEADING]]${text}` : text;
    }).filter(Boolean).join('\n');
  }).filter(Boolean);
  return pages.join('\n\n[[NAVIPDF_PAGE_BREAK]]\n\n');
}

function buildLinesFromPdfItems(items) {
  const rows = [];

  for (const item of items) {
    const text = item.str || '';

    if (!text.trim()) continue;

    const transform = item.transform || [];

    const x = transform[4] || 0;
    const y = transform[5] || 0;

    let row = rows.find(existing => {
      return Math.abs(existing.y - y) < 3;
    });

    if (!row) {
      row = {
        y,
        parts: []
      };

      rows.push(row);
    }

    const fontSize = Math.hypot(transform[0] || 0, transform[1] || 0) || Math.abs(transform[3] || 0) || Number(item.height || 0);
    row.parts.push({
      x,
      text,
      fontSize
    });
  }

  rows.sort((a, b) => b.y - a.y);

  return rows.map(row => {
    row.parts.sort((a, b) => a.x - b.x);

    return {
      y: row.y,
      text: joinPdfLineParts(row.parts),
      fontSize: Math.max(...row.parts.map(part => Number(part.fontSize || 0)), 0)
    };
  });
}

function joinPdfLineParts(parts) {
  let result = '';

  for (const part of parts) {
    const text = part.text || '';

    if (!result) {
      result = text;
      continue;
    }

    const previous = result[result.length - 1];

    const shouldJoinWithoutSpace =
      previous === '-' ||
      text.startsWith('.') ||
      text.startsWith(',') ||
      text.startsWith(';') ||
      text.startsWith(':') ||
      text.startsWith('!') ||
      text.startsWith('?') ||
      text.startsWith('”') ||
      text.startsWith('’');

    result += shouldJoinWithoutSpace
      ? text
      : ' ' + text;
  }

  return result.replace(/\s+/g, ' ').trim();
}

function extractChapterTitleMap(text) {
  const result = new Map();

  const introIndex = text.search(/Introduction\s+DESCRIPTION/i);

  const tocText =
    introIndex > 0
      ? text.slice(0, introIndex)
      : text.slice(0, Math.min(text.length, 6000));

  const regex =
    /(?:^|\s)(?:\d+\s+)?Chapter\s+(\d+)\s*:\s*([A-Za-z0-9'‘’" -]{1,45}?)\s+\d+(?=\s+(?:\d+\s+)?Chapter|\s+Introduction|\s*$)/gi;

  let match;

  while ((match = regex.exec(tocText)) !== null) {
    const number = Number(match[1]);
    const title = String(match[2] || '').trim();

    if (!number || !title) continue;

    result.set(number, title);
  }

  console.log(
    'TOC chapter title map:',
    Array.from(result.entries())
  );

  return result;
}

function getImportedChapterNumber(value = '') {
  const match = String(value || '').match(/^(?:chapter|part|book|section)\s+(\d+)\b/i);
  return match ? Number(match[1]) : null;
}
function cleanImportedChapterTitle(value = '', titleMap = new Map()) {
  const text = String(value || '').replace(/\[\[NAVIPDF_HEADING\]\]/g, '').trim().replace(/\s+/g, ' ');
  const number = getImportedChapterNumber(text);
  if (!number) return text;
  const tocTitle = String(titleMap.get(number) || '').trim();
  if (tocTitle) return `Chapter ${number}: ${tocTitle}`;
  return text.replace(/\s+\d{1,4}\s*$/, '').trim();
}
function splitIntoChapters(text, titleMap = new Map()) {
  const source = String(text || '').replace(/\r\n?/g, '\n');
  const regex = /(?:^|\n)(?:\[\[NAVIPDF_HEADING\]\])?\s*((?:chapter|part|book|section)\s+(?:\d+|[ivxlcdm]+)\b[^\n]*|prologue|epilogue|introduction|preface|foreword|afterword|conclusion)\s*(?=\n|$)/gim;
  const raw = [...source.matchAll(regex)].map(match => {
    const index = match.index + (match[0].startsWith('\n') ? 1 : 0);
    return {
      index,
      endOfHeading: index + match[0].replace(/^\n/, '').length,
      rawTitle: match[1].trim(),
      title: cleanImportedChapterTitle(match[1], titleMap)
    };
  });
  if (!raw.length) return [];

  // First score each physical occurrence using the text until the next
  // heading. TOC entries have only a handful of words; real chapters do not.
  const scored = raw.map((item, index) => {
    const end = raw[index + 1]?.index ?? source.length;
    const body = source.slice(item.endOfHeading, end)
      .replace(/\[\[NAVIPDF_(?:HEADING|PAGE_BREAK)\]\]/g, '')
      .trim();
    return { ...item, end, body, words: NaviEditor.countWords(body) };
  });

  // Deduplicate by chapter NUMBER, not title. TOC titles often end in a page
  // number, so title-based dedupe treated "Chapter 1: Welcome 1" and the real
  // "Chapter 1: Welcome" as different chapters.
  const best = new Map();
  scored.forEach(item => {
    const number = getImportedChapterNumber(item.title);
    const key = number ? `chapter:${number}` : item.title.toLowerCase();
    const existing = best.get(key);
    if (!existing || item.words > existing.words) best.set(key, item);
  });
  const chosen = Array.from(best.values()).sort((a, b) => a.index - b.index);

  return chosen.map((item, index) => {
    const next = chosen[index + 1];
    let body = source.slice(item.endOfHeading, next?.index ?? source.length)
      .replace(/\[\[NAVIPDF_(?:HEADING|PAGE_BREAK)\]\]/g, '')
      .trim();
    // Remove every repeated running heading for this chapter from the body.
    const number = getImportedChapterNumber(item.title);
    if (number) {
      const duplicate = new RegExp(
        '(?:^|\\n)\\s*(?:chapter\\s+' + number + '\\b[^\\n]*)\\s*(?=\\n|$)',
        'gim'
      );
      body = body.replace(duplicate, '\n');
    }
    // Repair common dropped-cap extraction where the capital was detached.
    body = body.replace(/^t\s+(?=[a-z])/i, 'It ')
      .replace(/^he\s+(?=[a-z])/i, 'The ')
      .replace(/^nd\s+(?=[a-z])/i, 'And ')
      .replace(/^([a-z])/, letter => letter.toUpperCase())
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    return {
      title: item.title,
      text: `${item.title}\n\n${body}`.trim(),
      number: number || index + 1
    };
  }).filter(item => NaviEditor.countWords(item.text) >= 20);
}

function forceCleanChapterStart(chapterText, chapterNumber, tocTitle, cleanTitle) {
  let result = String(chapterText || '');

  const headingPattern = new RegExp(
    '^\\s*(?:\\d+\\s+)?Chapter\\s+' +
      chapterNumber +
      '\\s*:\\s*' +
      escapeRegExp(tocTitle),
    'i'
  );

  result = result.replace(
    headingPattern,
    cleanTitle + '\n\n'
  );

  return result;
}

function removeRepeatedChapterHeadings(text, chapterNumber, tocTitle) {
  let result = String(text || '');

  if (!chapterNumber || !tocTitle) {
    return result;
  }

  const safeTitle = escapeRegExp(tocTitle);

  const headingRegex = new RegExp(
    '(?:^|\\n|\\s)(?:\\d+\\s+)?(?:C\\s*)?HAPTER\\s+' +
      chapterNumber +
      '\\s*:\\s*' +
      safeTitle +
      '\\s*',
    'gi'
  );

  let seenFirstHeading = false;

  result = result.replace(headingRegex, match => {
    if (!seenFirstHeading) {
      seenFirstHeading = true;
      return `\nChapter ${chapterNumber}: ${tocTitle}\n\n`;
    }

    return '\n';
  });

  return result;
}

function removeStrayOpeningLetters(text) {
  const paragraphs = String(text || '')
    .split(/\n{2,}/)
    .map(paragraph => paragraph.trim())
    .filter(Boolean);

  if (paragraphs.length < 2) {
    return String(text || '');
  }

  const titleIndex = paragraphs.findIndex(paragraph =>
    /^Chapter\s+\d+\s*:/i.test(paragraph)
  );

  const bodyIndex =
    titleIndex >= 0
      ? titleIndex + 1
      : 0;

  if (!paragraphs[bodyIndex]) {
    return paragraphs.join('\n\n');
  }

  const firstBodyFirstLetter =
    paragraphs[bodyIndex].trim()[0] || '';

  /*
    Remove stray single-letter drop caps at the beginning
    of the next few paragraphs.

    Examples:
    "T We trudged..." -> "We trudged..."
    "I I so desperately..." -> "I so desperately..."
    "A A choir..." -> "A choir..."
  */
  for (
    let i = bodyIndex + 1;
    i < Math.min(paragraphs.length, bodyIndex + 6);
    i++
  ) {
    const paragraph = paragraphs[i];

    const match = paragraph.match(/^([A-Z])\s+(.+)/);

    if (!match) continue;

    const strayLetter = match[1];
    const rest = match[2].trim();

    if (!rest) continue;

    const restFirstLetter = rest[0];

    const looksLikeDuplicate =
      strayLetter === firstBodyFirstLetter ||
      strayLetter === restFirstLetter;

    const looksLikeNotARealOneLetterWord =
      !['I', 'A'].includes(strayLetter);

    if (looksLikeDuplicate || looksLikeNotARealOneLetterWord) {
      paragraphs[i] = rest;
    }
  }

  return paragraphs.join('\n\n');
}

function escapeRegExp(value) {
  return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function createChapterDocs(manuscript, chapterItems) {
  for (let index = 0; index < chapterItems.length; index++) {
    const item = chapterItems[index];
    const title = String(item.title || `Chapter ${index + 1}`).trim();
    const number = getImportedChapterNumber(title);
    let body = String(item.text || '').replace(/\[\[NAVIPDF_(?:HEADING|PAGE_BREAK)\]\]/g, '').trim();
    if (number) {
      body = body.replace(
        new RegExp('(?:^|\\n)\\s*chapter\\s+' + number + '\\b[^\\n]*(?=\\n|$)', 'gim'),
        '\n'
      );
    } else {
      body = body.replace(new RegExp('^\\s*' + escapeRegExp(title) + '\\s*', 'i'), '');
    }
    body = body.replace(/^t\s+(?=[a-z])/i, 'It ')
      .replace(/^he\s+(?=[a-z])/i, 'The ')
      .replace(/^nd\s+(?=[a-z])/i, 'And ')
      .replace(/^([a-z])/, letter => letter.toUpperCase())
      .replace(/\n{3,}/g, '\n\n').trim();
    const chapterText = `${title}\n\n${body}`.trim();
    const chapterDoc = NaviStorage.createBlankDocument(title);
    chapterDoc.parentId = manuscript.id;
    chapterDoc.docType = 'chapter';
    chapterDoc.sortOrder = index;
    chapterDoc.content = pdfTextToHtml(chapterText);
    chapterDoc.plainText = chapterText;
    chapterDoc.wordCount = NaviEditor.countWords(chapterText);
    chapterDoc.charCount = chapterText.length;
    chapterDoc.importedFrom = manuscript.importedFrom || '';
    await NaviStorage.saveDocument(chapterDoc);
  }
}

function cleanupImportedPdfText(text) {
  let result = String(text || '');

  const lines = result.split('\n');

  const frequency = new Map();

  lines.forEach(line => {
    const clean = line.trim();

    if (clean.length < 5) return;

    frequency.set(
      clean,
      (frequency.get(clean) || 0) + 1
    );
  });

  const repeatedLines = new Set(
    Array.from(frequency.entries())
      .filter(([line, count]) => count >= 2 && !isImportedChapterHeadingText(line.replace(/^\[\[NAVIPDF_HEADING\]\]/, '')))
      .map(([line]) => line)
  );

  result = lines
    .filter(line => !repeatedLines.has(line.trim()))
    .join('\n');

  result = result.replace(
    /^\s*\d+\s*$/gm,
    ''
  );

  result = result.replace(
    /^page\s+\d+\s*$/gim,
    ''
  );

  result = result.replace(
    /\n{3,}/g,
    '\n\n'
  );

  //result = result.replace(
 // /(Chapter\s+\d+[:\-\s][A-Za-z0-9 ]+)\s+([A-Z])/g,
 // '$1\n\n$2'
//);
return result.trim();
}

function reflowImportedText(text) {
  const lines = String(text || '')
    .split(/\n+/)
    .map(line => line.trim())
    .filter(Boolean);

  const blocks = [];
  let current = [];

  function flush() {
    if (!current.length) return;

    blocks.push(current.join(' '));
    current = [];
  }

  for (const line of lines) {
    if (/^Chapter\s+\d+\s*:/i.test(line)) {
      flush();
      blocks.push(line);
      continue;
    }

    if (/^\d{1,4}$/.test(line)) {
      continue;
    }

    current.push(line);

    if (/[.!?…“”"’)]$/.test(line)) {
      flush();
    }
  }

  flush();

  return blocks.join('\n\n');
}

function pdfTextToHtml(text) {
  const clean = reflowImportedText(
    String(text || '').replace(/\[\[NAVIPDF_HEADING\]\]/g, '').trim()
  );
  if (!clean) return '<p></p>';

  return clean
    .split(/\n{2,}/)
    .map(block => {
      const value = block.trim();
      if (isImportedChapterHeadingText(value)) {
        return `<h1>${escapeHtml(value)}</h1>`;
      }
      return `<p>${escapeHtml(value)}</p>`;
    })
    .join('');
}

async function handlePdfImportClick() {
  if (els.pdfInput) {
    els.pdfInput.click();
  }
}

function removeTableOfContents(text) {
  const introIndex = text.search(
    /Introduction\s+DESCRIPTION/i
  );

  if (introIndex > 0) {
    return text.slice(introIndex);
  }

  const chapterOneIndex = text.search(
    /\b1\s+Chapter\s+1\s*:\s*/i
  );

  if (chapterOneIndex > 0) {
    return text.slice(chapterOneIndex);
  }

  return text;
}

async function handlePdfImportFile(event) {
  const file = event.target.files?.[0];

  if (!file) return;

  try {
    NaviEditor.setSaveStatus('Importing PDF...');

    const text = await extractTextFromPdfFile(file);

    if (!text.trim()) {
      showAppNotice('No selectable text was found. This may be a scanned/image PDF.');
      return;
    }

    const baseCleanedText =
  cleanupImportedPdfText(text);

const titleMap =
  extractChapterTitleMap(baseCleanedText);

const cleanedText =
  removeTableOfContents(baseCleanedText);

const title =
  file.name.replace(/\.pdf$/i, '') ||
  'Imported PDF';


const chapters =
  splitIntoChapters(cleanedText, titleMap);

  console.log(
  `PDF import detected ${chapters.length} chapter candidates.`
);

if (chapters.length >= 1) {

  const manuscript =
    NaviStorage.createBlankDocument(title);

  manuscript.docType = 'manuscript';

  manuscript.parentId = pendingPdfParentId;

  manuscript.content =
    `<h1>${escapeHtml(title)}</h1><p>Imported from PDF</p>`;

  manuscript.plainText =
    title;

  manuscript.importedFrom =
    file.name;

  const savedManuscript =
    await NaviStorage.saveDocument(
      manuscript
    );

  await createChapterDocs(
    savedManuscript,
    chapters
  );

  collapseImportedManuscript(savedManuscript.id);
  await loadDocuments();
  await openDocument(
    savedManuscript.id
  );

  NaviEditor.setSaveStatus(
    `Imported ${chapters.length} chapters`
  );

} else {

  const doc =
    NaviStorage.createBlankDocument(
      title
    );

  doc.docType = 'pdf';

  doc.parentId = pendingPdfParentId;

  doc.content =
    pdfTextToHtml(cleanedText);
  
  doc.status = getDefaultStatusForDoc(doc);

  doc.plainText =
    cleanedText;

  doc.wordCount =
    NaviEditor.countWords(
      cleanedText
    );

  doc.charCount =
    cleanedText.length;

  doc.importedFrom =
    file.name;

  const saved =
    await NaviStorage.saveDocument(
      doc
    );

  await loadDocuments();
  await openDocument(saved.id);

  NaviEditor.setSaveStatus(
    'PDF imported'
  );
}
  } catch (error) {
  console.error('PDF ERROR:', error);

  await showAppError(
  error?.message || String(error),
  'PDF import failed'
);

  NaviEditor.setSaveStatus('PDF import error');
  } finally {
  pendingPdfParentId = null;
    event.target.value = '';
  }
}

function openSubdocTypeModal() {
  if (!els.subdocTypeModal) return;

  els.subdocTypeModal.classList.remove('hidden');
}

function closeSubdocTypeModal() {
  if (!els.subdocTypeModal) return;

  els.subdocTypeModal.classList.add('hidden');
}

async function handleNewSubDocument() {
  openSubdocTypeModal();
}

async function createSubDocumentOfType(type) {
  const normalizedType =
    String(type || 'general')
      .trim()
      .toLowerCase();

  if (normalizedType === 'pdf') {
    await openPdfSubdocModal();
    return;
  }
  
  if (isMatterPresetType(normalizedType)) {
  closeSubdocTypeModal();
}


  const config =
    await getSubdocTypeConfig(normalizedType);

  if (!config) {
    return;
  }

  const parentId =
    currentDocumentId || null;

  const parent =
    parentId
      ? await NaviStorage.getDocument(parentId)
      : null;

  const doc =
    NaviStorage.createBlankDocument(config.title);

  doc.docType = config.type;
doc.parentId = parentId;
doc.folder = parent?.folder || '';

doc.status = getDefaultStatusForDoc(doc);
doc.pov = doc.pov || '';
doc.location = doc.location || '';
doc.timeline = doc.timeline || '';
doc.characters = doc.characters || '';
doc.summary = doc.summary || '';

doc.content = config.content;
doc.plainText = config.plainText;
doc.wordCount = NaviEditor.countWords(config.plainText);
doc.charCount = config.plainText.length;

  if (config.type === 'pdf') {
    doc.importedFrom = '';
    doc.importDate = Date.now();
  }

  const saved =
    await NaviStorage.saveDocument(doc);

  closeSubdocTypeModal();

  await loadDocuments();
  await openDocument(saved.id);

  NaviEditor.focusEditor();

  if (config.type === 'cover') {
    await openCoverSetupWorkflow(saved.id,{newDocument:true,parentId:saved.parentId||null});
  }
}

const MATTER_PRESET_DEFINITIONS = {
  front: {
    title: 'Choose Front Matter Preset',
    subtitle: 'Opening pages before the main body of the book.',
    presets: [
      {
        key: 'title',
        icon: '📖',
        title: 'Title Page',
        desc: 'Book title, subtitle, and author name.'
      },
      {
        key: 'copyright',
        icon: '©️',
        title: 'Copyright',
        desc: 'Copyright notice, rights statement, and fiction disclaimer.'
      },
      {
        key: 'dedication',
        icon: '💌',
        title: 'Dedication',
        desc: 'A short dedication page.'
      },
      {
        key: 'epigraph',
        icon: '❝',
        title: 'Epigraph',
        desc: 'A quote or excerpt before the story begins.'
      },
      {
        key: 'preface',
        icon: '📝',
        title: 'Preface',
        desc: 'A short introductory note before the main text.'
      },
      {
        key: 'attributions',
        icon: '📎',
        title: 'Attributions',
        desc: 'Credits, permissions, references, and source acknowledgments.'
      },
      {
        key: 'blank',
        icon: '⬜',
        title: 'Blank',
        desc: 'An empty front matter document.'
      }
    ]
  },

  body: {
    title: 'Choose Body Matter Preset',
    subtitle: 'Main story/book content that belongs between front and back matter.',
    presets: [
      {
        key: 'prologue',
        icon: '🌒',
        title: 'Prologue',
        desc: 'Opening story material before Chapter 1.'
      },
      {
        key: 'part',
        icon: 'Ⅰ',
        title: 'Part Break',
        desc: 'A large book division, like Part I or Part II.'
      },
      {
        key: 'interlude',
        icon: '⏳',
        title: 'Interlude',
        desc: 'A short break or bridge between major sections.'
      },
      {
        key: 'epilogue',
        icon: '🌅',
        title: 'Epilogue',
        desc: 'Closing story material after the final chapter.'
      },
      {
        key: 'scene',
        icon: '🎬',
        title: 'Scene',
        desc: 'A flexible scene or main-body fragment.'
      },
      {
        key: 'blank',
        icon: '⬜',
        title: 'Blank',
        desc: 'An empty body matter document.'
      }
    ]
  },

  back: {
    title: 'Choose Back Matter Preset',
    subtitle: 'Closing pages after the main body of the book.',
    presets: [
      {
        key: 'acknowledgments',
        icon: '🙏',
        title: 'Acknowledgments',
        desc: 'Thank people, communities, or contributors.'
      },
      {
        key: 'about-author',
        icon: '✍️',
        title: 'About the Author',
        desc: 'Author biography or author note.'
      },
      {
        key: 'appendix',
        icon: '📂',
        title: 'Appendix',
        desc: 'Extra reference material or supplemental content.'
      },
      {
        key: 'glossary',
        icon: '🔤',
        title: 'Glossary',
        desc: 'Terms and definitions.'
      },
      {
        key: 'endnotes',
        icon: '🔢',
        title: 'Endnotes',
        desc: 'Numbered notes or references.'
      },
      {
        key: 'blank',
        icon: '⬜',
        title: 'Blank',
        desc: 'An empty back matter document.'
      }
    ]
  }
};

function openMatterPresetPicker(kind) {
  const definition =
    MATTER_PRESET_DEFINITIONS[kind];

  if (
    !definition ||
    !els.matterPresetModal ||
    !els.matterPresetGrid
  ) {
    return Promise.resolve(null);
  }

  pendingMatterPresetKind = kind;

  if (els.matterPresetTitle) {
    els.matterPresetTitle.textContent = definition.title;
  }

  if (els.matterPresetSubtitle) {
    els.matterPresetSubtitle.textContent = definition.subtitle;
  }

  els.matterPresetGrid.innerHTML = '';

  definition.presets.forEach(preset => {
    const card = document.createElement('button');

    card.type = 'button';
    card.className = 'matter-preset-card';
    card.dataset.presetKey = preset.key;

    card.innerHTML = `
      <span class="matter-preset-icon">${preset.icon}</span>
      <span class="matter-preset-main">${escapeHtml(preset.title)}</span>
      <span class="matter-preset-desc">${escapeHtml(preset.desc)}</span>
    `;

    card.onclick = () => {
      resolveMatterPresetPicker(preset.key);
    };

    els.matterPresetGrid.appendChild(card);
  });

  els.matterPresetModal.classList.remove('hidden');

  return new Promise(resolve => {
    pendingMatterPresetResolve = resolve;
  });
}

function resolveMatterPresetPicker(value = null) {
  if (els.matterPresetModal) {
    els.matterPresetModal.classList.add('hidden');
  }

  const resolver =
    pendingMatterPresetResolve;

  pendingMatterPresetResolve = null;
  pendingMatterPresetKind = '';

  if (resolver) {
    resolver(value);
  }
}

function closeMatterPresetPicker() {
  resolveMatterPresetPicker(null);
}

function normalizePresetChoice(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '-');
}

function currentYearString() {
  return String(new Date().getFullYear());
}

async function getFrontMatterPresetConfig() {
  const meta =
    await getProjectMetadata();

  const choice =
    await openMatterPresetPicker('front');

  if (choice === null) return null;

  const preset =
    normalizePresetChoice(choice);

  const bookTitle =
    meta.title || 'Book Title';

  const subtitle =
    meta.subtitle || '';

  const author =
    meta.author || 'Author Name';

  if (preset === 'copyright') {
    return {
      type: 'front-matter',
      title: 'Copyright',
      content:
        `<h1>Copyright</h1>` +
        `<p>Copyright © ${currentYearString()} ${escapeHtml(author)}.</p>` +
        `<p>All rights reserved.</p>` +
        `<p>This is a work of fiction. Names, characters, places, and incidents are either products of the author’s imagination or used fictitiously.</p>`,
      plainText:
        `Copyright Copyright © ${currentYearString()} ${author}. All rights reserved. This is a work of fiction.`
    };
  }

  if (preset === 'dedication') {
    return {
      type: 'front-matter',
      title: 'Dedication',
      content:
        '<h1>Dedication</h1>' +
        '<p>For...</p>',
      plainText:
        'Dedication For...'
    };
  }

  if (preset === 'epigraph') {
    return {
      type: 'front-matter',
      title: 'Epigraph',
      content:
        '<h1>Epigraph</h1>' +
        '<blockquote><p>Add quote or excerpt here.</p></blockquote>' +
        '<p>— Attribution</p>',
      plainText:
        'Epigraph Add quote or excerpt here. — Attribution'
    };
  }

  if (preset === 'preface') {
    return {
      type: 'front-matter',
      title: 'Preface',
      content:
        '<h1>Preface</h1>' +
        '<p>Add preface text here.</p>',
      plainText:
        'Preface Add preface text here.'
    };
  }

  if (
    preset === 'attributions' ||
    preset === 'attribution'
  ) {
    return {
      type: 'front-matter',
      title: 'Attributions',
      content:
        '<h1>Attributions</h1>' +
        '<p>List credited sources, permissions, image credits, references, inspirations, or included materials here.</p>',
      plainText:
        'Attributions List credited sources, permissions, image credits, references, inspirations, or included materials here.'
    };
  }

  if (preset === 'blank') {
    return {
      type: 'front-matter',
      title: 'Front Matter',
      content:
        '<h1>Front Matter</h1><p></p>',
      plainText:
        'Front Matter'
    };
  }

  return {
    type: 'front-matter',
    title: 'Title Page',
    content:
      `<section class="title-page">` +
      `<h1>${escapeHtml(bookTitle)}</h1>` +
      `${subtitle ? `<p class="book-subtitle">${escapeHtml(subtitle)}</p>` : ''}` +
      `<p class="book-author">${escapeHtml(author)}</p>` +
      `</section>`,
    plainText:
      `${bookTitle} ${subtitle} ${author}`
  };
}

async function getBackMatterPresetConfig() {
  const meta =
    await getProjectMetadata();

  const choice =
    await openMatterPresetPicker('back');

  if (choice === null) return null;

  const preset =
    normalizePresetChoice(choice);

  const author =
    meta.author || 'Author Name';

  if (
    preset === 'about-author' ||
    preset === 'about-the-author'
  ) {
    return {
      type: 'back-matter',
      title: 'About the Author',
      content:
        '<h1>About the Author</h1>' +
        `<p>${escapeHtml(author)} is...</p>`,
      plainText:
        `About the Author ${author} is...`
    };
  }

  if (preset === 'appendix') {
    return {
      type: 'back-matter',
      title: 'Appendix',
      content:
        '<h1>Appendix</h1>' +
        '<p>Add appendix material here.</p>',
      plainText:
        'Appendix Add appendix material here.'
    };
  }

  if (preset === 'glossary') {
    return {
      type: 'back-matter',
      title: 'Glossary',
      content:
        '<h1>Glossary</h1>' +
        '<p><strong>Term:</strong> Definition.</p>',
      plainText:
        'Glossary Term: Definition.'
    };
  }

  if (preset === 'endnotes') {
    return {
      type: 'back-matter',
      title: 'Endnotes',
      content:
        '<h1>Endnotes</h1>' +
        '<ol><li>Add note here.</li></ol>',
      plainText:
        'Endnotes Add note here.'
    };
  }

  if (preset === 'blank') {
    return {
      type: 'back-matter',
      title: 'Back Matter',
      content:
        '<h1>Back Matter</h1><p></p>',
      plainText:
        'Back Matter'
    };
  }

  return {
    type: 'back-matter',
    title: 'Acknowledgments',
    content:
      '<h1>Acknowledgments</h1>' +
      '<p>Add acknowledgments here.</p>',
    plainText:
      'Acknowledgments Add acknowledgments here.'
  };
}

async function getBodyMatterPresetConfig() {
  const choice =
    await openMatterPresetPicker('body');

  if (choice === null) return null;

  const preset =
    normalizePresetChoice(choice);

  if (preset === 'part') {
    return {
      type: 'body-matter',
      title: 'Part I',
      content:
        '<h1>Part I</h1><p></p>',
      plainText:
        'Part I'
    };
  }

  if (preset === 'interlude') {
    return {
      type: 'body-matter',
      title: 'Interlude',
      content:
        '<h1>Interlude</h1><p></p>',
      plainText:
        'Interlude'
    };
  }

  if (preset === 'epilogue') {
    return {
      type: 'body-matter',
      title: 'Epilogue',
      content:
        '<h1>Epilogue</h1><p></p>',
      plainText:
        'Epilogue'
    };
  }

  if (preset === 'scene') {
    return {
      type: 'body-matter',
      title: 'Scene',
      content:
        '<h1>Scene</h1><p></p>',
      plainText:
        'Scene'
    };
  }

  if (preset === 'blank') {
    return {
      type: 'body-matter',
      title: 'Body Matter',
      content:
        '<h1>Body Matter</h1><p></p>',
      plainText:
        'Body Matter'
    };
  }

  return {
    type: 'body-matter',
    title: 'Prologue',
    content:
      '<h1>Prologue</h1><p></p>',
    plainText:
      'Prologue'
  };
}

async function getSubdocTypeConfig(type) {
  if (type === 'cover') {
    return {
      type: 'cover',
      title: 'Cover',
      content:
        '<h1>Cover</h1>' +
        '<p>Choose a cover image for this project.</p>',
      plainText:
        'Cover Choose a cover image for this project.'
    };
  }

  if (type === 'front-matter') {
    return await getFrontMatterPresetConfig();
  }

  if (type === 'back-matter') {
    return await getBackMatterPresetConfig();
  }

  if (type === 'body-matter') {
    return await getBodyMatterPresetConfig();
  }

  if (type === 'chapter') {
    return {
      type: 'chapter',
      title: 'New Chapter',
      content: '<h1>New Chapter</h1><p></p>',
      plainText: 'New Chapter'
    };
  }

  if (type === 'notes') {
    return {
      type: 'notes',
      title: 'New Notes',
      content: '<h1>Notes</h1><p></p>',
      plainText: 'Notes'
    };
  }

  if (type === 'research') {
    return {
      type: 'research',
      title: 'New Research',
      content: '<h1>Research</h1><p></p>',
      plainText: 'Research'
    };
  }

  if (type === 'pdf') {
    return {
      type: 'pdf',
      title: 'Imported PDF Notes',
      content:
        '<h1>Imported PDF</h1>' +
        '<p>Use PDF Import to bring text into this document.</p>',
      plainText:
        'Imported PDF Use PDF Import to bring text into this document.'
    };
  }

  return {
    type: 'general',
    title: 'New Subdocument',
    content: '<h1>New Subdocument</h1><p></p>',
    plainText: 'New Subdocument'
  };
}

async function handleNewChapterDocument() {
  const title = prompt('Chapter title?', 'Chapter 1');

  if (!title) return;

  const doc = NaviStorage.createBlankDocument(title.trim());

  doc.docType = 'chapter';
  doc.content = `<h1>${escapeHtml(title.trim())}</h1><p></p>`;
  doc.plainText = title.trim();
  doc.wordCount = NaviEditor.countWords(doc.plainText);
  doc.charCount = doc.plainText.length;

  if (currentDocumentId) {
    const current = await NaviStorage.getDocument(currentDocumentId);

    if (current?.docType === 'manuscript') {
      doc.parentId = current.id;
    } else if (current?.parentId) {
      doc.parentId = current.parentId;
    }
  }

  const saved = await NaviStorage.saveDocument(doc);

  await loadDocuments();
  await openDocument(saved.id);
}

let activeFindResults = [];
let activeFindIndex = -1;

function getEditorSearchRoot() {
  const editor = document.getElementById('editor');

  if (!editor) return null;

  return editor.querySelector('.ProseMirror') || editor;
}

function buildTextIndex(root) {
  const nodes = [];
  let text = '';
  let position = 0;
  const blockTags = new Set([
    'P', 'DIV', 'LI', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
    'BLOCKQUOTE', 'PRE', 'FIGCAPTION', 'TD', 'TH'
  ]);

  function addSeparator() {
    if (text && !text.endsWith('\n')) {
      text += '\n';
      position += 1;
    }
  }

  function visit(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const value = node.nodeValue || '';
      if (!value) return;
      nodes.push({ node, start: position, end: position + value.length });
      text += value;
      position += value.length;
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    if (node.tagName === 'BR') {
      addSeparator();
      return;
    }
    const isBlock = blockTags.has(node.tagName);
    if (isBlock && text && !text.endsWith('\n')) addSeparator();
    Array.from(node.childNodes).forEach(visit);
    if (isBlock) addSeparator();
  }

  Array.from(root.childNodes).forEach(visit);
  return { text, nodes };
}

function findOccurrencesInText(text, query, contextWords = 8, options = {}) {
  const needle = String(query || '').trim();
  if (!needle) return [];

  const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const flags = options.matchCase ? 'gu' : 'giu';
  const regex = new RegExp(escaped, flags);
  const wordCharacter = /[\p{L}\p{N}_]/u;
  const firstIsWord = wordCharacter.test(needle[0] || '');
  const lastIsWord = wordCharacter.test(needle.at(-1) || '');
  const results = [];
  let match;

  while ((match = regex.exec(text)) !== null) {
    const index = match.index;
    const value = match[0];
    if (options.wholeWord) {
      const beforeCharacter = index > 0 ? text[index - 1] : '';
      const afterCharacter = text[index + value.length] || '';
      const startsInsideWord = firstIsWord && wordCharacter.test(beforeCharacter);
      const endsInsideWord = lastIsWord && wordCharacter.test(afterCharacter);
      if (startsInsideWord || endsInsideWord) continue;
    }

    const before = text.slice(0, index).split(/\s+/).filter(Boolean).slice(-contextWords).join(' ');
    const after = text.slice(index + value.length).split(/\s+/).filter(Boolean).slice(0, contextWords).join(' ');
    results.push({ index, length:value.length, value, before, after });
    if (!value.length) regex.lastIndex += 1;
  }
  return results;
}

function selectEditorTextRange(index, length) {
  const root = getEditorSearchRoot();

  if (!root) return false;

  const textIndex = buildTextIndex(root);

  const startInfo = textIndex.nodes.find(item => {
    return index >= item.start && index < item.end;
  });

  const endPosition = index + length;

  const endInfo = textIndex.nodes.find(item => {
    return endPosition > item.start && endPosition <= item.end;
  });

  if (!startInfo || !endInfo) {
    return false;
  }

  const startOffset = Math.max(
    0,
    index - startInfo.start
  );

  const endOffset = Math.max(
    0,
    endPosition - endInfo.start
  );

  const range = document.createRange();

  range.setStart(startInfo.node, startOffset);
  range.setEnd(endInfo.node, endOffset);

  const blockElement =
    startInfo.node.parentElement?.closest('p, div, li, h1, h2, h3, h4, h5, h6, blockquote') ||
    startInfo.node.parentElement ||
    root;

  /*
    Use instant scroll instead of smooth scroll.
    Smooth scroll was making the marker chase the paragraph like a caffeinated mosquito.
  */
  blockElement.scrollIntoView({
    behavior: 'auto',
    block: 'center'
  });

  try {
    if (typeof root.focus === 'function') {
      root.focus({
        preventScroll: true
      });
    }

    const selectedByTiptap = window.NaviTiptap?.selectDomTextRange
      ? window.NaviTiptap.selectDomTextRange(
          startInfo.node,
          startOffset,
          endInfo.node,
          endOffset
        )
      : false;

    if (!selectedByTiptap) {
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
  } catch (error) {
    console.warn('Selection failed:', error);
  }

  flashFindResult(blockElement);

  return true;
}


function getHighlightedContext(result) {
  return `${escapeHtml(result.before)} <mark>${escapeHtml(result.value)}</mark> ${escapeHtml(result.after)}`;
}

function resolveProjectResultInOpenEditor(result) {
  const root = getEditorSearchRoot();
  if (!root || !result) return null;
  const query = els.floatingFindInput?.value || result.value || '';
  const textIndex = buildTextIndex(root);
  const liveOccurrences = findOccurrencesInText(textIndex.text, query, 8, getFindOptions());
  if (!liveOccurrences.length) return null;

  const ordinal = Number(result.occurrenceIndex);
  if (Number.isInteger(ordinal) && liveOccurrences[ordinal]) {
    return liveOccurrences[ordinal];
  }

  // If stored plain text and rendered HTML disagree, prefer the occurrence
  // whose nearby words most closely match the original result context.
  const expected = `${result.before || ''} ${result.after || ''}`
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  let best = liveOccurrences[0];
  let bestScore = -1;
  liveOccurrences.forEach(candidate => {
    const context = `${candidate.before || ''} ${candidate.after || ''}`.toLowerCase();
    const score = expected.reduce((total, word) => total + (context.includes(word) ? 1 : 0), 0);
    if (score > bestScore) {
      best = candidate;
      bestScore = score;
    }
  });
  return best;
}

function selectProjectFindResult(result) {
  const live = resolveProjectResultInOpenEditor(result);
  if (!live) {
    showAppNotice('The match could not be resolved in the opened document. Run Find again.');
    return false;
  }
  return selectEditorTextRange(live.index, live.length);
}

async function openFindPanel(query = '') {
  if (!els.findPanel) return;

  els.findPanel.classList.remove('hidden');

  if (query && els.floatingFindInput) {
    els.floatingFindInput.value = query;
  }

  await runFloatingFind();

  if (activeFindResults.length) {
    activeFindIndex = 0;

    const first = activeFindResults[0];

    if (
      getFindScope() !== 'current' &&
      first.docId &&
      first.docId !== currentDocumentId
    ) {
      await openDocument(first.docId);

      setTimeout(() => {
        selectProjectFindResult(first);
      }, 120);

      return;
    }

    selectEditorTextRange(
      first.index,
      first.length
    );
  }
}

function closeFindPanel() {
  if (!els.findPanel) return;

  const marker = document.getElementById('naviFindMarker');

  if (marker) {
    marker.style.opacity = '0';
  }

  els.findPanel.classList.add('hidden');
}

async function runFloatingFind() {
  const query = els.floatingFindInput?.value || '';
  const scope = getFindScope();

  if (!query.trim()) {
    const marker = document.getElementById('naviFindMarker');

    if (marker) {
      marker.style.opacity = '0';
    }

    activeFindResults = [];
    activeFindIndex = -1;

    if (els.findResultsSummary) {
      els.findResultsSummary.textContent = 'No search yet.';
    }

    if (els.findResultsList) {
      els.findResultsList.innerHTML = '';
    }

    return;
  }

  if (scope !== 'current') {
    activeFindResults = await findOccurrencesAcrossScope(query, scope, getFindOptions());
    activeFindIndex = -1;
    renderFloatingFindResults();
    return;
  }

  const root = getEditorSearchRoot();

  if (!root) {
    activeFindResults = [];
    activeFindIndex = -1;
    renderFloatingFindResults();
    return;
  }

  const textIndex = buildTextIndex(root);

  activeFindResults = findOccurrencesInText(
    textIndex.text,
    query,
    8,
    getFindOptions()
  ).map(result => ({
    ...result,
    docId: currentDocumentId,
    docTitle: NaviEditor.getEditorTitle
      ? NaviEditor.getEditorTitle()
      : 'Current Document',
    scope: 'current'
  }));

  activeFindIndex = -1;

  renderFloatingFindResults();
}

function renderFloatingFindResults() {
  if (!els.findResultsSummary || !els.findResultsList) return;

  const query = els.floatingFindInput?.value || '';
  const count = activeFindResults.length;
  const scope = getFindScope();

  els.findResultsSummary.textContent =
    count
      ? `${count} match${count === 1 ? '' : 'es'} for "${query}" ${
          scope === 'project' ? 'across project' : 'in current document'
        }`
      : `No matches for "${query}"`;

  els.findResultsList.innerHTML = '';

  activeFindResults.forEach((result, index) => {
    const item = document.createElement('button');

    item.className = 'find-result-item';

    const docLabel =
      scope === 'project'
        ? `<div class="find-result-doc">${escapeHtml(result.docTitle || 'Untitled Document')}</div>`
        : '';

    item.innerHTML = `
      ${docLabel}
      <div class="find-result-context">
        ... ${getHighlightedContext(result)} ...
      </div>
    `;

    item.addEventListener('pointerdown', event => {
      event.preventDefault();
    });

    item.onclick = async () => {
      activeFindIndex = index;

      if (scope === 'project' && result.docId && result.docId !== currentDocumentId) {
        await openDocument(result.docId);

        /*
          Wait one tick so Tiptap/editor DOM actually loads the opened doc.
          Without this, it tries to jump before the chapter exists onscreen.
        */
        setTimeout(() => {
          selectProjectFindResult(result);
        }, 120);

        return;
      }

      if (scope === 'project') {
        selectProjectFindResult(result);
      } else {
        selectEditorTextRange(result.index, result.length);
      }
    };

    els.findResultsList.appendChild(item);
  });
}

function replaceSelectedFindResult() {
  const scope = getFindScope();

  if (scope === 'project') {
    showAppNotice('Open the result document first, then replace inside that document.');
    return;
  }

  const replacement = els.floatingReplaceInput?.value || '';

  if (activeFindIndex < 0) {
    showAppNotice('Select a match first.');
    return;
  }

  const result = activeFindResults[activeFindIndex];

  if (!result) return;

  const selected = selectEditorTextRange(
    result.index,
    result.length
  );

  if (!selected) return;

  const replaced = NaviEditor.replaceCurrentSelection
    ? NaviEditor.replaceCurrentSelection(result.value, replacement)
    : document.execCommand('insertText', false, replacement);

  if (replaced === false) {
    showAppNotice('The selected match changed. Run Find again and retry.');
    runFloatingFind();
    return;
  }

  NaviEditor.updateCounts();
  scheduleAutosave();
  updateInspector();
  runFloatingFind();
}

function replaceAllFindResults() {
  const scope = getFindScope();

  if (scope !== 'current') {
    showAppNotice('Multi-document replace is disabled for safety. Open a specific document to replace text there.');
    return;
  }

  const query = els.floatingFindInput?.value || '';
  const replacement = els.floatingReplaceInput?.value || '';

  if (!query.trim()) return;

  const options = getFindOptions();
  let count = 0;

  if (!options.matchCase && !options.wholeWord) {
    count = NaviEditor.replaceAllInEditor
      ? NaviEditor.replaceAllInEditor(query, replacement)
      : NaviEditor.replaceAllText(query, replacement);
  } else {
    const root = getEditorSearchRoot();
    const textIndex = root ? buildTextIndex(root) : null;
    const matches = textIndex
      ? findOccurrencesInText(textIndex.text, query, 8, options)
      : [];

    for (const result of matches.slice().reverse()) {
      if (!selectEditorTextRange(result.index, result.length)) continue;
      const replaced = NaviEditor.replaceCurrentSelection
        ? NaviEditor.replaceCurrentSelection(result.value, replacement)
        : document.execCommand('insertText', false, replacement);
      if (replaced !== false) count += 1;
    }
    NaviEditor.updateCounts();
  }

  scheduleAutosave();
  updateInspector();
  runFloatingFind();

  showAppNotice(`Replaced ${count} match${count === 1 ? '' : 'es'}.`);
}

function setupDraggableFindPanel() {
  const panel = els.findPanel;
  const handle = panel?.querySelector('.floating-panel-head');

  if (!panel || !handle) return;

  const savedPosition = localStorage.getItem('naviwriter-find-panel-position');

  if (savedPosition) {
    try {
      const parsed = JSON.parse(savedPosition);

      if (
        typeof parsed.left === 'number' &&
        typeof parsed.top === 'number'
      ) {
        panel.style.left = `${parsed.left}px`;
        panel.style.top = `${parsed.top}px`;
        panel.style.right = 'auto';
      }
    } catch {
      // Ignore bad saved position.
    }
  }

  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let startLeft = 0;
  let startTop = 0;

  handle.addEventListener('pointerdown', event => {
    const clickedCloseButton = event.target.closest('button');

    if (clickedCloseButton) return;

    isDragging = true;

    const rect = panel.getBoundingClientRect();

    startX = event.clientX;
    startY = event.clientY;
    startLeft = rect.left;
    startTop = rect.top;

    panel.classList.add('dragging');

    handle.setPointerCapture(event.pointerId);
  });

  handle.addEventListener('pointermove', event => {
    if (!isDragging) return;

    const dx = event.clientX - startX;
    const dy = event.clientY - startY;

    const panelRect = panel.getBoundingClientRect();

    const maxLeft = window.innerWidth - panelRect.width - 8;
    const maxTop = window.innerHeight - panelRect.height - 8;

    const nextLeft = Math.max(
      8,
      Math.min(maxLeft, startLeft + dx)
    );

    const nextTop = Math.max(
      8,
      Math.min(maxTop, startTop + dy)
    );

    panel.style.left = `${nextLeft}px`;
    panel.style.top = `${nextTop}px`;
    panel.style.right = 'auto';
  });

  handle.addEventListener('pointerup', event => {
    if (!isDragging) return;

    isDragging = false;

    panel.classList.remove('dragging');

    try {
      handle.releasePointerCapture(event.pointerId);
    } catch {
      // Ignore release issues.
    }

    const rect = panel.getBoundingClientRect();

    localStorage.setItem(
      'naviwriter-find-panel-position',
      JSON.stringify({
        left: rect.left,
        top: rect.top
      })
    );
  });

  handle.addEventListener('pointercancel', () => {
    isDragging = false;
    panel.classList.remove('dragging');
  });
}

async function openPdfSubdocModal() {
  pendingPdfParentId = currentDocumentId || null;

  closeSubdocTypeModal();

  await renderExistingPdfList();

  if (els.pdfSubdocModal) {
    els.pdfSubdocModal.classList.remove('hidden');
  }
}

function closePdfSubdocModal() {
  if (!els.pdfSubdocModal) return;

  els.pdfSubdocModal.classList.add('hidden');
}

async function renderExistingPdfList() {
  if (!els.existingPdfList) return;

  const docs = await NaviStorage.getAllDocuments();

  const pdfDocs = docs.filter(doc => {
    return (
      doc.docType === 'pdf' ||
      String(doc.importedFrom || '').toLowerCase().endsWith('.pdf')
    );
  });

  if (!pdfDocs.length) {
    els.existingPdfList.innerHTML =
      '<div class="empty-note">No imported PDFs yet.</div>';
    return;
  }

  els.existingPdfList.innerHTML = '';

  pdfDocs.forEach(doc => {
    const item = document.createElement('button');

    item.className = 'existing-pdf-item';

    item.innerHTML = `
      <div class="existing-pdf-title">${escapeHtml(doc.title || 'Untitled PDF')}</div>
      <div class="existing-pdf-meta">
        ${Number(doc.wordCount || 0)} words
        ${doc.importedFrom ? ` • ${escapeHtml(doc.importedFrom)}` : ''}
      </div>
    `;

    item.onclick = () => {
      attachExistingPdfAsSubdoc(doc.id);
    };

    els.existingPdfList.appendChild(item);
  });
}

async function handleUploadPdfSubdoc() {
  pendingPdfParentId = currentDocumentId || null;

  closePdfSubdocModal();

  if (els.pdfInput) {
    els.pdfInput.click();
  }
}

async function createBlankPdfSubdoc() {
  const parent =
    currentDocumentId
      ? await NaviStorage.getDocument(currentDocumentId)
      : null;

  const doc =
    NaviStorage.createBlankDocument('PDF Notes');

  doc.docType = 'pdf';
  doc.parentId = currentDocumentId || null;
  doc.folder = parent?.folder || '';
  doc.status = getDefaultStatusForDoc(doc);
  doc.content = '<h1>PDF Notes</h1><p>Add notes or import PDF text here.</p>';
  doc.plainText = 'PDF Notes Add notes or import PDF text here.';
  doc.wordCount = NaviEditor.countWords(doc.plainText);
  doc.charCount = doc.plainText.length;
  doc.importedFrom = '';
  doc.importDate = Date.now();

  const saved = await NaviStorage.saveDocument(doc);

  closePdfSubdocModal();

  await loadDocuments();
  await openDocument(saved.id);

  NaviEditor.focusEditor();
  
}

const PROJECT_METADATA_KEY = 'naviwriter-project-metadata';

async function getProjectMetadata() {
  const saved =
    await NaviStorage.getSetting(PROJECT_METADATA_KEY, null);

  return {
    title: saved?.title || '',
    subtitle: saved?.subtitle || '',
    author: saved?.author || ''
  };
}

async function loadProjectMetadataFields() {
  const meta = await getProjectMetadata();

  if (els.projectTitleInput) {
    els.projectTitleInput.value = meta.title || '';
  }

  if (els.projectSubtitleInput) {
    els.projectSubtitleInput.value = meta.subtitle || '';
  }

  if (els.projectAuthorInput) {
    els.projectAuthorInput.value = meta.author || '';
  }
}

async function saveProjectMetadata() {
  const meta = {
    title: els.projectTitleInput?.value.trim() || '',
    subtitle: els.projectSubtitleInput?.value.trim() || '',
    author: els.projectAuthorInput?.value.trim() || '',
    updatedAt: Date.now()
  };

  await NaviStorage.saveSetting(PROJECT_METADATA_KEY, meta);

  NaviEditor.setSaveStatus('Project metadata saved');

  return meta;
}

function chooseCoverImageForDocument(docId) {
  if (!els.coverImageInput) {
    showAppNotice('Cover image input is missing.');
    return;
  }

  pendingCoverDocId = docId;
  els.coverImageInput.click();
}

async function handleCoverImageFile(event) {
  const file=event.target.files?.[0],docId=pendingCoverDocId;event.target.value='';pendingCoverDocId=null;
  if(!file||!docId)return;
  if(!String(file.type||'').startsWith('image/')){showAppNotice('Choose an image file for the cover.');return;}
  try{const asset=await NaviAssets.addFile(file,{kind:'image',sourceFormat:'cover',sourceFile:file.name,altText:file.name});const doc=await NaviStorage.getDocument(docId);if(!doc)throw new Error('Cover document not found.');const cover={assetId:asset.id,fit:doc.cover?.fit||'contain',focalX:Number(doc.cover?.focalX??.5),focalY:Number(doc.cover?.focalY??.5),altText:doc.cover?.altText||file.name,originalName:file.name,updatedAt:Date.now()};const content=coverHtmlForDocument(doc,cover);await NaviStorage.saveDocument({...doc,docType:'cover',type:'cover',cover,content,plainText:doc.title||'Cover',wordCount:NaviEditor.countWords(doc.title||'Cover'),charCount:String(doc.title||'Cover').length,coverImageName:file.name});await loadDocuments();if(currentDocumentId===docId)await openDocument(docId);NaviEditor.setSaveStatus('Cover image saved');}catch(error){NaviDiagnostics?.report?.({severity:'error',subsystem:'Cover',message:error?.message||String(error),error,recovered:true});showAppNotice('The cover image could not be saved.');}
}
function getInspectorCollapseKey(title, index) {
  const cleanTitle = String(title || `section-${index}`)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');

  return `naviwriter-inspector-collapsed:${cleanTitle}`;
}

function setInspectorSectionCollapsed(section, collapsed) {
  section.classList.toggle('collapsed', Boolean(collapsed));

  const chevron = section.querySelector('.inspector-section-chevron');

  if (chevron) {
    chevron.textContent = collapsed ? '▸' : '▾';
  }
}

const INSPECTOR_ACTIVE_TAB_KEY =
  'naviwriter-inspector-active-tab';

function getValidInspectorTab(tab) {
  return ['actions', 'view', 'details', 'review', 'analysis'].includes(tab)
    ? tab
    : 'details';
}

function setInspectorTab(tab = 'details') {
  const activeTab =
    getValidInspectorTab(tab);

  const inspector =
    document.querySelector('.inspector');

  if (inspector) {
    inspector.dataset.activeInspectorTab =
      activeTab;
  }

  document
    .querySelectorAll('[data-inspector-tab-btn]')
    .forEach(button => {
      const isActive =
        button.dataset.inspectorTabBtn === activeTab;

      button.classList.toggle(
        'active',
        isActive
      );

      button.setAttribute(
        'aria-selected',
        isActive ? 'true' : 'false'
      );
    });

  document
    .querySelectorAll('.inspector .inspector-section')
    .forEach(section => {
      const sectionTab =
        getValidInspectorTab(
          section.dataset.inspectorTab || 'details'
        );

      const isActive =
        sectionTab === activeTab;

      section.hidden =
        !isActive;

      section.classList.toggle(
        'inspector-tab-hidden',
        !isActive
      );
    });

  try {
    localStorage.setItem(
      INSPECTOR_ACTIVE_TAB_KEY,
      activeTab
    );
    const channelSelect = document.getElementById('inspectorChannelSelect');
    if (channelSelect && channelSelect.value !== activeTab) channelSelect.value = activeTab;
    document.dispatchEvent(new CustomEvent('naviwriter:inspector-channel', { detail: activeTab }));
  } catch {}
}

function setupInspectorTabs() {
  const savedTab =
    getValidInspectorTab(
      localStorage.getItem(
        INSPECTOR_ACTIVE_TAB_KEY
      )
    );

  document
    .querySelectorAll('[data-inspector-tab-btn]')
    .forEach(button => {
      if (
        button.dataset.inspectorTabReady === 'true'
      ) {
        return;
      }

      button.addEventListener('click', () => {
        setInspectorTab(
          button.dataset.inspectorTabBtn
        );
      });

      button.dataset.inspectorTabReady =
        'true';
    });

  const channelSelect = document.getElementById('inspectorChannelSelect');
  if (channelSelect && channelSelect.dataset.ready !== 'true') {
    channelSelect.addEventListener('change', () => setInspectorTab(channelSelect.value));
    channelSelect.dataset.ready = 'true';
  }
  setInspectorTab(savedTab);
}

function placeDocumentMapRefreshInOutlineHeader() {
  const refreshBtn =
    els.refreshDocumentMapBtn ||
    document.getElementById('refreshDocumentMapBtn');

  if (!refreshBtn) {
    return;
  }

  const outlineSection =
    refreshBtn.closest('.inspector-section');

  if (!outlineSection) {
    return;
  }

  outlineSection.classList.add(
    'inspector-outline-section'
  );

  const sectionTitle =
    outlineSection.querySelector(':scope > .section-title');

  if (!sectionTitle) {
    return;
  }

  /*
    If the refresh button is already in the section title,
    don't move it again.
  */
  if (sectionTitle.contains(refreshBtn)) {
    return;
  }

  refreshBtn.classList.add(
    'document-map-refresh-title-btn'
  );

  sectionTitle.appendChild(refreshBtn);
}

function setupCollapsibleInspectorSections() {
  const sections = document.querySelectorAll('.inspector .inspector-section');

  sections.forEach((section, index) => {
    if (section.dataset.collapsibleReady === 'true') {
      return;
    }

    const title = section.querySelector(':scope > .section-title');

    if (!title) return;

    const originalTitle = title.textContent.trim() || `Section ${index + 1}`;
    const storageKey = getInspectorCollapseKey(originalTitle, index);

    const body = document.createElement('div');
    body.className = 'inspector-section-body';

    let node = title.nextSibling;

    while (node) {
      const next = node.nextSibling;
      body.appendChild(node);
      node = next;
    }

    section.appendChild(body);

    title.innerHTML = '';

    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'inspector-section-toggle';

    toggle.innerHTML = `
      <span>${escapeHtml(originalTitle)}</span>
      <span class="inspector-section-chevron">▾</span>
    `;

    title.appendChild(toggle);

    const savedCollapsed =
      localStorage.getItem(storageKey) === 'true';

    setInspectorSectionCollapsed(section, savedCollapsed);

    toggle.onclick = () => {
      const nextCollapsed =
        !section.classList.contains('collapsed');

      setInspectorSectionCollapsed(section, nextCollapsed);

      try {
        localStorage.setItem(
          storageKey,
          nextCollapsed ? 'true' : 'false'
        );
      } catch {}
      syncInspectorCollapseAllButton();
      if (!nextCollapsed && section.id === 'writingHistorySection') {
        window.NaviWritingHistory?.refreshInline?.();
      }
    };

    section.dataset.collapsibleReady = 'true';
  });
  
  placeDocumentMapRefreshInOutlineHeader();
  syncInspectorCollapseAllButton();
  
}

function getVisibleInspectorSections() {
  return Array.from(document.querySelectorAll('.inspector .inspector-section')).filter(section => {
    if (section.hidden || section.classList.contains('inspector-tab-hidden')) return false;
    return window.getComputedStyle(section).display !== 'none';
  });
}

function syncInspectorCollapseAllButton() {
  if (!els.toggleInspectorSectionsBtn) return;
  const sections = getVisibleInspectorSections();
  const allCollapsed = sections.length > 0 && sections.every(section => section.classList.contains('collapsed'));
  els.toggleInspectorSectionsBtn.textContent = allCollapsed ? 'Expand All' : 'Collapse All';
  els.toggleInspectorSectionsBtn.dataset.action = allCollapsed ? 'expand' : 'collapse';
  els.toggleInspectorSectionsBtn.setAttribute('aria-label', allCollapsed ? 'Expand all visible Inspector sections' : 'Collapse all visible Inspector sections');
}

function toggleAllInspectorSections() {
  const sections = getVisibleInspectorSections();

  if (!sections.length) return;

  const shouldCollapse =
    sections.some(section => !section.classList.contains('collapsed'));

  sections.forEach((section, index) => {
    const titleButton = section.querySelector('.inspector-section-toggle span');
    const title = titleButton?.textContent || `Section ${index + 1}`;
    const storageKey = getInspectorCollapseKey(title, index);

    setInspectorSectionCollapsed(section, shouldCollapse);

    try {
      localStorage.setItem(
        storageKey,
        shouldCollapse ? 'true' : 'false'
      );
    } catch {}
  });

  syncInspectorCollapseAllButton();
}

function sanitizeHtmlForPrint(html = '') {
  const wrapper =
    document.createElement('div');

  wrapper.innerHTML =
    html || '<p></p>';

  /*
    Imported/editor HTML can sometimes carry inline widths,
    white-space behavior, or layout junk that makes print overflow.
    For compiled PDF/print, we want clean document flow.
  */
  wrapper
    .querySelectorAll('[style]')
    .forEach(node => {
      const tag =
        node.tagName.toLowerCase();

      /*
        Keep image src/alt, but remove sizing styles.
        CSS will handle image sizing in print.
      */
      node.removeAttribute('style');
    });

  wrapper
    .querySelectorAll('[contenteditable]')
    .forEach(node => {
      node.removeAttribute('contenteditable');
    });

  return wrapper.innerHTML;
}

function buildCompiledSectionHtml(doc, options = {}) {
  const includeTitles =
    options.includeTitles !== false;

  const pageBreaks =
    options.pageBreaks !== false;

  const type =
    doc?.docType || 'general';

  const classes = [
    'compiled-section',
    pageBreaks ? 'compiled-page-break' : '',
    `compiled-type-${type}`
  ].filter(Boolean).join(' ');

  const cleanContent =
    sanitizeHtmlForPrint(doc?.content || '<p></p>');

  return `
    <section class="${classes}">
      ${
        includeTitles && type !== 'cover'
          ? `
            <h1 class="compiled-section-title">
              ${escapeHtml(doc.title || 'Untitled Document')}
            </h1>
          `
          : ''
      }

      <div class="compiled-section-body">
        ${cleanContent}
      </div>
    </section>
  `;
}

function injectCompiledTitlePage(compiledDoc, html) {
  const meta =
    compiledDoc.metadata || {};

  const titlePageHtml =
    buildCompiledTitlePageHtml({
      title: meta.title || compiledDoc.title || 'Untitled Project',
      subtitle: meta.subtitle || '',
      author: meta.author || ''
    });

  const text =
    String(html || '');

  const coverMatch =
    text.match(
      /^\s*<section[^>]*compiled-type-cover[^>]*>[\s\S]*?<\/section>\s*/i
    );

  if (coverMatch) {
    return (
      coverMatch[0] +
      titlePageHtml +
      text.slice(coverMatch[0].length)
    );
  }

  return titlePageHtml + text;
}

function buildCompiledTitlePageHtml(metadata = {}) {
  const title =
    metadata.title || metadata.projectTitle || 'Untitled Project';

  const subtitle =
    metadata.subtitle || metadata.projectSubtitle || '';

  const author =
    metadata.author || metadata.projectAuthor || '';

  return `
    <section class="compiled-title-page">
      <div class="compiled-title-inner">
        <h1>${escapeHtml(title)}</h1>

        ${
          subtitle
            ? `<p class="compiled-subtitle">${escapeHtml(subtitle)}</p>`
            : ''
        }

        ${
          author
            ? `<p class="compiled-author">${escapeHtml(author)}</p>`
            : ''
        }
      </div>
    </section>
  `;
}


function buildPrintThemeCss(options = {}) {
  const style =
    options.style || options.printStyle || 'classic';

  const font =
    options.font || 'garamond';

  const margins =
    options.margins || 'standard';

  const pageSize =
    options.pageSize || 'letter';

  const fontFamilyMap = {
    garamond: 'Garamond, Georgia, "Times New Roman", serif',
    georgia: 'Georgia, "Times New Roman", serif',
    times: '"Times New Roman", Times, serif',
    system: 'Arial, Helvetica, sans-serif'
  };

  const marginMap = {
    narrow: '0.55in',
    compact: '0.55in',
    standard: '0.8in',
    wide: '1in'
  };

  const fontFamily =
    fontFamilyMap[font] || fontFamilyMap.garamond;

  const pageMargin =
    marginMap[margins] || marginMap.standard;

  const pageSizeCss =
    pageSize === 'a4'
      ? 'A4'
      : 'Letter';

  const pageOuterWidthCss =
    pageSize === 'a4'
      ? '8.27in'
      : '8.5in';

  const pageOuterHeightCss =
    pageSize === 'a4'
      ? '11.69in'
      : '11in';

  const theme =
    {
      manuscript: {
        fontSize: '12pt',
        lineHeight: '2',
        paragraphIndent: '0.5in',
        textAlign: 'left',
        headingAlign: 'left',
        headingSpacing: '1.25rem'
      },

      classic: {
        fontSize: '11.5pt',
        lineHeight: '1.65',
        paragraphIndent: '1.5em',
        textAlign: 'left',
        headingAlign: 'center',
        headingSpacing: '2.2rem'
      },

      modern: {
        fontSize: '11.5pt',
        lineHeight: '1.58',
        paragraphIndent: '0',
        textAlign: 'left',
        headingAlign: 'left',
        headingSpacing: '1.6rem'
      },

      compact: {
        fontSize: '10.5pt',
        lineHeight: '1.35',
        paragraphIndent: '1em',
        textAlign: 'left',
        headingAlign: 'left',
        headingSpacing: '1rem'
      },

      book: {
        fontSize: '11.5pt',
        lineHeight: '1.65',
        paragraphIndent: '1.5em',
        textAlign: 'left',
        headingAlign: 'center',
        headingSpacing: '2.2rem'
      }
    }[style] || {
      fontSize: '11.5pt',
      lineHeight: '1.6',
      paragraphIndent: '1.25em',
      textAlign: 'left',
      headingAlign: 'left',
      headingSpacing: '1.5rem'
    };

  return `
    @page {
      size: ${pageSizeCss};
      margin: ${pageMargin};
    }

    * {
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0;
      padding: 0;
      min-width: 0;

      color: #111827;
      font-family: ${fontFamily};
      font-size: ${theme.fontSize};
      line-height: ${theme.lineHeight};
    }

    body {
      background: #4b5563;
      padding: 0.35in 0;
    }

    .compiled-document {
      width: ${pageOuterWidthCss};
      max-width: calc(100vw - 24px);
      min-height: ${pageOuterHeightCss};

      margin: 0 auto;
      padding: ${pageMargin};

      background: #ffffff;
      color: #111827;

      overflow: hidden;

      box-shadow:
        0 0 0 1px #d1d5db,
        0 18px 48px rgba(0, 0, 0, 0.35);
    }

    .compiled-section {
      width: 100%;
      max-width: 100%;
      min-width: 0;

      overflow: visible;

      break-after: page;
      page-break-after: always;
    }

    .compiled-section:last-child {
      break-after: auto;
      page-break-after: auto;
    }

    .compiled-section-title {
      margin: ${theme.headingSpacing} 0 1.25rem;

      text-align: ${theme.headingAlign};

      font-family: ${fontFamily};
      font-size: ${style === 'manuscript' ? '14pt' : '17pt'};
      line-height: 1.2;
      font-weight: 800;

      break-after: avoid;
      page-break-after: avoid;
    }

    .compiled-section-body {
      display: block;

      width: 100%;
      max-width: 100%;
      min-width: 0;

      overflow: visible;
      text-align: ${theme.textAlign};

      white-space: normal;
      overflow-wrap: break-word;
      word-wrap: break-word;
      word-break: normal;
      hyphens: auto;
    }

    .compiled-section-body * {
      max-width: 100% !important;
      min-width: 0 !important;
      box-sizing: border-box !important;
    }

    .compiled-section-body p,
    .compiled-section-body div,
    .compiled-section-body li,
    .compiled-section-body blockquote {
      display: block;

      max-width: 100% !important;

      white-space: normal !important;
      overflow-wrap: break-word !important;
      word-wrap: break-word !important;
      word-break: normal !important;
    }

    .compiled-section-body span {
      display: inline !important;

      max-width: 100% !important;

      white-space: normal !important;
      overflow-wrap: break-word !important;
      word-wrap: break-word !important;
      word-break: normal !important;
    }

    .compiled-section-body p {
      margin: 0 0 0.75rem;

      orphans: 2;
      widows: 2;
    }

    .compiled-section-body p + p {
      text-indent: ${theme.paragraphIndent};
    }

    .compiled-section-body h1,
    .compiled-section-body h2,
    .compiled-section-body h3 {
      break-after: avoid;
      page-break-after: avoid;
      line-height: 1.25;
    }

    .compiled-section-body img {
      display: block;
      max-width: 100%;
      height: auto;
      margin: 1rem auto;

      break-inside: avoid;
      page-break-inside: avoid;
    }

    .compiled-section-body table {
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0;

      break-inside: avoid;
      page-break-inside: avoid;
    }

    .compiled-section-body th,
    .compiled-section-body td {
      border: 1px solid #d1d5db;
      padding: 0.35rem 0.45rem;
      vertical-align: top;
    }

    .compiled-section-body th {
      background: #f3f4f6;
      font-weight: 800;
    }

    .compiled-title-page {
      min-height: 85vh;

      display: grid;
      place-items: center;

      text-align: center;

      break-after: page;
      page-break-after: always;
    }

    .compiled-title-inner {
      display: grid;
      justify-items: center;
      gap: 0.65rem;
    }

    .compiled-title-inner h1 {
      margin: 0;
      font-size: 26pt;
      line-height: 1.15;
      font-weight: 800;
    }

    .compiled-subtitle {
      margin: 0;
      font-size: 14pt;
      color: #4b5563;
    }

    .compiled-author {
      margin-top: 2rem;
      font-size: 12pt;
      font-weight: 700;
    }

    .compiled-cover {
      min-height: 90vh;

      display: grid;
      place-items: center;

      text-align: center;

      break-after: page;
      page-break-after: always;
    }

    .compiled-cover img {
      max-width: min(100%, 520px);
      max-height: 760px;
      object-fit: contain;
    }

    @media print {
      html,
      body {
        background: white !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      .compiled-document {
        width: 100% !important;
        max-width: 100% !important;
        min-height: 0 !important;

        margin: 0 !important;
        padding: 0 !important;

        box-shadow: none !important;
        overflow: visible !important;
      }

      .no-print {
        display: none !important;
      }
    }
  `;
}

function getPrintOptions() {
  return {
    pageSize: els.printPageSizeSelect?.value || 'letter',
    style: els.printStyleSelect?.value || 'book',
    font: els.printFontSelect?.value || 'garamond',
    margins: els.printMarginsSelect?.value || 'standard',
    autoTitlePage: Boolean(els.printAutoTitlePage?.checked)
  };
}

function getPrintPageSizeCss(pageSize) {
  if (pageSize === 'a4') {
    return 'A4';
  }

  return 'Letter';
}

function getPrintMarginCss(margins) {
  if (margins === 'wide') {
    return '1in';
  }

  if (margins === 'compact') {
    return '0.55in';
  }

  return '0.75in';
}

function getPrintFontCss(font) {
  if (font === 'times') {
    return '"Times New Roman", Times, serif';
  }

  if (font === 'georgia') {
    return 'Georgia, "Times New Roman", serif';
  }

  return 'Garamond, Georgia, "Times New Roman", serif';
}

const COMPILE_PROFILES_KEY = 'naviwriter-compile-profiles';

const BOOK_THEMES = {
  classic: {
    name: 'Classic Novel',
    format: 'print',
    printStyle: 'book',
    font: 'garamond',
    margins: 'standard',
    pageSize: 'letter',
    autoTitlePage: true,
    includeCover: true,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  },

  modern: {
    name: 'Modern YA',
    format: 'print',
    printStyle: 'book',
    font: 'georgia',
    margins: 'standard',
    pageSize: 'letter',
    autoTitlePage: true,
    includeCover: true,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  },

  draft: {
    name: 'Draft Review',
    format: 'print',
    printStyle: 'manuscript',
    font: 'times',
    margins: 'wide',
    pageSize: 'letter',
    autoTitlePage: false,
    includeCover: false,
    includeFrontMatter: false,
    includeBodyMatter: true,
    includeBackMatter: false,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  },

  academic: {
    name: 'Academic / Research',
    format: 'print',
    printStyle: 'compact',
    font: 'georgia',
    margins: 'standard',
    pageSize: 'letter',
    autoTitlePage: true,
    includeCover: false,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: true,
    includeResearch: true,
    includePdf: true,
    includeTitles: true,
    pageBreaks: true
  },

  'large-print': {
    name: 'Large Print',
    format: 'print',
    printStyle: 'book',
    font: 'georgia',
    margins: 'wide',
    pageSize: 'letter',
    autoTitlePage: true,
    includeCover: true,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  }
};

const BUILT_IN_COMPILE_PROFILES = [
  {
    id: 'builtin-default-manuscript',
    builtIn: true,
    name: 'Default Manuscript',
    theme: 'classic',
    format: 'print',
    pageSize: 'letter',
    printStyle: 'book',
    font: 'garamond',
    margins: 'standard',
    autoTitlePage: true,
    includeCover: true,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  },
  {
    id: 'builtin-beta-reader-draft',
    builtIn: true,
    name: 'Beta Reader Draft',
    theme: 'draft',
    format: 'print',
    pageSize: 'letter',
    printStyle: 'manuscript',
    font: 'times',
    margins: 'wide',
    autoTitlePage: false,
    includeCover: false,
    includeFrontMatter: false,
    includeBodyMatter: true,
    includeBackMatter: false,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  },
  {
    id: 'builtin-full-archive',
    builtIn: true,
    name: 'Full Archive',
    theme: 'academic',
    format: 'html',
    pageSize: 'letter',
    printStyle: 'compact',
    font: 'georgia',
    margins: 'standard',
    autoTitlePage: true,
    includeCover: true,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: true,
    includeResearch: true,
    includePdf: true,
    includeTitles: true,
    pageBreaks: true
  },
  {
    id: 'builtin-modern-ya',
    builtIn: true,
    name: 'Modern YA PDF',
    theme: 'modern',
    format: 'print',
    pageSize: 'letter',
    printStyle: 'book',
    font: 'georgia',
    margins: 'standard',
    autoTitlePage: true,
    includeCover: true,
    includeFrontMatter: true,
    includeBodyMatter: true,
    includeBackMatter: true,
    includeNotes: false,
    includeResearch: false,
    includePdf: false,
    includeTitles: true,
    pageBreaks: true
  }
];

async function getUserCompileProfiles() {
  const saved =
    await NaviStorage.getSetting(COMPILE_PROFILES_KEY, []);

  return Array.isArray(saved)
    ? saved
    : [];
}

async function saveUserCompileProfiles(profiles) {
  await NaviStorage.saveSetting(
    COMPILE_PROFILES_KEY,
    Array.isArray(profiles) ? profiles : []
  );
}

async function getAllCompileProfiles() {
  const userProfiles =
    await getUserCompileProfiles();

  return [
    ...BUILT_IN_COMPILE_PROFILES,
    ...userProfiles
  ];
}

async function populateCompileProfileSelect() {
  if (!els.compileProfileSelect) return;

  const profiles =
    await getAllCompileProfiles();

  els.compileProfileSelect.innerHTML =
  '<option value="">Custom / Unsaved</option>';

  profiles.forEach(profile => {
    const option =
      document.createElement('option');

    option.value = profile.id;
    option.textContent = profile.builtIn
      ? `${profile.name}`
      : profile.name;

    els.compileProfileSelect.appendChild(option);
  });
}

function getCurrentCompileProfileSnapshot(name = 'Untitled Profile') {
  const compileOptions =
    getCompileOptions();

  const printOptions =
    getPrintOptions();

  return {
    id: `profile-${Date.now()}`,
    builtIn: false,
    name,
    theme: els.bookThemeSelect?.value || 'classic',

    format: compileOptions.format,
    includeTitles: compileOptions.includeTitles,
    pageBreaks: compileOptions.pageBreaks,
    includeCover: compileOptions.includeCover,
    includeFrontMatter: compileOptions.includeFrontMatter,
    includeBodyMatter: compileOptions.includeBodyMatter,
    includeBackMatter: compileOptions.includeBackMatter,
    includeNotes: compileOptions.includeNotes,
    includeResearch: compileOptions.includeResearch,
    includePdf: compileOptions.includePdf,

    pageSize: printOptions.pageSize,
    printStyle: printOptions.style,
    font: printOptions.font,
    margins: printOptions.margins,
    autoTitlePage: printOptions.autoTitlePage,

    updatedAt: Date.now()
  };
}

function setChecked(el, value) {
  if (el) {
    el.checked = Boolean(value);
  }
}

function setValue(el, value) {
  if (el && value !== undefined && value !== null) {
    el.value = value;
  }
}

function applyCompileProfileToControls(profile) {
  if (!profile) return;

  setValue(els.bookThemeSelect, profile.theme || 'classic');

  setValue(els.compileFormatSelect, profile.format || 'html');

  setChecked(els.compileIncludeTitles, profile.includeTitles);
  setChecked(els.compilePageBreaks, profile.pageBreaks);
  setChecked(els.compileIncludeCover, profile.includeCover);
  setChecked(els.compileIncludeFrontMatter, profile.includeFrontMatter);
  setChecked(els.compileIncludeBodyMatter, profile.includeBodyMatter);
  setChecked(els.compileIncludeBackMatter, profile.includeBackMatter);
  setChecked(els.compileIncludeNotes, profile.includeNotes);
  setChecked(els.compileIncludeResearch, profile.includeResearch);
  setChecked(els.compileIncludePdf, profile.includePdf);

  setValue(els.printPageSizeSelect, profile.pageSize || 'letter');
  setValue(els.printStyleSelect, profile.printStyle || 'book');
  setValue(els.printFontSelect, profile.font || 'garamond');
  setValue(els.printMarginsSelect, profile.margins || 'standard');
  setChecked(els.printAutoTitlePage, profile.autoTitlePage);

  renderCompilePreview();
}

function applyBookTheme(themeKey) {
  const theme =
    BOOK_THEMES[themeKey];

  if (!theme) return;

  const profileLike = {
    theme: themeKey,
    format: theme.format,
    pageSize: theme.pageSize,
    printStyle: theme.printStyle,
    font: theme.font,
    margins: theme.margins,
    autoTitlePage: theme.autoTitlePage,
    includeCover: theme.includeCover,
    includeFrontMatter: theme.includeFrontMatter,
    includeBodyMatter: theme.includeBodyMatter,
    includeBackMatter: theme.includeBackMatter,
    includeNotes: theme.includeNotes,
    includeResearch: theme.includeResearch,
    includePdf: theme.includePdf,
    includeTitles: theme.includeTitles,
    pageBreaks: theme.pageBreaks
  };

  applyCompileProfileToControls(profileLike);

  if (els.compileProfileSelect) {
    els.compileProfileSelect.value = '';
  }

  NaviEditor.setSaveStatus(`Theme applied: ${theme.name}`);
}

async function applySelectedCompileProfile() {
  const profileId =
    els.compileProfileSelect?.value || '';

  if (!profileId) {
    showAppNotice(
      'Choose a compile profile first.',
      'No profile selected'
    );
    return;
  }

  const profiles =
    await getAllCompileProfiles();

  const profile =
    profiles.find(item => item.id === profileId);

  if (!profile) {
    showAppNotice(
      'That compile profile could not be found.',
      'Profile missing'
    );
    return;
  }

  applyCompileProfileToControls(profile);
  NaviEditor.setSaveStatus(`Profile applied: ${profile.name}`);
}

async function saveCurrentCompileProfile() {
  const name =
    await openTextInputModal({
      title: 'Save Compile Profile',
      message: 'Name this export setup.',
      label: 'Profile name',
      defaultValue: 'New Compile Profile',
      placeholder: 'Beta Reader Draft',
      submitText: 'Save Profile'
    });

  if (!name || !name.trim()) return;

  const userProfiles =
    await getUserCompileProfiles();

  const cleanName =
    name.trim();

  const existingIndex =
    userProfiles.findIndex(profile => {
      return profile.name.toLowerCase() === cleanName.toLowerCase();
    });

  const nextProfile =
    getCurrentCompileProfileSnapshot(cleanName);

  if (existingIndex >= 0) {
    const ok =
      await openConfirmModal({
        title: 'Replace Profile?',
        message: `A profile named "${cleanName}" already exists. Replace it?`,
        confirmText: 'Replace',
        cancelText: 'Cancel',
        danger: false
      });

    if (!ok) return;

    nextProfile.id = userProfiles[existingIndex].id;
    userProfiles[existingIndex] = nextProfile;
  } else {
    userProfiles.push(nextProfile);
  }

  await saveUserCompileProfiles(userProfiles);
  await populateCompileProfileSelect();

  if (els.compileProfileSelect) {
    els.compileProfileSelect.value = nextProfile.id;
  }

  NaviEditor.setSaveStatus(`Profile saved: ${cleanName}`);
}

async function deleteSelectedCompileProfile() {
  const profileId =
    els.compileProfileSelect?.value || '';

  if (!profileId) {
    showAppNotice(
      'Choose a saved user profile first.',
      'No profile selected'
    );
    return;
  }

  const allProfiles =
    await getAllCompileProfiles();

  const selected =
    allProfiles.find(profile => profile.id === profileId);

  if (!selected) {
    showAppNotice(
      'That compile profile could not be found.',
      'Profile missing'
    );
    return;
  }

  if (selected.builtIn) {
    showAppNotice(
      'Built-in profiles cannot be deleted. Save your own copy if you want a custom version.',
      'Built-in profile'
    );
    return;
  }

  const ok =
    await openConfirmModal({
      title: 'Delete Compile Profile',
      message: `Delete "${selected.name}"?`,
      confirmText: 'Delete',
      cancelText: 'Cancel',
      danger: true
    });

  if (!ok) return;

  const userProfiles =
    await getUserCompileProfiles();

  const nextProfiles =
    userProfiles.filter(profile => profile.id !== profileId);

  await saveUserCompileProfiles(nextProfiles);
  await populateCompileProfileSelect();

  if (els.compileProfileSelect) {
    els.compileProfileSelect.value = '';
  }

  NaviEditor.setSaveStatus(`Profile deleted: ${selected.name}`);
}

function compiledHasTitlePage(compiledDoc) {
  return Boolean(
    compiledDoc?.compiledFrom?.some(item => {
      const title = String(item.title || '').toLowerCase();
      const type = item.docType || '';

      return (
        type === 'front-matter' &&
        (
          title.includes('title page') ||
          title === 'title' ||
          title.includes('book title')
        )
      );
    })
  );
}

function buildAutoTitlePageHtml(compiledDoc) {
  const meta = compiledDoc.metadata || {};

  const title =
    meta.title ||
    compiledDoc.title ||
    'Untitled Book';

  const subtitle =
    meta.subtitle || '';

  const author =
    meta.author || '';

  return `
    <section class="print-auto-title-page">
      <div>
        <h1>${escapeHtml(title)}</h1>
        ${subtitle ? `<p class="print-subtitle">${escapeHtml(subtitle)}</p>` : ''}
        ${author ? `<p class="print-author">${escapeHtml(author)}</p>` : ''}
      </div>
    </section>
  `;
}

function injectAutoTitlePage(compiledDoc, html) {
  const titlePageHtml =
    buildAutoTitlePageHtml(compiledDoc);

  /*
    If a cover exists first, place the auto title page after the cover.
    Otherwise, place it at the start.
  */
  const coverMatch =
    String(html || '').match(
      /^\s*<section class="compiled-cover">[\s\S]*?<\/section>\s*(?:<div[^>]*><\/div>\s*)?/i
    );

  if (coverMatch) {
    return (
      coverMatch[0] +
      titlePageHtml +
      String(html || '').slice(coverMatch[0].length)
    );
  }

  return titlePageHtml + html;
}

function getCompileScope() {
  const selected =
    document.querySelector('input[name="compileScope"]:checked');

  return selected?.value || 'current';
}

function getCompileOptions() {
  return {
    scope: getCompileScope(),
    format: els.compileFormatSelect?.value || 'html',
    includeTitles: Boolean(els.compileIncludeTitles?.checked),
    pageBreaks: Boolean(els.compilePageBreaks?.checked),
    includeCover: Boolean(els.compileIncludeCover?.checked),
    includeFrontMatter: Boolean(els.compileIncludeFrontMatter?.checked),
    includeBodyMatter: Boolean(els.compileIncludeBodyMatter?.checked),
    includeBackMatter: Boolean(els.compileIncludeBackMatter?.checked),
    includeNotes: Boolean(els.compileIncludeNotes?.checked),
    includeResearch: Boolean(els.compileIncludeResearch?.checked),
    includePdf: Boolean(els.compileIncludePdf?.checked)
  };
}

function getCompileMatterRank(doc) {
  const type = doc?.docType || 'general';

  if (type === 'cover') return -1;
  if (type === 'front-matter') return 0;

  if (type === 'manuscript') return 1;
  if (type === 'body-matter') return 2;
  if (type === 'chapter') return 2;
  if (type === 'general') return 2;

  if (type === 'notes') return 3;
  if (type === 'research') return 3;
  if (type === 'pdf') return 3;

  if (type === 'back-matter') return 4;

  return 3;
}

function sortDocsForCompile(docs) {
  return docs.slice().sort((a, b) => {
    const rankDifference = getCompileMatterRank(a) - getCompileMatterRank(b);
    return rankDifference || compareDocumentsByAuthoritativeOrder(a, b);
  });
}


function shouldIncludeDocInCompile(doc, options) {
  const type = doc?.docType || 'general';

  if (type === 'cover' && !options.includeCover) {
    return false;
  }

  if (type === 'front-matter' && !options.includeFrontMatter) {
    return false;
  }

  if (
    (
      type === 'manuscript' ||
      type === 'chapter' ||
      type === 'body-matter' ||
      type === 'general'
    ) &&
    !options.includeBodyMatter
  ) {
    return false;
  }

  if (type === 'back-matter' && !options.includeBackMatter) {
    return false;
  }

  if (type === 'notes' && !options.includeNotes) {
    return false;
  }

  if (type === 'research' && !options.includeResearch) {
    return false;
  }

  if (type === 'pdf' && !options.includePdf) {
    return false;
  }

  return true;
}

function compilePageBreakHtml() {
  return '<div style="break-after: page; page-break-after: always;"></div>';
}

function compileDocTitleHtml(doc) {
  const title = doc?.title || 'Untitled Document';

  return `<h1>${escapeHtml(title)}</h1>`;
}

function compileDocHtml(doc, options, index, total) {
  const parts = [];

  const type = doc?.docType || 'general';

  if (type === 'cover') {
    parts.push(`
      <section class="compiled-cover">
        ${getExportSafeDocumentContent(doc)}
      </section>
    `);

    if (options.pageBreaks && index < total - 1) {
      parts.push(compilePageBreakHtml());
    }

    return parts.join('\n');
  }

  if (type === 'front-matter') {
    parts.push(`
      <section class="compiled-front-matter">
        ${getExportSafeDocumentContent(doc)}
      </section>
    `);

    if (options.pageBreaks && index < total - 1) {
      parts.push(compilePageBreakHtml());
    }

    return parts.join('\n');
  }

  if (type === 'back-matter') {
    parts.push(`
      <section class="compiled-back-matter">
        ${getExportSafeDocumentContent(doc)}
      </section>
    `);

    if (options.pageBreaks && index < total - 1) {
      parts.push(compilePageBreakHtml());
    }

    return parts.join('\n');
  }

  const shouldAutoTitle =
    options.includeTitles &&
    type !== 'front-matter' &&
    type !== 'back-matter' &&
    type !== 'cover';

  parts.push('<section class="compiled-body-matter">');

  if (shouldAutoTitle) {
    parts.push(compileDocTitleHtml(doc));
  }

  parts.push(getExportSafeDocumentContent(doc));
  parts.push('</section>');

  if (options.pageBreaks && index < total - 1) {
    parts.push(compilePageBreakHtml());
  }

  return parts.join('\n');
}

function htmlToPlainTextForCompile(html = '') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html || '';

  return wrapper.innerText || wrapper.textContent || '';
}

function htmlToMarkdownForCompile(html = '') {
  if (window.NaviExport?.htmlToMarkdown) {
    return NaviExport.htmlToMarkdown(html);
  }

  const wrapper = document.createElement('div');
  wrapper.innerHTML = html || '';

  return wrapper.innerText || wrapper.textContent || '';
}

async function resolveCompileSelection(options = getCompileOptions()) {
  if (!currentDocumentId) return NaviDocumentTree.resolveScope([], '', options.scope, () => false);
  await saveCurrentDocument({manual:true});
  const all = await NaviStorage.getAllDocuments();
  return NaviDocumentTree.resolveScope(all, currentDocumentId, options.scope, doc => shouldIncludeDocInCompile(doc, options));
}

async function getCompileDocuments(options) {
  const resolution = await resolveCompileSelection(options);
  return resolution.includedNodes.map(node => node.doc);
}


async function buildCompiledDocument(options) {
  const docs =
    await getCompileDocuments(options);

  const metadata =
    await getProjectMetadata();

  if (!docs.length) {
    throw new Error('No documents matched the compile options.');
  }

  const title =
    options.scope === 'current'
      ? docs[0].title || 'Compiled Document'
      : metadata.title || `${docs[0].title || 'Project'} Compile`;

  const html =
    docs
      .map(doc => {
        return buildCompiledSectionHtml(doc, {
          includeTitles: options.includeTitles,
          pageBreaks: options.pageBreaks
        });
      })
      .join('\n');

  const plainText =
    htmlToPlainTextForCompile(html);

  return {
    id: `compile-${Date.now()}`,
    title,
    docType: 'compiled',
    content: html,
    plainText,
    wordCount: NaviEditor.countWords(plainText),
    charCount: plainText.length,
    metadata,
    compiledFrom: docs.map(doc => ({
      id: doc.id,
      title: doc.title || 'Untitled Document',
      docType: doc.docType || 'general'
    }))
  };
}
  
  function getReadableDocType(doc) {
  const type = doc?.docType || 'doc';

  if (type === 'cover') return 'Cover';
  if (type === 'manuscript') return 'Manuscript';
  if (type === 'chapter') return 'Chapter';
  if (type === 'body-matter') return 'Body Matter';
  if (type === 'front-matter') return 'Front Matter';
  if (type === 'back-matter') return 'Back Matter';
  if (type === 'notes') return 'Notes';
  if (type === 'research') return 'Research';
  if (type === 'pdf') return 'PDF';
  if (type === 'reference-view') return `Reference View · ${String(doc?.sourceOriginalName || doc?.sourceMimeType || 'File').split('.').pop().toUpperCase()}`;
  if (type === 'general') return 'General';

  return 'Doc';
}

function stripInlineCommentMarksFromElement(root) {
  if (!root) {
    return;
  }

  root
    .querySelectorAll('[data-inline-comment-id], .inline-comment-mark')
    .forEach(mark => {
      const parent =
        mark.parentNode;

      if (!parent) {
        return;
      }

      while (mark.firstChild) {
        parent.insertBefore(
          mark.firstChild,
          mark
        );
      }

      mark.remove();
    });
}

function getExportSafeHtml(html = '') {
  const wrapper =
    document.createElement('div');

  wrapper.innerHTML =
    html || '';

  stripInlineCommentMarksFromElement(wrapper);

  /*
    Defensive cleanup in case any class/data survives on nested elements.
  */
  wrapper
    .querySelectorAll('[data-inline-comment-id]')
    .forEach(node => {
      node.removeAttribute('data-inline-comment-id');
    });

  wrapper
    .querySelectorAll('.inline-comment-mark, .inline-comment-jump-highlight')
    .forEach(node => {
      node.classList.remove(
        'inline-comment-mark',
        'inline-comment-jump-highlight'
      );
    });

  return wrapper.innerHTML;
}

function getExportSafeDocumentContent(doc) {
  return getExportSafeHtml(
    doc?.content || '<p></p>'
  );
}

function getExportSafeCurrentEditorHtml() {
  const currentHtml = NaviEditor.getEditorHtml();
  return getExportSafeHtml(currentHtml || '<p></p>');
}

async function renderCompilePreview() {
  if (!els.compilePreviewList) return;
  const options = getCompileOptions();
  try {
    const resolution = await resolveCompileSelection(options);
    const showExcluded = Boolean(document.getElementById('compileShowExcluded')?.checked);
    const rows = showExcluded ? resolution.allNodes : resolution.includedNodes;
    const summary = document.getElementById('compileScopeSummary');
    const labels = {current:'Current Document',branch:'Current Branch',root:'Current Root Tree',project:'Entire Project'};
    if (summary) summary.innerHTML = `<strong>${labels[resolution.scope] || 'Export Scope'}</strong><span>${resolution.counts.documents} document${resolution.counts.documents===1?'':'s'} · ${resolution.counts.words} words · ${resolution.counts.excluded} excluded${resolution.scope==='project'?` · ${resolution.counts.topLevelTrees} top-level tree${resolution.counts.topLevelTrees===1?'':'s'}`:''}</span>`;
    if (!rows.length) {
      els.compilePreviewList.innerHTML = '<div class="empty-note">No documents matched this scope and the current filters.</div>';
      return;
    }
    els.compilePreviewList.innerHTML = '<div class="compile-order-notice">This exact ordered selection is supplied to PDF, DOCX, EPUB, ODT, HTML, Markdown, TXT, RTF, Fountain, and FDX.</div>';
    for (const node of rows) {
      const item = document.createElement('article');
      item.className = `compile-preview-item native-compile-tree-row${node.included===false?' is-excluded':''}`;
      item.dataset.docId = node.id;
      item.dataset.treeDepth = String(node.scopeDepth);
      item.style.setProperty('--compile-tree-depth', String(node.scopeDepth));
      item.setAttribute('role','treeitem');
      item.setAttribute('aria-level',String(node.scopeDepth + 1));
      const words = Number(node.doc.wordCount || 0);
      item.innerHTML = `<span class="compile-order-handle doc-type-icon" aria-hidden="true">${escapeHtml(getDocumentTypeIcon(node.doc))}</span><span class="compile-tree-number">${escapeHtml(node.scopeOutline || '1')}</span><span class="compile-tree-copy"><strong>${escapeHtml(node.doc.title || 'Untitled Document')}</strong><small>${escapeHtml(getReadableDocType(node.doc))} · ${words} ${words===1?'word':'words'}${node.descendantCount?` · ${node.descendantCount} descendant${node.descendantCount===1?'':'s'}`:''}${node.included===false?` · ${escapeHtml(node.exclusionReason)}`:''}</small></span>`;
      if (node.included !== false) wireDocumentOrderDrag(item,node.doc);
      els.compilePreviewList.appendChild(item);
    }
    const footer=document.createElement('div');footer.className='compile-preview-footer';footer.textContent=`${resolution.counts.documents} selected · ${resolution.counts.descendants} descendants · ${resolution.counts.words} words · ${resolution.counts.excluded} excluded`;els.compilePreviewList.appendChild(footer);
  } catch (error) {
    console.error('Compile preview failed:', error);
    els.compilePreviewList.innerHTML = '<div class="empty-note">Could not build preview.</div>';
  }
}

async function openCompileModal() {
  if (!els.compileModal) return;

  els.compileModal.classList.remove('hidden');

  await loadProjectMetadataFields();
  await populateCompileProfileSelect();

  wireCompileOptionPreviewEvents();
  renderCompilePreview();
}

function closeCompileModal() {
  if (!els.compileModal) return;

  els.compileModal.classList.add('hidden');
}

function downloadCompiledTextFile(compiledDoc, extension, type, content) {
  const blob = new Blob([content], {
    type
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');

  link.href = url;
  link.download = `${safeFileName(compiledDoc.title)}.${extension}`;
  link.click();

  URL.revokeObjectURL(url);
}

function buildCompiledPrintCss({
  pageSize = 'Letter',
  margin = '0.75in',
  fontFamily = 'Garamond, Georgia, "Times New Roman", serif',
  style = 'book'
} = {}) {
  const isManuscript =
    style === 'manuscript';

  const isCompact =
    style === 'compact';

  const baseFontSize =
    isManuscript ? '12pt' : isCompact ? '10.8pt' : '11.5pt';

  const lineHeight =
    isManuscript ? '2' : isCompact ? '1.45' : '1.62';

  const paragraphIndent =
    isManuscript ? '0.5in' : '1.35em';

  const paragraphSpacing =
    isManuscript ? '0' : '0.15em';

  return `
    @page {
      size: ${pageSize};
      margin: ${margin};
    }

    * {
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #111827;
    }

    body {
      font-family: ${fontFamily};
      font-size: ${baseFontSize};
      line-height: ${lineHeight};
    }

    .print-document {
      width: 100%;
      margin: 0 auto;
    }

    h1,
    h2,
    h3 {
      font-family: ${isManuscript
        ? 'Arial, Helvetica, sans-serif'
        : fontFamily};
      line-height: 1.22;
      break-after: avoid;
      page-break-after: avoid;
      color: #111827;
    }

    h1 {
      text-align: center;
      font-size: ${isManuscript ? '16pt' : '20pt'};
      margin: ${isManuscript ? '0 0 0.35in' : '0 0 0.45in'};
      font-weight: ${isManuscript ? '700' : '600'};
      letter-spacing: ${isManuscript ? '0' : '0.02em'};
    }

    h2 {
      font-size: ${isManuscript ? '14pt' : '15pt'};
      margin: 0.28in 0 0.16in;
    }

    h3 {
      font-size: ${isManuscript ? '12.5pt' : '13pt'};
      margin: 0.22in 0 0.12in;
    }

    p {
      margin: 0 0 ${paragraphSpacing};
      text-align: ${isManuscript ? 'left' : 'justify'};
      hyphens: auto;
      orphans: 2;
      widows: 2;
    }

    .compiled-body-matter p + p,
    .compiled-front-matter p + p,
    .compiled-back-matter p + p {
      text-indent: ${paragraphIndent};
    }

    h1 + p,
    h2 + p,
    h3 + p,
    blockquote + p,
    figure + p,
    table + p,
    ul + p,
    ol + p {
      text-indent: 0 !important;
    }

    .compiled-cover,
    .print-auto-title-page,
    .title-page {
      min-height: 90vh;
      display: grid;
      place-items: center;
      text-align: center;
      break-after: page;
      page-break-after: always;
    }

    .print-auto-title-page h1,
    .title-page h1 {
      font-size: ${isManuscript ? '20pt' : '28pt'};
      margin-bottom: 0.2in;
      letter-spacing: 0.03em;
    }

    .print-subtitle,
    .book-subtitle {
      font-size: ${isManuscript ? '13pt' : '15pt'};
      color: #374151;
      margin-top: 0;
      text-align: center;
      text-indent: 0 !important;
    }

    .print-author,
    .book-author {
      margin-top: 0.55in;
      font-size: ${isManuscript ? '12pt' : '13.5pt'};
      font-weight: 600;
      text-align: center;
      text-indent: 0 !important;
    }

    .compiled-cover figure,
    .cover-page {
      margin: 0;
      display: grid;
      justify-items: center;
      gap: 0.18in;
    }

    .compiled-cover img,
    .cover-page img {
      max-width: 100%;
      max-height: 8.6in;
      object-fit: contain;
      display: block;
      margin: 0 auto;
    }

    .compiled-cover figcaption,
    .cover-page figcaption {
      font-size: 9pt;
      color: #6b7280;
      text-align: center;
    }

    .compiled-front-matter,
    .compiled-body-matter,
    .compiled-back-matter {
      break-after: page;
      page-break-after: always;
    }

    .compiled-front-matter h1,
    .compiled-back-matter h1 {
      margin-top: 0;
    }

    blockquote {
      margin: 0.25in 0;
      padding-left: 0.18in;
      border-left: 3px solid #d1d5db;
      color: #374151;
      font-style: italic;
    }

    blockquote p {
      text-indent: 0 !important;
      text-align: left;
    }

    ul,
    ol {
      margin-top: 0.12in;
      margin-bottom: 0.18in;
      padding-left: 0.3in;
    }

    li {
      margin-bottom: 0.04in;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin: 0.22in 0;
      break-inside: avoid;
      page-break-inside: avoid;
      font-size: 10pt;
    }

    th,
    td {
      border: 1px solid #9ca3af;
      padding: 6px 8px;
      vertical-align: top;
    }

    th {
      background: #f3f4f6;
      font-weight: 700;
    }

    img {
      max-width: 100%;
      height: auto;
      break-inside: avoid;
      page-break-inside: avoid;
    }

    figure {
      break-inside: avoid;
      page-break-inside: avoid;
    }

    hr {
      border: 0;
      border-top: 1px solid #d1d5db;
      margin: 0.3in auto;
      width: 40%;
    }

    .endnotes {
      break-before: page;
      page-break-before: always;
    }

    @media print {
      body {
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }

      a {
        color: inherit;
        text-decoration: none;
      }

      .compiled-cover,
      .print-auto-title-page,
      .title-page {
        min-height: calc(100vh - 1in);
      }
    }
  `;
}

async function printCompiledDocument(compiledDoc) {
  const printOptions =
    getPrintOptions();

  const printWindow =
    window.open('', '_blank');

  if (!printWindow) {
    showAppNotice(
      'Popup blocked. Allow popups to print compiled document.'
    );
    return;
  }

  let printContent =
    compiledDoc.content || '';

  if (
    printOptions.autoTitlePage &&
    !compiledHasTitlePage(compiledDoc)
  ) {
    printContent =
      injectCompiledTitlePage(compiledDoc, printContent);
  }

  const printCss =
    buildPrintThemeCss(printOptions);

  printWindow.document.open();

  printWindow.document.write(`
    <!doctype html>
    <html>
      <head>
        <meta charset="utf-8" />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1"
        />

        <title>${escapeHtml(compiledDoc.title || 'NaviWriter Print')}</title>

        <style>
          ${printCss}
        </style>
      </head>

      <body>
        <main class="compiled-document">
          ${printContent}
        </main>
      </body>
    </html>
  `);

  printWindow.document.close();
  printWindow.focus();

  setTimeout(() => {
    printWindow.print();
  }, 120);
}

async function runCompileExport() {
  const options = getCompileOptions();

  try {
    const compiledDoc = await buildCompiledDocument(options);

    if (options.format === 'html') {
      if (window.NaviExport?.exportHtml) {
        NaviExport.exportHtml(compiledDoc);
      } else {
        downloadCompiledTextFile(
          compiledDoc,
          'html',
          'text/html',
          compiledDoc.content || ''
        );
      }

      NaviEditor.setSaveStatus('Compiled HTML exported');
      return;
    }

    if (options.format === 'txt') {
      if (window.NaviExport?.exportTxt) {
        NaviExport.exportTxt(compiledDoc);
      } else {
        downloadCompiledTextFile(
          compiledDoc,
          'txt',
          'text/plain',
          compiledDoc.plainText || ''
        );
      }

      NaviEditor.setSaveStatus('Compiled TXT exported');
      return;
    }

    if (options.format === 'markdown') {
      const markdown =
        window.NaviExport?.htmlToMarkdown
          ? NaviExport.htmlToMarkdown(compiledDoc.content || '')
          : htmlToMarkdownForCompile(compiledDoc.content || '');

      downloadCompiledTextFile(
        compiledDoc,
        'md',
        'text/markdown',
        markdown
      );

      NaviEditor.setSaveStatus('Compiled Markdown exported');
      return;
    }

    if (options.format === 'docx') {
      if (!window.NaviExport?.exportDocx) {
        showAppNotice('DOCX export is not available.');
        return;
      }

      await NaviExport.exportDocx(compiledDoc);
      NaviEditor.setSaveStatus('Compiled DOCX exported');
      return;
    }

    if (options.format === 'print') {
  await printCompiledDocument(compiledDoc);
  NaviEditor.setSaveStatus('Compiled print view opened');
  return;
}
  } catch (error) {
    console.error('Compile failed:', error);
    await showAppError(
  error?.message || String(error),
  'Compile failed'
);
    NaviEditor.setSaveStatus('Compile error');
  }
}

function isMatterPresetType(type) {
  return (
    type === 'front-matter' ||
    type === 'body-matter' ||
    type === 'back-matter'
  );
}

function getSelectedBoardItems() {
  return currentBoardData.items.filter(item => {
    return selectedBoardItemIds.has(item.id);
  });
}

function getSelectedBoardItem() {
  return getSelectedBoardItems()[0] || null;
}

function getNextBoardZIndex() {
  return currentBoardData.items.reduce((max, item) => {
    return Math.max(max, Number(item.zIndex || 2));
  }, 2) + 1;
}

function getLowestBoardZIndex() {
  return currentBoardData.items.reduce((min, item) => {
    return Math.min(min, Number(item.zIndex || 2));
  }, 2) - 1;
}

function duplicateSelectedBoardItem() {
  const selectedItems = getSelectedBoardItems();

  if (!selectedItems.length) {
    showAppNotice(
      'Select one or more board cards first.',
      'No card selected'
    );
    return;
  }

  pushBoardUndoState();

  const selectedIds =
    new Set(selectedItems.map(item => item.id));

  const idMap =
    new Map();

  const duplicates = [];
  let nextZ = getNextBoardZIndex();

  selectedItems.forEach(selected => {
    const nextId =
      crypto.randomUUID();

    idMap.set(selected.id, nextId);

    const duplicate = {
      ...JSON.parse(JSON.stringify(selected)),
      id: nextId,
      x: Number(selected.x || 0) + 28,
      y: Number(selected.y || 0) + 28,
      zIndex: nextZ
    };

    nextZ += 1;
    duplicates.push(duplicate);
  });

  const duplicatedConnectors =
    currentBoardData.connectors
      .filter(connector => {
        return (
          selectedIds.has(connector.fromId) &&
          selectedIds.has(connector.toId)
        );
      })
      .map(connector => {
        return {
          ...JSON.parse(JSON.stringify(connector)),
          id: crypto.randomUUID(),
          fromId: idMap.get(connector.fromId),
          toId: idMap.get(connector.toId)
        };
      });

  currentBoardData.items.push(...duplicates);
  currentBoardData.connectors.push(...duplicatedConnectors);

  selectedBoardItemIds =
    new Set(duplicates.map(item => item.id));

  activeBoardItemId =
    duplicates[0]?.id || null;

  renderBoard();
  scheduleAutosave();
}

function bringSelectedBoardItemToFront() {
  const selectedItems = getSelectedBoardItems();

  if (!selectedItems.length) {
    showAppNotice(
      'Select one or more board cards first.',
      'No card selected'
    );
    return;
  }

  pushBoardUndoState();

  let zIndex = getNextBoardZIndex();

  selectedItems.forEach(item => {
    item.zIndex = zIndex;
    zIndex += 1;
  });

  renderBoard();
  scheduleAutosave();
}

function sendSelectedBoardItemToBack() {
  const selectedItems = getSelectedBoardItems();

  if (!selectedItems.length) {
    showAppNotice(
      'Select one or more board cards first.',
      'No card selected'
    );
    return;
  }

  pushBoardUndoState();

  let zIndex = getLowestBoardZIndex();

  selectedItems.forEach(item => {
    item.zIndex = zIndex;
    zIndex -= 1;
  });

  renderBoard();
  scheduleAutosave();
}

function adjustSelectedBoardFontSize(delta) {
  const selectedItems = getSelectedBoardItems();

  if (!selectedItems.length) {
    showAppNotice(
      'Select one or more board cards first.',
      'No card selected'
    );
    return;
  }

  pushBoardUndoState();

  selectedItems.forEach(item => {
    const current =
      Number(item.fontSize || 13);

    item.fontSize =
      Math.max(9, Math.min(24, current + delta));
  });

  renderBoard();
  scheduleAutosave();
}

function resetSelectedBoardFontSize() {
  const selectedItems = getSelectedBoardItems();

  if (!selectedItems.length) {
    showAppNotice(
      'Select one or more board cards first.',
      'No card selected'
    );
    return;
  }

  pushBoardUndoState();

  selectedItems.forEach(item => {
    item.fontSize = 13;
  });

  renderBoard();
  scheduleAutosave();
}

function resetBoardZoom() {
  setBoardZoom(1);
}

function wireCompileOptionPreviewEvents() {
  document
    .querySelectorAll(
      [
        'input[name="compileScope"]',
        '#compileIncludeTitles',
        '#compilePageBreaks',
        '#compileIncludeFrontMatter',
        '#compileIncludeBackMatter',
        '#compileIncludeNotes',
        '#compileIncludeResearch',
        '#compileIncludeCover',
'#compileIncludeBodyMatter',
        '#compileIncludePdf'
      ].join(', ')
    )
    .forEach(control => {
      control.onchange = renderCompilePreview;
    });

  if (els.compileFormatSelect) {
    els.compileFormatSelect.onchange = renderCompilePreview;
  }
}

function syncOutlinerViewModeClass() {
  const view =
    els.outlinerViewSelect?.value || 'table';

  const isRelationshipView =
    view === 'relationships';

  const modalShell =
    els.outlinerModal;

  const modalPanel =
    els.outlinerModal?.querySelector('.outliner-modal');

  [modalShell, modalPanel]
    .filter(Boolean)
    .forEach(node => {
      node.classList.toggle(
        'relationship-view',
        isRelationshipView
      );

      node.classList.toggle(
        'table-view',
        !isRelationshipView
      );
    });
}

function closeTopMenus(exceptMenu = null) {
  document
    .querySelectorAll('.top-menu[open]')
    .forEach(menu => {
      if (menu !== exceptMenu) {
        menu.removeAttribute('open');
      }
    });
}

function setupTopMenus() {
  const menus =
    Array.from(
      document.querySelectorAll('.top-menu')
    );

  if (!menus.length) {
    return;
  }

  menus.forEach(menu => {
    if (menu.dataset.topMenuReady === 'true') {
      return;
    }

    menu.addEventListener('toggle', () => {
      if (menu.open) {
        closeTopMenus(menu);
      }
    });

    menu
      .querySelectorAll('.top-menu-panel button')
      .forEach(button => {
        button.addEventListener('click', () => {
          menu.removeAttribute('open');
        });
      });

    menu.dataset.topMenuReady = 'true';
  });

  document.addEventListener('click', event => {
    if (!event.target.closest('.top-actions-clean')) {
      closeTopMenus();
    }
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      closeTopMenus();
    }
  });
}

function closeBoardMoreMenu() {
  document
    .querySelectorAll('.board-more-menu[open]')
    .forEach(menu => {
      menu.removeAttribute('open');
    });
}

async function editBoardConnector(connectorId){const connector=currentBoardData.connectors.find(item=>item.id===connectorId);if(!connector)return;const result=await openBoardConnectionModal(connector);if(!result)return;pushBoardUndoState();Object.assign(connector,result);renderBoard();scheduleAutosave();}
async function deleteEditingBoardConnector(){if(!editingBoardConnectorId)return;const id=editingBoardConnectorId,connector=currentBoardData.connectors.find(item=>item.id===id);if(!connector)return;const choice=await openChoiceModal({title:'Delete Board Relationship',subtitle:`Remove “${connector.label||'related'}” from this board?`,options:[{value:'delete',icon:'×',title:'Delete relationship',description:'The connector will be removed. Board Undo can restore it.'},{value:'cancel',icon:'←',title:'Keep relationship',description:'Return without changing the board.'}]});if(choice!=='delete')return;pushBoardUndoState();currentBoardData.connectors=currentBoardData.connectors.filter(item=>item.id!==id);resolveBoardConnectionModal(null);renderBoard();scheduleAutosave();}
async function createRetainedSourceDocument(file,previewHtml=''){if(!file)return null;const asset=await NaviAssets.addFile(file,{kind:'original-file',sourceFormat:String(file.name.split('.').pop()||'').toLowerCase()});const existing=documentsCache.find(item=>item.docType==='reference-view'&&item.sourceAttachmentId===asset.id);if(existing)return existing;const doc=NaviStorage.createBlankDocument(file.name.replace(/\.[^.]+$/,'')||'Retained Source');Object.assign(doc,{docType:'reference-view',type:'reference-view',sourceAttachmentId:asset.id,sourceOriginalName:asset.originalName,sourceMimeType:asset.mimeType,referenceMaterial:true,referenceReadOnly:true,referencePreviewHtml:String(previewHtml||''),sourceViewerState:{page:1,zoom:1,fit:'width'},content:'<p></p>',plainText:'',wordCount:0,charCount:asset.originalName.length});return NaviStorage.saveDocument(doc);}
async function renderRetainedPdfPage(){if(!retainedSourcePdf||!els.retainedSourceStage)return;const canvas=els.retainedSourceStage.querySelector('canvas.retained-source-pdf-canvas');if(!canvas)return;retainedSourcePdfPage=Math.max(1,Math.min(retainedSourcePdf.numPages,retainedSourcePdfPage));const input=document.getElementById('retainedSourcePageInput'),count=document.getElementById('retainedSourcePageCount');if(input){input.max=String(retainedSourcePdf.numPages);input.value=String(retainedSourcePdfPage);}if(count)count.textContent=`/ ${retainedSourcePdf.numPages}`;canvas.classList.add('is-rendering');try{const width=Math.max(320,els.retainedSourceStage.clientWidth-44);await NaviPdfViewer.renderPage(retainedSourcePdf,retainedSourcePdfPage,canvas,{fit:retainedSourceViewerZoom===1?'width':'custom',width,height:Math.max(220,els.retainedSourceStage.clientHeight-44),scale:retainedSourceViewerZoom===1?null:retainedSourceViewerZoom,rotation:retainedSourcePdfRotation,gutter:44});}finally{canvas.classList.remove('is-rendering');}}
async function openRetainedSourceViewer(assetId,documentId=null){const asset=await NaviStorage.getAsset(assetId);if(!asset?.blob||!els.retainedSourceViewerModal||!els.retainedSourceStage)return;retainedSourceViewerAssetId=asset.id;const readerShell=els.retainedSourceViewerModal.querySelector('.retained-source-viewer');if(readerShell){readerShell.dataset.readerFilename=asset.originalName||'';readerShell.dataset.readerFormat=String(asset.originalName||'').split('.').pop().toLowerCase();readerShell.dataset.readerDocumentId=documentId||'';readerShell.dataset.readerAssetId=asset.id||'';}const header=els.retainedSourceViewerModal.querySelector('.retained-source-viewer>header');if(header){header.classList.add('retained-source-head-v4');const actions=header.querySelector('.retained-source-actions');actions?.classList.add('retained-source-controls-v4');const promote=actions?.querySelector('#promoteRetainedSourceBtn');if(promote){promote.classList.add('retained-promote-v4');const already=Boolean(documentId||documentsCache.some(doc=>doc.sourceAttachmentId===asset.id));promote.textContent=already?'In Documents':'Add to Documents';promote.disabled=already;}actions?.querySelector('#closeRetainedSourceViewerBtn')?.classList.add('retained-close-v4');}retainedSourceViewerDocumentId=documentId;retainedSourceViewerZoom=1;retainedSourcePdf=null;retainedSourcePdfPage=1;retainedSourcePdfRotation=0;els.retainedSourceViewerTitle.textContent=asset.originalName||'Retained Source';els.retainedSourceViewerMeta.textContent=`${asset.mimeType||'File'} · ${Math.ceil((asset.byteLength||asset.blob.size||0)/1024).toLocaleString()} KB`;const mime=String(asset.mimeType||asset.blob.type||'');const continuous=!mime.startsWith('image/')&&mime!=='application/pdf'&&!/\.pdf$/i.test(asset.originalName||'');const actions=els.retainedSourceViewerModal.querySelector('.retained-source-actions');if(actions){actions.classList.toggle('continuous-viewer-actions',continuous);for(const id of ['retainedSourcePrevPageBtn','retainedSourceNextPageBtn','retainedSourcePageInput','retainedSourcePageCount','retainedSourceRotateBtn'])document.getElementById(id)?.classList.toggle('hidden',continuous);document.getElementById('retainedSourceFitBtn').textContent=continuous?'Reflow':'Fit Width';}els.retainedSourceStage.innerHTML='';let node;if(mime.startsWith('image/')){const url=await NaviAssets.objectUrl(asset.id);node=document.createElement('img');node.src=url;node.alt=asset.originalName||'Retained image';node.dataset.viewerKind='image';}else if(mime==='application/pdf'||/\.pdf$/i.test(asset.originalName||'')){node=document.createElement('canvas');node.className='retained-source-content retained-source-pdf-canvas';els.retainedSourceStage.appendChild(node);els.retainedSourceViewerModal.classList.remove('hidden');try{retainedSourcePdf=await NaviPdfViewer.loadBlob(asset.blob);els.retainedSourceStage._naviReaderGoToPage=page=>{retainedSourcePdfPage=Math.max(1,Math.min(retainedSourcePdf.numPages,Number(page)||1));renderRetainedPdfPage();};await renderRetainedPdfPage();document.getElementById('retainedSourceZoomLabel').textContent=`${Math.round(retainedSourceViewerZoom*100)}%`;}catch(error){els.retainedSourceStage.innerHTML=`<div class="retained-source-unsupported"><strong>PDF rendering failed.</strong><p>${escapeHtml(error?.message||String(error))}</p><p>The original remains retained and downloadable.</p></div>`;NaviDiagnostics?.report?.({severity:'error',subsystem:'Retained PDF viewer',message:error?.message||String(error),error,recovered:true});}return;}else if((mime.startsWith('text/')&&!/rtf/i.test(mime))||/\.(txt|md|js|mjs|cjs|html|htm|fountain|json|csv)$/i.test(asset.originalName||'')){node=document.createElement('pre');node.textContent=await asset.blob.text();}else{const extension=String(asset.originalName||'').split('.').pop().toLowerCase();let previewHtml='';const owner=documentId?documentsCache.find(doc=>doc.id===documentId):documentsCache.find(doc=>doc.sourceAttachmentId===asset.id);previewHtml=String(owner?.referencePreviewHtml||'').trim();if(!previewHtml&&window.NaviOfficeParserAdapter?.parseFile&&['docx','odt','rtf','rtfd','epub'].includes(extension)){try{const sourceFile=new File([asset.blob],asset.originalName||`reference.${extension}`,{type:asset.mimeType||asset.blob.type});const parsed=await window.NaviOfficeParserAdapter.parseFile(sourceFile,{fileType:extension,readOnly:true});previewHtml=String(parsed?.sourceHtml||parsed?.html||'').trim();if(previewHtml&&owner){owner.referencePreviewHtml=previewHtml;NaviStorage.saveDocument({...owner,updatedAt:Date.now()});}}catch(error){NaviDiagnostics?.report?.({severity:'warning',subsystem:'Retained document viewer',message:error?.message||String(error),error,recovered:true});}}if(previewHtml){node=document.createElement('article');node.className='retained-source-content retained-office-paper';node.innerHTML=previewHtml;node.querySelectorAll('script,iframe,object,embed,form,input,button,textarea,select').forEach(child=>child.remove());}else{node=document.createElement('div');node.className='retained-source-unsupported';node.innerHTML='<strong>Preview not available for this format.</strong><p>The original file is safely retained and downloadable.</p>';}}node.classList.add('retained-source-content');els.retainedSourceStage.appendChild(node);els.retainedSourceViewerModal.classList.remove('hidden');if(node.dataset.viewerKind==='image'){await node.decode?.().catch(()=>{});await new Promise(resolve=>requestAnimationFrame(resolve));const rect=els.retainedSourceStage.getBoundingClientRect(),nw=Math.max(1,node.naturalWidth||asset.width||1),nh=Math.max(1,node.naturalHeight||asset.height||1);retainedSourceViewerZoom=Math.max(.1,Math.min(32,Math.min(Math.max(1,rect.width-36)/nw,Math.max(1,rect.height-36)/nh)));}updateRetainedSourceZoom();}
function updateRetainedSourceZoom(){document.getElementById('retainedSourceZoomLabel').textContent=`${Math.round(retainedSourceViewerZoom*100)}%`;if(retainedSourcePdf){renderRetainedPdfPage();return;}const node=els.retainedSourceStage?.querySelector('.retained-source-content');if(node)node.style.transform=`scale(${retainedSourceViewerZoom})`; }
function closeRetainedSourceViewer(){els.retainedSourceViewerModal?.classList.add('hidden');retainedSourceViewerAssetId=null;}
async function downloadRetainedSource(){const asset=await NaviStorage.getAsset(retainedSourceViewerAssetId);if(!asset?.blob)return;const url=URL.createObjectURL(asset.blob),a=document.createElement('a');a.href=url;a.download=asset.originalName||'attachment';a.click();setTimeout(()=>URL.revokeObjectURL(url),0);}
async function addBoardDocumentViewForDocument(doc){if(!doc?.sourceAttachmentId)return;pushBoardUndoState();const position=getBoardSpawnPosition();currentBoardData.items.push({id:crypto.randomUUID(),type:'document-view',x:position.x,y:position.y,width:360,height:180,title:doc.title,docId:doc.id,attachmentId:doc.sourceAttachmentId,originalName:doc.sourceOriginalName,mimeType:doc.sourceMimeType,viewerState:{page:1,zoom:1},color:'#e0f2fe',zIndex:2,fontSize:13});renderBoard();scheduleAutosave();}
async function chooseBoardDocumentView(){
 const retained=documentsCache.filter(doc=>doc.docType==='reference-view'&&doc.sourceAttachmentId);
 const linkedIds=new Set(currentBoardData.items.map(item=>item.attachmentId).filter(Boolean));
 const existingAssets=(NaviStorage.getAllAssets?await NaviStorage.getAllAssets():[]).filter(asset=>asset?.kind==='original-file'||String(asset?.mimeType||'').startsWith('image/'));
 const choice=await openChoiceModal({title:'Add Attachment Viewer',subtitle:'Attach a new file or reuse a durable attachment.',options:[{value:'__new__',icon:'+',title:'Attach New File',description:'Create a board-only attachment. Nothing is added to Documents.'},...retained.map(doc=>({value:`doc:${doc.id}`,icon:'📎',title:doc.title||doc.sourceOriginalName||'Retained Source',description:`Documents · ${doc.sourceOriginalName||doc.sourceMimeType||'Original file'}`})),...existingAssets.filter(asset=>!retained.some(doc=>doc.sourceAttachmentId===asset.id)&&!linkedIds.has(asset.id)).map(asset=>({value:`asset:${asset.id}`,icon:String(asset.mimeType||'').startsWith('image/')?'🖼':'📄',title:asset.originalName||'Stored Attachment',description:'Board-only stored attachment'}))]});
 if(!choice)return;if(choice==='__new__'){els.retainedSourceInput?.click();return;}
 if(choice.startsWith('doc:')){const doc=documentsCache.find(item=>item.id===choice.slice(4));if(doc)await addBoardDocumentViewForDocument(doc);return;}
 if(choice.startsWith('asset:')){const asset=await NaviStorage.getAsset(choice.slice(6));if(asset){pushBoardUndoState();const pos=getBoardSpawnPosition();currentBoardData.items.push({id:crypto.randomUUID(),type:'document-view',x:pos.x,y:pos.y,width:520,height:430,title:(asset.originalName||'Attachment').replace(/\.[^.]+$/,''),docId:'',attachmentId:asset.id,originalName:asset.originalName,mimeType:asset.mimeType,viewerState:{page:1,zoom:1,fit:'width',rotation:0},color:'#e0f2fe',zIndex:2,fontSize:13});renderBoard();scheduleAutosave();}}
}
async function addBoardDocumentViewFromFile(file){if(!file)return;if(String(file.type||'').startsWith('image/')){await showMessageModal({title:'Use + Image',message:'Images are added through the Image button so NaviWriter can apply image-specific viewing defaults.',kind:'warning'});return;}pushBoardUndoState();const item=await createBoardAttachmentItem(file);if(!item)return;currentBoardData.items.push(item);renderBoard();scheduleAutosave();}

async function ensureReferenceDocumentForAttachment(assetId){const existing=documentsCache.find(doc=>doc.docType==='reference-view'&&doc.sourceAttachmentId===assetId);if(existing)return existing;const asset=await NaviStorage.getAsset(assetId);if(!asset)return null;const doc=NaviStorage.createBlankDocument((asset.originalName||'Retained Source').replace(/\.[^.]+$/,''));Object.assign(doc,{docType:'reference-view',type:'reference-view',sourceAttachmentId:asset.id,sourceOriginalName:asset.originalName,sourceMimeType:asset.mimeType,referenceMaterial:true,referenceReadOnly:true,sourceViewerState:{page:1,zoom:1,fit:'width',rotation:0},content:'<p></p>',plainText:'',wordCount:0,charCount:String(asset.originalName||'').length});const saved=await NaviStorage.saveDocument(doc);await loadDocuments();return saved;}
async function promoteCurrentRetainedSource(){if(!retainedSourceViewerAssetId)return;const doc=await ensureReferenceDocumentForAttachment(retainedSourceViewerAssetId);if(doc){retainedSourceViewerDocumentId=doc.id;const button=document.getElementById('promoteRetainedSourceBtn');if(button){button.disabled=true;button.textContent='In Documents';}}}
async function showReferenceDocumentWorkspace(doc,{preserveMode=false}={}) {
  const stale=document.getElementById('referenceDocumentWorkspace');if(stale){try{stale._naviCleanup?.();}catch{}stale.remove();}
  if(isSplitOpen()) await closeSplitEditor({clearSaved:false});
  const asset = await NaviStorage.getAsset(doc.sourceAttachmentId);
  if (!asset?.blob) return;
  if(/retained-source-placeholder|Original file retained in NaviWriter/i.test(String(doc.content||''))){doc.content='<p></p>';doc.plainText='';doc.wordCount=0;await NaviStorage.saveDocument({...doc,content:'<p></p>',plainText:'',wordCount:0,updatedAt:Date.now()});window.NaviEditor?.setEditorHtml?.('<p></p>');}
  document.body.classList.add('reference-document-active');if(!preserveMode){referenceWorkspaceMode='viewer';document.body.classList.add('reference-viewer-tab-active');document.body.classList.remove('reference-notes-tab-active','reference-split-tab-active');}updateWorkspaceModeButtons(referenceWorkspaceMode);
  const page = document.querySelector('.workspace > .page-wrap');
  if (!page) return;
  let host = document.getElementById('referenceDocumentWorkspace');
  if (!host) {
    host = document.createElement('section');
    host.id = 'referenceDocumentWorkspace';
    host.className = 'reference-document-workspace';
    page.insertAdjacentElement('beforebegin', host);
  }
  const tabs = document.createElement('nav');
  tabs.className = 'reference-document-tabs';
  tabs.innerHTML = '<span class="reference-document-file-label"></span>';
  tabs.querySelector('.reference-document-file-label').textContent = asset.originalName || doc.title || 'Retained source';
  const surface = document.createElement('div');
  surface.className = 'reference-document-surface';
  host.replaceChildren(tabs, surface);


  const mime = String(asset.mimeType || asset.blob.type || '');
  const extension = String(asset.originalName || '').split('.').pop().toLowerCase();host.dataset.readerFormat=extension;host.dataset.readerFilename=asset.originalName||doc.title||'';host.dataset.readerDocumentId=doc.id||'';host.dataset.readerAssetId=asset.id||'';
  if (mime === 'application/pdf' || extension === 'pdf') {
    const bar = document.createElement('div');
    bar.className = 'reference-document-toolbar';
    bar.innerHTML = '<button data-ref-prev title="Previous page">‹</button><span data-ref-page>1/1</span><button data-ref-next title="Next page">›</button><button data-ref-minus title="Zoom out">−</button><span data-ref-zoom>100%</span><button data-ref-plus title="Zoom in">+</button><button data-ref-fit>Fit Page</button><button data-ref-rotate>Rotate</button><button data-ref-download>Download</button>';
    const stage = document.createElement('div'); stage.className = 'reference-document-stage';
    const canvas = document.createElement('canvas'); stage.appendChild(canvas); surface.append(bar, stage);
    const pdf = await NaviPdfViewer.loadBlob(asset.blob);
    const state = { page:1, zoom:1, fit:'width', rotation:0, ...(doc.sourceViewerState || {}) };if(state.fit==='custom'&&Math.abs(Number(state.zoom||1)-1)<.001)state.fit='width';
    stage._naviReaderGoToPage=page=>{state.page=Math.max(1,Math.min(pdf.numPages,Number(page)||1));render();persist();};
    let saveTimer = 0;
    const persist = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => NaviStorage.saveDocument({ ...doc, sourceViewerState:{...state}, updatedAt:Date.now() }).catch(error => NaviDiagnostics?.report?.({severity:'warning',subsystem:'Reference viewer',message:error?.message||String(error),error,recovered:true})), 180); };
    const render = async () => {
      state.page = Math.max(1, Math.min(pdf.numPages, Number(state.page) || 1));
      bar.querySelector('[data-ref-page]').textContent = `${state.page}/${pdf.numPages}`;
      bar.querySelector('[data-ref-zoom]').textContent = `${Math.round((state.zoom || 1) * 100)}%`;
      let scale = state.fit === 'custom' ? state.zoom : null;
      if (state.fit === 'page') {
        const pdfPage = await pdf.getPage(state.page), base = pdfPage.getViewport({scale:1,rotation:state.rotation||0});
        scale = Math.min(Math.max(320,stage.clientWidth-36)/base.width, Math.max(240,stage.clientHeight-36)/base.height);
      }
      bar.querySelector('[data-ref-fit]').textContent = state.fit === 'page' ? 'Fit Width' : 'Fit Page';
      const result=await NaviPdfViewer.renderPage(pdf,state.page,canvas,{fit:state.fit,width:Math.max(320,stage.clientWidth-36),height:Math.max(220,stage.clientHeight-36),scale,rotation:state.rotation||0,gutter:36});if(result)bar.querySelector('[data-ref-zoom]').textContent=`${state.fit==='custom'?'':state.fit==='page'?'Fit · ':'Width · '}${Math.round(result.scale*100)}%`; 
      persist();
    };
    const zoomBy = delta => { state.fit='custom'; state.zoom=Math.max(.25,Math.min(4,Math.round(((state.zoom||1)+delta)*100)/100)); render(); };
    bar.querySelector('[data-ref-prev]').onclick=()=>{state.page--;render();}; bar.querySelector('[data-ref-next]').onclick=()=>{state.page++;render();};
    bar.querySelector('[data-ref-minus]').onclick=()=>zoomBy(-.1); bar.querySelector('[data-ref-plus]').onclick=()=>zoomBy(.1);
    bar.querySelector('[data-ref-fit]').onclick=()=>{state.fit=state.fit==='page'?'width':'page';state.zoom=1;render();};
    bar.querySelector('[data-ref-rotate]').onclick=()=>{state.rotation=((state.rotation||0)+90)%360;render();};
    bar.querySelector('[data-ref-download]').onclick=()=>{retainedSourceViewerAssetId=asset.id;downloadRetainedSource();};
    stage.addEventListener('wheel',event=>{if(!(event.ctrlKey||event.metaKey))return;event.preventDefault();event.stopPropagation();const beforeX=stage.scrollLeft+event.offsetX,beforeY=stage.scrollTop+event.offsetY,old=state.zoom||1;zoomBy(event.deltaY<0?.08:-.08);requestAnimationFrame(()=>{const ratio=(state.zoom||1)/old;stage.scrollLeft=beforeX*ratio-event.offsetX;stage.scrollTop=beforeY*ratio-event.offsetY;});},{passive:false});
    await render();
  } else if (mime.startsWith('image/')) {
    const bar=document.createElement('div');bar.className='reference-document-toolbar';bar.innerHTML='<button data-img-minus>−</button><span data-img-zoom>100%</span><button data-img-plus>+</button><button data-img-fit>Fit</button><button data-img-rotate>Rotate</button><button data-img-download>Download</button>';
    const stage=document.createElement('div');stage.className='reference-document-stage reference-image-stage';const img=document.createElement('img');img.src=await NaviAssets.objectUrl(asset.id);img.alt=asset.originalName||'Retained image';stage.appendChild(img);surface.append(bar,stage);let zoom=1,rotation=0,mode='fit';const fitScale=()=>{const nw=Math.max(1,img.naturalWidth||asset.width||1),nh=Math.max(1,img.naturalHeight||asset.height||1),rect=stage.getBoundingClientRect();return Math.max(.1,Math.min(32,Math.min(Math.max(1,rect.width-24)/nw,Math.max(1,rect.height-24)/nh)));};const apply=()=>{if(mode==='fit')zoom=fitScale();const nw=Math.max(1,img.naturalWidth||asset.width||1);img.style.width=`${Math.max(1,Math.round(nw*zoom))}px`;img.style.height='auto';img.style.transform=`rotate(${rotation}deg)`;bar.querySelector('[data-img-zoom]').textContent=mode==='fit'?`Fit · ${Math.round(zoom*100)}%`:`${Math.round(zoom*100)}%`;bar.querySelector('[data-img-fit]').textContent=mode==='fit'?'Actual Size':'Fit';};const zoomBy=d=>{mode='custom';zoom=Math.max(.1,Math.min(32,Math.round((zoom+d)*100)/100));apply();};bar.querySelector('[data-img-minus]').onclick=()=>zoomBy(-.25);bar.querySelector('[data-img-plus]').onclick=()=>zoomBy(.25);bar.querySelector('[data-img-fit]').onclick=()=>{if(mode==='fit'){mode='custom';zoom=1;}else mode='fit';apply();};bar.querySelector('[data-img-rotate]').onclick=()=>{rotation=(rotation+90)%360;apply();};bar.querySelector('[data-img-download]').onclick=()=>{retainedSourceViewerAssetId=asset.id;downloadRetainedSource();};stage.addEventListener('wheel',e=>{if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();e.stopPropagation();zoomBy(Math.max(-.5,Math.min(.5,-e.deltaY*.004)));},{passive:false});await img.decode?.().catch(()=>{});requestAnimationFrame(apply);
  } else {
    let previewHtml = String(doc.referencePreviewHtml || '').trim();
    if(!previewHtml && window.NaviOfficeParserAdapter?.parseFile && ['docx','odt','rtf','rtfd','epub'].includes(extension)){try{const file=new File([asset.blob],asset.originalName||`reference.${extension}`,{type:asset.mimeType||asset.blob.type});const parsed=await NaviOfficeParserAdapter.parseFile(file,{fileType:extension,readOnly:true});previewHtml=String(parsed?.sourceHtml||parsed?.html||'').trim();if(previewHtml){doc.referencePreviewHtml=previewHtml;await NaviStorage.saveDocument({...doc,referencePreviewHtml:previewHtml,updatedAt:Date.now()});}}catch(error){NaviDiagnostics?.report?.({severity:'warning',subsystem:'Reference viewer',message:`${extension.toUpperCase()} preview unavailable`,error,recovered:true});}}
    if (previewHtml) {
      const wrapper=document.createElement('div');wrapper.innerHTML=previewHtml;wrapper.querySelectorAll('script,iframe,object,embed,form,input,button,textarea,select').forEach(node=>node.remove());
      const bar=document.createElement('div');bar.className='reference-document-toolbar';bar.innerHTML='<span class="reference-format-label"></span><button data-office-minus title="Zoom out">−</button><span data-office-zoom>100%</span><button data-office-plus title="Zoom in">+</button><button data-office-reset>Reset</button><button data-office-download>Download original</button>';
      bar.querySelector('.reference-format-label').textContent=`Read-only ${extension.toUpperCase()||'document'} view`;
      const stage=document.createElement('div');stage.className='reference-document-stage reference-office-stage';const paper=document.createElement('article');paper.className='reference-office-paper';while(wrapper.firstChild)paper.appendChild(wrapper.firstChild);stage.appendChild(paper);surface.append(bar,stage);let officeZoom=1;const applyOfficeZoom=()=>{paper.style.transform=`scale(${officeZoom})`;paper.style.transformOrigin='top center';bar.querySelector('[data-office-zoom]').textContent=`${Math.round(officeZoom*100)}%`;};bar.querySelector('[data-office-minus]').onclick=()=>{officeZoom=Math.max(.5,Math.round((officeZoom-.1)*100)/100);applyOfficeZoom();};bar.querySelector('[data-office-plus]').onclick=()=>{officeZoom=Math.min(2.5,Math.round((officeZoom+.1)*100)/100);applyOfficeZoom();};bar.querySelector('[data-office-reset]').onclick=()=>{officeZoom=1;applyOfficeZoom();};bar.querySelector('[data-office-download]').onclick=()=>{retainedSourceViewerAssetId=asset.id;downloadRetainedSource();};installPointerCenteredZoom(stage,()=>officeZoom,value=>{officeZoom=value;applyOfficeZoom();});applyOfficeZoom();
    } else if (mime.startsWith('text/') || ['txt','md','markdown','js','mjs','cjs','html','htm','fountain','json','csv'].includes(extension)) {
      const pre=document.createElement('pre');pre.className='reference-text-source';pre.textContent=await asset.blob.text();surface.appendChild(pre);
    } else {
      surface.innerHTML='<div class="retained-source-unsupported"><strong>Read-only preview is unavailable for this retained file.</strong><p>The original file is unchanged and remains downloadable. Reimport through the editable route to create a parsed reading copy.</p><button data-ref-download>Download original</button></div>';
      surface.querySelector('[data-ref-download]').onclick=()=>{retainedSourceViewerAssetId=asset.id;downloadRetainedSource();};
    }
  }
}
function leaveReferenceDocumentWorkspace(){const host=document.getElementById('referenceDocumentWorkspace');try{host?._naviCleanup?.();}catch{}host?.querySelectorAll('canvas').forEach(canvas=>{try{NaviPdfViewer?.cancelCanvas?.(canvas);}catch{}});host?.remove();document.body.classList.remove('reference-document-active','reference-viewer-tab-active','reference-notes-tab-active','reference-split-tab-active');referenceWorkspaceMode='viewer';const page=document.querySelector('.workspace > .page-wrap');if(page)page.classList.remove('reference-page-hidden');const toolbar=document.getElementById('toolbar');toolbar?.removeAttribute('aria-hidden');}

function openAttachmentMetadataModal(item,nodes={}){pendingAttachmentMetadataItem={item,nodes};els.attachmentDisplayTitleInput.value=item.title||'';els.attachmentDescriptionInput.value=item.description||'';els.attachmentMetadataModal.classList.remove('hidden');setTimeout(()=>els.attachmentDisplayTitleInput.focus(),0);}
function closeAttachmentMetadataModal(){els.attachmentMetadataModal?.classList.add('hidden');pendingAttachmentMetadataItem=null;}
function saveAttachmentMetadataModal(){const record=pendingAttachmentMetadataItem;if(!record)return;record.item.title=String(els.attachmentDisplayTitleInput?.value||'').trim()||record.item.title;record.item.description=String(els.attachmentDescriptionInput?.value||'').trim();if(record.nodes.titleNode)record.nodes.titleNode.textContent=record.item.title;if(record.nodes.descriptionNode)record.nodes.descriptionNode.textContent=record.item.description;scheduleAutosave();renderBoardMinimap();closeAttachmentMetadataModal();}
async function setReferenceWorkspaceMode(mode='viewer'){const doc=documentsCache.find(item=>item.id===currentDocumentId);if(doc?.docType!=='reference-view')return;referenceWorkspaceMode=['viewer','notes'].includes(mode)?mode:'viewer';document.body.classList.toggle('reference-viewer-tab-active',referenceWorkspaceMode==='viewer');document.body.classList.toggle('reference-notes-tab-active',referenceWorkspaceMode==='notes');document.body.classList.remove('reference-split-tab-active');updateWorkspaceModeButtons(referenceWorkspaceMode);if(referenceWorkspaceMode==='viewer')await showReferenceDocumentWorkspace(doc,{preserveMode:true});if(referenceWorkspaceMode==='notes')setTimeout(()=>window.NaviEditor?.focusEditor?.(),0);}

function getLayoutPreference() {
  try {
    return localStorage.getItem(
      LAYOUT_MODE_KEY
    ) || 'auto';
  } catch {
    return 'auto';
  }
}

function saveLayoutPreference(mode = 'auto') {
  currentLayoutPreference =
    ['auto', 'desktop', 'compact', 'mobile'].includes(mode)
      ? mode
      : 'auto';

  try {
    localStorage.setItem(
      LAYOUT_MODE_KEY,
      currentLayoutPreference
    );
  } catch {}
}

function getAutoLayoutMode() {
  const width =
    window.innerWidth || 1400;

  if (width < 720) {
    return 'mobile';
  }

  if (width < 1180) {
    return 'compact';
  }

  return 'desktop';
}

function resolveLayoutMode() {
  const preference =
    currentLayoutPreference || 'auto';

  if (preference === 'auto') {
    return getAutoLayoutMode();
  }

  return preference;
}

function closeResponsiveDrawers(){document.body.classList.remove('sidebar-drawer-open','inspector-drawer-open');}

function openSidebarDrawer(){setResponsivePage('documents');}

function openInspectorDrawer(){setResponsivePage('inspector');}

function applyLayoutMode() {
  const mode =
    resolveLayoutMode();

  currentResolvedLayoutMode =
    mode;

  document.body.dataset.layoutPreference =
    currentLayoutPreference;

  document.body.dataset.layoutMode =
    mode;
  document.body.classList.remove('sidebar-drawer-open','inspector-drawer-open');
  document.dispatchEvent(new CustomEvent('naviwriter:layout-mode-change',{detail:mode}));

  document.body.classList.toggle(
    'layout-desktop',
    mode === 'desktop'
  );

  document.body.classList.toggle(
    'layout-compact',
    mode === 'compact'
  );

  document.body.classList.toggle(
    'layout-mobile',
    mode === 'mobile'
  );

  closeTopMenus();

if (mode === 'desktop') {
  closeResponsiveDrawers();
}

  document
    .querySelectorAll('[data-layout-choice]')
    .forEach(button => {
      const active =
        button.dataset.layoutChoice === currentLayoutPreference;

      button.classList.toggle(
        'active',
        active
      );
    });
}

function setLayoutPreference(mode = 'auto') {
  saveLayoutPreference(mode);
  applyLayoutMode();
}

//wire ur shit here

function setupEvents() {
  wireTagChipEditor();
  
  [
  els.localGraphShowExplicit,
  els.localGraphShowCollections,
  els.localGraphShowFolders,
  els.localGraphShowSources,
  els.localGraphShowTags
]
  .filter(Boolean)
  .forEach(input => {
    input.onchange = async () => {
await refreshLocalGraphData({
  keepLayout: true
});

requestAnimationFrame(() => {
  fitLocalGraphToView();
});
    };
  });
  
  if (els.openLocalGraphBtn) {
  els.openLocalGraphBtn.onclick =
    openLocalGraphModal;
}
  
  document
  .querySelectorAll('.board-more-panel button')
  .forEach(button => {
    button.addEventListener('click', () => {
      closeBoardMoreMenu();
    });
  });
  
  if (els.outlinerViewSelect) {
  els.outlinerViewSelect.onchange = () => {
    syncOutlinerViewModeClass();
    renderOutliner();
  };
}
  
  setupTopMenus();
  
  if (els.renameSplitPaneDocBtn) {
  els.renameSplitPaneDocBtn.onclick =
    renameSplitPaneDocument;
}
  
  currentLayoutPreference =
  getLayoutPreference();

applyLayoutMode();

let naviAutoLayoutResizeFrame=0;
window.addEventListener('resize',()=>{
  if(currentLayoutPreference!=='auto')return;
  cancelAnimationFrame(naviAutoLayoutResizeFrame);
  naviAutoLayoutResizeFrame=requestAnimationFrame(()=>{
    const previous=currentResolvedLayoutMode;
    const next=resolveLayoutMode();
    if(previous!==next)applyLayoutMode();
  });
},{passive:true});

document
  .querySelectorAll('[data-layout-choice]')
  .forEach(button => {
    button.addEventListener('click', () => {
      setLayoutPreference(
        button.dataset.layoutChoice
      );

      button
        .closest('.top-menu')
        ?.removeAttribute('open');
    });
  });

if (els.openSidebarDrawerBtn) {
  els.openSidebarDrawerBtn.onclick =
    openSidebarDrawer;
}

if (els.openInspectorDrawerBtn) {
  els.openInspectorDrawerBtn.onclick =
    openInspectorDrawer;
}

if (els.closeSidebarDrawerBtn) {
  els.closeSidebarDrawerBtn.onclick =
    closeResponsiveDrawers;
}

if (els.closeInspectorDrawerBtn) {
  els.closeInspectorDrawerBtn.onclick =
    closeResponsiveDrawers;
}

if (els.responsiveOverlay) {
  els.responsiveOverlay.onclick =
    closeResponsiveDrawers;
}
  
  if (els.openProjectCommentsBtn) {
  els.openProjectCommentsBtn.onclick =
    openProjectCommentsPanel;
}

if (els.closeProjectCommentsBtn) {
  els.closeProjectCommentsBtn.onclick =
    closeProjectCommentsPanel;
}
  
  if (els.toggleResolvedCommentsBtn) {
  els.toggleResolvedCommentsBtn.onclick =
    toggleResolvedInlineComments;
}
  
  if (els.addInlineCommentBtn) {
  els.addInlineCommentBtn.onclick =
    addInlineCommentFromSelection;
}
  
  if (els.openCommentsDrawerBtn) {
  els.openCommentsDrawerBtn.onclick =
    openCommentsDrawer;
}
  
  if (
  els.projectCommentsPanel &&
  els.projectCommentsPanelHead
) {
  els.projectCommentsPanelHead.addEventListener(
    'pointerdown',
    event => {

      if (
        event.target.closest('button')
      ) {
        return;
      }

      const rect =
        els.projectCommentsPanel.getBoundingClientRect();

      projectCommentsDragging =
        true;

      projectCommentsDragStart = {
        x: event.clientX,
        y: event.clientY
      };

      projectCommentsStart = {
        x: rect.left,
        y: rect.top
      };

      try {
        els.projectCommentsPanelHead
          .setPointerCapture(
            event.pointerId
          );
      } catch {}
    }
  );

  els.projectCommentsPanelHead.addEventListener(
    'pointermove',
    event => {

      if (
        !projectCommentsDragging
      ) {
        return;
      }

      const dx =
        event.clientX -
        projectCommentsDragStart.x;

      const dy =
        event.clientY -
        projectCommentsDragStart.y;

      const nextX =
        projectCommentsStart.x + dx;

      const nextY =
        projectCommentsStart.y + dy;

      els.projectCommentsPanel.style.left =
        `${nextX}px`;

      els.projectCommentsPanel.style.top =
        `${nextY}px`;

      els.projectCommentsPanel.style.right =
        'auto';
    }
  );

  els.projectCommentsPanelHead.addEventListener(
    'pointerup',
    event => {

      projectCommentsDragging =
        false;

      try {
        els.projectCommentsPanelHead
          .releasePointerCapture(
            event.pointerId
          );
      } catch {}
    }
  );

  els.projectCommentsPanelHead.addEventListener(
    'pointercancel',
    () => {
      projectCommentsDragging =
        false;
    }
  );
}
  
  if (els.commentsDrawerHead && els.commentsDrawer) {
  els.commentsDrawerHead.addEventListener('pointerdown', event => {
    if (event.target.closest('button')) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    commentsDrawerDragging = true;

    const rect =
      els.commentsDrawer.getBoundingClientRect();

    commentsDrawerDragStart = {
      x: event.clientX,
      y: event.clientY
    };

    commentsDrawerStart = {
      x: rect.left,
      y: rect.top
    };

    els.commentsDrawerHead.setPointerCapture(
      event.pointerId
    );
  });

  els.commentsDrawerHead.addEventListener('pointermove', event => {
    if (!commentsDrawerDragging) {
      return;
    }

    event.preventDefault();

    const dx =
      event.clientX - commentsDrawerDragStart.x;

    const dy =
      event.clientY - commentsDrawerDragStart.y;

    const next =
      clampCommentsDrawerPosition(
        commentsDrawerStart.x + dx,
        commentsDrawerStart.y + dy
      );

    els.commentsDrawer.style.left =
      `${next.x}px`;

    els.commentsDrawer.style.top =
      `${next.y}px`;
  });

  els.commentsDrawerHead.addEventListener('pointerup', event => {
    if (!commentsDrawerDragging) {
      return;
    }

    commentsDrawerDragging = false;

    saveCommentsDrawerPosition();

    try {
      els.commentsDrawerHead.releasePointerCapture(
        event.pointerId
      );
    } catch {}
  });

  els.commentsDrawerHead.addEventListener('pointercancel', () => {
    commentsDrawerDragging = false;
  });
}

if (els.closeCommentsDrawerBtn) {
  els.closeCommentsDrawerBtn.onclick =
    closeCommentsDrawer;
}
  
  if (els.showBoardMinimapBtn) {
  els.showBoardMinimapBtn.onclick =
    toggleBoardMinimap;
}
  
  if (els.manageCustomMetadataFieldsBtn) {
  els.manageCustomMetadataFieldsBtn.onclick =
    openCustomMetadataFieldsModal;
}
  

if (els.closeCustomMetadataFieldsModalBtn) {
  els.closeCustomMetadataFieldsModalBtn.onclick =
    closeCustomMetadataFieldsModal;
}

if (els.customMetadataFieldTypeSelect) {
  els.customMetadataFieldTypeSelect.onchange =
    updateCustomMetadataOptionsVisibility;
}

if (els.addCustomMetadataFieldBtn) {
  els.addCustomMetadataFieldBtn.onclick =
    submitCustomMetadataFieldAdd;
}
  
  if (els.manageCustomMetadataFieldsInlineBtn) {
  els.manageCustomMetadataFieldsInlineBtn.onclick =
    openCustomMetadataFieldsModal;
}

  if (els.editSplitPaneBtn) {
  els.editSplitPaneBtn.onclick =
    toggleSplitPaneEditable;
}

if (els.saveSplitPaneBtn) {
  els.saveSplitPaneBtn.onclick =
    saveSplitPaneDocument;
}
  
if (els.customMetadataFieldsModal) {
  els.customMetadataFieldsModal.addEventListener('click', event => {
    if (event.target === els.customMetadataFieldsModal) {
      closeCustomMetadataFieldsModal();
    }
  });
}
  
  if (els.manageOutlinerCustomColumnsBtn) {
  els.manageOutlinerCustomColumnsBtn.onclick =
    openOutlinerCustomColumnsModal;
}

if (els.closeOutlinerCustomColumnsBtn) {
  els.closeOutlinerCustomColumnsBtn.onclick =
    closeOutlinerCustomColumnsModal;
}

if (els.outlinerCustomColumnsModal) {
  els.outlinerCustomColumnsModal.addEventListener('click', event => {
    if (event.target === els.outlinerCustomColumnsModal) {
      closeOutlinerCustomColumnsModal();
    }
  });
}
  
  if (els.boardMinimap) {
  const minimapHead =
    els.boardMinimap.querySelector(
      '.board-minimap-head'
    );

  if (minimapHead) {
    minimapHead.addEventListener(
      'pointerdown',
      event => {
        /*
          Do not start dragging if clicking the close button.
        */
        if (event.target.closest('button')) {
          return;
        }

        event.preventDefault();
        event.stopPropagation();

        isBoardMinimapPanelDragging = true;

        const parentRect =
          getBoardMinimapParentRect();

        const minimapRect =
          els.boardMinimap.getBoundingClientRect();

        boardMinimapPanelDragStart = {
          x: event.clientX,
          y: event.clientY
        };

        boardMinimapPanelStart = {
          x: minimapRect.left - parentRect.left,
          y: minimapRect.top - parentRect.top
        };

        /*
          Switch to explicit left/top while dragging.
        */
        els.boardMinimap.style.right =
          'auto';

        els.boardMinimap.style.bottom =
          'auto';

        minimapHead.setPointerCapture(
          event.pointerId
        );
      }
    );

    minimapHead.addEventListener(
      'pointermove',
      event => {
        if (!isBoardMinimapPanelDragging) {
          return;
        }

        event.preventDefault();

        const dx =
          event.clientX -
          boardMinimapPanelDragStart.x;

        const dy =
          event.clientY -
          boardMinimapPanelDragStart.y;

        const next =
          clampBoardMinimapPosition(
            boardMinimapPanelStart.x + dx,
            boardMinimapPanelStart.y + dy
          );

        els.boardMinimap.style.left =
          `${next.x}px`;

        els.boardMinimap.style.top =
          `${next.y}px`;

        updateBoardMinimapViewport();
      }
    );

    minimapHead.addEventListener(
      'pointerup',
      event => {
        if (!isBoardMinimapPanelDragging) {
          return;
        }

        isBoardMinimapPanelDragging = false;

        saveBoardMinimapPosition();

        try {
          minimapHead.releasePointerCapture(
            event.pointerId
          );
        } catch {}
      }
    );

    minimapHead.addEventListener(
      'pointercancel',
      () => {
        isBoardMinimapPanelDragging = false;
      }
    );
  }
}

if (els.toggleBoardMinimapBtn) {
  els.toggleBoardMinimapBtn.onclick =
    hideBoardMinimap;
}
  
 if (els.refreshDocumentMapBtn) {
  els.refreshDocumentMapBtn.onclick =
    scheduleDocumentMapRender;
}

if (els.editor) {
  els.editor.addEventListener(
    'input',
    scheduleDocumentMapRender
  );
}
  
  window.addEventListener(
  'naviwriter:editor-input',
  scheduleDocumentMapRender
);

if (els.boardSurface) {
  els.boardSurface.addEventListener('scroll',()=>{cancelAnimationFrame(els.boardSurface._minimapFrame||0);els.boardSurface._minimapFrame=requestAnimationFrame(updateBoardMinimapViewport);});
}
  
  const showLocalGraphMinimapBtn = document.getElementById('showLocalGraphMinimapBtn');
  const syncGraphMinimapButton = () => {
    if (showLocalGraphMinimapBtn) showLocalGraphMinimapBtn.hidden = !els.localGraphMinimap?.classList.contains('hidden');
  };
  if (els.toggleLocalGraphMinimapBtn) {
    els.toggleLocalGraphMinimapBtn.onclick = () => { els.localGraphMinimap?.classList.add('hidden'); syncGraphMinimapButton(); };
  }
  if (showLocalGraphMinimapBtn) {
    showLocalGraphMinimapBtn.onclick = () => { els.localGraphMinimap?.classList.remove('hidden'); syncGraphMinimapButton(); updateLocalGraphMinimap(); };
  }
  syncGraphMinimapButton();
  const graphMinimapHead = els.localGraphMinimap?.querySelector('.local-graph-minimap-head');
  if (graphMinimapHead && els.localGraphSurface) {
    let mapDrag = null;
    graphMinimapHead.addEventListener('pointerdown', event => {
      if (event.target.closest('button')) return;
      const mapRect=els.localGraphMinimap.getBoundingClientRect(), surfaceRect=els.localGraphSurface.getBoundingClientRect();
      mapDrag={dx:event.clientX-mapRect.left,dy:event.clientY-mapRect.top,surfaceRect};
      graphMinimapHead.setPointerCapture(event.pointerId); event.preventDefault();
    });
    graphMinimapHead.addEventListener('pointermove', event => {
      if(!mapDrag)return; const rect=els.localGraphMinimap.getBoundingClientRect(), s=mapDrag.surfaceRect;
      const left=Math.max(6,Math.min(s.width-rect.width-6,event.clientX-s.left-mapDrag.dx));
      const top=Math.max(6,Math.min(s.height-rect.height-6,event.clientY-s.top-mapDrag.dy));
      Object.assign(els.localGraphMinimap.style,{left:`${left}px`,top:`${top}px`,right:'auto',bottom:'auto'});
    });
    const stopMapDrag=event=>{if(!mapDrag)return;mapDrag=null;try{graphMinimapHead.releasePointerCapture(event.pointerId)}catch{}};
    graphMinimapHead.addEventListener('pointerup',stopMapDrag);graphMinimapHead.addEventListener('pointercancel',stopMapDrag);
  }

if (els.localGraphMinimapBody) {
  els.localGraphMinimapBody.addEventListener('pointerdown', event => {
    event.preventDefault();
    event.stopPropagation();

    isLocalGraphMinimapDragging = true;

    panLocalGraphToMinimapPoint(
      event.clientX,
      event.clientY
    );

    els.localGraphMinimapBody.setPointerCapture(
      event.pointerId
    );
  });

  els.localGraphMinimapBody.addEventListener('pointermove', event => {
    if (!isLocalGraphMinimapDragging) {
      return;
    }

    event.preventDefault();

    panLocalGraphToMinimapPoint(
      event.clientX,
      event.clientY
    );
  });

  els.localGraphMinimapBody.addEventListener('pointerup', event => {
    isLocalGraphMinimapDragging = false;

    try {
      els.localGraphMinimapBody.releasePointerCapture(
        event.pointerId
      );
    } catch {}
  });
}

if (els.boardMinimapBody) {
  els.boardMinimapBody.addEventListener('pointerdown', event => {
    event.preventDefault();
    event.stopPropagation();

    isBoardMinimapDragging = true;

    panBoardToMinimapPoint(
      event.clientX,
      event.clientY
    );

    els.boardMinimapBody.setPointerCapture(
      event.pointerId
    );
  });

  els.boardMinimapBody.addEventListener('pointermove', event => {
    if (!isBoardMinimapDragging) {
      return;
    }

    event.preventDefault();

    panBoardToMinimapPoint(
      event.clientX,
      event.clientY
    );
  });

  els.boardMinimapBody.addEventListener('pointerup', event => {
    isBoardMinimapDragging = false;

    try {
      els.boardMinimapBody.releasePointerCapture(
        event.pointerId
      );
    } catch {}
  });
}
  
  if (els.localGraphSurface) {
  els.localGraphSurface.addEventListener('click', async event => {
    const closeDetailsBtn =
      event.target.closest('#closeLocalGraphDetailsBtn');

    if (closeDetailsBtn) {
      event.preventDefault();
      event.stopPropagation();

      clearLocalGraphSelection();
      return;
    }

    const centerNodeBtn =
      event.target.closest('#centerLocalGraphNodeBtn');

    if (centerNodeBtn) {
      event.preventDefault();
      event.stopPropagation();

      if (localGraphSelectedNodeId) {
        centerLocalGraphOnNode(
          localGraphSelectedNodeId
        );
      }

      return;
    }

    const openNodeBtn =
      event.target.closest('#openLocalGraphNodeBtn');

    if (openNodeBtn) {
      event.preventDefault();
      event.stopPropagation();

      await openSelectedLocalGraphNode();
      return;
    }
  });
}
  
  if (els.openGlobalGraphBtn) {
  els.openGlobalGraphBtn.onclick =
    async () => {
      closeRelationshipDashboardModal();
      await openGlobalGraphModal();
    };
}
  
  if (els.openRelationshipDashboardBtn) {
  els.openRelationshipDashboardBtn.onclick =
    openRelationshipDashboardModal;
}

if (els.closeRelationshipDashboardBtn) {
  els.closeRelationshipDashboardBtn.onclick =
    closeRelationshipDashboardModal;
}

if (els.refreshRelationshipDashboardBtn) {
  els.refreshRelationshipDashboardBtn.onclick =
    renderRelationshipDashboard;
}

if (els.openOutlinerFromDashboardBtn) {
  els.openOutlinerFromDashboardBtn.onclick =
    async () => {
      closeRelationshipDashboardModal();

      if (els.outlinerViewSelect) {
        els.outlinerViewSelect.value = 'relationships';
      }

      await openOutlinerModal();
    };
}

if (els.relationshipDashboardModal) {
  els.relationshipDashboardModal.addEventListener('click', event => {
    if (event.target === els.relationshipDashboardModal) {
      closeRelationshipDashboardModal();
    }
  });
}

if (els.closeLocalGraphModalBtn) {
  els.closeLocalGraphModalBtn.onclick =
    closeLocalGraphModal;
}

if (els.localGraphZoomOutBtn) {
  els.localGraphZoomOutBtn.onclick =
    () => zoomLocalGraph(-0.12);
}

if (els.localGraphZoomInBtn) {
  els.localGraphZoomInBtn.onclick =
    () => zoomLocalGraph(0.12);
}

if (els.localGraphResetBtn) {
  els.localGraphResetBtn.onclick =
    () => {
      resetLocalGraphState();
      autoLayoutLocalGraph();
      renderLocalGraph();

      requestAnimationFrame(() => {
        fitLocalGraphToView();
      });
    };
}

if (els.localGraphModal) {
  els.localGraphModal.addEventListener(
    'click',
    event => {
      if (event.target === els.localGraphModal) {
        closeLocalGraphModal();
      }
    }
  );
}

setupLocalGraphInteractions();
  
  if (els.outlinerShowSourceRelationships) {
  els.outlinerShowSourceRelationships.onchange =
    renderOutliner;
}

if (els.outlinerShowTagRelationships) {
  els.outlinerShowTagRelationships.onchange =
    renderOutliner;
}
  
if (els.outlinerViewSelect) {
  els.outlinerViewSelect.onchange = () => {
    syncOutlinerViewModeClass();
    renderOutliner();
  };
}

if (els.outlinerShowExplicitRelationships) {
  els.outlinerShowExplicitRelationships.onchange =
    renderOutliner;
}

if (els.outlinerShowCollectionRelationships) {
  els.outlinerShowCollectionRelationships.onchange =
    renderOutliner;
}

if (els.outlinerShowFolderRelationships) {
  els.outlinerShowFolderRelationships.onchange =
    renderOutliner;
}


  
  if (els.manageRelationshipTypesBtn) {
  els.manageRelationshipTypesBtn.onclick =
    openRelationshipTypesModal;
}

if (els.closeRelationshipTypesModalBtn) {
  els.closeRelationshipTypesModalBtn.onclick =
    closeRelationshipTypesModal;
}

if (els.cancelRelationshipTypesModalBtn) {
  els.cancelRelationshipTypesModalBtn.onclick =
    closeRelationshipTypesModal;
}

if (els.addRelationshipTypeBtn) {
  els.addRelationshipTypeBtn.onclick =
    submitRelationshipTypeAdd;
}

if (els.relationshipTypeNameInput) {
  els.relationshipTypeNameInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      submitRelationshipTypeAdd();
    }
  });
}

if (els.relationshipTypesModal) {
  els.relationshipTypesModal.addEventListener('click', event => {
    if (event.target === els.relationshipTypesModal) {
      closeRelationshipTypesModal();
    }
  });
}
  
 if (els.outlinerViewSelect) {
  els.outlinerViewSelect.onchange = () => {
    syncOutlinerViewModeClass();
    renderOutliner();
  };
}
  
  if (els.createRelationshipBtn) {
  els.createRelationshipBtn.onclick = openRelationshipModal;
}

if (els.closeRelationshipModalBtn) {
  els.closeRelationshipModalBtn.onclick = closeRelationshipModal;
}

if (els.cancelRelationshipModalBtn) {
  els.cancelRelationshipModalBtn.onclick = closeRelationshipModal;
}

if (els.submitRelationshipModalBtn) {
  els.submitRelationshipModalBtn.onclick = submitRelationshipModal;
}

if (els.relationshipTargetTypeSelect) {
  els.relationshipTargetTypeSelect.onchange = populateRelationshipTargetSelect;
}

if (els.relationshipModal) {
  els.relationshipModal.addEventListener('click', event => {
    if (event.target === els.relationshipModal) {
      closeRelationshipModal();
    }
  });
}
  
  if (els.addDocsToCollectionBtn) {
  els.addDocsToCollectionBtn.onclick = openCollectionDocPicker;
}

if (els.closeCollectionDocPickerBtn) {
  els.closeCollectionDocPickerBtn.onclick = closeCollectionDocPicker;
}

if (els.cancelCollectionDocPickerBtn) {
  els.cancelCollectionDocPickerBtn.onclick = closeCollectionDocPicker;
}

if (els.submitCollectionDocPickerBtn) {
  els.submitCollectionDocPickerBtn.onclick = submitCollectionDocPicker;
}

if (els.collectionDocPickerSearch) {
  els.collectionDocPickerSearch.oninput = renderCollectionDocPickerList;
}

if (els.collectionDocPickerTypeFilter) {
  els.collectionDocPickerTypeFilter.onchange = renderCollectionDocPickerList;
}

if (els.collectionDocPickerModal) {
  els.collectionDocPickerModal.addEventListener('click', event => {
    if (event.target === els.collectionDocPickerModal) {
      closeCollectionDocPicker();
    }
  });
}
  
  if (els.openCollectionsBtn) {
  els.openCollectionsBtn.onclick = openCollectionsModal;
}

if (els.closeCollectionsModalBtn) {
  els.closeCollectionsModalBtn.onclick = closeCollectionsModal;
}

if (els.collectionsModal) {
  els.collectionsModal.addEventListener('click', event => {
    if (event.target === els.collectionsModal) {
      closeCollectionsModal();
    }
  });
}

if (els.newCollectionBtn) {
  els.newCollectionBtn.onclick = createCollection;
}

if (els.addCurrentDocToCollectionBtn) {
  els.addCurrentDocToCollectionBtn.onclick = addCurrentDocumentToCollection;
}

if (els.renameCollectionBtn) {
  els.renameCollectionBtn.onclick = renameActiveCollection;
}

if (els.deleteCollectionBtn) {
  els.deleteCollectionBtn.onclick = deleteActiveCollection;
}
  
  if (els.sourcesModeBtn) {
  els.sourcesModeBtn.onclick = () => {
    const next =
      !document.body.classList.contains('sources-mode-active');

    setSourcesMode(next);
  };
}

if (els.addSourceBtn) {
  els.addSourceBtn.onclick = () => {
    openSourceModal();
  };
}

if (els.closeSourceModalBtn) {
  els.closeSourceModalBtn.onclick = closeSourceModal;
}

if (els.cancelSourceModalBtn) {
  els.cancelSourceModalBtn.onclick = closeSourceModal;
}

if (els.submitSourceModalBtn) {
  els.submitSourceModalBtn.onclick = submitSourceModal;
}

if (els.sourceModal) {
  els.sourceModal.addEventListener('click', event => {
    if (event.target === els.sourceModal) {
      closeSourceModal();
    }
  });
}
  
 if (els.openSplitEditorBtn) {
  els.openSplitEditorBtn.onclick = () => {
  closeBoardMoreMenu();
  openSplitEditor();
};
}

if (els.closeSplitEditorBtn) {
  els.closeSplitEditorBtn.onclick = () => {
    closeSplitEditor();
  };
}

if (els.splitDocSelect) {
  els.splitDocSelect.onchange = handleSplitDocSelectChange;
}
if (els.splitDocSearch) {
  els.splitDocSearch.oninput = () => populateSplitDocSelect();
}

if (els.openSplitDocAsMainBtn) {
  els.openSplitDocAsMainBtn.onclick = openSplitDocAsMain;
}
  
  if (els.outlinerStatusFilterSelect) {
  els.outlinerStatusFilterSelect.onchange = renderOutliner;
}

if (els.outlinerTypeFilterSelect) {
  els.outlinerTypeFilterSelect.onchange = renderOutliner;
}

if (els.outlinerFolderFilterSelect) {
  els.outlinerFolderFilterSelect.onchange = renderOutliner;
}

if (els.outlinerSortSelect) {
  els.outlinerSortSelect.onchange = renderOutliner;
}
  
  if (els.openOutlinerBtn) {
  els.openOutlinerBtn.onclick = openOutlinerModal;
}

if (els.closeOutlinerModalBtn) {
  els.closeOutlinerModalBtn.onclick = closeOutlinerModal;
}

if (els.outlinerModal) {
  els.outlinerModal.addEventListener('click', event => {
    if (event.target === els.outlinerModal) {
      closeOutlinerModal();
    }
  });
}

if (els.outlinerScopeSelect) {
  els.outlinerScopeSelect.onchange = renderOutliner;
}

if (els.outlinerSearchInput) {
  els.outlinerSearchInput.oninput = renderOutliner;
}

if (els.refreshOutlinerBtn) {
  els.refreshOutlinerBtn.onclick = renderOutliner;
}
  
  if (els.decreaseBoardFontBtn) {
  els.decreaseBoardFontBtn.onclick = () => {
    adjustSelectedBoardFontSize(-1);
  };
}

if (els.increaseBoardFontBtn) {
  els.increaseBoardFontBtn.onclick = () => {
    adjustSelectedBoardFontSize(1);
  };
}

if (els.resetBoardFontBtn) {
  els.resetBoardFontBtn.onclick = resetSelectedBoardFontSize;
}
  
  if (els.duplicateBoardItemBtn) {
  els.duplicateBoardItemBtn.onclick = duplicateSelectedBoardItem;
}

if (els.bringBoardItemFrontBtn) {
  els.bringBoardItemFrontBtn.onclick = bringSelectedBoardItemToFront;
}

if (els.sendBoardItemBackBtn) {
  els.sendBoardItemBackBtn.onclick = sendSelectedBoardItemToBack;
}

if (els.familyConnectorBtn) {
  els.familyConnectorBtn.onclick = createFamilyConnector;
}

if (els.resetBoardZoomBtn) {
  els.resetBoardZoomBtn.onclick = resetBoardZoom;
}
  
  if (els.bookThemeSelect) {
  els.bookThemeSelect.onchange = event => {
    applyBookTheme(event.target.value);
  };
}

if (els.applyCompileProfileBtn) {
  els.applyCompileProfileBtn.onclick = applySelectedCompileProfile;
}

if (els.saveCompileProfileBtn) {
  els.saveCompileProfileBtn.onclick = saveCurrentCompileProfile;
}

if (els.deleteCompileProfileBtn) {
  els.deleteCompileProfileBtn.onclick = deleteSelectedCompileProfile;
}
  
  if (els.closeChoiceModalBtn) {
  els.closeChoiceModalBtn.onclick = closeChoiceModal;
}

if (els.choiceModal) {
  els.choiceModal.addEventListener('click', event => {
    if (event.target === els.choiceModal) {
      closeChoiceModal();
    }
  });
}

if (els.closeBoardLinkModalBtn) {
  els.closeBoardLinkModalBtn.onclick = closeBoardLinkModal;
}

if (els.cancelBoardLinkModalBtn) {
  els.cancelBoardLinkModalBtn.onclick = closeBoardLinkModal;
}

if (els.submitBoardLinkModalBtn) {
  els.submitBoardLinkModalBtn.onclick = submitBoardLinkModal;
}

if (els.boardLinkModal) {
  els.boardLinkModal.addEventListener('click', event => {
    if (event.target === els.boardLinkModal) {
      closeBoardLinkModal();
    }
  });
}

[
  els.boardLinkTitleInput,
  els.boardLinkUrlInput
]
  .filter(Boolean)
  .forEach(input => {
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        submitBoardLinkModal();
      }
    });
  });

if (els.closeBoardConnectionModalBtn) {
  els.closeBoardConnectionModalBtn.onclick = closeBoardConnectionModal;
}

if (els.cancelBoardConnectionModalBtn) {
  els.cancelBoardConnectionModalBtn.onclick = closeBoardConnectionModal;
}

if (els.submitBoardConnectionModalBtn) {
  els.submitBoardConnectionModalBtn.onclick = submitBoardConnectionModal;
}

if (els.boardConnectionModal) {
  els.boardConnectionModal.addEventListener('click', event => {
    if (event.target === els.boardConnectionModal) {
      closeBoardConnectionModal();
    }
  });
}

if (els.boardConnectionLabelInput) {
  els.boardConnectionLabelInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      submitBoardConnectionModal();
    }
  });
}
  
  if (els.closeBoardPersonModalBtn) {
  els.closeBoardPersonModalBtn.onclick = closeBoardPersonModal;
}

if (els.cancelBoardPersonModalBtn) {
  els.cancelBoardPersonModalBtn.onclick = closeBoardPersonModal;
}

if (els.submitBoardPersonModalBtn) {
  els.submitBoardPersonModalBtn.onclick = submitBoardPersonModal;
}

if (els.boardPersonModal) {
  els.boardPersonModal.addEventListener('click', event => {
    if (event.target === els.boardPersonModal) {
      closeBoardPersonModal();
    }
  });
}

[
  els.boardPersonNameInput,
  els.boardPersonRoleInput,
  els.boardPersonNotesInput
]
  .filter(Boolean)
  .forEach(input => {
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        submitBoardPersonModal();
      }
    });
  });
  
  if (els.closeMessageModalBtn) {
  els.closeMessageModalBtn.onclick = closeMessageModal;
}

if (els.okMessageModalBtn) {
  els.okMessageModalBtn.onclick = closeMessageModal;
}

if (els.messageModal) {
  els.messageModal.addEventListener('click', event => {
    if (event.target === els.messageModal) {
      closeMessageModal();
    }
  });
}
  
  if (els.closeTextInputModalBtn) {
  els.closeTextInputModalBtn.onclick = closeTextInputModal;
}

if (els.cancelTextInputModalBtn) {
  els.cancelTextInputModalBtn.onclick = closeTextInputModal;
}

if (els.submitTextInputModalBtn) {
  els.submitTextInputModalBtn.onclick = submitTextInputModal;
}

if (els.textInputModalField) {
  els.textInputModalField.addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      submitTextInputModal();
    }
  });
}

if (els.textInputModal) {
  els.textInputModal.addEventListener('click', event => {
    if (event.target === els.textInputModal) {
      closeTextInputModal();
    }
  });
}

if (els.closeConfirmModalBtn) {
  els.closeConfirmModalBtn.onclick = closeConfirmModal;
}

if (els.cancelConfirmModalBtn) {
  els.cancelConfirmModalBtn.onclick = closeConfirmModal;
}

if (els.submitConfirmModalBtn) {
  els.submitConfirmModalBtn.onclick = () => {
    resolveConfirmModal(true);
  };
}

if (els.confirmModal) {
  els.confirmModal.addEventListener('click', event => {
    if (event.target === els.confirmModal) {
      closeConfirmModal();
    }
  });
}
  
  if (els.closeMatterPresetModalBtn) {
  els.closeMatterPresetModalBtn.onclick = closeMatterPresetPicker;
}

if (els.matterPresetModal) {
  els.matterPresetModal.addEventListener('click', event => {
    if (event.target === els.matterPresetModal) {
      closeMatterPresetPicker();
    }
  });
}
  
  if (els.saveProjectMetaBtn) {
  els.saveProjectMetaBtn.onclick = saveProjectMetadata;
}
  
  if (els.coverImageInput) {
  els.coverImageInput.onchange = handleCoverImageFile;
}
  
  if (els.toggleInspectorSectionsBtn) {
  els.toggleInspectorSectionsBtn.onclick = toggleAllInspectorSections;
}
  
  setupInspectorTabs();
  
  if (els.insertEndnoteBtn) {
  els.insertEndnoteBtn.onclick = () => {
    NaviEditor.insertEndnote();
    scheduleAutosave();
    updateInspector();
  };
}

if (els.splitDocBtn) {
  els.splitDocBtn.onclick = async () => {
    const docs = NaviEditor.splitByHeadings();

    if (!docs.length) {
      showAppNotice(
  'No headings found to split.',
  'Nothing to split'
);
      return;
    }

    showAppNotice(
  'Split preview is not wired yet.'
);
  };
}
  
  if (els.openProjectFileBtn) {
  els.openProjectFileBtn.onclick = handleOpenProjectFile;
}
  
  if (els.compileExportBtn) {
  els.compileExportBtn.onclick = openCompileModal;
}

if (els.closeCompileModalBtn) {
  els.closeCompileModalBtn.onclick = closeCompileModal;
}

if (els.cancelCompileBtn) {
  els.cancelCompileBtn.onclick = closeCompileModal;
}

if (els.runCompileBtn) {
  els.runCompileBtn.onclick = runCompileExport;
}

wireCompileOptionPreviewEvents();

if (els.compileFormatSelect) {
  els.compileFormatSelect.onchange = renderCompilePreview;
}

if (els.saveProjectAsBtn) {
  els.saveProjectAsBtn.onclick = handleSaveProjectAs;
}

if (els.saveProjectFileBtn) {
  els.saveProjectFileBtn.onclick = handleSaveProjectFile;
}

if (els.projectAutosaveSelect) {
  els.projectAutosaveSelect.onchange = handleProjectAutosaveChange;
}
  
  if (els.takeSnapshotBtn) {
  els.takeSnapshotBtn.onclick = handleTakeSnapshot;
}
  
  if (els.exportProjectBackupBtn) {
  els.exportProjectBackupBtn.onclick = handleExportProjectBackup;
}

if (els.importProjectBackupBtn) {
  els.importProjectBackupBtn.onclick = handleImportProjectBackupClick;
}

if (els.projectBackupInput) {
  els.projectBackupInput.onchange = handleImportProjectBackupFile;
}

if (els.snapshotHistoryBtn) {
  els.snapshotHistoryBtn.onclick = openSnapshotHistory;
}

if (els.closeSnapshotModalBtn) {
  els.closeSnapshotModalBtn.onclick = closeSnapshotHistory;
}

if (els.snapshotModal) {
  els.snapshotModal.addEventListener('click', event => {
    if (event.target === els.snapshotModal) {
      closeSnapshotHistory();
    }
  });
}


if (els.writeModeBtn) {
  els.writeModeBtn.onclick = () => {
    if(documentsCache.find(item=>item.id===currentDocumentId)?.docType==='reference-view'){setReferenceWorkspaceMode('viewer');return;}
    document.body.classList.remove('sources-mode-active');
    setBoardMode(false);
    updateWorkspaceModeButtons('write');
  };
}

if (els.boardModeBtn) {
  els.boardModeBtn.onclick = () => {
    if(documentsCache.find(item=>item.id===currentDocumentId)?.docType==='reference-view'){setReferenceWorkspaceMode('notes');return;}
    document.body.classList.remove('sources-mode-active');
    setBoardMode(true);
    updateWorkspaceModeButtons('board');
  };
}

if (els.addBoardNoteBtn) {
  els.addBoardNoteBtn.onclick = addBoardNote;
}

if (els.addBoardImageBtn && els.boardImageInput) {
  els.addBoardImageBtn.onclick = () => {
    els.boardImageInput.click();
  };

  els.boardImageInput.onchange = async event => {
    const file = event.target.files?.[0];

    if (file) {
      await addBoardImageFile(file);
    }

    event.target.value = '';
  };
}

if (els.addBoardLinkBtn) {
  els.addBoardLinkBtn.onclick = addBoardLink;
}

  if (els.closePdfSubdocModalBtn) {
  els.closePdfSubdocModalBtn.onclick = closePdfSubdocModal;
}

if (els.pdfUploadNewBtn) {
  els.pdfUploadNewBtn.onclick = handleUploadPdfSubdoc;
}

if (els.pdfBlankNoteBtn) {
  els.pdfBlankNoteBtn.onclick = createBlankPdfSubdoc;
}

if (els.pdfSubdocModal) {
  els.pdfSubdocModal.addEventListener('click', event => {
    if (event.target === els.pdfSubdocModal) {
      closePdfSubdocModal();
    }
  });
}

  if (els.closeSubdocModalBtn) {
  els.closeSubdocModalBtn.onclick = closeSubdocTypeModal;
}

if (els.subdocTypeModal) {
  els.subdocTypeModal.addEventListener('click', event => {
    if (event.target === els.subdocTypeModal) {
      closeSubdocTypeModal();
    }

    const card = event.target.closest('[data-subdoc-type]');

    if (!card) return;

    createSubDocumentOfType(card.dataset.subdocType);
  });
}

  if (els.closeFindPanelBtn) {
  els.closeFindPanelBtn.onclick = closeFindPanel;
}

if (els.floatingFindBtn) {
  els.floatingFindBtn.onclick = runFloatingFind;
}

if (els.floatingFindInput) {
  els.floatingFindInput.oninput = runFloatingFind;
}

if (els.floatingFindScopeSelect) {
  els.floatingFindScopeSelect.onchange = () => {
    runFloatingFind();
  };
}

[els.floatingFindMatchCase, els.floatingFindWholeWord]
  .filter(Boolean)
  .forEach(input => { input.onchange = runFloatingFind; });

if (els.floatingReplaceSelectedBtn) {
  els.floatingReplaceSelectedBtn.onclick = replaceSelectedFindResult;
}

if (els.floatingReplaceAllBtn) {
  els.floatingReplaceAllBtn.onclick = replaceAllFindResults;
}

if (els.saveLongGoalBtn) {
  els.saveLongGoalBtn.onclick = saveLongGoal;
}

if (els.clearLongGoalBtn) {
  els.clearLongGoalBtn.onclick = clearLongGoal;
}
  
  if (els.newManuscriptBtn) {
  els.newManuscriptBtn.onclick = handleNewManuscript;
}
  if (els.newSubDocBtn) {
  els.newSubDocBtn.onclick = handleNewSubDocument;
}
  if (els.importPdfBtn) {
  els.importPdfBtn.onclick = handlePdfImportClick;
}

if (els.pdfInput) {
  els.pdfInput.onchange = handlePdfImportFile;
}

  if (els.findNextBtn) {
  els.findNextBtn.onclick = () => {
    openFindPanel(els.findInput?.value || '');
  };
}

  if (els.replaceBtn) {
  els.replaceBtn.onclick = () => {
    openFindPanel(els.findInput?.value || '');

    if (els.floatingReplaceInput && els.replaceInput) {
      els.floatingReplaceInput.value = els.replaceInput.value || '';
    }
  };
}

  if (els.replaceAllBtn) {
  els.replaceAllBtn.onclick = () => {
    openFindPanel(els.findInput?.value || '');

    if (els.floatingReplaceInput && els.replaceInput) {
      els.floatingReplaceInput.value = els.replaceInput.value || '';
    }

    replaceAllFindResults();
  };
}

  if (els.saveGoalBtn) {
    els.saveGoalBtn.onclick = saveDocumentGoal;
  }

  if (els.saveMetaBtn) {
    els.saveMetaBtn.onclick = saveCurrentMetadata;
  }
  
  if (els.applyStatusToSubdocsBtn) {
  els.applyStatusToSubdocsBtn.onclick = applyCurrentStatusToSubdocs;
}
  
  if (els.docStatusSelect) {
  els.docStatusSelect.onchange = () => {
    saveCurrentMetadata();
  };
}

  window.addEventListener('naviwriter:editor-input', () => {
    updateInspector();
  });
  if (els.newDocBtn) {
    els.newDocBtn.onclick = handleNewDocument;
  }

  if (els.renameDocBtn) {
    els.renameDocBtn.onclick = handleRenameDocument;
  }

  if (els.duplicateDocBtn) {
    els.duplicateDocBtn.onclick = handleDuplicateDocument;
  }

  if (els.deleteDocBtn) {
    els.deleteDocBtn.onclick = handleDeleteDocument;
  }

  if (els.exportSelect) {
  els.exportSelect.onchange = event => {
    const format = event.target.value;

    if (!format) return;

    handleExportDocument(format);

    event.target.value = '';
  };
}

  if (els.importBtn) {
    els.importBtn.onclick = handleImportClick;
  }
  if (els.exportCurrentNaviDocBtn) {
    els.exportCurrentNaviDocBtn.onclick = async () => {
      if (!currentDocumentId) { showAppNotice('Open a document before exporting a NaviDoc.'); return; }
      const doc=await NaviStorage.getDocument(currentDocumentId);
      if(doc) await NaviExport.exportNaviDoc(doc);
    };
  }


  if (els.importFile) {
    els.importFile.onchange = handleImportFile;
  }

  if (els.docSearch) {
    els.docSearch.oninput = handleSearch;
  }

  if (els.focusBtn) {
  els.focusBtn.onclick = () => {
    const next = !document.body.classList.contains('focus-mode');
    setFocusMode(next);
  };
  }



if (els.exitFocusBtn) {
  els.exitFocusBtn.onclick = exitFocusMode;
}

  window.addEventListener('naviwriter:manual-save', () => {
    saveCurrentDocument({ manual: true });
  });
  window.addEventListener('keydown', event => {

if (document.body.classList.contains('board-mode-active')) {
  const isUndo =
    (event.ctrlKey || event.metaKey) &&
    !event.shiftKey &&
    event.key.toLowerCase() === 'z';

  const isRedo =
    (event.ctrlKey || event.metaKey) &&
    (
      event.key.toLowerCase() === 'y' ||
      (event.shiftKey && event.key.toLowerCase() === 'z')
    );

  if (isUndo) {
    event.preventDefault();
    undoBoardChange();
    return;
  }

  if (isRedo) {
    event.preventDefault();
    redoBoardChange();
    return;
  }
  
  if (
  event.key === 'Escape' &&
  (
    document.body.classList.contains('sidebar-drawer-open') ||
    document.body.classList.contains('inspector-drawer-open')
  )
) {
  closeResponsiveDrawers();
  return;
}
  
  if (
  event.key === 'Escape' &&
  els.commentsDrawer &&
  !els.commentsDrawer.classList.contains('hidden')
) {
  closeCommentsDrawer();
  return;
}
  
  if (
  event.key === 'Escape' &&
  els.outlinerCustomColumnsModal &&
  !els.outlinerCustomColumnsModal.classList.contains('hidden')
) {
  closeOutlinerCustomColumnsModal();
  return;
}
  
  if (
  event.key === 'Escape' &&
  els.customMetadataFieldsModal &&
  !els.customMetadataFieldsModal.classList.contains('hidden')
) {
  closeCustomMetadataFieldsModal();
  return;
}
  
  if (
  event.key === 'Escape' &&
  els.relationshipDashboardModal &&
  !els.relationshipDashboardModal.classList.contains('hidden')
) {
  closeRelationshipDashboardModal();
  return;
}
  
  if (
  event.key === 'Escape' &&
  els.localGraphModal &&
  !els.localGraphModal.classList.contains('hidden')
) {
  closeLocalGraphModal();
  return;
}
  
  if (
  event.key === 'Escape' &&
  els.relationshipTypesModal &&
  !els.relationshipTypesModal.classList.contains('hidden')
) {
  closeRelationshipTypesModal();
  return;
}
}
    
    if (
  event.key === 'Escape' &&
  els.relationshipModal &&
  !els.relationshipModal.classList.contains('hidden')
) {
  closeRelationshipModal();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.collectionDocPickerModal &&
  !els.collectionDocPickerModal.classList.contains('hidden')
) {
  closeCollectionDocPicker();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.collectionsModal &&
  !els.collectionsModal.classList.contains('hidden')
) {
  closeCollectionsModal();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.sourceModal &&
  !els.sourceModal.classList.contains('hidden')
) {
  closeSourceModal();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.splitPane &&
  !els.splitPane.classList.contains('hidden')
) {
  closeSplitEditor();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.outlinerModal &&
  !els.outlinerModal.classList.contains('hidden')
) {
  closeOutlinerModal();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.choiceModal &&
  !els.choiceModal.classList.contains('hidden')
) {
  closeChoiceModal();
  return;
}

if (
  event.key === 'Escape' &&
  els.boardLinkModal &&
  !els.boardLinkModal.classList.contains('hidden')
) {
  closeBoardLinkModal();
  return;
}

if (
  event.key === 'Escape' &&
  els.boardConnectionModal &&
  !els.boardConnectionModal.classList.contains('hidden')
) {
  closeBoardConnectionModal();
  return;
}
    
if (event.key === 'Escape' && els.matterPresetModal && !els.matterPresetModal.classList.contains('hidden')) {
  closeMatterPresetPicker();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.boardPersonModal &&
  !els.boardPersonModal.classList.contains('hidden')
) {
  closeBoardPersonModal();
  return;
}
    
    if (
  event.key === 'Escape' &&
  els.messageModal &&
  !els.messageModal.classList.contains('hidden')
) {
  closeMessageModal();
  return;
}
    
if (
  event.key === 'Escape' &&
  els.textInputModal &&
  !els.textInputModal.classList.contains('hidden')
) {
  closeTextInputModal();
  return;
}

if (
  event.key === 'Escape' &&
  els.confirmModal &&
  !els.confirmModal.classList.contains('hidden')
) {
  closeConfirmModal();
  return;
}

  if (event.key === 'Escape' && document.body.classList.contains('focus-mode')) {
    exitFocusMode();
  }

if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'f') {
  event.preventDefault();
  openFindPanel('');
}

  });
if (els.analysisScopeSelect) {
  els.analysisScopeSelect.onchange = () => {
    updateRepeatedTextAnalysis();
  };
}
if (els.statsScopeSelect) els.statsScopeSelect.onchange = () => updateInspector();
if (els.temporaryGoalScopeSelect) els.temporaryGoalScopeSelect.onchange = () => updateInspector();
if (els.longGoalScopeSelect) { els.longGoalScopeSelect.onchange = async () => { const preview = await resolveDocumentScope(currentDocumentId, els.longGoalScopeSelect.value); if (els.longGoalScopeSummary) els.longGoalScopeSummary.textContent = `${preview.docs.length} document${preview.docs.length === 1 ? '' : 's'} · Save to apply`; }; }
if (els.clearTemporaryGoalBtn) els.clearTemporaryGoalBtn.onclick = clearTemporaryGoal;

if (els.addBoardPersonBtn) {
  els.addBoardPersonBtn.onclick = addBoardPerson;
}

if (els.connectBoardItemsBtn) {
  els.connectBoardItemsBtn.onclick = connectBoardItems;
}

if (els.exportBoardBtn) {
  els.exportBoardBtn.onclick = exportCurrentBoard;
}

if (els.connectBoardItemsBtn) {
  els.connectBoardItemsBtn.onclick = connectBoardItems;
}

if (els.zoomInBoardBtn) {
  els.zoomInBoardBtn.onclick = zoomBoardIn;
}

if (els.zoomOutBoardBtn) {
  els.zoomOutBoardBtn.onclick = zoomBoardOut;
}

if (els.colorBoardItemBtn) {
  els.colorBoardItemBtn.onclick = colorSelectedBoardItem;
}

if (els.undoBoardBtn) {
  els.undoBoardBtn.onclick = undoBoardChange;
}

if (els.undoBoardBtn) {
  els.undoBoardBtn.onclick = undoBoardChange;
}

if (els.redoBoardBtn) {
  els.redoBoardBtn.onclick = redoBoardChange;
}

}

async function exportCurrentBoard() {
  
  const boardMoreMenu =
  document.querySelector('.board-more-menu');

if (boardMoreMenu) {
  boardMoreMenu.removeAttribute('open');
}
  
  const choice = await openChoiceModal({
    title: 'Export Board',
    subtitle: 'Choose the board export format.',
    options: [
      {
        value: 'html',
        icon: '🌐',
        title: 'HTML',
        desc: 'Export a visual board page you can open in a browser.'
      },
      {
        value: 'svg',
        icon: '🖼️',
        title: 'SVG',
        desc: 'Export the board as a scalable image.'
      },
      {
        value: 'png',
        icon: '📸',
        title: 'PNG',
        desc: 'Export the board as a shareable image.'
      },
      {
        value: 'json',
        icon: '{}',
        title: 'JSON',
        desc: 'Export raw board data for backup or future importing.'
      }
    ]
  });

  if (choice === 'json') {
    exportBoardJson();
    return;
  }

  if (choice === 'svg') {
    exportBoardSvg();
    return;
  }

  if (choice === 'png') {
    await exportBoardPng();
    return;
  }

  if (choice === 'html') {
    exportBoardHtml();
  }
}

function exportBoardJson() {
  const board = getBoardSnapshot();

  const title = NaviEditor.getEditorTitle
    ? NaviEditor.getEditorTitle()
    : 'Board';

  const json = JSON.stringify(board, null, 2);

  downloadBoardFile(
    `${safeFileName(title)}-board.json`,
    json,
    'application/json'
  );
}

function renderOutlinerCollectionLinks(doc) {
  const collections =
    getCollectionsForDocument(collectionsCache, doc.id);

  if (!collections.length) {
    return '<span class="outliner-muted">—</span>';
  }

  return collections.map(collection => {
    return `
      <button
        type="button"
        class="outliner-collection-link"
        data-outliner-collection="${escapeHtml(collection.id)}"
      >
        ${escapeHtml(collection.name)}
      </button>
    `;
  }).join('');
}

async function handleSaveMeta() {
  if (!currentDocumentId) return;

  const doc =
    await NaviStorage.getDocument(currentDocumentId);

  if (!doc) return;

  doc.folder =
    els.folderInput?.value.trim() || '';

  doc.tags =
    els.tagsInput?.value
      .split(',')
      .map(tag => tag.trim())
      .filter(Boolean) || [];

  doc.status =
    els.docStatusSelect?.value || 'Drafting';

  doc.pov =
    els.docPovInput?.value.trim() || '';

  doc.location =
    els.docLocationInput?.value.trim() || '';

  doc.timeline =
    els.docTimelineInput?.value.trim() || '';

  doc.characters =
    els.docCharactersInput?.value.trim() || '';

  doc.summary =
    els.docSummaryInput?.value.trim() || '';

  doc.updatedAt = Date.now();

  await NaviStorage.saveDocument(doc);

  await loadDocuments();

  NaviEditor.setSaveStatus('Details saved');
  if (els.detailsSaveFeedback) { els.detailsSaveFeedback.textContent='Saved'; els.detailsSaveFeedback.classList.add('saved'); setTimeout(()=>{els.detailsSaveFeedback.textContent='Changes save when you choose Save Details.';els.detailsSaveFeedback.classList.remove('saved');},1800); }
}

function exportBoardHtml() {
  const board = getBoardSnapshot();

  const title = NaviEditor.getEditorTitle
    ? NaviEditor.getEditorTitle()
    : 'Board';

  const html = buildBoardExportHtml(
    title,
    board
  );

  downloadBoardFile(
    `${safeFileName(title)}-board.html`,
    html,
    'text/html'
  );
}

async function getOutlinerBaseDocuments() {
  const scope =
    els.outlinerScopeSelect?.value || 'project';

  if (scope === 'all') {
    return await NaviStorage.getAllDocuments();
  }

  if (scope === 'folder') {
    const allDocs =
      await NaviStorage.getAllDocuments();

    return getFolderFilteredDocuments(allDocs);
  }

  if (!currentDocumentId) {
    return await NaviStorage.getAllDocuments();
  }

  const rootId =
    await getProjectRootDocumentId(currentDocumentId);

  if (!rootId) {
    return await NaviStorage.getAllDocuments();
  }

  return await getProjectDocuments(rootId);
}

function getOutlinerRelationshipToggleState() {
  return {
    explicit:
      els.outlinerShowExplicitRelationships?.checked !== false,

    collections:
      Boolean(
        els.outlinerShowCollectionRelationships?.checked
      ),

    folders:
      Boolean(
        els.outlinerShowFolderRelationships?.checked
      ),

    sources:
      Boolean(
        els.outlinerShowSourceRelationships?.checked
      ),

    tags:
      Boolean(
        els.outlinerShowTagRelationships?.checked
      )
  };
}

function buildImplicitSourceRelationships(docs = []) {
  const relationships = [];

  docs.forEach(doc => {
    const sources =
      getCurrentSourceList(doc);

    if (!sources.length) {
      return;
    }

    sources.forEach(source => {
      relationships.push(
        createImplicitRelationship({
          id: `implicit-source-${doc.id}-${source.id}`,
          sourceEntityType: 'document',
          sourceEntityId: doc.id,
          targetEntityType: 'source',
          targetEntityId: getSourceEntityId(
            doc.id,
            source.id
          ),
          relationType: 'has source',
          note: 'Implicit: research source',
          strength: 1
        })
      );
    });
  });

  return relationships;
}

function buildImplicitTagRelationships(docs = []) {
  const relationships = [];

  docs.forEach(doc => {
    const tags =
      Array.isArray(doc.tags)
        ? doc.tags
        : [];

    tags
      .map(tag => {
        return String(tag || '').trim();
      })
      .filter(Boolean)
      .forEach(tag => {
        relationships.push(
          createImplicitRelationship({
            id: `implicit-tag-${tag}-${doc.id}`,
            sourceEntityType: 'tag',
            sourceEntityId: tag,
            targetEntityType: 'document',
            targetEntityId: doc.id,
            relationType: 'includes',
            note: 'Implicit: document tag',
            strength: 1
          })
        );
      });
  });

  return relationships;
}

function createImplicitRelationship({
  id,
  sourceEntityType,
  sourceEntityId,
  targetEntityType,
  targetEntityId,
  relationType = 'contains',
  note = '',
  strength = 1
}) {
  return {
    id,
    sourceEntityType,
    sourceEntityId,
    targetEntityType,
    targetEntityId,
    relationType,
    note,
    strength,
    isImplicit: true
  };
}

async function buildImplicitCollectionRelationships(docs = []) {
  const visibleDocIds =
    new Set(
      docs.map(doc => doc.id)
    );

  const collections =
    await getCollections();

  const relationships = [];

  collections.forEach(collection => {
    const documentIds =
      Array.isArray(collection.documentIds)
        ? collection.documentIds
        : [];

    documentIds.forEach(docId => {
      if (!visibleDocIds.has(docId)) {
        return;
      }

      relationships.push(
        createImplicitRelationship({
          id: `implicit-collection-${collection.id}-${docId}`,
          sourceEntityType: 'collection',
          sourceEntityId: collection.id,
          targetEntityType: 'document',
          targetEntityId: docId,
          relationType: 'contains',
          note: 'Implicit: collection membership',
          strength: 1
        })
      );
    });
  });

  return relationships;
}

function buildImplicitFolderRelationships(docs = []) {
  const relationships = [];

  docs.forEach(doc => {
    const folder =
      getDocumentFolderName(doc);

    if (!folder || folder === 'Unfiled') {
      return;
    }

    relationships.push(
      createImplicitRelationship({
        id: `implicit-folder-${folder}-${doc.id}`,
        sourceEntityType: 'folder',
        sourceEntityId: folder,
        targetEntityType: 'document',
        targetEntityId: doc.id,
        relationType: 'contains',
        note: 'Implicit: folder membership',
        strength: 1
      })
    );
  });

  return relationships;
}

function preserveSelectValue(select, callback) {
  if (!select) return;

  const previous =
    select.value;

  callback();

  const hasPrevious =
    Array.from(select.options).some(option => {
      return option.value === previous;
    });

  if (hasPrevious) {
    select.value = previous;
  }
}

function populateOutlinerFolderFilter(docs = []) {
  if (!els.outlinerFolderFilterSelect) return;

  preserveSelectValue(els.outlinerFolderFilterSelect, () => {
    els.outlinerFolderFilterSelect.innerHTML =
      '<option value="">All Folders</option>';

    const folders =
      getFolderNamesFromDocuments(docs);

    folders.forEach(folder => {
      const option =
        document.createElement('option');

      option.value = folder;
      option.textContent = folder;

      els.outlinerFolderFilterSelect.appendChild(option);
    });
  });
}

function getStatusSortRank(status = '') {
  const normalized =
    normalizeStatus(status);

  const order = [
    '',
    'Idea',
    'Drafting',
    'Needs Rewrite',
    'Revising',
    'Final',
    'Reference'
  ];

  const index =
    order.indexOf(normalized);

  return index >= 0
    ? index
    : 999;
}

function sortDocumentsForOutliner(list = []) {
  const sortMode =
    els.outlinerSortSelect?.value || 'structure';

  if (sortMode === 'structure') {
    return sortDocumentsForDisplay(list);
  }

  return list.slice().sort((a, b) => {
    if (sortMode === 'title-asc') {
      return String(a.title || '').localeCompare(String(b.title || ''));
    }

    if (sortMode === 'title-desc') {
      return String(b.title || '').localeCompare(String(a.title || ''));
    }

    if (sortMode === 'words-desc') {
      return Number(b.wordCount || 0) - Number(a.wordCount || 0);
    }

    if (sortMode === 'words-asc') {
      return Number(a.wordCount || 0) - Number(b.wordCount || 0);
    }

    if (sortMode === 'status') {
      return (
        getStatusSortRank(getDocStatusForDisplay(a)) -
        getStatusSortRank(getDocStatusForDisplay(b))
      );
    }

    if (sortMode === 'updated-desc') {
      return Number(b.updatedAt || 0) - Number(a.updatedAt || 0);
    }

    if (sortMode === 'updated-asc') {
      return Number(a.updatedAt || 0) - Number(b.updatedAt || 0);
    }

    return 0;
  });
}

function downloadBoardFile(filename, content, type) {
  const blob = new Blob([content], {
    type
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');

  link.href = url;
  link.download = filename;
  link.click();

  URL.revokeObjectURL(url);
}

function buildBoardExportHtml(title, board) {
  const safeTitle = escapeHtml(title || 'Board');
  const connectorsSvg = buildBoardExportConnectorsSvg(board);

  const itemsHtml = board.items.map(item => {
    const left = Number(item.x || 0);
    const top = Number(item.y || 0);
    const width = Number(item.width || 240);
    const height = Number(item.height || 140);
    const color = item.color || '#fff8b5';
    const typeLabel = getReadableBoardType(item.type);

    const style = [
      `left:${left}px`,
      `top:${top}px`,
      `width:${width}px`,
      `min-height:${height}px`,
      `background:${color}`,
      `z-index:${Number(item.zIndex || 2)}`
    ].join(';');

    if (item.type === 'person') {
      return `
        <article class="export-board-card export-board-person" style="${style}">
          <div class="export-board-card-head">${escapeHtml(typeLabel)}</div>
          <div class="export-board-card-body">
            <h2>${escapeHtml(item.name || item.title || 'Unnamed Person')}</h2>
            <p class="export-board-role">${escapeHtml(item.role || 'Character')}</p>
            ${
              item.notes
                ? `<p>${escapeHtml(item.notes)}</p>`
                : ''
            }
          </div>
        </article>
      `;
    }

    if (item.type === 'link') {
      const url = normalizeExternalUrl(item.url || '');
      const host = item.docId
        ? 'NaviWriter document'
        : getHostnameFromUrl(url) || 'External link';

      return `
        <article class="export-board-card export-board-link" style="${style}">
          <div class="export-board-card-head">${escapeHtml(typeLabel)}</div>
          <div class="export-board-card-body">
            <h2>${escapeHtml(item.title || 'Untitled Link')}</h2>
            <div class="export-link-preview">
              <div class="export-link-domain">${escapeHtml(host)}</div>
              ${
                item.docId
                  ? `<div class="export-link-url">Linked document: ${escapeHtml(item.title || item.docId)}</div>`
                  : `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(item.url || url)}</a>`
              }
            </div>
          </div>
        </article>
      `;
    }

    if (item.type === 'image') {
      return `
        <article class="export-board-card export-board-image" style="${style}">
          <div class="export-board-card-head">${escapeHtml(typeLabel)}</div>
          <div class="export-board-card-body">
            <h2>${escapeHtml(item.title || 'Image')}</h2>
            ${
              item.src
                ? `<img src="${item.src}" alt="${escapeHtml(item.title || 'Board image')}" />`
                : `<p>No image data.</p>`
            }
          </div>
        </article>
      `;
    }

    return `
      <article class="export-board-card export-board-note" style="${style}">
        <div class="export-board-card-head">${escapeHtml(typeLabel)}</div>
        <div class="export-board-card-body">
          <h2>${escapeHtml(item.title || 'Note')}</h2>
          <p>${escapeHtml(item.text || '')}</p>
        </div>
      </article>
    `;
  }).join('\n');

  return `
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${safeTitle}</title>
  <style>
    * {
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0;
      min-height: 100%;
      background: #111827;
      color: #111827;
      font-family: Arial, Helvetica, sans-serif;
    }

    body {
      padding: 32px;
    }

    h1 {
      color: #f8fafc;
      margin: 0 0 18px;
      font-size: 22px;
    }

    .export-board {
      position: relative;
      width: 5000px;
      height: 3500px;
      overflow: hidden;
      border-radius: 18px;
      border: 1px solid rgba(148, 163, 184, 0.22);
      background:
        radial-gradient(circle, rgba(148, 163, 184, 0.26) 1px, transparent 1px),
        #111827;
      background-size: 22px 22px;
    }

    .export-board-connectors {
      position: absolute;
      inset: 0;
      width: 5000px;
      height: 3500px;
      pointer-events: none;
      z-index: 1;
    }

    .export-board-card {
      position: absolute;
      border-radius: 14px;
      overflow: hidden;
      border: 1px solid rgba(0, 0, 0, 0.16);
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.18);
    }

    .export-board-card-head {
      min-height: 28px;
      padding: 6px 10px;
      background: rgba(0, 0, 0, 0.08);
      display: flex;
      align-items: center;
      font-size: 11px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.03em;
    }

    .export-board-card-body {
      padding: 10px 12px 14px;
      font-size: 12px;
      line-height: 1.35;
    }

    .export-board-card-body h2 {
      margin: 0 0 6px;
      font-size: 16px;
      line-height: 1.15;
      color: #831843;
    }

    .export-board-role {
      margin: 0 0 8px;
      color: #9d174d;
      font-weight: 700;
    }

    .export-board-card-body p {
      margin: 0 0 6px;
      white-space: pre-wrap;
    }

    .export-board-image img {
      display: block;
      width: 100%;
      max-height: 220px;
      object-fit: contain;
      border-radius: 10px;
      background: #fff;
    }

    .export-link-preview {
      display: grid;
      gap: 4px;
      padding: 8px;
      border-radius: 10px;
      background: rgba(255, 255, 255, 0.65);
      border: 1px solid rgba(0, 0, 0, 0.08);
    }

    .export-link-domain {
      color: #0f172a;
      font-size: 11px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .export-link-url,
    .export-link-preview a {
      color: #1d4ed8;
      font-size: 12px;
      word-break: break-word;
      font-weight: 700;
    }

    .board-connector-label {
      font-size: 12px;
      font-weight: 800;
      fill: #ffffff;
      paint-order: stroke;
      stroke: rgba(0, 0, 0, 0.65);
      stroke-width: 3px;
    }
  </style>
</head>

<body>
  <h1>${safeTitle}</h1>
  <main class="export-board">
    ${connectorsSvg}
    ${itemsHtml}
  </main>
</body>
</html>
  `.trim();
}

function setupSplitResize(){const handle=els.splitResizeHandle,workspace=els.workspace;if(!handle||!workspace)return;const widthRatio=Math.max(.22,Math.min(.72,Number(localStorage.getItem('naviwriter-split-width-ratio')||.42))),heightRatio=Math.max(.25,Math.min(.72,Number(localStorage.getItem('naviwriter-split-height-ratio')||.46)));workspace.style.setProperty('--split-width-ratio',widthRatio);workspace.style.setProperty('--split-height-ratio',heightRatio);handle.onpointerdown=event=>{event.preventDefault();event.stopPropagation();handle.setPointerCapture?.(event.pointerId);const vertical=workspace.classList.contains('split-vertical')||matchMedia('(min-width:721px) and (max-width:1050px)').matches;function move(ev){const rect=workspace.getBoundingClientRect();if(vertical){const available=Math.max(1,rect.height-6),secondary=Math.max(180,Math.min(available-220,rect.bottom-ev.clientY)),ratio=Math.max(.25,Math.min(.72,secondary/available));workspace.style.setProperty('--split-height-ratio',ratio);localStorage.setItem('naviwriter-split-height-ratio',String(ratio));}else{const available=Math.max(1,rect.width-6),secondary=Math.max(260,Math.min(available-280,rect.right-ev.clientX)),ratio=Math.max(.22,Math.min(.72,secondary/available));workspace.style.setProperty('--split-width-ratio',ratio);localStorage.setItem('naviwriter-split-width-ratio',String(ratio));}window.dispatchEvent(new Event('resize'));}function up(ev){removeEventListener('pointermove',move);removeEventListener('pointerup',up);try{handle.releasePointerCapture?.(ev.pointerId);}catch{}}addEventListener('pointermove',move);addEventListener('pointerup',up);};}

function setupPaneResize(){
 const main=document.querySelector('.main-layout'),gutters=[document.getElementById('leftResize'),document.getElementById('rightResize')];if(!main)return;
 const orders={dei:['documents','editor','inspector'],ied:['inspector','editor','documents'],edi:['editor','documents','inspector'],eid:['editor','inspector','documents'],die:['documents','inspector','editor'],ide:['inspector','documents','editor']};
 const fixed=p=>p==='documents'||p==='inspector';
 const widthOf=p=>(p==='documents'?document.getElementById('sidebar'):document.getElementById('inspector')).getBoundingClientRect().width;
 function limits(panel,value){const min=panel==='documents'?210:230,max=panel==='documents'?520:560;return Math.max(min,Math.min(max,value));}
 function commit(preset,panel,value){value=Math.round(limits(panel,value));const key=panel==='documents'?'documentsWidth':'inspectorWidth',variable=panel==='documents'?'--preset-documents-width':'--preset-inspector-width';main.style.setProperty(variable,`${value}px`);saveWorkspacePresetSize(preset,key,value);const input=document.getElementById(panel==='documents'?'presetDocumentsSize':'presetInspectorSize');if(input){input.value=value;updatePresetRangeVisual(input);}}
 gutters.forEach((gutter,index)=>{if(!gutter)return;gutter.onpointerdown=e=>{const preset=main.dataset.workspacePreset||'dei',order=orders[preset];if(!order||document.body.dataset.layoutMode!=='desktop')return;e.preventDefault();const a=order[index],b=order[index+1],startX=e.clientX,a0=fixed(a)?widthOf(a):0,b0=fixed(b)?widthOf(b):0;function move(ev){const dx=ev.clientX-startX;if(fixed(a)&&fixed(b)){commit(preset,a,a0+dx);commit(preset,b,b0-dx);}else if(fixed(a)){commit(preset,a,a0+dx);}else if(fixed(b)){commit(preset,b,b0-dx);}}function up(){removeEventListener('pointermove',move);removeEventListener('pointerup',up)}addEventListener('pointermove',move);addEventListener('pointerup',up);};});
}async function handleExportProjectBackup() {
  if (!window.NaviExport?.exportProjectBackup) {
    showAppNotice(
  'Project backup export is not available.',
);
    return;
  }

  await saveCurrentDocument({
    manual: true
  });

  await NaviExport.exportProjectBackup();

  NaviEditor.setSaveStatus('Project backup exported');
}

function handleImportProjectBackupClick() {
  if (!els.projectBackupInput) {
    
    showAppNotice(
  'Backup import input is missing.',
);
    return;
  }

  els.projectBackupInput.click();
}

async function handleImportProjectBackupFile(event) {
  const file=event.target.files?.[0]; if(!file)return;
  try{
    const decoded=await NaviExport.decodeNativeFile(file,'naviwriter-backup');
    const approved=confirm('Restore this complete NaviWriter workspace backup?\n\nAll current durable NaviWriter data will be replaced.');
    if(!approved)return;
    await NaviExport.restoreWorkspacePayload(decoded.payload);
    showAppNotice('Workspace restored. NaviWriter will reload.');
    location.reload();
  }catch(error){console.error(error);await showAppError(error?.message||String(error),'Workspace restore failed.');}
  finally{event.target.value='';}
}

function supportsFileSystemAccess() {
  return typeof window.showSaveFilePicker === 'function' && typeof window.showOpenFilePicker === 'function' && window.isSecureContext !== false;
}

async function verifyFileHandlePermission(fileHandle, readWrite = false) {
  if (!fileHandle) return false;

  const options = readWrite
    ? { mode: 'readwrite' }
    : { mode: 'read' };

  if (typeof fileHandle.queryPermission === 'function') {
    const existingPermission =
      await fileHandle.queryPermission(options);

    if (existingPermission === 'granted') {
      return true;
    }
  }

  if (typeof fileHandle.requestPermission === 'function') {
    const requestedPermission =
      await fileHandle.requestPermission(options);

    return requestedPermission === 'granted';
  }

  return true;
}

async function getCurrentProjectPayload() {
  if (!window.NaviExport?.createProjectFilePayload) {
    throw new Error('Project file tools are not available.');
  }

  await saveCurrentDocument({
    manual: true
  });

  return await NaviExport.createProjectFilePayload();
}

async function writeProjectPayloadToHandle(fileHandle, payload) {
  const hasPermission =
    await verifyFileHandlePermission(fileHandle, true);

  if (!hasPermission) {
    throw new Error('Permission to write project file was denied.');
  }

  const writable = await fileHandle.createWritable();

  const encryptedBlob = await NaviNativeContainer.encode(payload, 'nwproj');
  await writable.write(encryptedBlob);

  await writable.close();
}

function setProjectFileStatus(message) {
  if (window.NaviEditor?.setSaveStatus) {
    NaviEditor.setSaveStatus(message);
  }

  if (!els.projectFileStatus) return;

  els.projectFileStatus.textContent = message;

  els.projectFileStatus.classList.remove(
    'linked',
    'warning',
    'error'
  );

  const lower = String(message || '').toLowerCase();

  if (
    lower.includes('saved') ||
    lower.includes('opened') ||
    lower.includes('linked')
  ) {
    els.projectFileStatus.classList.add('linked');
    return;
  }

  if (
    lower.includes('downloaded') ||
    lower.includes('needs') ||
    lower.includes('preview')
  ) {
    els.projectFileStatus.classList.add('warning');
    return;
  }

  if (
    lower.includes('error') ||
    lower.includes('failed')
  ) {
    els.projectFileStatus.classList.add('error');
  }
}

async function handleSaveProjectAs() {
  if (!supportsFileSystemAccess()) {
    await downloadProjectFileFallback();
    return;
  }

  try {
    const date = new Date()
      .toISOString()
      .slice(0, 10);

    const fileHandle = await window.showSaveFilePicker({
      suggestedName: `NaviWriter Project ${date}.nwproj`,
      types: [
        {
          description: 'NaviWriter Project File',
          accept: {
            'application/x-naviwriter-native': [
              '.nwproj'
            ]
          }
        }
      ]
    });

    const payload = await getCurrentProjectPayload();

    await writeProjectPayloadToHandle(fileHandle, payload);

    currentProjectFileHandle = fileHandle;
    currentProjectFileName = fileHandle.name || 'NaviWriter Project';

    setProjectFileStatus(`Project saved: ${currentProjectFileName}`);
    scheduleProjectFileAutosave();
  } catch (error) {
    if (error?.name === 'AbortError') {
      return;
    }

    if (isFilePickerBlockedError(error)) {
      console.warn(
        'File picker blocked by embedded/cross-origin environment. Falling back to download.',
        error
      );

      await downloadProjectFileFallback();
      
  

      showAppNotice(
  'Because you are in preview mode, automatic saving is off. A .nwproj file was downloaded to your computer to keep your work safe. \n\n' +
  'To easily update your original file, open your project in a Chromium browser (Chrome, Edge, or Brave) and select Save Project File.'
);

      return;
    }

    
    console.error('Save Project As failed:', error);
    window.NaviDiagnostics?.report?.({severity:'error',subsystem:'Project save as',message:error?.message||String(error),error,recovered:true});
    await showAppError(
  error?.message || String(error),
  'Save Project As failed.'
);
    setProjectFileStatus('Project save error');
  }
}

async function handleSaveProjectFile() {
  if (projectFileSaveInFlight) { setProjectFileStatus('Project save already in progress'); return; }
  if (!currentProjectFileHandle) {
    await handleSaveProjectAs();
    return;
  }

  try {
    projectFileSaveInFlight = true;
    const payload = await getCurrentProjectPayload();

    await writeProjectPayloadToHandle(
      currentProjectFileHandle,
      payload
    );

    setProjectFileStatus(
      `Project file saved${currentProjectFileName ? `: ${currentProjectFileName}` : ''}`
    );
  } catch (error) {
    console.error('Project file save failed:', error);
    window.NaviDiagnostics?.report?.({severity:'error',subsystem:'Project save',message:error?.message||String(error),error,recovered:true});

    if (isFilePickerBlockedError(error)) {
      await downloadProjectFileFallback();

      showAppNotice(
        'This environment blocked direct project-file saving.\n\n' +
        'NaviWriter downloaded an updated project file instead.'
      );

      return;
    }

    const retry = confirm(
      `Project file save failed:\n\n${error?.message || error}\n\nSave as a new project file?`
    );

    if (retry) {
      currentProjectFileHandle = null;
      currentProjectFileName = '';
      await handleSaveProjectAs();
    } else {
      setProjectFileStatus('Project file save error');
    }
  } finally {
    projectFileSaveInFlight = false;
  }
}

async function handleOpenProjectFile() {
  if (!supportsFileSystemAccess()) {
    handleImportClick();
    return;
  }

  try {
    const [fileHandle] = await window.showOpenFilePicker({
      multiple: false,
      types: [
        {
          description: 'NaviWriter Project File',
          accept: {
            'application/x-naviwriter-native': [
              '.nwproj'
            ]
          }
        }
      ]
    });

    const hasPermission =
      await verifyFileHandlePermission(fileHandle, false);

    if (!hasPermission) {
      throw new Error('Permission to read project file was denied.');
    }

    const file = await fileHandle.getFile();
    const decodedProject = await NaviExport.decodeNativeFile(file, 'nwproj');
    const replaceExisting = confirm('Open this NaviWriter project?\n\nThe currently loaded project will be replaced.');
    if(!replaceExisting)return;
    const result = await NaviExport.importProjectPayload(decodedProject.payload);

    await loadDocuments();

    if (result.documents && result.documents.length) {
      await openDocument(result.documents[0].id);
    }

    if (replaceExisting) {
      currentProjectFileHandle = fileHandle;
      currentProjectFileName = file.name || 'NaviWriter Project';
      scheduleProjectFileAutosave();
    } else {
      currentProjectFileHandle = null;
      currentProjectFileName = '';
      scheduleProjectFileAutosave();
    }

    setProjectFileStatus(
      replaceExisting
        ? `Project opened: ${currentProjectFileName}`
        : `Imported ${result.documents.length} document${result.documents.length === 1 ? '' : 's'} as copies`
    );
  } catch (error) {
    if (error?.name === 'AbortError') {
      return;
    }

    if (isFilePickerBlockedError(error)) {
      console.warn(
        'File picker blocked by embedded/cross-origin environment. Falling back to file input.',
        error
      );

      showAppNotice(
        'This preview environment blocks direct project-file opening.\n\n' +
        'Use the normal Import Project Backup picker instead.'
      );

      handleImportClick();
      return;
    }

    console.error('Open Project File failed:', error);
    window.NaviDiagnostics?.report?.({severity:'error',subsystem:'Project open',message:error?.message||String(error),error,recovered:true});
    await showAppError(
  error?.message || String(error),
  'Open Project File failed.'
);
    setProjectFileStatus('Project open error');
  }
}

function isFilePickerBlockedError(error) {
  const message = String(error?.message || error || '');

  return (
    error?.name === 'SecurityError' ||
    message.includes('Cross origin sub frames') ||
    message.includes('not allowed to show a file picker') ||
    message.includes('blocked by the same-origin policy')
  );
}

function loadProjectFileAutosaveSetting() {
  const saved =
    localStorage.getItem(PROJECT_FILE_AUTOSAVE_KEY) || '0';

  if (els.projectAutosaveSelect) {
    els.projectAutosaveSelect.value = saved;
  }
}

function getProjectFileAutosaveMinutes() {
  return Number(els.projectAutosaveSelect?.value || 0) || 0;
}

function scheduleProjectFileAutosave() {
  clearInterval(projectFileAutosaveTimer);
  projectFileAutosaveTimer = null;

  const minutes = getProjectFileAutosaveMinutes();

  localStorage.setItem(
    PROJECT_FILE_AUTOSAVE_KEY,
    String(minutes)
  );

  if (!minutes) {
    return;
  }

  if (!currentProjectFileHandle) {
    setProjectFileStatus('Auto project save needs Save Project As in a supported browser.');
    return;
  }

  projectFileAutosaveTimer = setInterval(() => {
    handleSaveProjectFile();
  }, minutes * 60 * 1000);
}

function handleProjectAutosaveChange() {
  const minutes = getProjectFileAutosaveMinutes();

  localStorage.setItem(
    PROJECT_FILE_AUTOSAVE_KEY,
    String(minutes)
  );

  if (minutes && !currentProjectFileHandle) {
    showAppNotice('Use Save Project As first before enabling automatic project file saves.');
  }

  scheduleProjectFileAutosave();
}

async function downloadProjectFileFallback() {
  const payload = await getCurrentProjectPayload();

  const date = new Date()
    .toISOString()
    .slice(0, 10);

  const blob = await NaviNativeContainer.encode(payload, 'nwproj');

  const link = document.createElement('a');

  link.href = URL.createObjectURL(blob);
  link.download = `NaviWriter Project ${date}.nwproj`;
  link.click();

  URL.revokeObjectURL(link.href);

  setProjectFileStatus('Project file downloaded');
}


const OUTLINER_COLUMN_ORDER_KEY = 'outlinerColumnOrder:v1';
const OUTLINER_BASE_COLUMNS = [
  ['title','Title'],['type','Type'],['status','Status'],['words','Words'],['pov','POV'],['location','Location'],['folder','Folder'],['collections','Collections'],['updated','Updated']
];
let outlinerDraggedColumnKey = null;

function getOutlinerColumnDescriptors() {
  const table = els.outlinerTableBody?.closest('table');
  const headers = Array.from(table?.querySelectorAll('thead th') || []);
  return headers.map((header,index) => ({ key: header.dataset.columnKey || `column:${index}`, header, index }));
}
async function getSavedOutlinerColumnOrder(availableKeys) {
  const saved = await NaviStorage.getSetting(OUTLINER_COLUMN_ORDER_KEY, []);
  const valid = Array.isArray(saved) ? saved.filter(key => availableKeys.includes(key)) : [];
  return [...valid, ...availableKeys.filter(key => !valid.includes(key))];
}
function decorateOutlinerColumnKeys(customFields = []) {
  const table=els.outlinerTableBody?.closest('table'); if(!table)return;
  const headers=Array.from(table.querySelectorAll('thead th'));
  const keys=['title','type','status','words','pov','location','folder','collections',...customFields.map(field=>`metadata:${field.id}`),'updated'];
  headers.forEach((header,index)=>{header.dataset.columnKey=keys[index]||`column:${index}`;header.draggable=true;header.title='Drag to reorder this outliner column';});
}
async function applySavedOutlinerColumnOrder() {
  const table=els.outlinerTableBody?.closest('table'); if(!table || els.outlinerViewSelect?.value==='relationships')return;
  const descriptors=getOutlinerColumnDescriptors(); const available=descriptors.map(item=>item.key); if(!available.length)return;
  const order=await getSavedOutlinerColumnOrder(available); const indexByKey=new Map(descriptors.map(item=>[item.key,item.index]));
  const rows=Array.from(table.querySelectorAll('tr'));
  rows.forEach(row=>{const cells=Array.from(row.children);if(cells.length!==available.length)return;order.forEach(key=>{const cell=cells[indexByKey.get(key)];if(cell)row.appendChild(cell);});});
  wireOutlinerHeaderDragging();
}
function wireOutlinerHeaderDragging() {
  const headers=Array.from(els.outlinerTableBody?.closest('table')?.querySelectorAll('thead th')||[]);
  headers.forEach(header=>{
    header.ondragstart=event=>{outlinerDraggedColumnKey=header.dataset.columnKey;header.classList.add('outliner-column-dragging');event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',outlinerDraggedColumnKey);};
    header.ondragend=()=>{outlinerDraggedColumnKey=null;header.classList.remove('outliner-column-dragging');headers.forEach(item=>item.classList.remove('outliner-column-target'));};
    header.ondragover=event=>{if(outlinerDraggedColumnKey&&outlinerDraggedColumnKey!==header.dataset.columnKey){event.preventDefault();header.classList.add('outliner-column-target');}};
    header.ondragleave=()=>header.classList.remove('outliner-column-target');
    header.ondrop=async event=>{event.preventDefault();header.classList.remove('outliner-column-target');const source=outlinerDraggedColumnKey||event.dataTransfer.getData('text/plain');const target=header.dataset.columnKey;if(!source||!target||source===target)return;const current=Array.from(header.parentElement.children).map(item=>item.dataset.columnKey);const next=current.filter(key=>key!==source);next.splice(next.indexOf(target),0,source);await NaviStorage.saveSetting(OUTLINER_COLUMN_ORDER_KEY,next);await applySavedOutlinerColumnOrder();NaviEditor.setSaveStatus('Outliner column order saved');};
  });
}

function setupImageCaptionDialog() {
  const modal=document.getElementById('imageCaptionModal'); if(!modal)return;
  const preview=document.getElementById('imageCaptionPreview'), fileName=document.getElementById('imageCaptionFileName'), input=document.getElementById('imageCaptionInput');
  let resolver=null;
  const finish=value=>{modal.classList.add('hidden');const current=resolver;resolver=null;if(current)current(value);if(preview)preview.removeAttribute('src');};
  window.NaviWriterDialogs=window.NaviWriterDialogs||{};
  window.NaviWriterDialogs.requestImageCaption=({ file, dataUrl, caption = '', mode = 'insert' } = {})=>new Promise(resolve=>{
    resolver=resolve;
    const title=document.getElementById('imageCaptionModalTitle');
    const confirm=document.getElementById('confirmImageCaptionBtn');
    if(title) title.textContent=mode==='edit'?'Edit Image Caption':'Insert Image';
    if(confirm) confirm.textContent=mode==='edit'?'Save Caption':'Insert Image';
    if(fileName) fileName.textContent=file?.name || (mode==='edit'?'Existing image':'Selected image');
    if(preview) preview.src=dataUrl;
    if(input) input.value=caption;
    modal.classList.remove('hidden');
    setTimeout(()=>{input?.focus();input?.select();},0);
  });
  document.getElementById('confirmImageCaptionBtn').onclick=()=>finish(input?.value.trim()||'');
  document.getElementById('cancelImageCaptionBtn').onclick=()=>finish(null);
  document.getElementById('closeImageCaptionModalBtn').onclick=()=>finish(null);
  modal.addEventListener('click',event=>{if(event.target===modal)finish(null);});
  modal.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();finish(null);}if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();finish(input?.value.trim()||'');}});
}

const _setOutlinerTableHeaderPhase67 = setOutlinerTableHeader;
setOutlinerTableHeader = function(mode='table', customFields=[]) {
  _setOutlinerTableHeaderPhase67(mode, customFields);
  if(mode==='table') decorateOutlinerColumnKeys(customFields);
};
const _renderOutlinerPhase67 = renderOutliner;
renderOutliner = async function(...args) {
  const result=await _renderOutlinerPhase67(...args);
  await applySavedOutlinerColumnOrder();
  return result;
};


function setupShellChannelIcons() {
  const buttons = Array.from(document.querySelectorAll('[data-inspector-channel]'));
  const sync = tab => buttons.forEach(button => {
    const active = button.dataset.inspectorChannel === tab;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  buttons.forEach(button => button.addEventListener('click', () => {
    setInspectorTab(button.dataset.inspectorChannel);
    sync(button.dataset.inspectorChannel);
  }));
  sync(document.getElementById('inspectorChannelSelect')?.value || 'details');
  document.addEventListener('naviwriter:inspector-channel', event => sync(event.detail));
}
function setupShellCommandSections() {
  document.querySelectorAll('.shell-command-section-toggle').forEach(button => {
    button.addEventListener('click', () => {
      const body = button.nextElementSibling;
      const open = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', open ? 'false' : 'true');
      body.hidden = open;
    });
  });
}

function installRecoveryBranding() {
  const head = document.querySelector('.documents-sticky-controls .sidebar-head, .sidebar-head');
  if (!head || head.querySelector('.navi-brand-lockup')) return;
  const brand = document.createElement('div');
  brand.className = 'navi-brand-lockup';
  brand.innerHTML = '<span><strong>NaviWriter</strong><small>Offline Writing Suite</small></span>';
  head.prepend(brand);
}


function installRecoveryThemesPanel() {
  const inspector = document.getElementById('inspector');
  if (!inspector || document.getElementById('recoveryThemesSection')) return;
  const themes = [
    ['purple','Purple'],['midnight','Midnight'],['forest','Forest'],['rose','Rose'],
    ['ocean','Ocean'],['amber','Amber'],['plain-light','Plain Light'],['plain-dark','Plain Dark']
  ];
  const section = document.createElement('section');
  section.id = 'recoveryThemesSection';
  section.className = 'inspector-section recovery-themes-section';
  section.dataset.inspectorTab = 'view';
  const customFields = [
    ['bg','Base background'],['panel','Panel'],['panel2','Secondary panel'],['text','Main text'],
    ['muted','Muted text'],['line','Borders'],['accent','Primary accent'],['accent2','Secondary accent']
  ];
  section.innerHTML = `<div class="section-title">Themes</div><p class="recovery-themes-note">Choose a preset, then optionally customize its base palette and accents.</p><div class="recovery-theme-grid">${themes.map(([id,label]) => `<button type="button" data-theme-choice="${id}"><span class="recovery-theme-swatch recovery-theme-${id}"></span><span>${label}</span></button>`).join('')}</div><div class="custom-theme-editor"><div class="custom-theme-title">Custom palette</div><div class="custom-theme-field-grid">${customFields.map(([id,label])=>`<label><span>${label}</span><input type="color" data-custom-theme-field="${id}"></label>`).join('')}</div><div class="custom-theme-actions"><button id="saveCustomThemeBtn" type="button">Save Custom Palette</button><button id="resetCustomThemeBtn" type="button">Reset</button></div><div id="customThemeContrastNote" class="custom-theme-contrast-note"></div></div>`;
  const firstView = inspector.querySelector('[data-inspector-tab="view"]');
  if (firstView) firstView.before(section); else inspector.append(section);
  section.querySelectorAll('[data-theme-choice]').forEach(button => {
    button.addEventListener('click', () => window.NaviThemes?.applyTheme(button.dataset.themeChoice));
  });
  const updateContrastNote=()=>{const inputs=Array.from(section.querySelectorAll('[data-custom-theme-field]'));const values=Object.fromEntries(inputs.map(input=>[input.dataset.customThemeField,input.value]));const lum=hex=>{const c=hex.replace('#','');const rgb=[0,2,4].map(i=>parseInt(c.slice(i,i+2),16)/255).map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2]};const contrast=(Math.max(lum(values.text),lum(values.panel))+.05)/(Math.min(lum(values.text),lum(values.panel))+.05);document.getElementById('customThemeContrastNote').textContent=contrast<4.5?'Low contrast warning: main text may be difficult to read on panels.':'Text and panel contrast looks usable.';};
  const current=window.NaviThemes?.readCustomTheme?.()||{};section.querySelectorAll('[data-custom-theme-field]').forEach(input=>{const key=input.dataset.customThemeField;const computed=getComputedStyle(document.body).getPropertyValue(`--${key}`).trim();input.value=current[key]||(/^#[0-9a-f]{6}$/i.test(computed)?computed:'#777777');input.addEventListener('input',updateContrastNote);});updateContrastNote();
  document.getElementById('saveCustomThemeBtn').onclick=()=>{const values=Object.fromEntries(Array.from(section.querySelectorAll('[data-custom-theme-field]')).map(input=>[input.dataset.customThemeField,input.value]));window.NaviThemes?.saveCustomTheme?.(values);updateContrastNote();};
  document.getElementById('resetCustomThemeBtn').onclick=()=>{window.NaviThemes?.clearCustomTheme?.();const style=getComputedStyle(document.body);section.querySelectorAll('[data-custom-theme-field]').forEach(input=>{const value=style.getPropertyValue(`--${input.dataset.customThemeField}`).trim();if(/^#[0-9a-f]{6}$/i.test(value))input.value=value;});updateContrastNote();};
  document.getElementById('lightModeBtn')?.classList.add('legacy-light-toggle-hidden');
  setupCollapsibleInspectorSections();
  const saved = localStorage.getItem('naviwriter-theme') || 'purple';
  section.querySelectorAll('[data-theme-choice]').forEach(button => button.classList.toggle('active', button.dataset.themeChoice === saved));
}


function updateDetailedDocumentStatus() {
  const doc = documentsCache.find(item => String(item.id) === String(currentDocumentId));
  const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value||'—';};
  if(!doc){['statusDocumentType','statusDocumentState','statusDocumentParent','statusLastModified'].forEach(id=>set(id,'No document open'));set('statusStorageMode','Local browser storage');return;}
  const parent=doc.parentId?documentsCache.find(item=>String(item.id)===String(doc.parentId)):null;
  const type=doc.type==='manuscript'?'Manuscript':doc.type==='pdf'?'PDF':doc.type==='notes'?'Notes':'Document';
  set('statusDocumentType',type); set('statusDocumentState',doc.status||'No status'); set('statusDocumentParent',parent?.title||'Top level');
  const stamp=Number(doc.updatedAt||doc.createdAt||0);set('statusLastModified',stamp?new Date(stamp).toLocaleString():'Unknown');set('statusStorageMode','Local browser storage');
}





function setupCombinedLayoutViewControls(){
  const syncAppearance=()=>{
    if(window.NaviThemes?.syncAppearanceModeControls){window.NaviThemes.syncAppearanceModeControls();return;}
    const mode=localStorage.getItem('naviwriter-appearance-mode') || (document.body.classList.contains('light')?'light':'dark');
    document.querySelectorAll('[data-appearance-mode]').forEach(button=>{
      const active=button.dataset.appearanceMode===mode;
      button.classList.toggle('active',active);
      button.setAttribute('aria-pressed',active?'true':'false');
    });
  };
  document.querySelectorAll('[data-appearance-mode]').forEach(button=>{
    button.onclick=()=>{window.NaviThemes?.setLightMode(button.dataset.appearanceMode==='light');syncAppearance();};
  });
  document.addEventListener('naviwriter:appearance-mode-change',syncAppearance);
  window.addEventListener('storage',event=>{if(['naviwriter-appearance-mode','naviwriter-light-mode'].includes(event.key))syncAppearance();});
  setTimeout(syncAppearance,0);
  const focusButton=document.getElementById('focusModeViewBtn');
  if(focusButton)focusButton.onclick=()=>setFocusMode(!document.body.classList.contains('focus-mode'));
  document.addEventListener('naviwriter:focus-change',event=>{if(focusButton)focusButton.textContent=event.detail?'Exit Focus':'Enter Focus';});
  window.NaviThemes?.syncAppearanceModeControls?.();
}


function loadNaviLocalScript(src,globalName){
  return new Promise(resolve=>{
    if(window[globalName])return resolve(true);
    const existing=document.querySelector(`script[data-navi-local="${globalName}"]`);
    if(existing){existing.addEventListener('load',()=>resolve(Boolean(window[globalName])),{once:true});existing.addEventListener('error',()=>resolve(false),{once:true});return;}
    const script=document.createElement('script');script.src=src;script.dataset.naviLocal=globalName;script.onload=()=>resolve(Boolean(window[globalName]));script.onerror=()=>resolve(false);document.head.appendChild(script);
  });
}
async function initializeLocalDocumentLibraries(){
  const [mammothReady,jszipReady]=await Promise.all([
    loadNaviLocalScript('./js/vendor/mammoth.browser.min.js','mammoth'),
    loadNaviLocalScript('./js/vendor/jszip.min.js','JSZip')
  ]);
  window.NaviLocalLibraries={mammoth:mammothReady,jszip:jszipReady,pdf:Boolean(await Promise.resolve(window.NaviPdfReady).catch(()=>false))};
  document.dispatchEvent(new CustomEvent('naviwriter:local-libraries',{detail:window.NaviLocalLibraries}));
}


function isNaviEditableControl(target){
  if(!target)return false;
  return Boolean(target.closest('input, textarea, select, [contenteditable="true"]'));
}
function editorHasKeyboardFocus(){
  const root=getEditorContentRoot();
  return Boolean(root && (root===document.activeElement || root.contains(document.activeElement)));
}
function runNaviEditorShortcut(command){
  if(window.NaviTiptap?.run)return window.NaviTiptap.run(command);
  return false;
}
function setupKeyboardShortcuts(){
  if(document.documentElement.dataset.naviShortcutsReady==='true')return;
  document.documentElement.dataset.naviShortcutsReady='true';
  window.addEventListener('keydown',event=>{
    const key=String(event.key||'').toLowerCase();
    const mod=event.ctrlKey||event.metaKey;
    const editable=isNaviEditableControl(event.target);
    if(event.key==='Escape')return;
    if(!mod)return;
    if(key==='s'&&!event.shiftKey){event.preventDefault();event.stopImmediatePropagation();saveCurrentDocument({manual:true});return;}
    if(key==='f'&&!event.shiftKey){event.preventDefault();event.stopImmediatePropagation();openFindPanel('');setTimeout(()=>els.floatingFindInput?.focus(),0);return;}
    if(key==='f'&&event.shiftKey){event.preventDefault();event.stopImmediatePropagation();setFocusMode(!document.body.classList.contains('focus-mode'));return;}
    if(key==='n'&&!event.shiftKey&&!editable){event.preventDefault();event.stopImmediatePropagation();handleNewDocument();return;}
    if(key==='n'&&event.shiftKey&&!editable){event.preventDefault();event.stopImmediatePropagation();handleNewManuscript();return;}
    if(key==='i'&&event.shiftKey&&!editable){event.preventDefault();event.stopImmediatePropagation();document.getElementById('insertImageBtn')?.click();return;}
    if(!event.shiftKey&&['1','2','3','4','5'].includes(key)&&!editable){
      const tabs=['actions','view','details','review','analysis'];event.preventDefault();event.stopImmediatePropagation();setInspectorTab(tabs[Number(key)-1]);return;
    }
    if(!editorHasKeyboardFocus())return;
    if(key==='b'&&!event.shiftKey){event.preventDefault();event.stopImmediatePropagation();runNaviEditorShortcut('bold');return;}
    if(key==='i'&&!event.shiftKey){event.preventDefault();event.stopImmediatePropagation();runNaviEditorShortcut('italic');return;}
    if(key==='u'&&!event.shiftKey){event.preventDefault();event.stopImmediatePropagation();runNaviEditorShortcut('underline');return;}
    if(key==='z'&&!event.shiftKey){event.preventDefault();event.stopImmediatePropagation();runNaviEditorShortcut('undo');return;}
    if((key==='z'&&event.shiftKey)||key==='y'){event.preventDefault();event.stopImmediatePropagation();runNaviEditorShortcut('redo');}
  },true);
}



function updatePresetRangeVisual(input){
  if(!input)return;
  const min=Number(input.min)||0,max=Number(input.max)||100,value=Number(input.value)||min;
  const percentage=Math.max(0,Math.min(100,((value-min)/(max-min))*100));
  input.style.setProperty('--range-fill',`${percentage}%`);
  const suffix=input.id==='presetSharedSplit'?'%':'px';input.closest('label')?.style.setProperty('--range-value',`"${Math.round(value)}${suffix}"`);
}

const NAVI_WORKSPACE_PRESET_KEY='naviwriter-workspace-presets-v2';
const NAVI_WORKSPACE_SIZE_KEY='naviwriter-workspace-preset-sizes-v2';
const NAVI_WORKSPACE_PRESETS={
  desktop:[
    ['dei','Documents · Editor · Inspector',['D','E','I']],
    ['ied','Inspector · Editor · Documents',['I','E','D']],
    ['edi','Editor · Documents · Inspector',['E','D','I']],
    ['eid','Editor · Inspector · Documents',['E','I','D']],
    ['die','Documents · Inspector · Editor',['D','I','E']],
    ['ide','Inspector · Documents · Editor',['I','D','E']],
    ['e-di','Editor above · Documents / Inspector',['E','D','I']],
    ['e-id','Editor above · Inspector / Documents',['E','I','D']],
    ['di-e','Documents above Inspector · Editor',['D','I','E']],
    ['id-e','Inspector above Documents · Editor',['I','D','E']],
    ['di-top','Documents / Inspector above Editor',['D','I','E']],
    ['id-top','Inspector / Documents above Editor',['I','D','E']],
    ['d-e-i','Documents above · Editor · Inspector below',['D','E','I']],
    ['i-e-d','Inspector above · Editor · Documents below',['I','E','D']],
    ['e-d-i','Editor above · Documents · Inspector below',['E','D','I']],
    ['e-i-d','Editor above · Inspector · Documents below',['E','I','D']]
  ],
  compact:[
    ['c-edi','Editor · Documents · Inspector',['E','D','I']],
    ['c-eid','Editor · Inspector · Documents',['E','I','D']],
    ['c-dei','Documents · Editor · Inspector',['D','E','I']],
    ['c-ied','Inspector · Editor · Documents',['I','E','D']]
  ]
};
function readNaviJson(key,fallback={}){try{return JSON.parse(localStorage.getItem(key)||'null')||fallback}catch{return fallback}}
function workspacePresetKind(){return document.body.dataset.layoutMode==='compact'?'compact':'desktop'}
function workspacePresetDefaults(id){return {documentsWidth:280,inspectorWidth:310,stackedHeight:250,topRowHeight:250,middleRowHeight:300,sharedSplit:50}}
function saveWorkspacePresetSize(id,key,value){const all=readNaviJson(NAVI_WORKSPACE_SIZE_KEY,{});all[id]={...workspacePresetDefaults(id),...(all[id]||{}),[key]:Number(value)};localStorage.setItem(NAVI_WORKSPACE_SIZE_KEY,JSON.stringify(all));}
function applyWorkspacePreset(id,{save=true}={}){
  const main=document.querySelector('.main-layout');if(!main)return;
  const kind=workspacePresetKind();const allowed=(NAVI_WORKSPACE_PRESETS[kind]||[]).map(item=>item[0]);
  if(!allowed.includes(id))id=allowed[0];
  main.dataset.workspacePreset=id;document.body.dataset.workspacePreset=id;
  const size={...workspacePresetDefaults(id),...(readNaviJson(NAVI_WORKSPACE_SIZE_KEY,{})[id]||{})};
  main.style.setProperty('--preset-documents-width',`${size.documentsWidth}px`);
  main.style.setProperty('--preset-inspector-width',`${size.inspectorWidth}px`);
  main.style.setProperty('--preset-stacked-height',`${size.stackedHeight}px`);main.style.setProperty('--preset-top-row-height',`${size.topRowHeight}px`);main.style.setProperty('--preset-middle-row-height',`${size.middleRowHeight}px`);main.style.setProperty('--preset-shared-split',`${size.sharedSplit}%`);
  if(save){const prefs=readNaviJson(NAVI_WORKSPACE_PRESET_KEY,{});prefs[kind]=id;localStorage.setItem(NAVI_WORKSPACE_PRESET_KEY,JSON.stringify(prefs));}
  document.querySelectorAll('[data-workspace-preset]').forEach(button=>{const selected=button.dataset.workspacePreset===id;button.dataset.selected=selected?'true':'false';button.classList.toggle('active',selected);button.setAttribute('aria-pressed',selected?'true':'false');});
  const stacked=['e-di','e-id','di-e','id-e','di-top','id-top','d-e-i','i-e-d','e-d-i','e-i-d'].includes(id); const topRow=['di-top','id-top','d-e-i','i-e-d','e-d-i','e-i-d'].includes(id); const sharedSplit=['e-di','e-id','di-top','id-top','di-e','id-e'].includes(id); const middleRow=['d-e-i','i-e-d','e-d-i','e-i-d'].includes(id);
  document.querySelector('[data-size-control="stacked"]')?.toggleAttribute('hidden',!stacked);document.querySelector('[data-size-control="top-row"]')?.toggleAttribute('hidden',!topRow);document.querySelector('[data-size-control="shared-split"]')?.toggleAttribute('hidden',!sharedSplit);document.querySelector('[data-size-control="middle-row"]')?.toggleAttribute('hidden',!middleRow);
  for(const [inputId,key] of [['presetDocumentsSize','documentsWidth'],['presetInspectorSize','inspectorWidth'],['presetStackedSize','stackedHeight'],['presetTopRowSize','topRowHeight'],['presetMiddleRowSize','middleRowHeight'],['presetSharedSplit','sharedSplit']]){const input=document.getElementById(inputId);if(input){input.value=String(size[key]);updatePresetRangeVisual(input);}}
  requestAnimationFrame(()=>{clampWorkspaceGeometryToViewport();window.NaviRefreshWorkspaceGutters?.();});
}
function renderWorkspacePresets(){
  const grid=document.getElementById('workspacePresetGrid');if(!grid)return;
  const kind=workspacePresetKind();grid.innerHTML='';
  for(const [id,label,cells] of NAVI_WORKSPACE_PRESETS[kind]){
    const button=document.createElement('button');button.type='button';button.dataset.workspacePreset=id;button.setAttribute('aria-label',label);
    button.innerHTML=`<span class="workspace-wire workspace-wire-${id}">${cells.map(cell=>`<i data-cell="${cell}">${cell}</i>`).join('')}</span><span>${label}</span>`;
    button.onclick=()=>applyWorkspacePreset(id);grid.append(button);
  }
  const pref=readNaviJson(NAVI_WORKSPACE_PRESET_KEY,{})[kind]||NAVI_WORKSPACE_PRESETS[kind][0][0];applyWorkspacePreset(pref,{save:false});
}
function setupWorkspacePresets(){
  const main=document.querySelector('.main-layout');if(!main||!document.getElementById('workspacePresetGrid'))return;
  renderWorkspacePresets();
  const bindings=[['presetDocumentsSize','documentsWidth','--preset-documents-width'],['presetInspectorSize','inspectorWidth','--preset-inspector-width'],['presetStackedSize','stackedHeight','--preset-stacked-height'],['presetTopRowSize','topRowHeight','--preset-top-row-height'],['presetMiddleRowSize','middleRowHeight','--preset-middle-row-height'],['presetSharedSplit','sharedSplit','--preset-shared-split']];
  for(const [id,key,variable] of bindings){const input=document.getElementById(id);if(!input)continue;input.oninput=()=>{const preset=main.dataset.workspacePreset||'dei';saveWorkspacePresetSize(preset,key,input.value);const unit=id==='presetSharedSplit'?'%':'px';main.style.setProperty(variable,`${input.value}${unit}`);updatePresetRangeVisual(input);requestAnimationFrame(()=>{clampWorkspaceGeometryToViewport();window.NaviRefreshWorkspaceGutters?.();});};}
  const reset=document.getElementById('resetWorkspacePresetBtn');if(reset)reset.onclick=()=>{const preset=main.dataset.workspacePreset||'dei';const all=readNaviJson(NAVI_WORKSPACE_SIZE_KEY,{});delete all[preset];localStorage.setItem(NAVI_WORKSPACE_SIZE_KEY,JSON.stringify(all));applyWorkspacePreset(preset,{save:false});};
  const resetDefault=document.getElementById('resetDefaultLayoutBtn');if(resetDefault)resetDefault.onclick=()=>{localStorage.removeItem(NAVI_WORKSPACE_PRESET_KEY);localStorage.removeItem(NAVI_WORKSPACE_SIZE_KEY);saveLayoutPreference('auto');applyLayoutMode();renderWorkspacePresets();applyWorkspacePreset('dei',{save:true});};
  let priorKind=workspacePresetKind();window.addEventListener('resize',()=>{const next=workspacePresetKind();if(next!==priorKind){priorKind=next;renderWorkspacePresets();}},{passive:true});
  document.addEventListener('naviwriter:layout-mode-change',renderWorkspacePresets);
}


function setupVerticalPresetResize(){
 const main=document.querySelector('.main-layout');if(!main)return;
 const ensure=(id,cls)=>{let node=document.getElementById(id);if(!node){node=document.createElement('div');node.id=id;node.className=cls;main.append(node);}return node;};
 const row1=ensure('workspaceRowResize','workspace-row-resize');
 const row2=ensure('workspaceRowResize2','workspace-row-resize workspace-row-resize-2');
 const col=ensure('workspaceColumnResize','workspace-column-resize');
 const panel=id=>id==='documents'?document.getElementById('sidebar'):id==='inspector'?document.getElementById('inspector'):document.querySelector('.workspace');
 const threeRows={
  'd-e-i':['documents','editor','inspector'],'i-e-d':['inspector','editor','documents'],
  'e-d-i':['editor','documents','inspector'],'e-i-d':['editor','inspector','documents']
 };
 const hide=node=>{node.style.setProperty('display','none','important');};
 const show=(node,styles)=>{node.style.setProperty('display','block','important');for(const [key,value] of Object.entries(styles))node.style.setProperty(key,value,'important');};
 function localRect(element){const outer=main.getBoundingClientRect(),rect=element.getBoundingClientRect();return {left:rect.left-outer.left,top:rect.top-outer.top,right:rect.right-outer.left,bottom:rect.bottom-outer.top,width:rect.width,height:rect.height};}
 function refresh(){
  hide(row1);hide(row2);hide(col);
  if(document.body.dataset.layoutMode!=='desktop')return;
  const preset=main.dataset.workspacePreset||'';
  if(['e-di','e-id'].includes(preset)){
   const editor=localRect(panel('editor')),lowerA=localRect(panel('documents')),lowerB=localRect(panel('inspector'));
   show(row1,{left:'0px',right:'0px',top:`${editor.bottom-6}px`});
   show(col,{left:`${Math.max(lowerA.left,lowerB.left)-6}px`,top:`${Math.min(lowerA.top,lowerB.top)}px`,bottom:`${Math.max(0,main.clientHeight-Math.max(lowerA.bottom,lowerB.bottom))}px`});
  }else if(['di-top','id-top'].includes(preset)){
   const docs=localRect(panel('documents')),inspector=localRect(panel('inspector')),editor=localRect(panel('editor'));
   show(row1,{left:'0px',right:'0px',top:`${editor.top-6}px`});
   show(col,{left:`${Math.max(docs.left,inspector.left)-6}px`,top:`${Math.min(docs.top,inspector.top)}px`,bottom:`${Math.max(0,main.clientHeight-Math.max(docs.bottom,inspector.bottom))}px`});
  }else if(['di-e','id-e'].includes(preset)){
   const docs=localRect(panel('documents')),inspector=localRect(panel('inspector')),editor=localRect(panel('editor'));
   show(col,{left:`${editor.left-6}px`,top:'0px',bottom:'0px'});
   show(row1,{left:'0px',right:`${Math.max(0,main.clientWidth-editor.left)}px`,top:`${Math.max(docs.top,inspector.top)-6}px`});
  }else if(threeRows[preset]){
   const [a,b]=threeRows[preset].map(panel).map(localRect);
   show(row1,{left:'0px',right:'0px',top:`${a.bottom-6}px`});
   show(row2,{left:'0px',right:'0px',top:`${b.bottom-6}px`});
  }
 }
 function updateInput(id,value){const input=document.getElementById(id);if(input){input.value=String(Math.round(value));updatePresetRangeVisual(input);}}
 function saveDimension(preset,key,variable,value,inputId,unit='px'){main.style.setProperty(variable,`${value}${unit}`);saveWorkspacePresetSize(preset,key,value);updateInput(inputId,value);requestAnimationFrame(refresh);}
 row1.onpointerdown=e=>{
  const preset=main.dataset.workspacePreset||'',bbox=main.getBoundingClientRect();e.preventDefault();
  function move(ev){
   const h=bbox.height,y=ev.clientY-bbox.top,minSide=150,minEditor=240;
   if(['e-di','e-id'].includes(preset)){const bottom=Math.max(minSide,Math.min(h-minEditor,h-y));saveDimension(preset,'stackedHeight','--preset-stacked-height',bottom,'presetStackedSize');}
   else if(['di-top','id-top'].includes(preset)){const top=Math.max(minSide,Math.min(h-minEditor,y));saveDimension(preset,'topRowHeight','--preset-top-row-height',top,'presetTopRowSize');}
   else if(['di-e','id-e'].includes(preset)){const pct=Math.round(Math.max(25,Math.min(75,(y/h)*100)));saveDimension(preset,'sharedSplit','--preset-shared-split',pct,'presetSharedSplit','%');}
   else if(threeRows[preset]){const saved={...workspacePresetDefaults(preset),...(readNaviJson(NAVI_WORKSPACE_SIZE_KEY,{})[preset]||{})};const maxTop=Math.max(minSide,h-saved.stackedHeight-minEditor);const top=Math.max(minSide,Math.min(maxTop,y));saveDimension(preset,'topRowHeight','--preset-top-row-height',top,'presetTopRowSize');}
  }
  function up(){removeEventListener('pointermove',move);removeEventListener('pointerup',up);refresh();}addEventListener('pointermove',move);addEventListener('pointerup',up);
 };
 row2.onpointerdown=e=>{
  const preset=main.dataset.workspacePreset||'',bbox=main.getBoundingClientRect();if(!threeRows[preset])return;e.preventDefault();
  function move(ev){const h=bbox.height,y=ev.clientY-bbox.top,minSide=150,minEditor=240;const saved={...workspacePresetDefaults(preset),...(readNaviJson(NAVI_WORKSPACE_SIZE_KEY,{})[preset]||{})};const maxBottom=Math.max(minSide,h-saved.topRowHeight-minEditor);const bottom=Math.max(minSide,Math.min(maxBottom,h-y));saveDimension(preset,'stackedHeight','--preset-stacked-height',bottom,'presetStackedSize');}
  function up(){removeEventListener('pointermove',move);removeEventListener('pointerup',up);refresh();}addEventListener('pointermove',move);addEventListener('pointerup',up);
 };
 col.onpointerdown=e=>{
  const preset=main.dataset.workspacePreset||'',bbox=main.getBoundingClientRect();e.preventDefault();
  function move(ev){
   const x=ev.clientX-bbox.left;
   if(['e-di','e-id','di-top','id-top'].includes(preset)){const pct=Math.round(Math.max(25,Math.min(75,(x/bbox.width)*100)));saveDimension(preset,'sharedSplit','--preset-shared-split',pct,'presetSharedSplit','%');}
   else if(['di-e','id-e'].includes(preset)){const width=Math.round(Math.max(230,Math.min(bbox.width-360,x)));const key=preset==='di-e'?'documentsWidth':'inspectorWidth',variable=preset==='di-e'?'--preset-documents-width':'--preset-inspector-width',input=preset==='di-e'?'presetDocumentsSize':'presetInspectorSize';saveDimension(preset,key,variable,width,input);}
  }
  function up(){removeEventListener('pointermove',move);removeEventListener('pointerup',up);refresh();}addEventListener('pointermove',move);addEventListener('pointerup',up);
 };
 window.NaviRefreshWorkspaceGutters=refresh;
 window.addEventListener('resize',()=>requestAnimationFrame(refresh),{passive:true});
 document.addEventListener('naviwriter:layout-mode-change',()=>requestAnimationFrame(refresh));
 requestAnimationFrame(refresh);
}

const NAVI_RESPONSIVE_PAGE_KEY='naviwriter-responsive-page-v1';
const NAVI_COMPACT_SIDE_KEY='naviwriter-compact-side-page-v1';
function isCompactLandscape(){return document.body.dataset.layoutMode==='compact'&&window.matchMedia('(orientation: landscape)').matches&&window.innerWidth>=760;}
function getResponsivePage(){return localStorage.getItem(NAVI_RESPONSIVE_PAGE_KEY)||'editor'}
function getCompactSidePage(){const value=localStorage.getItem(NAVI_COMPACT_SIDE_KEY)||'documents';return value==='inspector'?'inspector':'documents'}

let naviResponsiveGeometrySignature='';
function applyResponsivePageVisibility({force=false}={}){
 const mode=document.body.dataset.layoutMode;
 const page=document.body.dataset.responsivePage||'editor';
 const landscape=mode==='compact'&&isCompactLandscape();
 const signature=`${mode}|${page}|${landscape?'landscape':'single'}`;
 if(!force&&signature===naviResponsiveGeometrySignature)return;
 naviResponsiveGeometrySignature=signature;
 const responsive=mode==='compact'||mode==='mobile';
 const main=document.querySelector('.main-layout'),docs=document.getElementById('sidebar'),editor=document.querySelector('.main-layout > .workspace'),inspector=document.getElementById('inspector'),nav=document.getElementById('responsivePageNav');
 if(!main||!docs||!editor||!inspector||!nav)return;
 const panels=[docs,editor,inspector];
 const set=(el,key,value)=>el.style.setProperty(key,value,'important');
 const shellProps=['display','position','inset','left','right','top','bottom','width','max-width','height','max-height','min-width','min-height','opacity','visibility','pointer-events','transform','translate','grid-area','grid-column','grid-row','z-index','overflow','border-radius','flex-direction','float'];
 const mainProps=['display','position','inset','width','max-width','height','max-height','overflow','padding','grid-template','grid-template-areas','grid-template-columns','grid-template-rows','gap'];
 const navProps=['display','position','inset','left','right','top','bottom','width','max-width','height','grid-template-columns','grid-template-rows','z-index','margin','padding'];
 const clear=(el,props)=>props.forEach(key=>el.style.removeProperty(key));
 if(!responsive){
   panels.forEach(el=>clear(el,shellProps));clear(main,mainProps);clear(nav,navProps);
   document.body.classList.remove('compact-landscape');
   const pref=readNaviJson(NAVI_WORKSPACE_PRESET_KEY,{}).desktop||'dei';
   requestAnimationFrame(()=>{applyWorkspacePreset(pref,{save:false});clampWorkspaceGeometryToViewport();window.NaviRefreshWorkspaceGutters?.();});
   return;
 }

 set(nav,'display','grid');set(nav,'position','fixed');set(nav,'inset','auto 0 0 0');set(nav,'width','100vw');set(nav,'max-width','100vw');set(nav,'height','calc(64px + env(safe-area-inset-bottom, 0px))');set(nav,'grid-template-columns','repeat(3,minmax(0,1fr))');set(nav,'grid-template-rows','1fr');set(nav,'z-index','99999');set(nav,'margin','0');
 panels.forEach(el=>{shellProps.forEach(key=>el.style.removeProperty(key));set(el,'display','none');set(el,'opacity','1');set(el,'visibility','visible');set(el,'pointer-events','auto');set(el,'transform','none');set(el,'translate','none');set(el,'min-width','0');set(el,'min-height','0');set(el,'z-index','5');set(el,'overflow','hidden');set(el,'flex-direction','column');});
 if(landscape){
   set(main,'display','grid');set(main,'position','relative');set(main,'width','100vw');set(main,'height','100dvh');set(main,'overflow','hidden');set(main,'grid-template-columns',page==='editor'?'minmax(0,1fr)':'minmax(0,1fr) minmax(280px,34vw)');set(main,'grid-template-rows','minmax(0,1fr)');set(main,'gap',page==='editor'?'0':'8px');set(main,'padding','8px 8px calc(72px + env(safe-area-inset-bottom,0px))');
   set(editor,'display','flex');set(editor,'position','relative');set(editor,'inset','auto');set(editor,'width','auto');set(editor,'height','auto');set(editor,'max-height','none');set(editor,'grid-column','1');set(editor,'grid-row','1');set(editor,'border-radius','12px');
   if(page!=='editor'){
     const side=page==='inspector'?inspector:docs;set(side,'display','flex');set(side,'position','relative');set(side,'inset','auto');set(side,'width','auto');set(side,'height','auto');set(side,'max-height','none');set(side,'grid-column','2');set(side,'grid-row','1');set(side,'border-radius','12px');if(side===inspector)set(side,'overflow','auto');
   }
 }else{
   set(main,'display','block');set(main,'position','relative');set(main,'width','100vw');set(main,'height','100dvh');set(main,'overflow','hidden');set(main,'padding','0 0 calc(64px + env(safe-area-inset-bottom,0px))');
   panels.forEach(el=>{set(el,'position','absolute');set(el,'inset','0');set(el,'width','100%');set(el,'height','calc(100dvh - 64px - env(safe-area-inset-bottom,0px))');set(el,'max-height','calc(100dvh - 64px - env(safe-area-inset-bottom,0px))');set(el,'border-radius','0');});
   const active=page==='documents'?docs:page==='inspector'?inspector:editor;set(active,'display','flex');if(active===inspector)set(active,'overflow','auto');
 }
}function setResponsivePage(page,{save=true}={}){
 const valid=['documents','editor','inspector'];if(!valid.includes(page))page='editor';
 const mode=document.body.dataset.layoutMode;
 const changed=document.body.dataset.responsivePage!==page;
 if(save)localStorage.setItem(NAVI_RESPONSIVE_PAGE_KEY,page);
 if(mode==='compact'&&isCompactLandscape()&&page!=='editor')localStorage.setItem(NAVI_COMPACT_SIDE_KEY,page);
 document.body.dataset.responsivePage=page;
 document.body.dataset.compactSidePage=getCompactSidePage();
 document.querySelectorAll('[data-responsive-page]').forEach(button=>{const active=button.dataset.responsivePage===page;button.classList.toggle('active',active);button.setAttribute('aria-current',active?'page':'false');});
 closeResponsiveDrawers();
 applyResponsivePageVisibility({force:changed});
}
function refreshResponsiveShell(){
 document.body.classList.remove('sidebar-drawer-open','inspector-drawer-open');
 const mode=document.body.dataset.layoutMode||resolveLayoutMode();
 const responsive=mode==='compact'||mode==='mobile';
 const landscape=mode==='compact'&&isCompactLandscape();
 document.body.classList.toggle('compact-landscape',landscape);
 if(!responsive){
   document.body.removeAttribute('data-responsive-page');document.body.removeAttribute('data-compact-side-page');
   applyResponsivePageVisibility({force:true});
   return;
 }
 let page=getResponsivePage();if(!['documents','editor','inspector'].includes(page))page='editor';
 document.body.dataset.responsivePage=page;document.body.dataset.compactSidePage=getCompactSidePage();
 document.querySelectorAll('[data-responsive-page]').forEach(button=>{const active=button.dataset.responsivePage===page;button.classList.toggle('active',active);button.setAttribute('aria-current',active?'page':'false');});
 applyResponsivePageVisibility();
}
function setupResponsivePageShell(){
 document.querySelectorAll('[data-responsive-page]').forEach(button=>button.onclick=()=>setResponsivePage(button.dataset.responsivePage));
 document.getElementById('documentList')?.addEventListener('click',event=>{if(event.target.closest('.doc-card,.document-card,[data-document-id]'))setResponsivePage('editor');});
 document.addEventListener('naviwriter:layout-mode-change',refreshResponsiveShell);
 let orientationFrame=0;
 const scheduleOrientationRefresh=()=>{cancelAnimationFrame(orientationFrame);orientationFrame=requestAnimationFrame(()=>{naviResponsiveGeometrySignature='';refreshResponsiveShell();});};
 window.matchMedia('(orientation: landscape)').addEventListener?.('change',scheduleOrientationRefresh);
 refreshResponsiveShell();
}


function clampWorkspaceGeometryToViewport(){
 const main=document.querySelector('.main-layout');if(!main||document.body.dataset.layoutMode!=='desktop')return;
 const preset=main.dataset.workspacePreset||'',sizes={...workspacePresetDefaults(preset),...(readNaviJson(NAVI_WORKSPACE_SIZE_KEY,{})[preset]||{})};
 const h=Math.max(0,main.clientHeight-18),minMiddle=220,minSide=140;
 if(['d-e-i','i-e-d','e-d-i','e-i-d'].includes(preset)){
  const top=Math.max(minSide,Math.min(sizes.topRowHeight,h-minMiddle-minSide));
  const bottom=Math.max(minSide,Math.min(sizes.stackedHeight,h-minMiddle-top));
  main.style.setProperty('--preset-top-row-height',`${top}px`);main.style.setProperty('--preset-stacked-height',`${bottom}px`);
 }
}


function wireInterfaceLayoutToResponsiveShell(){
  document.querySelectorAll('[data-layout-choice]').forEach(button=>{
    button.onclick=()=>{
      const requested=button.dataset.layoutChoice||'auto';
      saveLayoutPreference(requested);
      applyLayoutMode();
      refreshResponsiveShell();
    };
  });
}

async function initApp() {
  cacheElements();
  initializeLocalDocumentLibraries();
  loadProjectFileAutosaveSetting();
  setupCollapsibleInspectorSections();
  setupBoardPanning();
  setupPaneResize();
  setupWorkspacePresets();
  setupResponsivePageShell();
  wireInterfaceLayoutToResponsiveShell();
  setupVerticalPresetResize();
  setupSplitResize();
  setupDraggableFindPanel();
  loadCollapsedDocIds();

  await NaviStorage.openDatabase();
  window.NaviWritingHistory?.installUI?.();

  NaviThemes.initThemes();

  await NaviEditor.initEditor({
  onChange: () => {

    if (isLoadingDocument) {
      return;
    }

    window.NaviWritingHistory?.recordChange?.({
      documentId: currentDocumentId,
      title: NaviEditor.getEditorTitle(),
      text: NaviEditor.getEditorText()
    });
    scheduleAutosave();
  }
});

  setFocusMode(false);

  setupEvents();
  setupKeyboardShortcuts();
  installRecoveryBranding();
  installRecoveryThemesPanel();
  setupCombinedLayoutViewControls();
  const inspectorNode=document.getElementById('inspector');
  const themesNode=document.getElementById('recoveryThemesSection');
  const displayNode=document.getElementById('viewModeControlsSection');
  const firstLegacyLayout=Array.from(inspectorNode?.querySelectorAll('[data-inspector-tab="view"]')||[]).find(node=>!['recoveryThemesSection','viewModeControlsSection'].includes(node.id));
  if(themesNode&&displayNode){if(firstLegacyLayout)inspectorNode.insertBefore(themesNode,firstLegacyLayout);else inspectorNode.append(themesNode);if(firstLegacyLayout)inspectorNode.insertBefore(displayNode,firstLegacyLayout);else inspectorNode.append(displayNode);}
  const optionalStartup = async (label, task) => {
    try { return await task(); }
    catch (error) { console.warn(`NaviWriter optional startup task failed: ${label}`, error); window.NaviDiagnostics?.report?.({severity:'warning',subsystem:`Startup: ${label}`,message:error?.message||String(error),error,recovered:true}); return null; }
  };
  await optionalStartup('document status', async () => { updateDetailedDocumentStatus(); window.setInterval(updateDetailedDocumentStatus, 1500); });
  await optionalStartup('shell icons', async () => setupShellChannelIcons());
  await optionalStartup('image caption dialog', async () => setupImageCaptionDialog());
  await openInitialDocument();
  await optionalStartup('repeated-text analysis', async () => updateRepeatedTextAnalysis());
  await optionalStartup('heading counts', async () => renderHeadingCounts());
  await optionalStartup('long-term goals', async () => loadLongGoal());
  await optionalStartup('editor counts', async () => NaviEditor.updateCounts());
}

window.addEventListener('DOMContentLoaded', () => {
  initApp().catch(error => {
    console.error('NaviWriter critical startup failure:', error);
    window.NaviDiagnostics?.report?.({severity:'fatal',subsystem:'Critical startup',message:error?.message||String(error),error,fatal:true,recovered:false});
    showAppNotice(`NaviWriter could not finish critical startup: ${error?.message || error}`);
  });
});
async function clearTemporaryGoal() {
  temporaryGoalSession = null; currentGoal = 0;
  await NaviStorage.saveSetting('temporaryGoalSession', null);
  if (els.goalInput) els.goalInput.value='';
  if (els.goalProgress) els.goalProgress.textContent='No goal set.';
  if (els.goalBarFill) els.goalBarFill.style.width='0%';
}

async function handleExportSelectionProject() {
  const options=getCompileOptions();
  if(options.scope==='current') { showAppNotice('Use Export Current Document for a one-document NaviDoc. Choose Current Branch, Current Root Tree, or Entire Project for a project file.','Choose a Project Scope'); return; }
  try {
    const resolution=await resolveCompileSelection(options);
    if(!resolution.includedNodes.length) throw new Error('No documents matched this project selection.');
    await NaviExport.exportProjectSelection(resolution);
    NaviEditor.setSaveStatus('Project selection exported');
  } catch(error) {
    NaviDiagnostics?.report?.({severity:'error',subsystem:'Project selection export',message:error?.message||String(error),error,recovered:true});
    showAppNotice(error?.message||String(error),'Project Export Failed');
  }
}

window.addEventListener('naviwriter:document-tree-changed', async () => {
  documentsCache = await NaviStorage.getAllDocuments();
  renderDocumentList(documentsCache);
  if (els.compileModal && !els.compileModal.classList.contains('hidden')) renderCompilePreview();
  if (els.outlinerModal && !els.outlinerModal.classList.contains('hidden')) renderOutliner();
});
window.addEventListener('keydown', async event => {
  if (!(event.altKey && event.shiftKey)) return;
  if (event.key.toLowerCase() === 'z' && !event.ctrlKey && !event.metaKey) {
    event.preventDefault();
    const docs = await NaviDocumentTree.undo();
    if (docs) NaviEditor.setSaveStatus('Tree move undone');
  } else if (event.key.toLowerCase() === 'y' && !event.ctrlKey && !event.metaKey) {
    event.preventDefault();
    const docs = await NaviDocumentTree.redo();
    if (docs) NaviEditor.setSaveStatus('Tree move redone');
  }
});

window.addEventListener('DOMContentLoaded',()=>{document.getElementById('exportSelectionProjectBtn')?.addEventListener('click',handleExportSelectionProject);document.getElementById('compileShowExcluded')?.addEventListener('change',renderCompilePreview);document.getElementById('expandAllDocumentsBtn')?.addEventListener('click',expandAllDocumentTrees);document.getElementById('collapseAllDocumentsBtn')?.addEventListener('click',collapseAllDocumentTrees);});


window.addEventListener('DOMContentLoaded',()=>{document.getElementById('deleteBoardConnectionBtn')?.addEventListener('click',deleteEditingBoardConnector);document.getElementById('addBoardDocumentViewBtn')?.addEventListener('click',chooseBoardDocumentView);document.getElementById('retainedSourceInput')?.addEventListener('change',async event=>{const file=event.target.files?.[0];if(file)await addBoardDocumentViewFromFile(file);event.target.value='';});document.getElementById('closeRetainedSourceViewerBtn')?.addEventListener('click',closeRetainedSourceViewer);document.getElementById('retainedSourceZoomOutBtn')?.addEventListener('click',()=>{retainedSourceViewerZoom=Math.max(.25,Math.round((retainedSourceViewerZoom-.1)*100)/100);updateRetainedSourceZoom();});document.getElementById('retainedSourceZoomInBtn')?.addEventListener('click',()=>{retainedSourceViewerZoom=Math.min(32,Math.round((retainedSourceViewerZoom+.25)*100)/100);updateRetainedSourceZoom();});document.getElementById('retainedSourceFitBtn')?.addEventListener('click',()=>{retainedSourceViewerZoom=1;updateRetainedSourceZoom();});document.getElementById('downloadRetainedSourceBtn')?.addEventListener('click',downloadRetainedSource);document.addEventListener('click',event=>{const trigger=event.target.closest('[data-open-retained-source]');if(trigger)openRetainedSourceViewer(trigger.dataset.openRetainedSource);});});

window.addEventListener('DOMContentLoaded',()=>{document.getElementById('retainedSourcePrevPageBtn')?.addEventListener('click',()=>{if(retainedSourcePdf&&retainedSourcePdfPage>1){retainedSourcePdfPage--;renderRetainedPdfPage();}});document.getElementById('retainedSourceNextPageBtn')?.addEventListener('click',()=>{if(retainedSourcePdf&&retainedSourcePdfPage<retainedSourcePdf.numPages){retainedSourcePdfPage++;renderRetainedPdfPage();}});document.getElementById('retainedSourcePageInput')?.addEventListener('change',event=>{if(retainedSourcePdf){retainedSourcePdfPage=Number(event.target.value)||1;renderRetainedPdfPage();}});document.getElementById('retainedSourceRotateBtn')?.addEventListener('click',()=>{if(retainedSourcePdf){retainedSourcePdfRotation=(retainedSourcePdfRotation+90)%360;renderRetainedPdfPage();}});});
window.addEventListener('change',event=>{if(event.target?.id==='importFile'&&event.target.files?.[0])retainedSourceLastImportFile=event.target.files[0];},true);
function installDirectReferenceImportAction(){
  const observer=new MutationObserver(()=>{
    document.querySelectorAll('.modal-backdrop:not(.hidden)').forEach(root=>{
      if(root.dataset.retainedReferenceReady==='true')return;
      const panel=root.firstElementChild||root;
      const heading=panel.querySelector('h1,h2,h3,.subdoc-modal-head strong,.navi-doc-import-head strong')?.textContent||'';
      if(!/Import (PDF|DOCX|ODT|RTF|RTFD|EPUB|HTML|TXT|Fountain|FDX|JavaScript)/i.test(`${heading} ${panel.textContent||''}`))return;
      const primary=[...panel.querySelectorAll('button')].find(button=>/Analyze PDF|Import document|Import reviewed|Import$/i.test(button.textContent||''));
      let footer=[...panel.querySelectorAll('footer,.modal-actions,.navi-pdf-import-actions')].filter(node=>node.contains(primary)||node.querySelector('button')).pop();
      if(!footer){footer=document.createElement('footer');footer.className='reference-import-footer';if(primary?.parentElement){primary.parentElement.insertAdjacentElement('beforebegin',footer);}else panel.appendChild(footer);}
      footer.classList.add('reference-import-actions');
      const button=document.createElement('button');button.type='button';button.className='navi-button-secondary retained-reference-import-btn';button.textContent='Keep Original as Reference View';button.title='Store the unchanged original and create a read-only Viewer plus editable Notes.';
      button.onclick=async()=>{const file=retainedSourceLastImportFile||document.getElementById('importFile')?.files?.[0];if(!file)return;button.disabled=true;button.textContent='Retaining original…';try{const preview=root.querySelector('.navi-doc-import-preview');const previewClone=preview?.cloneNode(true);previewClone?.querySelectorAll('button,input,select,textarea,script,iframe').forEach(node=>node.remove());const doc=await createRetainedSourceDocument(file,previewClone?.innerHTML||'');await loadDocuments();root.classList.add('hidden');await openDocument(doc.id);}catch(error){button.disabled=false;button.textContent='Keep Original as Reference View';NaviDiagnostics?.report?.({severity:'error',subsystem:'Reference import',message:error?.message||String(error),error,recovered:true});}};
      footer.prepend(button);root.dataset.retainedReferenceReady='true';
    });
  });
  observer.observe(document.body,{childList:true,subtree:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installDirectReferenceImportAction,{once:true});else installDirectReferenceImportAction();

window.addEventListener('DOMContentLoaded',()=>{document.getElementById('promoteRetainedSourceBtn')?.addEventListener('click',promoteCurrentRetainedSource);});

window.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('retainedSourceStage')?.addEventListener('wheel',event=>{
    if(!(event.ctrlKey||event.metaKey))return;
    event.preventDefault();
    const delta=event.deltaY<0?.08:-.08;
    retainedSourceViewerZoom=Math.max(.1,Math.min(retainedSourcePdf?8:32,Math.round((retainedSourceViewerZoom+delta)*100)/100));
    updateRetainedSourceZoom();
  },{passive:false});
});

window.addEventListener('DOMContentLoaded',()=>{document.getElementById('closeAttachmentMetadataBtn')?.addEventListener('click',closeAttachmentMetadataModal);document.getElementById('cancelAttachmentMetadataBtn')?.addEventListener('click',closeAttachmentMetadataModal);document.getElementById('saveAttachmentMetadataBtn')?.addEventListener('click',saveAttachmentMetadataModal);document.getElementById('attachmentMetadataModal')?.addEventListener('click',event=>{if(event.target.id==='attachmentMetadataModal')closeAttachmentMetadataModal();});});

window.addEventListener('DOMContentLoaded',()=>{
  els.boardConnectionWidthInput?.addEventListener('input',()=>{if(els.boardConnectionWidthOutput)els.boardConnectionWidthOutput.value=`${els.boardConnectionWidthInput.value} px`;});
  els.reverseBoardConnectionBtn?.addEventListener('click',()=>{const from=els.boardConnectionFromSelect?.value||'';if(els.boardConnectionFromSelect&&els.boardConnectionToSelect){els.boardConnectionFromSelect.value=els.boardConnectionToSelect.value;els.boardConnectionToSelect.value=from;}});
});

window.addEventListener('DOMContentLoaded',()=>{const board=document.getElementById('boardSurface');if(!board||board.dataset.selectionGuard)return;board.dataset.selectionGuard='1';board.addEventListener('selectstart',event=>{const target=event.target instanceof Element?event.target:event.target?.parentElement;if(target?.closest('textarea,input,[contenteditable="true"],a,button,select'))return;event.preventDefault();});board.addEventListener('pointerdown',event=>{const target=event.target instanceof Element?event.target:event.target?.parentElement;if(target?.closest('.board-item,.board-minimap,button,input,textarea,[contenteditable="true"]'))return;event.preventDefault();try{window.getSelection()?.removeAllRanges();}catch{}},{capture:true});});

window.addEventListener('resize',()=>{if(document.body.classList.contains('board-mode-active'))requestAnimationFrame(renderBoardMinimap);},{passive:true});


/* 2026-09-29: isolated retained-source viewer and responsive document split */
(() => {
  const MOBILE = 720;
  let returnFocus = null;
  const viewerOpen = () => !!els.retainedSourceViewerModal && !els.retainedSourceViewerModal.classList.contains('hidden');
  const focusable = root => [...root.querySelectorAll('button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(el => !el.hidden && el.getClientRects().length);

  function syncViewerIsolation() {
    const open = viewerOpen(), app = document.querySelector('main.app'), modal = els.retainedSourceViewerModal;
    document.body.classList.toggle('retained-source-modal-open', open);
    if (open) {
      if (!returnFocus) returnFocus = document.activeElement;
      app?.setAttribute('inert',''); app?.setAttribute('aria-hidden','true');
      const dialog=modal?.querySelector('[role="dialog"]'); if(dialog && !dialog.hasAttribute('tabindex')) dialog.tabIndex=-1;
      requestAnimationFrame(()=>{ if(!modal?.contains(document.activeElement)) (document.getElementById('closeRetainedSourceViewerBtn')||dialog)?.focus({preventScroll:true}); });
    } else {
      app?.removeAttribute('inert'); app?.removeAttribute('aria-hidden');
      const target=returnFocus; returnFocus=null; requestAnimationFrame(()=>target?.isConnected&&target.focus?.({preventScroll:true}));
    }
  }
  function viewerKeys(event){
    if(!viewerOpen()) return;
    if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeRetainedSourceViewer();return;}
    if(event.key!=='Tab') return;
    const dialog=els.retainedSourceViewerModal.querySelector('[role="dialog"]'), items=focusable(dialog);
    if(!items.length){event.preventDefault();dialog?.focus();return;}
    const first=items[0],last=items.at(-1);
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  }
  function ensureSwitcher(){
    const w=els.workspace;if(!w||w.querySelector('.split-mobile-switcher'))return;
    const bar=document.createElement('div');bar.className='split-mobile-switcher';bar.setAttribute('role','tablist');bar.setAttribute('aria-label','Split view pane');
    bar.innerHTML='<button type="button" data-split-view="draft" role="tab">Draft</button><button type="button" data-split-view="reference" role="tab">Reference</button>';
    w.insertBefore(bar,els.splitResizeHandle||els.splitPane||null);
    bar.addEventListener('click',e=>{const b=e.target.closest('[data-split-view]');if(b)setMobileView(b.dataset.splitView);});
  }
  function setMobileView(view){
    const w=els.workspace;if(!w)return;view=view==='draft'?'draft':'reference';w.dataset.splitMobileView=view;
    w.querySelectorAll('[data-split-view]').forEach(b=>{const on=b.dataset.splitView===view;b.classList.toggle('active',on);b.setAttribute('aria-selected',String(on));});
    requestAnimationFrame(()=>dispatchEvent(new Event('resize')));
  }
  function syncSplit(){
    const w=els.workspace;if(!w||!isSplitOpen())return;const mobile=innerWidth<=MOBILE,vertical=!mobile&&matchMedia('(max-width:1050px)').matches;
    w.classList.toggle('split-mobile',mobile);w.classList.toggle('split-vertical',vertical);if(mobile&&!w.dataset.splitMobileView)setMobileView('reference');
  }
  const baseShow=showSplitShell;showSplitShell=function(...args){const r=baseShow.apply(this,args);ensureSwitcher();els.workspace?.classList.add('document-split-active');if(!els.workspace?.dataset.splitMobileView)setMobileView('reference');syncSplit();return r;};
  const baseCleanup=cleanupSplitViewer;cleanupSplitViewer=function(...args){const r=baseCleanup.apply(this,args);if(els.workspace){els.workspace.classList.remove('document-split-active','split-mobile');delete els.workspace.dataset.splitMobileView;}return r;};
  addEventListener('DOMContentLoaded',()=>{
    const modal=els.retainedSourceViewerModal||document.getElementById('retainedSourceViewerModal');
    if(modal){new MutationObserver(syncViewerIsolation).observe(modal,{attributes:true,attributeFilter:['class']});modal.addEventListener('pointerdown',e=>{if(e.target===modal)closeRetainedSourceViewer();});syncViewerIsolation();}
    document.addEventListener('keydown',viewerKeys,true);ensureSwitcher();syncSplit();addEventListener('resize',syncSplit,{passive:true});
  });
})();


/* 2026-09-29: canonical split/reference responsive state repair v2 */
(() => {
  function requestedSplitMode() {
    const explicit = document.body.dataset.layoutMode;
    if (explicit === 'mobile') return 'mobile';
    if (explicit === 'compact') return 'compact';
    if (explicit === 'desktop') return 'desktop';
    if (window.innerWidth <= 720) return 'mobile';
    if (window.innerWidth <= 1050) return 'compact';
    return 'desktop';
  }

  function placeSplitSwitcher() {
    const workspace = els.workspace;
    const switcher = workspace?.querySelector('.split-mobile-switcher');
    const toolbar = els.toolbar || document.getElementById('toolbar');
    if (workspace && switcher && toolbar && switcher.nextElementSibling !== toolbar) {
      workspace.insertBefore(switcher, toolbar);
    }
  }

  function applyCanonicalSplitMode() {
    const workspace = els.workspace;
    if (!workspace || !isSplitOpen()) return;
    placeSplitSwitcher();
    const mode = requestedSplitMode();
    workspace.dataset.splitLayout = mode;
    workspace.classList.toggle('split-mobile', mode === 'mobile');
    workspace.classList.toggle('split-vertical', mode === 'compact');
    workspace.classList.add('document-split-active');
    if (mode === 'mobile' && !workspace.dataset.splitMobileView) {
      workspace.dataset.splitMobileView = 'reference';
    }
    workspace.querySelectorAll('.split-mobile-switcher [data-split-view]').forEach(button => {
      const active = button.dataset.splitView === (workspace.dataset.splitMobileView || 'reference');
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
    });
  }

  function observeSplitPaneWidth() {
    if (!els.splitPane || els.splitPane._naviWidthObserver) return;
    let frame = 0;let last = '';const observer = new ResizeObserver(entries => {
      const width = entries[0]?.contentRect?.width || 0;
      const next = width < 520 ? 'narrow' : width < 720 ? 'medium' : 'wide';
      if(next===last)return;last=next;cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{if(els.splitPane?.dataset.controlLayout!==next)els.splitPane.dataset.controlLayout=next;});
    });
    observer.observe(els.splitPane);
    els.splitPane._naviWidthObserver = observer;
  }

  addEventListener('DOMContentLoaded', () => {
    placeSplitSwitcher();
    observeSplitPaneWidth();
    applyCanonicalSplitMode();
    addEventListener('resize', applyCanonicalSplitMode, { passive: true });
    new MutationObserver(applyCanonicalSplitMode).observe(document.body, { attributes: true, attributeFilter: ['data-layout-mode'] });
  });

  const previousShowSplitShellV2 = showSplitShell;
  showSplitShell = function canonicalShowSplitShell(...args) {
    const result = previousShowSplitShellV2.apply(this, args);
    placeSplitSwitcher();
    observeSplitPaneWidth();
    applyCanonicalSplitMode();
    return result;
  };
})();


/* 2026-09-29 structural split + reference viewer repair v3 */
(() => {
  const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));

  function splitLayoutMode(){
    const explicit=document.body.dataset.layoutMode;
    if(explicit==='mobile'||explicit==='compact')return 'mobile';
    if(explicit==='desktop')return 'desktop';
    return innerWidth<=1050?'mobile':'desktop';
  }

  function syncStructuralLayout(){
    const workspace=els.workspace;
    if(!workspace)return;
    if(isSplitOpen()){
      const mode=splitLayoutMode();
      workspace.dataset.splitLayout=mode;
      workspace.classList.toggle('split-vertical',mode==='compact');
      workspace.classList.toggle('split-mobile',mode==='mobile');
      workspace.classList.add('document-split-active');
    }
    const reference=document.getElementById('referenceDocumentWorkspace');
    if(reference) reference.dataset.referenceReady='true';
  }

  function installAuthoritativeSplitDrag(){
    if(document.documentElement.dataset.naviSplitDragV3==='true')return;
    document.documentElement.dataset.naviSplitDragV3='true';
    document.addEventListener('pointerdown',event=>{
      const handle=event.target.closest('#splitResizeHandle');
      if(!handle||!isSplitOpen())return;
      const workspace=els.workspace;
      const mode=workspace?.dataset.splitLayout||splitLayoutMode();
      if(mode==='mobile')return;
      event.preventDefault();event.stopImmediatePropagation();
      const pointerId=event.pointerId;
      try{handle.setPointerCapture(pointerId);}catch{}
      document.body.classList.add('split-resizing');
      const move=ev=>{
        const rect=workspace.getBoundingClientRect();
        if(mode==='compact'){
          const divider=12,available=Math.max(1,rect.height-divider);
          const minPrimary=Math.min(260,available*.45),minSecondary=Math.min(220,available*.45);
          const secondary=clamp(rect.bottom-ev.clientY,minSecondary,Math.max(minSecondary,available-minPrimary));
          const ratio=clamp(secondary/available,.18,.82);
          workspace.style.setProperty('--split-height-ratio',ratio);
          localStorage.setItem('naviwriter-split-height-ratio',String(ratio));
        }else{
          const divider=10,available=Math.max(1,rect.width-divider);
          const secondary=clamp(rect.right-ev.clientX,260,Math.max(260,available-280));
          const ratio=clamp(secondary/available,.18,.82);
          workspace.style.setProperty('--split-width-ratio',ratio);
          localStorage.setItem('naviwriter-split-width-ratio',String(ratio));
        }
        dispatchEvent(new Event('resize'));
      };
      const end=ev=>{
        removeEventListener('pointermove',move,true);removeEventListener('pointerup',end,true);removeEventListener('pointercancel',end,true);
        document.body.classList.remove('split-resizing');
        try{handle.releasePointerCapture(ev.pointerId);}catch{}
      };
      addEventListener('pointermove',move,true);addEventListener('pointerup',end,true);addEventListener('pointercancel',end,true);
    },true);
  }

  addEventListener('DOMContentLoaded',()=>{
    installAuthoritativeSplitDrag();syncStructuralLayout();
    addEventListener('resize',syncStructuralLayout,{passive:true});
    new MutationObserver(syncStructuralLayout).observe(document.body,{attributes:true,attributeFilter:['data-layout-mode','class']});
  });
  const showV3=showSplitShell;
  showSplitShell=function(...args){const result=showV3.apply(this,args);syncStructuralLayout();return result;};
})();


/* 2026-09-30 deliberate cover workflow v1 */
function coverHtmlForDocument(doc,cover=doc?.cover){
  if(!cover?.assetId)return '<section class="navi-cover-empty"><h1>'+escapeHtml(doc?.title||'Cover')+'</h1><p>No cover image selected.</p></section>';
  const fit=['contain','width','crop'].includes(cover.fit)?cover.fit:'contain';
  return `<figure class="navi-cover-figure" data-cover-fit="${fit}" data-cover-asset-id="${escapeHtml(cover.assetId)}"><img src="${NaviAssets.uri(cover.assetId)}" data-navi-asset-id="${escapeHtml(cover.assetId)}" alt="${escapeHtml(cover.altText||doc?.title||'Cover image')}" style="object-position:${Number(cover.focalX??.5)*100}% ${Number(cover.focalY??.5)*100}%"><figcaption class="sr-only">${escapeHtml(cover.altText||doc?.title||'Cover image')}</figcaption></figure>`;
}
async function openCoverSetupWorkflow(docId,{newDocument=false,parentId=null}={}){
  const choice=await openChoiceModal({title:'Cover Image',subtitle:'Choose artwork now or create the Cover without an image.',options:[{value:'choose',icon:'🖼',title:'Choose Cover Image',description:'Store a dedicated cover asset and open the cover workspace.'},{value:'without',icon:'□',title:'Continue Without Image',description:'Create the Cover now and add artwork later.'},{value:'cancel',icon:'×',title:'Cancel',description:newDocument?'Do not create this Cover document.':'Leave the document type unchanged.'}]});
  if(choice==='choose'){chooseCoverImageForDocument(docId);return true;}
  if(choice==='without')return true;
  if(choice==='cancel'&&newDocument){await NaviStorage.deleteDocument(docId);await loadDocuments();if(parentId)await openDocument(parentId);}
  return false;
}
async function setCoverFit(docId,fit){const doc=await NaviStorage.getDocument(docId);if(!doc||doc.docType!=='cover')return;const cover={...(doc.cover||{}),fit,updatedAt:Date.now()};await NaviStorage.saveDocument({...doc,cover,content:coverHtmlForDocument(doc,cover)});await loadDocuments();if(currentDocumentId===docId)await openDocument(docId);}
async function removeCoverImage(docId){const doc=await NaviStorage.getDocument(docId);if(!doc)return;await NaviStorage.saveDocument({...doc,cover:null,coverImageName:'',content:coverHtmlForDocument(doc,null)});await loadDocuments();if(currentDocumentId===docId)await openDocument(docId);}
function syncCoverEditor(doc){document.querySelector('.navi-cover-workspace')?.remove();document.body.classList.toggle('cover-document-active',doc?.docType==='cover');if(doc?.docType!=='cover')return;requestAnimationFrame(async()=>{const page=document.querySelector('.workspace>.page-wrap');if(!page||document.querySelector('.navi-cover-workspace'))return;const shell=document.createElement('section');shell.className='navi-cover-workspace';shell.innerHTML=`<nav class="navi-cover-toolbar"><button data-cover-set>${doc.cover?.assetId?'Replace':'Set'} Cover Image</button><button data-cover-remove ${doc.cover?.assetId?'':'disabled'}>Remove Cover Image</button><span class="navi-cover-divider"></span><button data-cover-fit="contain">Fit within page</button><button data-cover-fit="width">Fill page width</button><button data-cover-fit="crop">Full-page crop</button></nav><div class="navi-cover-page">${coverHtmlForDocument(doc)}</div>`;page.insertAdjacentElement('beforebegin',shell);shell.querySelector('[data-cover-set]').onclick=()=>chooseCoverImageForDocument(doc.id);shell.querySelector('[data-cover-remove]').onclick=()=>removeCoverImage(doc.id);shell.querySelectorAll('[data-cover-fit]').forEach(b=>{b.classList.toggle('active',(doc.cover?.fit||'contain')===b.dataset.coverFit);b.onclick=()=>setCoverFit(doc.id,b.dataset.coverFit);});await NaviAssets.hydrateStable(shell);});}
const _applyDocumentTypePresetCover=applyDocumentTypePreset;applyDocumentTypePreset=function(doc){const result=_applyDocumentTypePresetCover(doc);syncCoverEditor(doc);return result;};
window.addEventListener('naviwriter:document-type-changed',async event=>{const {documentId,oldType,newType}=event.detail||{};if(newType!=='cover'||oldType==='cover'||!documentId)return;const doc=await NaviStorage.getDocument(documentId);if(!doc)return;const ok=await openCoverSetupWorkflow(documentId,{newDocument:false});if(!ok){await NaviStorage.saveDocument({...doc,docType:oldType||'standard',type:oldType||'standard'});await loadDocuments();await openDocument(documentId);}});
window.NaviCoverWorkflow={open:openCoverSetupWorkflow,setImage:chooseCoverImageForDocument,setFit:setCoverFit,remove:removeCoverImage,html:coverHtmlForDocument};


/* 2026-09-30 stable pointer document drag + board audio v12 */
function formatAudioDuration(seconds=0){seconds=Math.max(0,Math.round(Number(seconds)||0));return `${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;}
function preferredAudioMime(){const choices=['audio/webm;codecs=opus','audio/ogg;codecs=opus','audio/mp4','audio/webm'];return choices.find(type=>globalThis.MediaRecorder?.isTypeSupported?.(type))||'';}
async function recordBoardAudioMemo(existingItem=null){
  if(!navigator.mediaDevices?.getUserMedia||!globalThis.MediaRecorder){await showAppNotice('Audio recording is not available in this browser.','Audio unavailable');return null;}
  let stream;try{stream=await navigator.mediaDevices.getUserMedia({audio:true});}catch(error){NaviDiagnostics?.report?.({severity:'warning',subsystem:'Board audio',message:'Microphone permission was not granted.',error,recovered:true});await showAppNotice('Microphone access is required to record an audio memo.','Microphone unavailable');return null;}
  const mimeType=preferredAudioMime(),recorder=new MediaRecorder(stream,mimeType?{mimeType}:undefined),chunks=[];let elapsed=0,timer=0,resolveDone;
  const done=new Promise(resolve=>resolveDone=resolve);recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};recorder.onerror=e=>resolveDone({error:e.error||new Error('Recording failed.')});recorder.onstop=()=>resolveDone({blob:new Blob(chunks,{type:recorder.mimeType||mimeType||'audio/webm'})});
  const modal=document.createElement('div');modal.className='board-audio-recorder-backdrop';modal.innerHTML='<section class="board-audio-recorder" role="dialog" aria-modal="true" aria-labelledby="boardAudioRecorderTitle"><header><div><h2 id="boardAudioRecorderTitle">Audio Memo</h2><p data-audio-status>Ready to record</p></div><button type="button" data-audio-cancel aria-label="Cancel">×</button></header><div class="board-audio-time" data-audio-time>0:00</div><label>Memo name<input type="text" data-audio-name maxlength="120" value="'+escapeHtml(existingItem?.title||'Audio memo')+'"></label><footer><button type="button" data-audio-start>Record</button><button type="button" data-audio-stop disabled>Stop and Save</button></footer></section>';document.body.appendChild(modal);
  const status=modal.querySelector('[data-audio-status]'),time=modal.querySelector('[data-audio-time]'),start=modal.querySelector('[data-audio-start]'),stop=modal.querySelector('[data-audio-stop]'),cancel=modal.querySelector('[data-audio-cancel]'),name=modal.querySelector('[data-audio-name]');
  let cancelled=false,started=false;const close=()=>{clearInterval(timer);stream?.getTracks().forEach(track=>track.stop());modal.remove();};
  start.onclick=()=>{started=true;elapsed=0;recorder.start(500);start.disabled=true;stop.disabled=false;status.textContent='Recording';timer=setInterval(()=>{elapsed++;time.textContent=formatAudioDuration(elapsed);},1000);};
  stop.onclick=()=>{if(recorder.state!=='inactive')recorder.stop();stop.disabled=true;status.textContent='Saving recording';};
  cancel.onclick=()=>{cancelled=true;if(recorder.state!=='inactive')recorder.stop();else resolveDone({cancelled:true});};modal.onclick=e=>{if(e.target===modal)cancel.click();};
  name.focus();const result=await done;close();if(cancelled||result.cancelled||!result.blob?.size)return null;if(result.error)throw result.error;
  const ext=/ogg/i.test(result.blob.type)?'ogg':/mp4/i.test(result.blob.type)?'m4a':'webm',title=name.value.trim()||'Audio memo',asset=await NaviAssets.addAudio(result.blob,{originalName:`${title}.${ext}`,sourceFormat:'board-recording'});
  if(existingItem){pushBoardUndoState();existingItem.assetId=asset.id;existingItem.mimeType=asset.mimeType;existingItem.duration=asset.duration||elapsed;existingItem.title=title;}else{pushBoardUndoState();const position=getBoardSpawnPosition();currentBoardData.items.push({id:crypto.randomUUID(),type:'audio',assetId:asset.id,mimeType:asset.mimeType,duration:asset.duration||elapsed,title,x:position.x,y:position.y,width:320,height:170,color:'#ede9fe',zIndex:getNextBoardZIndex()});}
  renderBoard();scheduleAutosave();NaviEditor.setSaveStatus('Audio memo saved');return asset;
}

(() => {
  let state=null,suppressClick=false;
  const root=()=>document.getElementById('documentList'),cardAt=(x,y)=>document.elementFromPoint(x,y)?.closest?.('.doc-card[data-id]')||null;
  function clear(){clearDocumentDropIndicators();document.querySelector('.navi-doc-drag-ghost')?.remove();document.querySelectorAll('.doc-pointer-source').forEach(node=>node.classList.remove('doc-pointer-source'));document.body.classList.remove('document-pointer-dragging');state=null;draggedDocumentId=null;}
  function position(card,y,forceInside=false){if(forceInside)return'inside';const r=card.getBoundingClientRect(),q=(y-r.top)/Math.max(1,r.height);return q<.44?'before':q>.56?'after':'inside';}
  function paint(card,pos){clearDocumentDropIndicators();document.querySelectorAll('.doc-drop-target').forEach(node=>node.classList.remove('doc-drop-target'));card.classList.add(`doc-tree-drop-${pos}`,'doc-drop-target');card.dataset.treeDropPosition=pos;card.dataset.orderDropLabel=`${pos==='inside'?'Move inside':pos==='before'?'Place before':'Place after'} ${documentsCache.find(d=>String(d.id)===card.dataset.id)?.title||'document'}`;}
  function install(){const list=root();if(!list||list.dataset.pointerTreeDrag==='true')return;list.dataset.pointerTreeDrag='true';
    list.addEventListener('dragstart',e=>e.preventDefault(),true);list.addEventListener('click',e=>{if(suppressClick){e.preventDefault();e.stopImmediatePropagation();suppressClick=false;}},true);
    list.addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('button,input,select,textarea,a,[contenteditable="true"]'))return;const card=e.target.closest('.doc-card[data-id]');if(!card)return;state={id:card.dataset.id,card,startX:e.clientX,startY:e.clientY,x:e.clientX,y:e.clientY,moved:false,pointerId:e.pointerId};},true);
    addEventListener('pointermove',e=>{if(!state||e.pointerId!==state.pointerId)return;state.x=e.clientX;state.y=e.clientY;if(!state.moved&&Math.hypot(e.clientX-state.startX,e.clientY-state.startY)<7)return;if(!state.moved){state.moved=true;suppressClick=true;draggedDocumentId=state.id;document.body.classList.add('document-pointer-dragging');const ghost=state.card.cloneNode(true);ghost.className='navi-doc-drag-ghost';ghost.removeAttribute('id');ghost.dataset.dragTitle=documentsCache.find(d=>String(d.id)===String(state.id))?.title||'Document';document.body.appendChild(ghost);state.card.classList.add('doc-pointer-source');}e.preventDefault();const ghost=document.querySelector('.navi-doc-drag-ghost');if(ghost)ghost.style.transform=`translate3d(${e.clientX+12}px,${e.clientY+12}px,0)`;const target=cardAt(e.clientX,e.clientY);if(target&&target.dataset.id!==state.id){const pos=position(target,e.clientY,e.shiftKey);if(NaviDocumentTree.validateMove(documentsCache,state.id,target.dataset.id,pos).ok)paint(target,pos);}const listRect=list.getBoundingClientRect();if(e.clientY<listRect.top+30)list.scrollTop-=12;else if(e.clientY>listRect.bottom-30)list.scrollTop+=12;}, {passive:false,capture:true});
    addEventListener('pointerup',async e=>{if(!state||e.pointerId!==state.pointerId)return;const snapshot=state,target=cardAt(e.clientX,e.clientY);if(snapshot.moved&&target&&target.dataset.id!==snapshot.id){const pos=position(target,e.clientY,e.shiftKey);clear();if(await moveDocumentInTree(snapshot.id,target.dataset.id,pos)){documentsCache=await NaviStorage.getAllDocuments();renderDocumentList(documentsCache);window.dispatchEvent(new CustomEvent('naviwriter:documents-reordered',{detail:{documentId:snapshot.id,targetId:target.dataset.id,position:pos}}));}}else clear();},true);
    addEventListener('pointercancel',clear,true);
  }
  document.readyState==='loading'?document.addEventListener('DOMContentLoaded',install,{once:true}):install();
})();

window.addEventListener('DOMContentLoaded',()=>{document.getElementById('addBoardAudioBtn')?.addEventListener('click',()=>recordBoardAudioMemo());});
