// js/tiptap-adapter.js
// Optional Tiptap adapter for NaviWriter.
// Uses the local bundled Tiptap vendor build. If it is unavailable, NaviWriter falls back to contenteditable.

let Editor = null;
let StarterKit = null;
let ImageExtension = null;
let TableKit = null;
let TextStyle = null;
let Color = null;
let Highlight = null;
let Underline = null;
let FontFamily = null;
let Extension = null;
let FontSize = null;
let NaviImage = null;
let tiptapEditor = null;
let suppressTiptapUpdate = false;
let Mark = null;
let InlineComment = null;
let NaviFormatting = null;

function clearTiptapMountElement(element) {
  if (!element) return;

  /*
    Important:
    The browser can restore old contenteditable DOM on reload.
    Tiptap then mounts its own ProseMirror tree inside the same element.
    Clearing the mount element prevents ghost/duplicate visual content.
  */
  element.innerHTML = '';

  /*
    Tiptap manages editing through its own ProseMirror element.
    Leaving contenteditable on the outer article can invite browser
    restoration weirdness.
  */
  element.removeAttribute('contenteditable');
}

const TIPTAP_MODULE_TIMEOUT_MS = 3500;

function importTiptapModuleWithTimeout(url, timeoutMs = TIPTAP_MODULE_TIMEOUT_MS) {
  let timeoutId = null;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(new Error(`Tiptap module timed out: ${url}`));
    }, timeoutMs);
  });
  return Promise.race([import(url), timeout])
    .finally(() => clearTimeout(timeoutId));
}

async function importOptionalTiptapModule(url, label) {
  try {
    return await importTiptapModuleWithTimeout(url);
  } catch (error) {
    console.warn(
      `Optional Tiptap module failed to load: ${label}`,
      error
    );

    return null;
  }
}

async function importRequiredTiptapModule(urls, label) {
  let lastError = null;
  for (const url of urls) {
    try { return await importTiptapModuleWithTimeout(url); }
    catch (error) {
      lastError = error;
      console.warn(`Tiptap ${label} source failed: ${url}`, error);
    }
  }
  throw new Error(`Could not load Tiptap ${label}: ${lastError?.message || 'all sources failed'}`);
}

function removeTiptapGhostNodes(element) {
  if (!element) return;

  const proseMirror = element.querySelector('.ProseMirror');

  if (!proseMirror) return;

  Array.from(element.childNodes).forEach(node => {
    if (node === proseMirror) return;

    if (
      node.nodeType === Node.ELEMENT_NODE &&
      node.contains(proseMirror)
    ) {
      return;
    }

    node.remove();
  });
}

function setEngineStatus(text, className) {
  const el = document.getElementById('engineStatus');

  if (!el) return;

  el.textContent = text;
  el.classList.remove('engine-tiptap', 'engine-fallback', 'engine-error');

  if (className) {
    el.classList.add(className);
  }
}

window.NaviTiptapReady = (async () => {
  try {
   const vendor = window.NaviTiptapVendor;

if (!vendor || typeof vendor.Editor !== 'function') {
  throw new Error(
    'Local Tiptap bundle is missing or did not initialize. Expected js/vendor/navitiptap.bundle.js.'
  );
}

const CoreModule = {
  Editor: vendor.Editor,
  Extension: vendor.Extension,
  Mark: vendor.Mark
};
const StarterKitModule = { default: vendor.StarterKit, StarterKit: vendor.StarterKit };
const ImageModule = { default: vendor.Image, Image: vendor.Image };
const TableModule = { TableKit: vendor.TableKit, default: vendor.TableKit };
const TextStyleModule = { TextStyle: vendor.TextStyle, default: vendor.TextStyle };
const ColorModule = { Color: vendor.Color, default: vendor.Color };
const HighlightModule = { Highlight: vendor.Highlight, default: vendor.Highlight };
const UnderlineModule = { Underline: vendor.Underline, default: vendor.Underline };
const FontFamilyModule = { FontFamily: vendor.FontFamily, default: vendor.FontFamily };

Editor =
  CoreModule.Editor;

Extension =
  CoreModule.Extension || null;
    
    Mark =
  CoreModule.Mark || null;

StarterKit =
  StarterKitModule.default ||
  StarterKitModule.StarterKit ||
  null;

ImageExtension =
  ImageModule?.default ||
  ImageModule?.Image ||
  null;

TableKit =
  TableModule?.TableKit ||
  TableModule?.default ||
  null;

TextStyle =
  TextStyleModule?.TextStyle ||
  TextStyleModule?.default ||
  null;

Color =
  ColorModule?.Color ||
  ColorModule?.default ||
  null;

Highlight =
  HighlightModule?.Highlight ||
  HighlightModule?.default ||
  null;

Underline =
  UnderlineModule?.Underline ||
  UnderlineModule?.default ||
  null;

FontFamily =
  FontFamilyModule?.FontFamily ||
  FontFamilyModule?.default ||
  null;


if (Extension && TextStyle) {
  FontSize =
    Extension.create({
      name: 'fontSize',

      addOptions() {
        return {
          types: ['textStyle']
        };
      },

      addGlobalAttributes() {
        return [
          {
            types: this.options.types,
            attributes: {
              fontSize: {
                default: null,

                parseHTML: element => {
                  return element.style.fontSize || null;
                },

                renderHTML: attributes => {
                  if (!attributes.fontSize) {
                    return {};
                  }

                  return {
                    style: `font-size: ${attributes.fontSize}`
                  };
                }
              }
            }
          }
        ];
      },

      addCommands() {
        return {
          setFontSize:
            fontSize =>
            ({ chain }) => {
              return chain()
                .setMark('textStyle', {
                  fontSize
                })
                .run();
            },

          unsetFontSize:
            () =>
            ({ chain }) => {
              return chain()
                .setMark('textStyle', {
                  fontSize: null
                })
                .removeEmptyTextStyle()
                .run();
            }
        };
      }
    });
}
    


NaviFormatting = null;
if (Extension) {
  NaviFormatting = Extension.create({
    name: 'naviFormatting',
    addGlobalAttributes() {
      return [
        {
          types: ['paragraph', 'heading'],
          attributes: {
            naviTextAlign: {
              default: null,
              parseHTML: element => element.style.textAlign || null,
              renderHTML: attributes => attributes.naviTextAlign
                ? { style: `text-align: ${attributes.naviTextAlign}` }
                : {}
            },
            naviIndent: {
              default: 0,
              parseHTML: element => Math.max(-4, Math.min(8, Number(element.getAttribute('data-navi-indent') || 0))),
              renderHTML: attributes => {
                const level = Math.max(-4, Math.min(8, Number(attributes.naviIndent) || 0));
                return level !== 0
                  ? {
                      'data-navi-indent': String(level),
                      style: `margin-left: ${level * 2}em`
                    }
                  : {};
              }
            }
          }
        },
        {
          types: ['tableCell', 'tableHeader'],
          attributes: {
            naviBackgroundColor: {
              default: null,
              parseHTML: element => element.style.backgroundColor || null,
              renderHTML: attributes => attributes.naviBackgroundColor
                ? { style: `background-color: ${attributes.naviBackgroundColor}` }
                : {}
            },
            naviTextColor: {
              default: null,
              parseHTML: element => element.style.color || null,
              renderHTML: attributes => attributes.naviTextColor
                ? { style: `color: ${attributes.naviTextColor}` }
                : {}
            }
          }
        }
      ];
    },
    addCommands() {
      return {
        setNaviTextAlign: alignment => ({ editor, commands }) => {
          const type = editor.isActive('heading') ? 'heading' : 'paragraph';
          return commands.updateAttributes(type, { naviTextAlign: alignment });
        },
        naviIndent: () => ({ editor, state, dispatch }) => {
          if (editor.isActive('table')) return false;
          if (editor.isActive('listItem') && editor.commands.sinkListItem) return editor.commands.sinkListItem('listItem');
          const { $from } = state.selection;
          let depth = $from.depth;
          while (depth > 0 && !['paragraph', 'heading'].includes($from.node(depth).type.name)) depth -= 1;
          if (depth <= 0) return false;
          const node = $from.node(depth);
          const level = Number(node.attrs.naviIndent || 0);
          if (level >= 8) return false;
          if (dispatch) dispatch(state.tr.setNodeMarkup($from.before(depth), undefined, { ...node.attrs, naviIndent: level + 1 }));
          return true;
        },
        naviOutdent: () => ({ editor, state, dispatch }) => {
          if (editor.isActive('table')) return false;
          if (editor.isActive('listItem') && editor.commands.liftListItem) return editor.commands.liftListItem('listItem');
          const { $from } = state.selection;
          let depth = $from.depth;
          while (depth > 0 && !['paragraph', 'heading'].includes($from.node(depth).type.name)) depth -= 1;
          if (depth <= 0) return false;
          const node = $from.node(depth);
          const level = Number(node.attrs.naviIndent || 0);
          if (level <= -4) return false;
          if (dispatch) dispatch(state.tr.setNodeMarkup($from.before(depth), undefined, { ...node.attrs, naviIndent: level - 1 }));
          return true;
        }
      };
    },
    addKeyboardShortcuts() {
      return {
        Tab: () => this.editor.isActive('table') ? false : this.editor.commands.naviIndent(),
        'Shift-Tab': () => this.editor.isActive('table') ? false : this.editor.commands.naviOutdent()
      };
    }
  });
}

    if (Mark) {
  InlineComment =
    Mark.create({
      name: 'inlineComment',

      inclusive: false,

      addAttributes() {
        return {
          id: {
            default: null,

            parseHTML: element => {
              return element.getAttribute(
                'data-inline-comment-id'
              );
            },

            renderHTML: attributes => {
              if (!attributes.id) {
                return {};
              }

              return {
                'data-inline-comment-id': attributes.id
              };
            }
          }
        };
      },

      parseHTML() {
        return [
          {
            tag: 'span[data-inline-comment-id]'
          }
        ];
      },

      renderHTML({ HTMLAttributes }) {
        return [
          'span',
          {
            ...HTMLAttributes,
            class: [
              HTMLAttributes.class,
              'inline-comment-mark'
            ]
              .filter(Boolean)
              .join(' ')
          },
          0
        ];
      },

      addCommands() {
        return {
          setInlineComment:
            id =>
            ({ chain }) => {
              return chain()
                .setMark('inlineComment', {
                  id
                })
                .run();
            },

          unsetInlineComment:
            () =>
            ({ chain }) => {
              return chain()
                .unsetMark('inlineComment')
                .run();
            }
        };
      }
    });
}


console.log('Tiptap loaded extensions:', {
  hasTextStyle: Boolean(TextStyle),
  hasColor: Boolean(Color),
  hasHighlight: Boolean(Highlight),
  hasUnderline: Boolean(Underline),
  hasFontFamily: Boolean(FontFamily),
  hasFontSize: Boolean(FontSize),
  hasTableKit: Boolean(TableKit),
  hasImage: Boolean(ImageExtension)
});




if (ImageExtension) {
  NaviImage = ImageExtension.extend({
    addAttributes() {
      const parentAttributes = this.parent ? this.parent() : {};
      return {
        ...parentAttributes,
        src: { default: null, parseHTML: element => { const image = element.tagName === 'FIGURE' ? element.querySelector('img') : element; return image?.getAttribute('src') || null; } },
        alt: { default: null, parseHTML: element => { const image = element.tagName === 'FIGURE' ? element.querySelector('img') : element; return image?.getAttribute('alt') || null; } },
        title: { default: null, parseHTML: element => { const image = element.tagName === 'FIGURE' ? element.querySelector('img') : element; return image?.getAttribute('title') || null; } },
        width: { default: null, parseHTML: element => { const image = element.tagName === 'FIGURE' ? element.querySelector('img') : element; return image?.getAttribute('data-width') || image?.getAttribute('width') || image?.style.width || null; } },
        caption: { default: '', parseHTML: element => element.tagName === 'FIGURE' ? (element.querySelector('figcaption')?.textContent?.trim() || element.querySelector('img')?.getAttribute('alt') || '') : (element.getAttribute('alt') || '') },
        assetId: { default: null, parseHTML: element => { const image=element.tagName==='FIGURE'?element.querySelector('img'):element; return image?.getAttribute('data-navi-asset-id') || window.NaviAssets?.idFrom?.(image?.getAttribute('src')) || null; } },
        groupId: { default: null, parseHTML: element => element.tagName==='FIGURE' ? element.getAttribute('data-image-group-id') : null },
        groupColumns: { default: null, parseHTML: element => element.tagName==='FIGURE' ? element.getAttribute('data-image-group-columns') : null },
        groupIndex: { default: null, parseHTML: element => element.tagName==='FIGURE' ? element.getAttribute('data-image-group-index') : null }
      };
    },
    parseHTML() { return [{ tag: 'figure.editor-image-figure' }, { tag: 'img[src]' }]; },
    renderHTML({ HTMLAttributes }) {
      const caption = String(HTMLAttributes.caption || HTMLAttributes.alt || '').trim();
      const width = HTMLAttributes.width || '75%';
      const imageAttributes = { src: HTMLAttributes.assetId ? `naviasset://${HTMLAttributes.assetId}` : HTMLAttributes.src, 'data-navi-asset-id': HTMLAttributes.assetId || null, alt: caption, title: HTMLAttributes.title || null, class: 'navi-editor-image', 'data-width': width, style: `width: ${width}; max-width: 100%; height: auto;` };
      Object.keys(imageAttributes).forEach(key => imageAttributes[key] == null && delete imageAttributes[key]);
      const children = [['img', imageAttributes]];
      if (caption) children.push(['figcaption', { class: 'image-caption' }, caption]);
      const groupId = HTMLAttributes.groupId || null;
      const groupColumns = Math.max(0, Math.min(4, Number(HTMLAttributes.groupColumns || 0)));
      const groupIndex = Number(HTMLAttributes.groupIndex || 0);
      const figureClass = ['editor-image-figure', groupId ? 'navi-image-group-member' : '', groupColumns ? `navi-image-group-columns-${groupColumns}` : ''].filter(Boolean).join(' ');
      return ['figure', { class: figureClass, 'data-image-figure': 'true', 'data-image-group-id': groupId, 'data-image-group-columns': groupColumns || null, 'data-image-group-index': groupId ? groupIndex : null }, ...children];
    }
  });
} else {
  NaviImage = null;
}

    window.NaviTiptap = {
      initTiptapEditor,
      getEditor,
      getHtml,
      getText,
      setHtml,
      focus,
      selectDomTextRange,
      run,
      insertImage,
      updateImageCaptionBySrc,
      updateImageWidthBySrc,
      updateImageGrouping,
      getFormattingState
    };

    console.log('NaviTiptap loaded successfully.');

    return true;
  } catch (error) {
    console.warn(
      'NaviTiptap failed to load. Falling back to contenteditable.',
      error
    );

    window.NaviTiptap = null;

    setEngineStatus('Engine: fallback editor', 'engine-fallback');

    return false;
  }
})();

function initTiptapEditor({
  element,
  content = '<p></p>',
  onChange,
  onSelectionChange
} = {}) {
  if (!element) {
    console.warn('NaviTiptap: missing editor element.');
    setEngineStatus('Engine: fallback editor', 'engine-fallback');
    return null;
  }

  if (!Editor || !StarterKit) {
    console.warn('NaviTiptap: editor modules are not loaded.');
    setEngineStatus('Engine: fallback editor', 'engine-fallback');
    return null;
  }

  if (tiptapEditor) {
  tiptapEditor.destroy();
  tiptapEditor = null;
}

clearTiptapMountElement(element);

const extensions = [
  StarterKit.configure({ heading: { levels: [1, 2, 3, 4, 5, 6] } })
];

if (TextStyle) {
  extensions.push(TextStyle);
}
  
  if (InlineComment) {
  extensions.push(InlineComment);
}

if (FontFamily && TextStyle) {
  extensions.push(FontFamily);
}

if (FontSize) {
  extensions.push(FontSize);
}

if (Underline) {
  extensions.push(Underline);
}

if (Color) {
  extensions.push(Color);
}

if (Highlight) {
  extensions.push(
    Highlight.configure({
      multicolor: true
    })
  );
}

if (NaviImage) {
  extensions.push(
    NaviImage.configure({
      inline: false,
      allowBase64: true,
      HTMLAttributes: {
        class: 'navi-editor-image'
      }
    })
  );
}

if (NaviFormatting) extensions.push(NaviFormatting);

if (TableKit) {
  extensions.push(
    TableKit.configure({
      table: {
        resizable: true
      }
    })
  );
}

// Tiptap v3 StarterKit may already contain extensions such as Underline.
// Registering a second copy can prevent editor construction in some builds.
const uniqueExtensions = [];
const extensionNames = new Set();
for (const extension of extensions) {
  const name = extension?.name || extension?.config?.name;
  if (name && extensionNames.has(name)) {
    console.warn(`NaviTiptap: skipped duplicate extension: ${name}`);
    continue;
  }
  if (name) extensionNames.add(name);
  uniqueExtensions.push(extension);
}
tiptapEditor = new Editor({
  element,
  extensions: uniqueExtensions,
  content: content || '<p></p>',

  onCreate() {
    queueMicrotask(() => {
      window.NaviAssets?.installEditorRecovery?.(element);
      window.NaviAssets?.hydrateStable?.(element);
      emitFormattingState();
      if (typeof onSelectionChange === 'function') onSelectionChange(getFormattingState());
    });
  },
  onSelectionUpdate() {
    emitFormattingState();
    if (typeof onSelectionChange === 'function') onSelectionChange(getFormattingState());
  },
  onTransaction() {
    emitFormattingState();
    requestAnimationFrame(() => window.NaviAssets?.hydrateStable?.(element));
  },
  onUpdate({ editor }) {
    emitFormattingState();
    if (suppressTiptapUpdate || window.NaviWriterIsLoadingDocument) return;
    if (typeof onChange === 'function') onChange(editor.getHTML(), editor.getText());
  }
});

setTimeout(() => {
  removeTiptapGhostNodes(element);
}, 0);

setEngineStatus('Engine: Tiptap', 'engine-tiptap');

return tiptapEditor;
  
}

function getEditor() {
  return tiptapEditor;
}

function getHtml() {
  return tiptapEditor
    ? tiptapEditor.getHTML()
    : '';
}

function getText() {
  return tiptapEditor
    ? tiptapEditor.getText()
    : '';
}

function setHtml(html = '<p></p>') {
  if (!tiptapEditor) return;

  const nextHtml =
    html && String(html).trim()
      ? html
      : '<p></p>';

  suppressTiptapUpdate = true;

  try {
    try {
      tiptapEditor.commands.setContent(
        nextHtml,
        {
          emitUpdate: false
        }
      );
    } catch (error) {
      tiptapEditor.commands.setContent(
        nextHtml,
        false
      );
    }

    const mountElement = tiptapEditor.options.element;

    setTimeout(() => {
      removeTiptapGhostNodes(mountElement);
      window.NaviAssets?.installEditorRecovery?.(mountElement);
      window.NaviAssets?.hydrateStable?.(mountElement);
    }, 0);
  } finally {
    setTimeout(() => {
      suppressTiptapUpdate = false;
    }, 120);
  }
}

function focus() {
  if (!tiptapEditor) return;

  tiptapEditor.commands.focus();
}

function selectDomTextRange(startNode, startOffset, endNode, endOffset) {
  if (!tiptapEditor || !startNode || !endNode) return false;
  try {
    const from = tiptapEditor.view.posAtDOM(startNode, startOffset);
    const to = tiptapEditor.view.posAtDOM(endNode, endOffset);
    if (!Number.isFinite(from) || !Number.isFinite(to)) return false;
    return tiptapEditor
      .chain()
      .focus()
      .setTextSelection({ from: Math.min(from, to), to: Math.max(from, to) })
      .scrollIntoView()
      .run();
  } catch (error) {
    console.warn('Tiptap exact find selection failed:', error);
    return false;
  }
}

function insertImage(src, alt = '', assetId = '') {
  if (!tiptapEditor || !src) return false;
  const caption = String(alt || '').trim();
  const content = [
    { type: 'image', attrs: { src, alt: caption, caption, width: '75%', assetId: assetId || window.NaviAssets?.idFrom?.(src) || null } },
    { type: 'paragraph' }
  ];
  return tiptapEditor.chain().focus().insertContent(content).run();
}

function updateImageCaptionBySrc(src, caption = '') {
  if (!tiptapEditor || !src) return false;
  const { state } = tiptapEditor;
  let foundPos = null;
  state.doc.descendants((node, pos) => {
    if (node.type.name === 'image' && node.attrs.src === src) {
      foundPos = pos;
      return false;
    }
    return true;
  });
  if (foundPos === null) return false;
  const cleanCaption = String(caption || '').trim();
  return tiptapEditor.chain().focus().setNodeSelection(foundPos).updateAttributes('image', {
    caption: cleanCaption,
    alt: cleanCaption
  }).run();
}

function updateImageWidthBySrc(src, width = null, assetId = '') {
  if (!tiptapEditor || (!src && !assetId)) return false;
  const stableId=assetId || window.NaviAssets?.idFrom?.(src) || '';
  let foundPos=null;
  tiptapEditor.state.doc.descendants((node,pos)=>{if(node.type.name==='image' && ((stableId && node.attrs.assetId===stableId) || (!stableId && node.attrs.src===src))){foundPos=pos;return false;}return true;});
  if(foundPos===null)return false;
  return tiptapEditor.chain().focus().setNodeSelection(foundPos).updateAttributes('image',{width,assetId:stableId||undefined}).run();
}


function updateImageGrouping(items = [], groupId = null, columns = 0) {
  if (!tiptapEditor || !Array.isArray(items) || !items.length) return false;
  const byPosition = new Map(items.filter(item => Number.isFinite(item.pos)).map((item, index) => [Number(item.pos), { ...item, index }]));
  const wanted = new Map(items.map((item, index) => [String(item.assetId || item.src || ''), { ...item, index }]));
  let transaction = tiptapEditor.state.tr;
  let changed = false;
  tiptapEditor.state.doc.descendants((node, pos) => {
    if (node.type.name !== 'image') return true;
    const key = String(node.attrs.assetId || node.attrs.src || '');
    const item = byPosition.get(pos) || (!byPosition.size ? wanted.get(key) : null);
    if (!item) return true;
    transaction = transaction.setNodeMarkup(pos, undefined, {
      ...node.attrs,
      groupId: groupId || null,
      groupColumns: groupId ? String(columns) : null,
      groupIndex: groupId ? String(item.index) : null,
      width: groupId ? '100%' : node.attrs.width
    });
    changed = true;
    return true;
  });
  if (!changed) return false;
  tiptapEditor.view.dispatch(transaction);
  requestAnimationFrame(() => window.NaviAssets?.hydrateStable?.(tiptapEditor.options.element));
  return true;
}

function getFormattingState() {
  if (!tiptapEditor) return null;
  let block = 'p';
  for (let level = 1; level <= 6; level += 1) {
    if (tiptapEditor.isActive('heading', { level })) { block = `h${level}`; break; }
  }
  if (tiptapEditor.isActive('blockquote')) block = 'blockquote';
  const textStyle = tiptapEditor.getAttributes('textStyle') || {};
  const blockType = block.startsWith('h') ? 'heading' : 'paragraph';
  const blockAttrs = tiptapEditor.getAttributes(blockType) || {};
  const rawSize = String(textStyle.fontSize || '').trim();
  const parsedSize = Number.parseFloat(rawSize);
  return {
    block,
    bold: tiptapEditor.isActive('bold'),
    italic: tiptapEditor.isActive('italic'),
    underline: tiptapEditor.isActive('underline'),
    strikeThrough: tiptapEditor.isActive('strike'),
    bulletList: tiptapEditor.isActive('bulletList'),
    orderedList: tiptapEditor.isActive('orderedList'),
    alignment: blockAttrs.naviTextAlign || 'left',
    fontFamily: textStyle.fontFamily || '',
    fontSize: Number.isFinite(parsedSize) ? Math.max(1, Math.min(400, Math.round(parsedSize))) : 16,
    textColor: textStyle.color || '',
    highlightColor: tiptapEditor.getAttributes('highlight')?.color || ''
  };
}

function emitFormattingState() {
  const detail = getFormattingState();
  if (!detail) return;
  window.dispatchEvent(new CustomEvent('naviwriter:formatting-state', { detail }));
}


function runInlineCommandOnSelection(commandName, ...args) {
  if (!tiptapEditor) return false;
  const chain = tiptapEditor.chain().focus();
  if (typeof chain[commandName] !== 'function') return false;
  // With a selection, Tiptap marks only that selection. With a caret, it
  // toggles a stored mark for text typed next. Never expand to the whole line.
  return chain[commandName](...args).run();
}

function run(command, value = null) {
  if (!tiptapEditor) return false;

  const chain =
    tiptapEditor
      .chain()
      .focus();

  if (command === 'bold') {
    return runInlineCommandOnSelection('toggleBold');
  }

  if (command === 'italic') {
    return runInlineCommandOnSelection('toggleItalic');
  }

  if (command === 'underline') {
    if (!tiptapEditor.commands.toggleUnderline) {
      console.warn('Underline unavailable: toggleUnderline command is missing.');
      return false;
    }

    return runInlineCommandOnSelection('toggleUnderline');
  }

  if (command === 'strikeThrough') {
    return runInlineCommandOnSelection('toggleStrike');
  }

  if (command === 'bulletList') {
    return chain.toggleBulletList().run();
  }

  if (command === 'orderedList') {
    return chain.toggleOrderedList().run();
  }

  if (command === 'blockquote') {
    return chain.toggleBlockquote().run();
  }

  if (command === 'horizontalRule') {
    return chain.setHorizontalRule().run();
  }

  if (command === 'undo') {
    return tiptapEditor.commands.undo();
  }
  
  if (command === 'inlineComment') {
  if (!value) return false;

  if (!tiptapEditor.commands.setInlineComment) {
    console.warn(
      'Inline comments unavailable: setInlineComment command is missing.'
    );
    return false;
  }

  return chain
    .setInlineComment(value)
    .run();
}

if (command === 'removeInlineComment') {
  if (!tiptapEditor.commands.unsetInlineComment) {
    return false;
  }

  return chain
    .unsetInlineComment()
    .run();
}

  if (command === 'redo') {
    return tiptapEditor.commands.redo();
  }

  if (command === 'paragraph') {
    return chain.setParagraph().run();
  }

  if (command === 'heading') {
    return chain
      .toggleHeading({
        level: Number(value) || 1
      })
      .run();
  }

  if (command === 'fontFamily') {
    if (!value) return false;

    if (!tiptapEditor.commands.setFontFamily) {
      console.warn(
        'Font family unavailable: setFontFamily command is missing.'
      );
      return false;
    }

    const { from, empty, $from } = tiptapEditor.state.selection;
    if (empty && $from.parent.isTextblock) {
      const start = $from.start();
      const end = $from.end();
      return chain.setTextSelection({ from: start, to: end }).setFontFamily(value).setTextSelection(from).run();
    }
    return chain.setFontFamily(value).run();
  }

  if (command === 'fontSize') {
    if (!value) return false;

    if (!tiptapEditor.commands.setFontSize) {
      console.warn(
        'Font size unavailable: setFontSize command is missing.'
      );
      return false;
    }

    const legacySizeMap = {
      '1': '10px',
      '2': '12px',
      '3': '14px',
      '4': '18px',
      '5': '24px',
      '6': '32px',
      '7': '48px'
    };

    const raw =
      String(value || '').trim();

    const legacy = legacySizeMap[raw];
    const numeric = Number.parseFloat(legacy || raw);
    if (!Number.isFinite(numeric)) return false;
    const size = `${Math.max(1, Math.min(400, Math.round(numeric)))}px`;
    const { from, empty, $from } = tiptapEditor.state.selection;
    if (empty && $from.parent.isTextblock) {
      const start = $from.start();
      const end = $from.end();
      return chain.setTextSelection({ from: start, to: end }).setFontSize(size).setTextSelection(from).run();
    }
    return chain.setFontSize(size).run();
  }

  if (command === 'textAlign') {
    if (!['left','center','right'].includes(String(value))) return false;
    return tiptapEditor.commands.setNaviTextAlign(String(value));
  }
  if (command === 'indent') return tiptapEditor.commands.naviIndent();
  if (command === 'outdent') return tiptapEditor.commands.naviOutdent();
  if (command === 'cellBackgroundColor') {
    if (!tiptapEditor.commands.setCellAttribute) return false;
    return chain.setCellAttribute('naviBackgroundColor', value).run();
  }
  if (command === 'cellTextColor') {
    if (!tiptapEditor.commands.setCellAttribute) return false;
    return chain.setCellAttribute('naviTextColor', value).run();
  }

  /*
    Tables.
    These commands come from Tiptap's table extension/TableKit.
  */
  if (command === 'insertTable') {
    const options =
      value && typeof value === 'object'
        ? value
        : {};

    if (!tiptapEditor.commands.insertTable) {
      console.warn('Table unavailable: insertTable command is missing.');
      return false;
    }

    return chain
      .insertTable({
        rows: Number(options.rows) || 3,
        cols: Number(options.cols) || 3,
        withHeaderRow: options.withHeaderRow !== false
      })
      .run();
  }

  if (command === 'addRowBefore') {
    if (!tiptapEditor.commands.addRowBefore) return false;
    return chain.addRowBefore().run();
  }

  if (command === 'addRowAfter') {
    if (!tiptapEditor.commands.addRowAfter) return false;
    return chain.addRowAfter().run();
  }

  if (command === 'deleteRow') {
    if (!tiptapEditor.commands.deleteRow) return false;
    return chain.deleteRow().run();
  }

  if (command === 'addColumnBefore') {
    if (!tiptapEditor.commands.addColumnBefore) return false;
    return chain.addColumnBefore().run();
  }

  if (command === 'addColumnAfter') {
    if (!tiptapEditor.commands.addColumnAfter) return false;
    return chain.addColumnAfter().run();
  }

  if (command === 'deleteColumn') {
    if (!tiptapEditor.commands.deleteColumn) return false;
    return chain.deleteColumn().run();
  }

  if (command === 'deleteTable') {
    if (!tiptapEditor.commands.deleteTable) return false;
    return chain.deleteTable().run();
  }

  if (command === 'mergeCells') {
    if (!tiptapEditor.commands.mergeCells) return false;
    return chain.mergeCells().run();
  }

  if (command === 'splitCell') {
    if (!tiptapEditor.commands.splitCell) return false;
    return chain.splitCell().run();
  }

  if (command === 'textColor') {
    if (!value) return false;

    if (!tiptapEditor.schema.marks.textStyle) {
      console.warn('Text color unavailable: textStyle mark is not registered.');
      return false;
    }

    if (!tiptapEditor.commands.setColor) {
      console.warn('Text color unavailable: setColor command is missing.');
      return false;
    }

    return runInlineCommandOnSelection('setColor', value);
  }

  if (command === 'highlightColor') {
    if (!value) return false;

    if (!tiptapEditor.commands.setHighlight) {
      console.warn('Highlight unavailable: setHighlight command is missing.');
      return false;
    }

    return runInlineCommandOnSelection('setHighlight', { color: value });
  }

  if (command === 'removeFormat') {
    const type = tiptapEditor.isActive('heading') ? 'heading' : 'paragraph';
    return chain.unsetAllMarks().updateAttributes(type,{naviTextAlign:null,naviIndent:0}).clearNodes().run();
  }

  return false;
}